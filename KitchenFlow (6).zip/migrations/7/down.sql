
DROP INDEX idx_recipe_tags_tag;
DROP INDEX idx_recipe_tags_recipe_id;
DROP TABLE recipe_tags;
