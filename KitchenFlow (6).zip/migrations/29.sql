
CREATE TABLE IF NOT EXISTS order_snapshots (
  id INTEGER PRIMARY KEY,
  plan_id INTEGER NOT NULL UNIQUE,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(plan_id) REFERENCES planner_plans(id) ON DELETE CASCADE
);
