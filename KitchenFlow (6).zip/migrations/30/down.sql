
DROP TABLE IF EXISTS batch_consumption;
DROP TABLE IF EXISTS lots;
ALTER TABLE items DROP COLUMN allergen_codes;
ALTER TABLE items DROP COLUMN kcal_per_100;
ALTER TABLE items DROP COLUMN protein_g_per_100;
ALTER TABLE items DROP COLUMN carbs_g_per_100;
ALTER TABLE items DROP COLUMN fat_g_per_100;
DROP TABLE IF EXISTS allergens;
