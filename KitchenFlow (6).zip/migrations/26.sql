
CREATE TABLE planner_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  week_start_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  name TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(week_start_date, status)
);

CREATE TABLE planner_slots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plan_id INTEGER NOT NULL,
  day_index INTEGER NOT NULL CHECK(day_index >= 0 AND day_index <= 6),
  slot_label TEXT NOT NULL,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(plan_id, day_index, slot_label)
);

CREATE TABLE planner_slot_recipes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slot_id INTEGER NOT NULL,
  recipe_id INTEGER NOT NULL,
  portions INTEGER NOT NULL DEFAULT 1,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_planner_plans_week_status ON planner_plans(week_start_date, status);
CREATE INDEX idx_planner_slots_plan ON planner_slots(plan_id);
CREATE INDEX idx_planner_slot_recipes_slot ON planner_slot_recipes(slot_id);
