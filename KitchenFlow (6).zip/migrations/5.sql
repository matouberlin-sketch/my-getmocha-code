
-- Add equipment and cooking instruction columns to recipe_steps
ALTER TABLE recipe_steps ADD COLUMN equipment TEXT;
ALTER TABLE recipe_steps ADD COLUMN temperature TEXT;
ALTER TABLE recipe_steps ADD COLUMN cooking_time TEXT;
ALTER TABLE recipe_steps ADD COLUMN cooking_method TEXT;
