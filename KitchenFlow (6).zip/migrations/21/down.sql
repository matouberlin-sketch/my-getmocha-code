
DROP INDEX idx_recipe_bom_sort;
DROP INDEX idx_recipe_bom_component;
DROP INDEX idx_recipe_bom_recipe;
DROP TABLE recipe_bom;
