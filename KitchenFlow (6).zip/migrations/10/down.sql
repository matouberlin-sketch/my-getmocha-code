
-- Remove indexes
DROP INDEX idx_ingredient_tags_tag;
DROP INDEX idx_ingredient_tags_ingredient_id;

-- Remove ingredient_tags table
DROP TABLE ingredient_tags;

-- Remove waste_percentage column from ingredients table
ALTER TABLE ingredients DROP COLUMN waste_percentage;
