
DROP TABLE recipe_cooking_steps;
