
-- Create table for meal components to support main, sides, and desserts
CREATE TABLE meal_components (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  planned_meal_id INTEGER NOT NULL,
  component_type TEXT NOT NULL, -- 'main', 'side', 'dessert'
  component_order INTEGER DEFAULT 1, -- Order within component type (side1, side2, etc)
  recipe_id INTEGER NOT NULL,
  portion_count INTEGER NOT NULL,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create index for efficient queries
CREATE INDEX idx_meal_components_planned_meal ON meal_components(planned_meal_id);
CREATE INDEX idx_meal_components_type ON meal_components(component_type);
