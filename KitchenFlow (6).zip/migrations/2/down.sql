
DROP INDEX idx_portion_profiles_name;
DROP INDEX idx_shopping_items_needed_by_date;
DROP INDEX idx_planned_meals_date;
DROP TABLE portion_profiles;
DROP TABLE shopping_items;
DROP TABLE planned_meals;
