
DROP INDEX idx_recipe_shortlist_recipe_id;
DROP TABLE recipe_shortlist;

ALTER TABLE planned_meals DROP COLUMN total_portions;
ALTER TABLE planned_meals DROP COLUMN vegetarian_portions;
ALTER TABLE planned_meals DROP COLUMN service_time;
ALTER TABLE planned_meals DROP COLUMN same_menu_both_services;
ALTER TABLE planned_meals DROP COLUMN lunch_portions;
ALTER TABLE planned_meals DROP COLUMN lunch_vegetarian;
ALTER TABLE planned_meals DROP COLUMN dinner_portions;
ALTER TABLE planned_meals DROP COLUMN dinner_vegetarian;
