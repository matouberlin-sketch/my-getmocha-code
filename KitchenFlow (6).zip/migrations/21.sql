
-- Recipe BOM - store gross (pre-trim) and yield to compute net
CREATE TABLE recipe_bom (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id INTEGER NOT NULL,
  component_type TEXT NOT NULL CHECK(component_type IN ('item','subrecipe')),
  component_id INTEGER NOT NULL,
  gross_qty REAL NOT NULL,         -- input before losses
  uom TEXT NOT NULL,               -- e.g. 'g','ml','ea'
  trim_loss_pct REAL DEFAULT 0,    -- 0..100, for peel/trim
  cook_yield_pct REAL DEFAULT 100, -- 0..100, shrink or gain
  stage TEXT DEFAULT NULL,         -- optional process stage
  note TEXT DEFAULT NULL,
  sort_order INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
  FOREIGN KEY(uom) REFERENCES uom(code)
);

CREATE INDEX idx_recipe_bom_recipe ON recipe_bom(recipe_id);
CREATE INDEX idx_recipe_bom_component ON recipe_bom(component_type, component_id);
CREATE INDEX idx_recipe_bom_sort ON recipe_bom(recipe_id, sort_order);
