
ALTER TABLE recipe_ingredients DROP COLUMN ingredient_order;
