
DROP INDEX idx_recipes_status;
DROP INDEX idx_recipes_folder_id;
ALTER TABLE recipes DROP COLUMN status;
ALTER TABLE recipes DROP COLUMN folder_id;
DROP TABLE document_imports;
DROP TABLE recipe_folders;
