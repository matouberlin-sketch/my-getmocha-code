
DELETE FROM recipe_tags WHERE recipe_id IN (1, 2, 3);
DELETE FROM recipe_cooking_steps WHERE recipe_id IN (1, 2, 3);
DELETE FROM recipe_steps WHERE recipe_id IN (1, 2, 3);
DELETE FROM recipe_ingredients WHERE recipe_id IN (1, 2, 3);
DELETE FROM recipes WHERE id IN (1, 2, 3);
