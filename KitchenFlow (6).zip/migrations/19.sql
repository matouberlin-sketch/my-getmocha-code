
-- Units of measure - canonicalize
CREATE TABLE uom (
  code TEXT PRIMARY KEY,           -- 'g','kg','ml','L','ea'
  kind TEXT NOT NULL               -- 'mass','volume','each'
);

-- Insert standard units of measure
INSERT INTO uom (code, kind) VALUES 
  ('g', 'mass'),
  ('kg', 'mass'),
  ('ml', 'volume'),
  ('l', 'volume'),
  ('ea', 'each'),
  ('cup', 'volume'),
  ('tbsp', 'volume'),
  ('tsp', 'volume'),
  ('oz', 'mass'),
  ('lb', 'mass'),
  ('fl_oz', 'volume'),
  ('pint', 'volume'),
  ('quart', 'volume'),
  ('gallon', 'volume'),
  ('piece', 'each'),
  ('clove', 'each'),
  ('large', 'each'),
  ('medium', 'each'),
  ('small', 'each'),
  ('whole', 'each'),
  ('can', 'each'),
  ('bunch', 'each'),
  ('head', 'each');
