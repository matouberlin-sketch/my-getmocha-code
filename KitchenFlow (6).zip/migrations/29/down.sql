
DROP TABLE order_snapshots;
