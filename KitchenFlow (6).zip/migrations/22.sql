
-- Optional co-products (rendered fats, stocks from bones)
CREATE TABLE recipe_coproducts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id INTEGER NOT NULL,
  item_id INTEGER NOT NULL,
  output_qty REAL NOT NULL,
  uom TEXT NOT NULL,
  note TEXT DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
  FOREIGN KEY(item_id) REFERENCES items(id),
  FOREIGN KEY(uom) REFERENCES uom(code)
);

CREATE INDEX idx_recipe_coproducts_recipe ON recipe_coproducts(recipe_id);
CREATE INDEX idx_recipe_coproducts_item ON recipe_coproducts(item_id);
