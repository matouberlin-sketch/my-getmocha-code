
DROP INDEX IF EXISTS idx_items_type;
DROP INDEX IF EXISTS idx_items_base_uom;
