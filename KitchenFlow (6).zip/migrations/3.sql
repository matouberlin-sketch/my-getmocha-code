
ALTER TABLE recipe_ingredients ADD COLUMN ingredient_order INTEGER DEFAULT 1;
