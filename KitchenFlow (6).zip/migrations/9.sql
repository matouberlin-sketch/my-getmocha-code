
ALTER TABLE recipe_cooking_steps ADD COLUMN process TEXT;
ALTER TABLE recipe_cooking_steps ADD COLUMN timing TEXT DEFAULT 'sequential';
