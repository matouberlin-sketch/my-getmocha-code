
DROP INDEX idx_item_suppliers_price;
DROP INDEX idx_item_suppliers_preferred;
DROP INDEX idx_item_suppliers_item;
DROP TABLE item_suppliers;
