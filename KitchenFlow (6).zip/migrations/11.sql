
-- Recipe folders for organization
CREATE TABLE recipe_folders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  parent_folder_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Document imports tracking
CREATE TABLE document_imports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  filename TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size INTEGER,
  status TEXT DEFAULT 'processing',
  extracted_recipes_count INTEGER DEFAULT 0,
  processed_data TEXT,
  error_message TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Add folder_id to recipes table
ALTER TABLE recipes ADD COLUMN folder_id INTEGER;

-- Add status for shortlist management  
ALTER TABLE recipes ADD COLUMN status TEXT DEFAULT 'active';

-- Index for faster folder queries
CREATE INDEX idx_recipes_folder_id ON recipes(folder_id);
CREATE INDEX idx_recipes_status ON recipes(status);
