
ALTER TABLE recipe_cooking_steps DROP COLUMN timing;
ALTER TABLE recipe_cooking_steps DROP COLUMN process;
