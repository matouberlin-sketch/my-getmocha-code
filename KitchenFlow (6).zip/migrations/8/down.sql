
DROP TABLE locations;
