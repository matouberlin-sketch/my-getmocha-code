
-- Remove timing columns from recipe_components
ALTER TABLE recipe_components DROP COLUMN cook_time_min;
ALTER TABLE recipe_components DROP COLUMN prep_time_min;
