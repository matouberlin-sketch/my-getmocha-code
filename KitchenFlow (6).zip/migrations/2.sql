
CREATE TABLE planned_meals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date DATE NOT NULL,
  meal_type TEXT NOT NULL, -- 'lunch', 'dinner'
  recipe_id INTEGER NOT NULL,
  portion_count INTEGER NOT NULL,
  portion_profile TEXT DEFAULT 'standard', -- 'standard', 'staff', 'xl'
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE shopping_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ingredient_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  unit TEXT NOT NULL,
  needed_by_date DATE NOT NULL,
  supplier TEXT,
  estimated_cost REAL,
  is_ordered BOOLEAN DEFAULT FALSE,
  ordered_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE portion_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  lunch_portions REAL NOT NULL DEFAULT 1.0,
  dinner_portions REAL NOT NULL DEFAULT 1.0,
  dessert_factor REAL NOT NULL DEFAULT 1.0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_planned_meals_date ON planned_meals(date);
CREATE INDEX idx_shopping_items_needed_by_date ON shopping_items(needed_by_date);
CREATE INDEX idx_portion_profiles_name ON portion_profiles(name);
