
-- Remove invoices table
DROP TABLE invoices;

-- Remove ingredient_supplier_prices table
DROP TABLE ingredient_supplier_prices;

-- Remove suppliers table
DROP TABLE suppliers;

-- Remove weight_grams column from recipe_ingredients
ALTER TABLE recipe_ingredients DROP COLUMN weight_grams;
