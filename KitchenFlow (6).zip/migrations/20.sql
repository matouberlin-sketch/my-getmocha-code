
-- Optional per-item conversion helpers
CREATE TABLE item_uom (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL,
  from_uom TEXT NOT NULL,
  to_uom TEXT NOT NULL,
  factor REAL NOT NULL,            -- qty_in_to = qty_in_from * factor
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(item_id, from_uom, to_uom),
  FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE CASCADE,
  FOREIGN KEY(from_uom) REFERENCES uom(code),
  FOREIGN KEY(to_uom) REFERENCES uom(code)
);

CREATE INDEX idx_item_uom_item ON item_uom(item_id);
CREATE INDEX idx_item_uom_from ON item_uom(from_uom);
CREATE INDEX idx_item_uom_to ON item_uom(to_uom);
