
-- Drop indexes
DROP INDEX IF EXISTS idx_enhanced_recipe_ingredients_recipe;
DROP INDEX IF EXISTS idx_recipe_components_component;
DROP INDEX IF EXISTS idx_recipe_components_parent;
DROP INDEX IF EXISTS idx_supplier_items_enhanced_item;
DROP INDEX IF EXISTS idx_items_category;
DROP INDEX IF EXISTS idx_items_type;

-- Drop tables in reverse order
DROP TABLE IF EXISTS enhanced_recipe_ingredients;
DROP TABLE IF EXISTS recipe_components;
DROP TABLE IF EXISTS enhanced_recipes;
DROP TABLE IF EXISTS item_uom_conversions;
DROP TABLE IF EXISTS supplier_items_enhanced;
DROP TABLE IF EXISTS items;
