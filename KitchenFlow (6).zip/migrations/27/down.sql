
DROP INDEX idx_planner_slots_position;
ALTER TABLE planner_slots DROP COLUMN position;
