
-- Insert sample items first
INSERT INTO items (item_id, name, item_type, base_uom, category, edible_yield_pct, allergen_tags) VALUES
('onion-yellow', 'Yellow Onions', 'raw', 'kg', 'Vegetables', 90, ''),
('garlic', 'Garlic', 'raw', 'piece', 'Vegetables', 85, ''),
('olive-oil', 'Extra Virgin Olive Oil', 'raw', 'l', 'Oils', 100, ''),
('salt', 'Sea Salt', 'raw', 'kg', 'Seasonings', 100, ''),
('pepper', 'Black Pepper', 'raw', 'kg', 'Seasonings', 100, ''),
('tomatoes-canned', 'Canned Tomatoes', 'raw', 'can', 'Vegetables', 95, ''),
('beef-ground', 'Ground Beef', 'raw', 'kg', 'Meat', 85, ''),
('pasta-spaghetti', 'Spaghetti Pasta', 'raw', 'kg', 'Grains', 100, ''),
('onion-diced', 'Diced Onions', 'prepped', 'kg', 'Vegetables', 100, ''),
('garlic-minced', 'Minced Garlic', 'prepped', 'kg', 'Vegetables', 100, '');

-- Insert enhanced recipes
INSERT INTO enhanced_recipes (recipe_id, name, type, default_yield_qty, default_yield_uom, output_item_id, active_minutes, passive_minutes, lead_time_hours, station, notes) VALUES
('prep-onions-dice', 'Diced Onions', 'prep', 1.0, 'kg', 'onion-diced', 15, 0, 0, 'Prep Station', 'Standard medium dice, 6mm cubes'),
('prep-garlic-mince', 'Minced Garlic', 'prep', 0.5, 'kg', 'garlic-minced', 10, 0, 0, 'Prep Station', 'Fine mince for cooking'),
('comp-bolognese-sauce', 'Bolognese Sauce', 'component', 2.0, 'l', null, 45, 180, 0, 'Sauce Station', 'Classic Italian meat sauce'),
('final-spaghetti-bolognese', 'Spaghetti Bolognese', 'final', 10, 'portions', null, 20, 0, 0, 'Hot Station', 'Complete pasta dish ready for service');

-- Insert recipe ingredients
INSERT INTO enhanced_recipe_ingredients (recipe_id, line_no, item_id, qty, uom, scrap_pct, notes) VALUES
-- Diced Onions recipe
('prep-onions-dice', 1, 'onion-yellow', 1.2, 'kg', 10, 'Account for peel and trim loss'),

-- Minced Garlic recipe  
('prep-garlic-mince', 1, 'garlic', 25, 'piece', 15, 'Remove papery skin and ends'),

-- Bolognese Sauce recipe
('comp-bolognese-sauce', 1, 'beef-ground', 0.8, 'kg', 5, 'Brown thoroughly'),
('comp-bolognese-sauce', 2, 'onion-yellow', 0.3, 'kg', 10, 'Medium dice'),
('comp-bolognese-sauce', 3, 'garlic', 6, 'piece', 15, 'Mince fine'),
('comp-bolognese-sauce', 4, 'tomatoes-canned', 2, 'can', 0, 'San Marzano preferred'),
('comp-bolognese-sauce', 5, 'olive-oil', 0.05, 'l', 0, 'For cooking'),
('comp-bolognese-sauce', 6, 'salt', 0.02, 'kg', 0, 'Season to taste'),
('comp-bolognese-sauce', 7, 'pepper', 0.005, 'kg', 0, 'Fresh ground'),

-- Spaghetti Bolognese final dish
('final-spaghetti-bolognese', 1, 'pasta-spaghetti', 1.0, 'kg', 0, 'Cook al dente');

-- Insert recipe components  
INSERT INTO recipe_components (parent_recipe_id, component_recipe_id, qty, uom, notes) VALUES
('comp-bolognese-sauce', 'prep-onions-dice', 0.3, 'kg', 'Use for soffritto base'),
('comp-bolognese-sauce', 'prep-garlic-mince', 0.03, 'kg', 'Add after onions'),
('final-spaghetti-bolognese', 'comp-bolognese-sauce', 2.0, 'l', 'Heat before serving');
