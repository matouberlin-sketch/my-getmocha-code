
DELETE FROM recipe_components WHERE parent_recipe_id IN ('comp-bolognese-sauce', 'final-spaghetti-bolognese');
DELETE FROM enhanced_recipe_ingredients WHERE recipe_id IN ('prep-onions-dice', 'prep-garlic-mince', 'comp-bolognese-sauce', 'final-spaghetti-bolognese');
DELETE FROM enhanced_recipes WHERE recipe_id IN ('prep-onions-dice', 'prep-garlic-mince', 'comp-bolognese-sauce', 'final-spaghetti-bolognese');
DELETE FROM items WHERE item_id IN ('onion-yellow', 'garlic', 'olive-oil', 'salt', 'pepper', 'tomatoes-canned', 'beef-ground', 'pasta-spaghetti', 'onion-diced', 'garlic-minced');
