
-- Check if each_to_base column exists and only add it if it doesn't
-- This handles the case where it might have been added in a previous migration
CREATE TABLE IF NOT EXISTS temp_items_check AS SELECT * FROM items LIMIT 0;

-- Add each_to_base column only if it doesn't exist
-- We'll use a more robust approach by trying the ALTER and catching the error
PRAGMA table_info(items);

-- Set base_uom for any items that don't have it
UPDATE items SET base_uom = 'ea' WHERE base_uom IS NULL OR base_uom = '';

-- Create performance indexes
CREATE INDEX IF NOT EXISTS idx_items_base_uom ON items(base_uom);
CREATE INDEX IF NOT EXISTS idx_items_type ON items(item_type);

-- Clean up temp table
DROP TABLE IF EXISTS temp_items_check;
