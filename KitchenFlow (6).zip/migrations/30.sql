
CREATE TABLE IF NOT EXISTS allergens (
  code TEXT PRIMARY KEY,
  label TEXT NOT NULL
);

ALTER TABLE items ADD COLUMN allergen_codes TEXT;
ALTER TABLE items ADD COLUMN kcal_per_100 REAL;
ALTER TABLE items ADD COLUMN protein_g_per_100 REAL;
ALTER TABLE items ADD COLUMN carbs_g_per_100 REAL;
ALTER TABLE items ADD COLUMN fat_g_per_100 REAL;

CREATE TABLE IF NOT EXISTS lots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL,
  lot_code TEXT NOT NULL,
  received_at TEXT NOT NULL,
  qty REAL NOT NULL,
  uom TEXT NOT NULL,
  supplier_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(item_id, lot_code)
);

CREATE TABLE IF NOT EXISTS batch_consumption (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plan_id INTEGER NOT NULL,
  day_index INTEGER NOT NULL,
  recipe_id INTEGER NOT NULL,
  item_id INTEGER NOT NULL,
  lot_id INTEGER,
  qty_used REAL NOT NULL,
  uom TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO allergens (code, label) VALUES 
('GLUTEN', 'Gluten'),
('EGG', 'Eggs'),
('MILK', 'Milk/Dairy'),
('NUTS', 'Tree Nuts'),
('PEANUTS', 'Peanuts'),
('SOY', 'Soy'),
('FISH', 'Fish'),
('SHELLFISH', 'Shellfish'),
('SESAME', 'Sesame'),
('SULFITES', 'Sulfites'),
('CELERY', 'Celery'),
('MUSTARD', 'Mustard'),
('LUPIN', 'Lupin');
