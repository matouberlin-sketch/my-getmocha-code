
-- Add weight_grams column to recipe_ingredients table
ALTER TABLE recipe_ingredients ADD COLUMN weight_grams REAL;

-- Create suppliers table
CREATE TABLE suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    contact_person TEXT,
    phone TEXT,
    email TEXT,
    address TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create ingredient_supplier_prices table
CREATE TABLE ingredient_supplier_prices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ingredient_id INTEGER NOT NULL,
    supplier_id INTEGER NOT NULL,
    pack_size REAL NOT NULL,
    pack_unit TEXT NOT NULL,
    cost_per_pack REAL NOT NULL,
    last_updated_price DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (ingredient_id, supplier_id, pack_size, pack_unit)
);

-- Create invoices table for tracking uploaded invoices
CREATE TABLE invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier_id INTEGER,
    invoice_date DATE,
    total_amount REAL,
    currency TEXT DEFAULT 'USD',
    file_path TEXT,
    processed_data TEXT, -- JSON of extracted data
    status TEXT DEFAULT 'pending', -- pending, reviewed, processed
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
