
-- Add waste_percentage column to ingredients table
ALTER TABLE ingredients ADD COLUMN waste_percentage REAL DEFAULT 0;

-- Create ingredient_tags table for flexible tagging
CREATE TABLE ingredient_tags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ingredient_id INTEGER NOT NULL,
  tag TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (ingredient_id, tag)
);

-- Create index for better performance
CREATE INDEX idx_ingredient_tags_ingredient_id ON ingredient_tags(ingredient_id);
CREATE INDEX idx_ingredient_tags_tag ON ingredient_tags(tag);
