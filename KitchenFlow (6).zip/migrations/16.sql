
INSERT INTO recipes (name, description, yield_amount, yield_unit, prep_time_minutes, hands_on_minutes, notes, created_at, updated_at) 
VALUES 
('Classic Beef Bolognese', 'Rich and hearty Italian meat sauce perfect for pasta', 8, 'servings', 45, 30, 'Let simmer slowly for best flavor development', datetime('now'), datetime('now')),
('Homemade Pizza Dough', 'Traditional Italian pizza dough with perfect texture', 4, 'pizzas', 20, 15, 'Let rise at room temperature for 2 hours', datetime('now'), datetime('now')),
('Chicken Caesar Salad', 'Fresh romaine with grilled chicken and classic Caesar dressing', 4, 'servings', 25, 20, 'Make dressing fresh for best taste', datetime('now'), datetime('now'));

INSERT INTO recipe_ingredients (recipe_id, ingredient_id, amount, unit, notes, ingredient_order, created_at, updated_at)
VALUES 
-- Bolognese ingredients
(1, NULL, 1, 'lb', 'ground beef', 1, datetime('now'), datetime('now')),
(1, NULL, 1, 'medium', 'onion, diced', 2, datetime('now'), datetime('now')),
(1, NULL, 2, 'cloves', 'garlic, minced', 3, datetime('now'), datetime('now')),
(1, NULL, 28, 'oz', 'crushed tomatoes', 4, datetime('now'), datetime('now')),
(1, NULL, 0.5, 'cup', 'red wine', 5, datetime('now'), datetime('now')),
(1, NULL, 2, 'tbsp', 'olive oil', 6, datetime('now'), datetime('now')),

-- Pizza dough ingredients  
(2, NULL, 3, 'cups', 'bread flour', 1, datetime('now'), datetime('now')),
(2, NULL, 1, 'tsp', 'active dry yeast', 2, datetime('now'), datetime('now')),
(2, NULL, 1, 'tsp', 'salt', 3, datetime('now'), datetime('now')),
(2, NULL, 1, 'cup', 'warm water', 4, datetime('now'), datetime('now')),
(2, NULL, 2, 'tbsp', 'olive oil', 5, datetime('now'), datetime('now')),

-- Caesar salad ingredients
(3, NULL, 2, 'large', 'chicken breasts', 1, datetime('now'), datetime('now')),
(3, NULL, 2, 'heads', 'romaine lettuce', 2, datetime('now'), datetime('now')),
(3, NULL, 0.5, 'cup', 'parmesan cheese, grated', 3, datetime('now'), datetime('now')),
(3, NULL, 1, 'cup', 'croutons', 4, datetime('now'), datetime('now'));

INSERT INTO recipe_steps (recipe_id, step_number, instruction, created_at, updated_at)
VALUES 
-- Bolognese steps
(1, 1, 'Heat olive oil in a large heavy-bottomed pot over medium heat. Add diced onion and cook until softened, about 5 minutes.', datetime('now'), datetime('now')),
(1, 2, 'Add minced garlic and cook for another minute until fragrant.', datetime('now'), datetime('now')),
(1, 3, 'Add ground beef and cook, breaking it up with a spoon, until browned and no longer pink, about 8-10 minutes.', datetime('now'), datetime('now')),
(1, 4, 'Pour in red wine and let it simmer for 2-3 minutes to cook off the alcohol.', datetime('now'), datetime('now')),
(1, 5, 'Add crushed tomatoes and bring to a simmer. Reduce heat to low and let cook for 30 minutes, stirring occasionally.', datetime('now'), datetime('now')),
(1, 6, 'Season with salt and pepper to taste. Serve over pasta with fresh basil and parmesan cheese.', datetime('now'), datetime('now')),

-- Pizza dough steps
(2, 1, 'In a small bowl, dissolve yeast in warm water and let sit for 5 minutes until foamy.', datetime('now'), datetime('now')),
(2, 2, 'In a large bowl, combine flour and salt. Make a well in the center and pour in yeast mixture and olive oil.', datetime('now'), datetime('now')),
(2, 3, 'Mix until a shaggy dough forms, then turn out onto a floured surface and knead for 8-10 minutes until smooth and elastic.', datetime('now'), datetime('now')),
(2, 4, 'Place dough in an oiled bowl, cover with a damp cloth, and let rise in a warm place for 1-2 hours until doubled in size.', datetime('now'), datetime('now')),
(2, 5, 'Punch down dough and divide into 4 equal pieces. Shape into balls and let rest for 15 minutes before rolling out.', datetime('now'), datetime('now')),

-- Caesar salad steps
(3, 1, 'Season chicken breasts with salt and pepper. Grill over medium-high heat for 6-7 minutes per side until cooked through.', datetime('now'), datetime('now')),
(3, 2, 'Let chicken rest for 5 minutes, then slice into strips.', datetime('now'), datetime('now')),
(3, 3, 'Wash and chop romaine lettuce into bite-sized pieces.', datetime('now'), datetime('now')),
(3, 4, 'In a large bowl, toss lettuce with Caesar dressing until well coated.', datetime('now'), datetime('now')),
(3, 5, 'Add sliced chicken, croutons, and parmesan cheese. Toss gently and serve immediately.', datetime('now'), datetime('now'));

INSERT INTO recipe_cooking_steps (recipe_id, step_number, equipment, method, temperature, duration, notes, created_at, updated_at)
VALUES 
-- Bolognese cooking steps
(1, 1, 'stove', 'sauté', 'medium heat', '5 minutes', 'cook onions until softened', datetime('now'), datetime('now')),
(1, 2, 'stove', 'brown', 'medium heat', '10 minutes', 'break up meat as it cooks', datetime('now'), datetime('now')),
(1, 3, 'stove', 'simmer', 'low heat', '30 minutes', 'stir occasionally', datetime('now'), datetime('now')),

-- Pizza dough cooking steps
(2, 1, 'counter', 'knead', 'room temperature', '10 minutes', 'until smooth and elastic', datetime('now'), datetime('now')),
(2, 2, 'counter', 'rise', 'warm place', '2 hours', 'until doubled in size', datetime('now'), datetime('now')),

-- Caesar salad cooking steps
(3, 1, 'grill', 'grill', 'medium-high heat', '14 minutes', '7 minutes per side', datetime('now'), datetime('now')),
(3, 2, 'counter', 'rest', 'room temperature', '5 minutes', 'let meat rest before slicing', datetime('now'), datetime('now'));

INSERT INTO recipe_tags (recipe_id, tag, created_at, updated_at)
VALUES 
(1, 'italian', datetime('now'), datetime('now')),
(1, 'pasta', datetime('now'), datetime('now')),
(1, 'dinner', datetime('now'), datetime('now')),
(1, 'comfort food', datetime('now'), datetime('now')),
(2, 'italian', datetime('now'), datetime('now')),
(2, 'bread', datetime('now'), datetime('now')),
(2, 'pizza', datetime('now'), datetime('now')),
(2, 'vegetarian', datetime('now'), datetime('now')),
(3, 'salad', datetime('now'), datetime('now')),
(3, 'chicken', datetime('now'), datetime('now')),
(3, 'lunch', datetime('now'), datetime('now')),
(3, 'healthy', datetime('now'), datetime('now'));
