
-- Timings per component for more accurate prep/cook planning
ALTER TABLE recipe_components ADD COLUMN prep_time_min INTEGER DEFAULT 0;
ALTER TABLE recipe_components ADD COLUMN cook_time_min INTEGER DEFAULT 0;
