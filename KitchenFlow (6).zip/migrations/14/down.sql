
DROP INDEX idx_meal_components_type;
DROP INDEX idx_meal_components_planned_meal;
DROP TABLE meal_components;
