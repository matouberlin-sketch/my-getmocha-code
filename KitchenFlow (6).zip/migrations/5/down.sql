
-- Remove equipment and cooking instruction columns from recipe_steps
ALTER TABLE recipe_steps DROP COLUMN cooking_method;
ALTER TABLE recipe_steps DROP COLUMN cooking_time;
ALTER TABLE recipe_steps DROP COLUMN temperature;
ALTER TABLE recipe_steps DROP COLUMN equipment;
