
-- Add some enhanced recipes with GN tray yields to demonstrate portion-based scaling
INSERT INTO enhanced_recipes (recipe_id, name, type, default_yield_qty, default_yield_uom, active_minutes, passive_minutes, station, notes) VALUES
('RCP_LASAGNE_001', 'Classic Beef Lasagne', 'final', 1, '1/1 GN 10cm tray', 45, 60, 'oven', 'Serves 36 portions per tray'),
('RCP_MOUSSAKA_001', 'Greek Moussaka', 'final', 1, '1/1 GN 10cm tray', 50, 90, 'oven', 'Serves 36 portions per tray'),
('RCP_GRATIN_001', 'Potato Gratin', 'component', 1, '1/2 GN 6cm tray', 30, 45, 'oven', 'Serves 12 portions per half tray'),
('RCP_RATATOUILLE_001', 'Mediterranean Ratatouille', 'component', 1, '1/1 GN 6cm tray', 25, 40, 'oven', 'Serves 24 portions per tray');

-- Add ingredients for these recipes
INSERT INTO enhanced_recipe_ingredients (recipe_id, line_no, item_id, qty, uom, notes) VALUES
('RCP_LASAGNE_001', 1, 'ING_PASTA_LASAGNE', 1.2, 'kg', 'Fresh lasagne sheets'),
('RCP_LASAGNE_001', 2, 'ING_BEEF_MINCE', 2.5, 'kg', 'Lean beef mince'),
('RCP_LASAGNE_001', 3, 'ING_CHEESE_MOZZARELLA', 800, 'g', 'Shredded mozzarella'),
('RCP_LASAGNE_001', 4, 'ING_CHEESE_PARMESAN', 300, 'g', 'Grated parmesan'),

('RCP_MOUSSAKA_001', 1, 'ING_AUBERGINE', 3, 'kg', 'Sliced aubergines'),
('RCP_MOUSSAKA_001', 2, 'ING_LAMB_MINCE', 2.2, 'kg', 'Ground lamb'),
('RCP_MOUSSAKA_001', 3, 'ING_CHEESE_FETA', 400, 'g', 'Crumbled feta'),

('RCP_GRATIN_001', 1, 'ING_POTATO', 2.5, 'kg', 'Waxy potatoes, sliced'),
('RCP_GRATIN_001', 2, 'ING_CREAM_HEAVY', 600, 'ml', 'Heavy cream'),
('RCP_GRATIN_001', 3, 'ING_CHEESE_GRUYERE', 300, 'g', 'Grated gruyere'),

('RCP_RATATOUILLE_001', 1, 'ING_COURGETTE', 1.5, 'kg', 'Diced courgettes'),
('RCP_RATATOUILLE_001', 2, 'ING_AUBERGINE', 1.2, 'kg', 'Diced aubergines'),
('RCP_RATATOUILLE_001', 3, 'ING_PEPPER_RED', 800, 'g', 'Red peppers, diced'),
('RCP_RATATOUILLE_001', 4, 'ING_TOMATO_CANNED', 800, 'ml', 'Canned tomatoes');
