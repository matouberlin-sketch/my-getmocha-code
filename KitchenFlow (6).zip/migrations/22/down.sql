
DROP INDEX idx_recipe_coproducts_item;
DROP INDEX idx_recipe_coproducts_recipe;
DROP TABLE recipe_coproducts;
