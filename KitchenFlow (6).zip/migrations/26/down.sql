
DROP INDEX idx_planner_slot_recipes_slot;
DROP INDEX idx_planner_slots_plan;
DROP INDEX idx_planner_plans_week_status;
DROP TABLE planner_slot_recipes;
DROP TABLE planner_slots;
DROP TABLE planner_plans;
