
-- Phase 1: Enhanced Item Management System (avoiding existing tables)
-- Enhanced items table to complement existing ingredients
CREATE TABLE items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  item_type TEXT NOT NULL, -- raw, prepped, component, finished
  base_uom TEXT NOT NULL,
  category TEXT,
  default_state TEXT,
  edible_yield_pct INTEGER DEFAULT 100,
  density_g_per_ml REAL,
  allergen_tags TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- UOM conversions
CREATE TABLE item_uom_conversions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id TEXT NOT NULL,
  from_uom TEXT NOT NULL,
  to_uom TEXT NOT NULL,
  factor REAL NOT NULL,
  method TEXT NOT NULL, -- multiply, density
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced recipes with output items
CREATE TABLE enhanced_recipes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  type TEXT NOT NULL, -- prep, component, final
  default_yield_qty REAL NOT NULL,
  default_yield_uom TEXT NOT NULL,
  output_item_id TEXT,
  active_minutes INTEGER DEFAULT 0,
  passive_minutes INTEGER DEFAULT 0,
  lead_time_hours REAL DEFAULT 0,
  station TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Recipe components (recipe hierarchy)
CREATE TABLE recipe_components (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_recipe_id TEXT NOT NULL,
  component_recipe_id TEXT NOT NULL,
  qty REAL NOT NULL,
  uom TEXT NOT NULL,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced recipe ingredients using items
CREATE TABLE enhanced_recipe_ingredients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id TEXT NOT NULL,
  line_no INTEGER NOT NULL,
  item_id TEXT NOT NULL,
  qty REAL NOT NULL,
  uom TEXT NOT NULL,
  scrap_pct REAL DEFAULT 0,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced supplier items with pricing
CREATE TABLE supplier_items_enhanced (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_item_id TEXT NOT NULL UNIQUE,
  supplier_name TEXT NOT NULL,
  item_id TEXT NOT NULL,
  name_on_invoice TEXT,
  order_code TEXT,
  pack_qty REAL NOT NULL,
  pack_uom TEXT NOT NULL,
  price REAL NOT NULL,
  currency TEXT DEFAULT 'EUR',
  vat_pct REAL DEFAULT 19,
  deposit REAL DEFAULT 0,
  price_valid_from DATE,
  price_valid_to DATE,
  moq_packs INTEGER DEFAULT 1,
  order_multiple_packs INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX idx_items_type ON items(item_type);
CREATE INDEX idx_items_category ON items(category);
CREATE INDEX idx_supplier_items_enhanced_item ON supplier_items_enhanced(item_id);
CREATE INDEX idx_recipe_components_parent ON recipe_components(parent_recipe_id);
CREATE INDEX idx_recipe_components_component ON recipe_components(component_recipe_id);
CREATE INDEX idx_enhanced_recipe_ingredients_recipe ON enhanced_recipe_ingredients(recipe_id);
