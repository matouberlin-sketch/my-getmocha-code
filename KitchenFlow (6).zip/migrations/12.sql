
-- Add shortlist table for quick recipe access
CREATE TABLE recipe_shortlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id INTEGER NOT NULL,
  added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Update planned_meals to support detailed portion tracking
ALTER TABLE planned_meals ADD COLUMN total_portions INTEGER DEFAULT 0;
ALTER TABLE planned_meals ADD COLUMN vegetarian_portions INTEGER DEFAULT 0;
ALTER TABLE planned_meals ADD COLUMN service_time TEXT DEFAULT '12:30';
ALTER TABLE planned_meals ADD COLUMN same_menu_both_services BOOLEAN DEFAULT FALSE;
ALTER TABLE planned_meals ADD COLUMN lunch_portions INTEGER DEFAULT 0;
ALTER TABLE planned_meals ADD COLUMN lunch_vegetarian INTEGER DEFAULT 0;
ALTER TABLE planned_meals ADD COLUMN dinner_portions INTEGER DEFAULT 0;
ALTER TABLE planned_meals ADD COLUMN dinner_vegetarian INTEGER DEFAULT 0;

-- Create index for shortlist lookups
CREATE INDEX idx_recipe_shortlist_recipe_id ON recipe_shortlist(recipe_id);
