
CREATE TABLE locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  type TEXT,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Add some default locations for immediate use
INSERT INTO locations (name, type, description, created_at, updated_at) VALUES 
('Walk-in Cooler', 'Refrigerated', 'Main refrigerated storage area', datetime('now'), datetime('now')),
('Dry Storage', 'Dry', 'Ambient temperature dry goods storage', datetime('now'), datetime('now')),
('Freezer', 'Frozen', 'Frozen ingredient storage', datetime('now'), datetime('now')),
('Prep Station A', 'Prep', 'Main preparation area', datetime('now'), datetime('now')),
('Pantry', 'Dry', 'Easy access pantry items', datetime('now'), datetime('now'));
