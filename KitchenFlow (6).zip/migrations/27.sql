
ALTER TABLE planner_slots ADD COLUMN position INTEGER DEFAULT 0;

-- Update existing slots to have position values based on creation order
UPDATE planner_slots SET position = (
  SELECT COUNT(*) 
  FROM planner_slots ps2 
  WHERE ps2.plan_id = planner_slots.plan_id 
    AND ps2.day_index = planner_slots.day_index 
    AND ps2.id <= planner_slots.id
) - 1;

CREATE INDEX idx_planner_slots_position ON planner_slots(plan_id, day_index, position);
