
DROP INDEX idx_recipe_steps_recipe_id;
DROP INDEX idx_recipe_ingredients_recipe_id;
DROP INDEX idx_recipes_name;
DROP INDEX idx_ingredients_name;
DROP TABLE recipe_steps;
DROP TABLE recipe_ingredients;
DROP TABLE recipes;
DROP TABLE ingredients;
