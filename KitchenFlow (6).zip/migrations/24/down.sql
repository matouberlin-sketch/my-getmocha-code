
ALTER TABLE items DROP COLUMN each_to_base;
