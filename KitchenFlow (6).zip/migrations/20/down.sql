
DROP INDEX idx_item_uom_to;
DROP INDEX idx_item_uom_from;
DROP INDEX idx_item_uom_item;
DROP TABLE item_uom;
