
-- Add only the missing BOM-related column to items table
ALTER TABLE items ADD COLUMN each_to_base REAL;

-- Update existing items with sensible defaults
UPDATE items SET each_to_base = 1.0 WHERE each_to_base IS NULL;
