
-- Supplier pricing table for Items
CREATE TABLE item_suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL,
  supplier_name TEXT NOT NULL,
  price_cents INTEGER NOT NULL,    -- price in cents to avoid float precision issues
  pack_size_qty REAL NOT NULL,
  pack_size_unit TEXT NOT NULL,
  currency TEXT DEFAULT 'USD',
  preferred BOOLEAN DEFAULT FALSE,
  valid_from DATE DEFAULT NULL,
  valid_to DATE DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE CASCADE,
  FOREIGN KEY(pack_size_unit) REFERENCES uom(code)
);

CREATE INDEX idx_item_suppliers_item ON item_suppliers(item_id);
CREATE INDEX idx_item_suppliers_preferred ON item_suppliers(item_id, preferred);
CREATE INDEX idx_item_suppliers_price ON item_suppliers(item_id, price_cents);
