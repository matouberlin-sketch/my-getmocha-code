import { describe, it, expect, beforeAll, afterAll } from 'vitest';

const API_BASE = process.env.VITE_API_URL || 'http://localhost:5173';

describe('Where-Used API', () => {
  let testItemId: number;
  let testSubrecipeId: number;
  let testMainRecipeId: number;

  beforeAll(async () => {
    // Create test item
    const itemResponse = await fetch(`${API_BASE}/api/items`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        item_id: 'test-whereused-item',
        name: 'Test Where-Used Item',
        item_type: 'raw',
        base_uom: 'g'
      })
    });
    
    if (itemResponse.ok) {
      const itemData = await itemResponse.json();
      testItemId = itemData.item.id;
    }

    // Create a subrecipe that uses the item
    const subrecipeResponse = await fetch(`${API_BASE}/api/recipes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test Subrecipe',
        description: 'A subrecipe for testing where-used',
        yield_amount: 1,
        yield_unit: 'batch',
        is_subrecipe: true,
        ingredients: [
          {
            ingredient_name: 'Test Where-Used Item',
            amount: 100,
            unit: 'g',
            weight_grams: 100
          }
        ],
        steps: [
          { step_number: 1, instruction: 'Process the test item' }
        ]
      })
    });

    if (subrecipeResponse.ok) {
      const subrecipeData = await subrecipeResponse.json();
      testSubrecipeId = subrecipeData.id;
    }

    // Create a main recipe that uses the subrecipe
    const mainRecipeResponse = await fetch(`${API_BASE}/api/recipes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test Main Recipe',
        description: 'Main recipe that uses the subrecipe',
        yield_amount: 4,
        yield_unit: 'servings',
        ingredients: [
          {
            ingredient_name: 'Test Subrecipe',
            amount: 1,
            unit: 'batch',
            subrecipe_id: testSubrecipeId,
            is_subrecipe: true
          },
          {
            ingredient_name: 'Water',
            amount: 500,
            unit: 'ml',
            weight_grams: 500
          }
        ],
        steps: [
          { step_number: 1, instruction: 'Prepare the subrecipe first' },
          { step_number: 2, instruction: 'Combine with water and serve' }
        ]
      })
    });

    if (mainRecipeResponse.ok) {
      const mainRecipeData = await mainRecipeResponse.json();
      testMainRecipeId = mainRecipeData.id;
    }
  });

  afterAll(async () => {
    // Cleanup in reverse order
    if (testMainRecipeId) {
      await fetch(`${API_BASE}/api/recipes/${testMainRecipeId}`, {
        method: 'DELETE'
      });
    }
    
    if (testSubrecipeId) {
      await fetch(`${API_BASE}/api/recipes/${testSubrecipeId}`, {
        method: 'DELETE'
      });
    }
    
    if (testItemId) {
      await fetch(`${API_BASE}/api/items/${testItemId}`, {
        method: 'DELETE'
      });
    }
  });

  describe('Where-Used Analysis', () => {
    it('should find direct usage of item in subrecipe', async () => {
      const response = await fetch(`${API_BASE}/api/items/${testItemId}/where-used`);
      
      expect(response.ok).toBe(true);
      const data = await response.json();
      
      expect(data).toHaveProperty('item');
      expect(data.item.id).toBe(testItemId);
      expect(data.item.name).toBe('Test Where-Used Item');
      
      expect(data).toHaveProperty('subrecipes');
      expect(Array.isArray(data.subrecipes)).toBe(true);
      
      // Should find the subrecipe that directly uses this item
      const directSubrecipe = data.subrecipes.find((sr: any) => sr.id === testSubrecipeId);
      expect(directSubrecipe).toBeDefined();
      expect(directSubrecipe.name).toBe('Test Subrecipe');
      expect(directSubrecipe.via_subrecipe).toBe(false); // Direct usage
    });

    it('should find indirect usage through subrecipe hierarchy', async () => {
      const response = await fetch(`${API_BASE}/api/items/${testItemId}/where-used`);
      const data = await response.json();
      
      expect(data).toHaveProperty('recipes');
      expect(Array.isArray(data.recipes)).toBe(true);
      
      // Should find the main recipe that uses the subrecipe
      const indirectRecipe = data.recipes.find((r: any) => r.id === testMainRecipeId);
      expect(indirectRecipe).toBeDefined();
      expect(indirectRecipe.name).toBe('Test Main Recipe');
      expect(indirectRecipe.via_subrecipe).toBe(true); // Indirect usage through subrecipe
    });

    it('should handle circular dependency protection', async () => {
      // Create a potential circular reference by having the main recipe reference itself
      // This should be caught by the visited set mechanism
      
      const response = await fetch(`${API_BASE}/api/items/${testItemId}/where-used`);
      
      expect(response.ok).toBe(true);
      const data = await response.json();
      
      // Should not cause infinite recursion or crashes
      expect(data).toHaveProperty('recipes');
      expect(data).toHaveProperty('subrecipes');
      
      // Results should be finite and reasonable
      expect(data.recipes.length).toBeLessThan(100);
      expect(data.subrecipes.length).toBeLessThan(100);
    });

    it('should return empty results for unused item', async () => {
      // Create an item that's not used anywhere
      const unusedItemResponse = await fetch(`${API_BASE}/api/items`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          item_id: 'unused-test-item',
          name: 'Unused Test Item',
          item_type: 'raw',
          base_uom: 'g'
        })
      });

      if (unusedItemResponse.ok) {
        const unusedItemData = await unusedItemResponse.json();
        const unusedItemId = unusedItemData.item.id;

        const whereUsedResponse = await fetch(`${API_BASE}/api/items/${unusedItemId}/where-used`);
        const whereUsedData = await whereUsedResponse.json();

        expect(whereUsedData.recipes).toEqual([]);
        expect(whereUsedData.subrecipes).toEqual([]);

        // Cleanup
        await fetch(`${API_BASE}/api/items/${unusedItemId}`, {
          method: 'DELETE'
        });
      }
    });

    it('should handle non-existent item gracefully', async () => {
      const response = await fetch(`${API_BASE}/api/items/999999/where-used`);
      
      expect(response.status).toBe(404);
      const data = await response.json();
      expect(data).toHaveProperty('error', 'Item not found');
    });
  });

  describe('Recipe Supplier Matrix', () => {
    it('should calculate per-portion cost correctly', async () => {
      // First create some supplier data for our test item
      const supplierResponse = await fetch(`${API_BASE}/api/suppliers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Test Supplier',
          contact_person: 'Test Contact',
          email: 'test@supplier.com'
        })
      });

      if (supplierResponse.ok) {
        const supplierData = await supplierResponse.json();
        const supplierId = supplierData.supplier.id;

        // Add supplier pricing for our test item
        await fetch(`${API_BASE}/api/items/${testItemId}/suppliers`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            supplier_id: supplierId,
            price_cents: 1000, // $10.00
            pack_size_qty: 1000, // 1kg
            pack_size_unit: 'g',
            preferred: true
          })
        });

        // Now test the supplier matrix for our subrecipe
        const matrixResponse = await fetch(`${API_BASE}/api/recipes/${testSubrecipeId}/suppliers`);
        
        if (matrixResponse.ok) {
          const matrixData = await matrixResponse.json();
          
          expect(matrixData).toHaveProperty('recipe_id');
          expect(matrixData).toHaveProperty('name', 'Test Subrecipe');
          expect(matrixData).toHaveProperty('per_portion_cost');
          expect(matrixData).toHaveProperty('items');
          
          // Should calculate cost correctly
          // 100g at $10/1000g = $1.00 total, for 1 portion = $1.00 per portion
          expect(matrixData.per_portion_cost).toBeCloseTo(1.0, 2);
          
          expect(Array.isArray(matrixData.items)).toBe(true);
          expect(matrixData.items.length).toBeGreaterThan(0);
          
          const testItem = matrixData.items.find((item: any) => item.name === 'Test Where-Used Item');
          expect(testItem).toBeDefined();
          expect(testItem.suppliers.length).toBeGreaterThan(0);
          
          const preferredSupplier = testItem.suppliers.find((s: any) => s.preferred);
          expect(preferredSupplier).toBeDefined();
          expect(preferredSupplier.unit_cost).toBeCloseTo(0.01, 3); // $0.01 per gram
        }

        // Cleanup supplier data
        await fetch(`${API_BASE}/api/suppliers/${supplierId}`, {
          method: 'DELETE'
        });
      }
    });

    it('should handle recipes with no supplier data', async () => {
      // Create a recipe with an item that has no suppliers
      const noSupplierItemResponse = await fetch(`${API_BASE}/api/items`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          item_id: 'no-supplier-item',
          name: 'No Supplier Item',
          item_type: 'raw',
          base_uom: 'g'
        })
      });

      if (noSupplierItemResponse.ok) {
        const noSupplierItemData = await noSupplierItemResponse.json();
        const noSupplierItemId = noSupplierItemData.item.id;

        const noSupplierRecipeResponse = await fetch(`${API_BASE}/api/recipes`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: 'No Supplier Recipe',
            yield_amount: 2,
            yield_unit: 'servings',
            ingredients: [
              {
                ingredient_name: 'No Supplier Item',
                amount: 200,
                unit: 'g',
                weight_grams: 200
              }
            ],
            steps: [
              { step_number: 1, instruction: 'Use the item with no suppliers' }
            ]
          })
        });

        if (noSupplierRecipeResponse.ok) {
          const noSupplierRecipeData = await noSupplierRecipeResponse.json();
          const noSupplierRecipeId = noSupplierRecipeData.id;

          const matrixResponse = await fetch(`${API_BASE}/api/recipes/${noSupplierRecipeId}/suppliers`);
          
          if (matrixResponse.ok) {
            const matrixData = await matrixResponse.json();
            
            expect(matrixData.per_portion_cost).toBeNull();
            expect(matrixData.items.length).toBeGreaterThan(0);
            
            const testItem = matrixData.items[0];
            expect(testItem.suppliers.length).toBe(0);
          }

          // Cleanup
          await fetch(`${API_BASE}/api/recipes/${noSupplierRecipeId}`, {
            method: 'DELETE'
          });
        }

        await fetch(`${API_BASE}/api/items/${noSupplierItemId}`, {
          method: 'DELETE'
        });
      }
    });
  });
});
