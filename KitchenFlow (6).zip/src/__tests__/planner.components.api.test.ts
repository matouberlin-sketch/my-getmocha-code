import { describe, it, expect } from 'vitest';

// These would hit your worker handlers in isolation if you have a test harness.
// For now, we validate schemas/shape expectations as a guard.

describe('components endpoint contract', () => {
  it('items view lines include net_qty, uom, mins', () => {
    const line = { type:'item', item_id:1, name:'X', net_qty:1.23, uom:'kg', mins:10 };
    expect(typeof line.net_qty).toBe('number');
    expect(typeof line.uom).toBe('string');
    expect(typeof line.mins).toBe('number');
  });

  it('components view includes recipe with children', () => {
    const recipe = { 
      type: 'recipe', 
      recipe_id: 1, 
      name: 'Test Recipe', 
      portions: 4, 
      children: [
        { type: 'item', item_id: 1, name: 'Flour', net_qty: 500, uom: 'g', mins: 5 }
      ] 
    };
    expect(recipe.children).toBeInstanceOf(Array);
    expect(recipe.children[0]).toHaveProperty('net_qty');
    expect(recipe.children[0]).toHaveProperty('mins');
  });
});

describe('tasks endpoint contract', () => {
  it('prep, cook, order tasks have required fields', () => {
    const task = { name: 'Prep vegetables', qty: 2, uom: 'kg', source_recipe: 'Salad', mins: 15 };
    expect(typeof task.name).toBe('string');
    expect(typeof task.qty).toBe('number');
    expect(typeof task.uom).toBe('string');
    expect(typeof task.mins).toBe('number');
  });
});
