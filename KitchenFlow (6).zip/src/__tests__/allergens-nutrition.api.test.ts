import { describe, it, expect, beforeAll, afterAll } from 'vitest';

const API_BASE = process.env.VITE_API_URL || 'http://localhost:5173';

describe('Allergens and Nutrition API', () => {
  let testRecipeId: number;
  let testItemId: number;

  beforeAll(async () => {
    // Create test item with allergens and nutrition data
    const itemResponse = await fetch(`${API_BASE}/api/items`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        item_id: 'test-allergen-item',
        name: 'Test Allergen Item',
        item_type: 'raw',
        base_uom: 'g',
        allergen_codes: 'GLUTEN,EGG',
        kcal_per_100: 250,
        protein_g_per_100: 12,
        carbs_g_per_100: 45,
        fat_g_per_100: 8
      })
    });
    
    if (itemResponse.ok) {
      const itemData = await itemResponse.json();
      testItemId = itemData.item.id;
    }

    // Create test recipe
    const recipeResponse = await fetch(`${API_BASE}/api/recipes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test Allergen Recipe',
        description: 'Recipe for testing allergens and nutrition',
        yield_amount: 4,
        yield_unit: 'servings',
        prep_time_minutes: 30,
        hands_on_minutes: 20,
        ingredients: [
          {
            ingredient_name: 'Test Allergen Item',
            amount: 200,
            unit: 'g',
            notes: 'main ingredient',
            weight_grams: 200
          },
          {
            ingredient_name: 'Salt',
            amount: 5,
            unit: 'g',
            notes: 'seasoning',
            weight_grams: 5
          }
        ],
        steps: [
          { step_number: 1, instruction: 'Combine ingredients' },
          { step_number: 2, instruction: 'Mix well and serve' }
        ],
        tags: ['test', 'allergen-test']
      })
    });

    if (recipeResponse.ok) {
      const recipeData = await recipeResponse.json();
      testRecipeId = recipeData.id;
    }
  });

  afterAll(async () => {
    // Cleanup
    if (testRecipeId) {
      await fetch(`${API_BASE}/api/recipes/${testRecipeId}`, {
        method: 'DELETE'
      });
    }
    
    if (testItemId) {
      await fetch(`${API_BASE}/api/items/${testItemId}`, {
        method: 'DELETE'
      });
    }
  });

  describe('Allergen Detection', () => {
    it('should return allergens from recipe ingredients', async () => {
      const response = await fetch(`${API_BASE}/api/recipes/${testRecipeId}/allergens`);
      
      expect(response.ok).toBe(true);
      const data = await response.json();
      
      expect(data).toHaveProperty('recipe_id', testRecipeId);
      expect(data).toHaveProperty('allergens');
      expect(Array.isArray(data.allergens)).toBe(true);
      
      // Should contain the allergens from our test item
      const allergenCodes = data.allergens.map((a: any) => a.code);
      expect(allergenCodes).toContain('GLUTEN');
      expect(allergenCodes).toContain('EGG');
    });

    it('should dedupe allergens from multiple ingredients', async () => {
      const response = await fetch(`${API_BASE}/api/recipes/${testRecipeId}/allergens`);
      const data = await response.json();
      
      // Check that allergens are unique
      const allergenCodes = data.allergens.map((a: any) => a.code);
      const uniqueCodes = [...new Set(allergenCodes)];
      expect(allergenCodes.length).toBe(uniqueCodes.length);
    });

    it('should return empty array for recipe with no allergens', async () => {
      // Create a recipe with no allergenic ingredients
      const cleanRecipeResponse = await fetch(`${API_BASE}/api/recipes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Clean Test Recipe',
          yield_amount: 2,
          yield_unit: 'servings',
          ingredients: [
            { ingredient_name: 'Water', amount: 500, unit: 'ml', weight_grams: 500 }
          ],
          steps: [
            { step_number: 1, instruction: 'Boil water' }
          ]
        })
      });

      if (cleanRecipeResponse.ok) {
        const cleanRecipeData = await cleanRecipeResponse.json();
        const cleanRecipeId = cleanRecipeData.id;

        const allergensResponse = await fetch(`${API_BASE}/api/recipes/${cleanRecipeId}/allergens`);
        const allergensData = await allergensResponse.json();

        expect(allergensData.allergens).toEqual([]);

        // Cleanup
        await fetch(`${API_BASE}/api/recipes/${cleanRecipeId}`, {
          method: 'DELETE'
        });
      }
    });
  });

  describe('Nutrition Calculation', () => {
    it('should calculate per-portion nutrition correctly', async () => {
      const response = await fetch(`${API_BASE}/api/recipes/${testRecipeId}/nutrition`);
      
      expect(response.ok).toBe(true);
      const data = await response.json();
      
      expect(data).toHaveProperty('recipe_id', testRecipeId);
      expect(data).toHaveProperty('per_portion');
      
      const nutrition = data.per_portion;
      expect(nutrition).toHaveProperty('kcal_per_portion');
      expect(nutrition).toHaveProperty('protein_g_per_portion');
      expect(nutrition).toHaveProperty('carbs_g_per_portion');
      expect(nutrition).toHaveProperty('fat_g_per_portion');

      // Check calculations based on our test ingredient
      // 200g of test item with 250 kcal/100g = 500 kcal total
      // Divided by 4 portions = 125 kcal per portion
      expect(nutrition.kcal_per_portion).toBe(125);
      
      // 200g with 12g protein/100g = 24g total / 4 portions = 6g per portion
      expect(nutrition.protein_g_per_portion).toBe(6);
      
      // 200g with 45g carbs/100g = 90g total / 4 portions = 22.5g per portion
      expect(nutrition.carbs_g_per_portion).toBe(22.5);
      
      // 200g with 8g fat/100g = 16g total / 4 portions = 4g per portion
      expect(nutrition.fat_g_per_portion).toBe(4);
    });

    it('should scale nutrition with recipe yield', async () => {
      // Create a recipe with different yield
      const scaledRecipeResponse = await fetch(`${API_BASE}/api/recipes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Scaled Test Recipe',
          yield_amount: 8, // Double the portions
          yield_unit: 'servings',
          ingredients: [
            {
              ingredient_name: 'Test Allergen Item',
              amount: 200,
              unit: 'g',
              weight_grams: 200
            }
          ],
          steps: [
            { step_number: 1, instruction: 'Prepare ingredients' }
          ]
        })
      });

      if (scaledRecipeResponse.ok) {
        const scaledRecipeData = await scaledRecipeResponse.json();
        const scaledRecipeId = scaledRecipeData.id;

        const nutritionResponse = await fetch(`${API_BASE}/api/recipes/${scaledRecipeId}/nutrition`);
        const nutritionData = await nutritionResponse.json();

        const nutrition = nutritionData.per_portion;
        
        // With 8 portions instead of 4, per-portion values should be half
        expect(nutrition.kcal_per_portion).toBe(62.5); // 125 / 2
        expect(nutrition.protein_g_per_portion).toBe(3); // 6 / 2

        // Cleanup
        await fetch(`${API_BASE}/api/recipes/${scaledRecipeId}`, {
          method: 'DELETE'
        });
      }
    });

    it('should handle recipes with no nutritional data', async () => {
      const response = await fetch(`${API_BASE}/api/recipes/999999/nutrition`);
      expect(response.status).toBe(404);
    });
  });

  describe('Integration Tests', () => {
    it('should handle ingredient updates affecting allergens', async () => {
      // Update the test item to remove allergens
      const updateResponse = await fetch(`${API_BASE}/api/items/${testItemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          allergen_codes: null // Remove allergens
        })
      });

      expect(updateResponse.ok).toBe(true);

      // Check that recipe allergens are updated
      const allergensResponse = await fetch(`${API_BASE}/api/recipes/${testRecipeId}/allergens`);
      const allergensData = await allergensResponse.json();

      expect(allergensData.allergens).toEqual([]);

      // Restore allergens for other tests
      await fetch(`${API_BASE}/api/items/${testItemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          allergen_codes: 'GLUTEN,EGG'
        })
      });
    });

    it('should handle nutrition updates for ingredients', async () => {
      // Update nutritional values
      const updateResponse = await fetch(`${API_BASE}/api/items/${testItemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kcal_per_100: 300, // Increased from 250
          protein_g_per_100: 15 // Increased from 12
        })
      });

      expect(updateResponse.ok).toBe(true);

      // Check that recipe nutrition is updated
      const nutritionResponse = await fetch(`${API_BASE}/api/recipes/${testRecipeId}/nutrition`);
      const nutritionData = await nutritionResponse.json();

      const nutrition = nutritionData.per_portion;
      
      // New calculations: 200g * 300kcal/100g / 4 portions = 150 kcal per portion
      expect(nutrition.kcal_per_portion).toBe(150);
      
      // 200g * 15g protein/100g / 4 portions = 7.5g per portion
      expect(nutrition.protein_g_per_portion).toBe(7.5);
    });
  });
});
