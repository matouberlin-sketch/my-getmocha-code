import { describe, it, expect, beforeEach } from 'vitest';

// Mock database and environment
const mockDB = {
  prepare: (sql: string) => ({
    bind: (...params: any[]) => ({
      first: async () => {
        if (sql.includes('SELECT * FROM planner_plans WHERE id = ?')) {
          return { id: 1, status: 'draft', week_start_date: '2024-01-01' };
        }
        if (sql.includes('SELECT COUNT(*) as count')) {
          return { count: 1 };
        }
        if (sql.includes('SELECT id FROM order_snapshots')) {
          return { id: 1 };
        }
        return null;
      },
      all: async () => ({
        results: sql.includes('WITH RECURSIVE recipe_expansion') ? [
          { item_id: 1, item_name: 'Test Item', uom: 'kg', net_qty: 5.0 }
        ] : []
      }),
      run: async () => ({ meta: { last_row_id: 1 } })
    })
  })
};

const mockEnv = { DB: mockDB };

describe('Planner Lock API', () => {
  beforeEach(() => {
    // Reset mocks
  });

  it('should lock a plan with recipes and create order snapshot', async () => {
    // Mock the lock endpoint logic
    const planId = '1';
    const plan = await mockDB.prepare('SELECT * FROM planner_plans WHERE id = ?').bind(planId).first();
    
    expect(plan.status).toBe('draft');
    
    // Check for recipes
    const hasRecipes = await mockDB.prepare('SELECT COUNT(*) as count FROM planner_slots ps JOIN planner_slot_recipes psr ON ps.id = psr.slot_id WHERE ps.plan_id = ?').bind(planId).first();
    expect(hasRecipes.count).toBeGreaterThan(0);
    
    // Mock successful lock
    const lockResult = {
      status: 'locked',
      order_snapshot_id: 1,
      totals: {
        grand_total: 100.50,
        suppliers: 1
      }
    };
    
    expect(lockResult.status).toBe('locked');
    expect(lockResult.order_snapshot_id).toBe(1);
  });

  it('should return 409 when trying to lock an already locked plan', async () => {
    const planId = '1';
    
    // Mock locked plan
    const lockedPlan = { id: 1, status: 'locked', week_start_date: '2024-01-01' };
    
    // Simulate 409 error
    const error = lockedPlan.status === 'locked' ? { error: 'Plan is already locked', status: 409 } : null;
    
    expect(error?.status).toBe(409);
    expect(error?.error).toBe('Plan is already locked');
  });

  it('should return 409 for write operations on locked plan', async () => {
    const planId = '1';
    const lockedPlan = { id: 1, status: 'locked', week_start_date: '2024-01-01' };
    
    // Simulate checkPlanNotLocked function
    const checkPlanNotLocked = (plan: any) => {
      if (plan.status === 'locked') {
        throw new Error('Plan is locked and cannot be modified');
      }
    };
    
    expect(() => checkPlanNotLocked(lockedPlan)).toThrow('Plan is locked and cannot be modified');
  });

  it('should select preferred supplier pricing when available', async () => {
    const itemId = 1;
    const costingStrategy = 'preferred';
    
    // Mock supplier prices
    const mockPrices = [
      { supplier_name: 'Supplier A', price_cents: 500, pack_size_qty: 1, preferred: true },
      { supplier_name: 'Supplier B', price_cents: 400, pack_size_qty: 1, preferred: false }
    ];
    
    // Sort by preferred first
    const sortedPrices = mockPrices.sort((a, b) => {
      if (costingStrategy === 'preferred') {
        return b.preferred ? 1 : (a.preferred ? -1 : 0);
      }
      return a.price_cents / a.pack_size_qty - b.price_cents / b.pack_size_qty;
    });
    
    expect(sortedPrices[0].supplier_name).toBe('Supplier A');
    expect(sortedPrices[0].preferred).toBe(true);
  });

  it('should select lowest pricing when strategy is lowest', async () => {
    const itemId = 1;
    const costingStrategy = 'lowest';
    
    // Mock supplier prices
    const mockPrices = [
      { supplier_name: 'Supplier A', price_cents: 500, pack_size_qty: 1, preferred: true },
      { supplier_name: 'Supplier B', price_cents: 400, pack_size_qty: 1, preferred: false }
    ];
    
    // Sort by lowest cost
    const sortedPrices = mockPrices.sort((a, b) => {
      if (costingStrategy === 'lowest') {
        return a.price_cents / a.pack_size_qty - b.price_cents / b.pack_size_qty;
      }
      return b.preferred ? 1 : (a.preferred ? -1 : 0);
    });
    
    expect(sortedPrices[0].supplier_name).toBe('Supplier B');
    expect(sortedPrices[0].price_cents).toBe(400);
  });

  it('should return CSV with proper headers and data', async () => {
    const planId = '1';
    
    // Mock order snapshot
    const mockSnapshot = {
      suppliers: [
        {
          supplier_name: 'Test Supplier',
          lines: [
            { name: 'Test Item', qty: 5.0, uom: 'kg', unit_cost: 2.50, line_cost: 12.50 }
          ]
        }
      ]
    };
    
    // Build CSV
    let csv = 'Supplier,Item,Qty,UoM,UnitCost,LineCost\n';
    for (const supplier of mockSnapshot.suppliers) {
      for (const line of supplier.lines) {
        csv += `"${supplier.supplier_name}","${line.name}",${line.qty},"${line.uom}",${line.unit_cost},${line.line_cost}\n`;
      }
    }
    
    expect(csv).toContain('Supplier,Item,Qty,UoM,UnitCost,LineCost');
    expect(csv).toContain('"Test Supplier","Test Item",5,"kg",2.5,12.5');
  });
});
