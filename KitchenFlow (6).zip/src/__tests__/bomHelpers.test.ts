import { describe, it, expect } from 'vitest';
import {
  convertQty,
  netQty,
  explodeRecipe,
  unitCost,
  costRecipePortion,
  type ItemData,
  type RecipeData,
  type SupplierPrice,
  type UomConversion
} from '@/shared/utils/bomHelpers';

describe('BOM Helper Functions', () => {
  // Test data
  const testItem: ItemData = {
    id: 1,
    base_uom: 'kg',
    density_g_per_ml: 1.0,
    each_to_base: 0.5,
    conversions: [
      { from_uom: 'g', to_uom: 'kg', factor: 0.001 },
      { from_uom: 'kg', to_uom: 'g', factor: 1000 }
    ]
  };

  const testItemEach: ItemData = {
    id: 2,
    base_uom: 'ea',
    each_to_base: 1.0,
    conversions: []
  };

  const testSuppliers: SupplierPrice[] = [
    {
      price_cents: 1000, // $10.00
      pack_size_qty: 5,
      pack_size_unit: 'kg',
      preferred: false
    },
    {
      price_cents: 1200, // $12.00
      pack_size_qty: 6,
      pack_size_unit: 'kg',
      preferred: true
    }
  ];

  describe('convertQty', () => {
    it('should handle same unit conversion', () => {
      expect(convertQty(testItem, 5, 'kg', 'kg')).toBe(5);
    });

    it('should handle direct conversion', () => {
      expect(convertQty(testItem, 1000, 'g', 'kg')).toBe(1);
      expect(convertQty(testItem, 1, 'kg', 'g')).toBe(1000);
    });

    it('should handle mass-volume conversion with density', () => {
      expect(convertQty(testItem, 1000, 'ml', 'kg')).toBe(1);
      expect(convertQty(testItem, 1, 'kg', 'ml')).toBe(1000);
    });

    it('should handle each_to_base conversion', () => {
      expect(convertQty(testItemEach, 2, 'ea', 'ea')).toBe(2);
    });

    it('should throw error for impossible conversion', () => {
      expect(() => convertQty(testItem, 1, 'unknown', 'kg')).toThrow();
    });
  });

  describe('netQty', () => {
    it('should calculate net quantity with no losses', () => {
      expect(netQty(1000, 0, 100)).toBe(1000);
    });

    it('should calculate net quantity with trim loss', () => {
      expect(netQty(1000, 10, 100)).toBe(900);
    });

    it('should calculate net quantity with cook yield loss', () => {
      expect(netQty(1000, 0, 80)).toBe(800);
    });

    it('should calculate net quantity with both losses', () => {
      expect(netQty(1000, 10, 80)).toBe(720); // 1000 * 0.9 * 0.8
    });

    it('should handle yield gains (>100%)', () => {
      expect(netQty(1000, 0, 120)).toBe(1200);
    });
  });

  describe('explodeRecipe', () => {
    const simpleRecipe: RecipeData = {
      id: 1,
      name: 'Test Recipe',
      portion_yield: 4,
      bom: [
        {
          id: 1,
          component_type: 'item',
          component_id: 1,
          gross_qty: 1,
          uom: 'kg',
          trim_loss_pct: 0,
          cook_yield_pct: 100
        }
      ]
    };

    const complexRecipe: RecipeData = {
      id: 2,
      name: 'Complex Recipe',
      portion_yield: 2,
      bom: [
        {
          id: 2,
          component_type: 'subrecipe',
          component_id: 1,
          gross_qty: 2,
          uom: 'portion',
          trim_loss_pct: 0,
          cook_yield_pct: 100
        }
      ]
    };

    const allRecipes = new Map([
      [1, simpleRecipe],
      [2, complexRecipe]
    ]);

    const allItems = new Map([
      [1, testItem]
    ]);

    it('should explode simple recipe', () => {
      const result = explodeRecipe(simpleRecipe, 4, allRecipes, allItems);
      expect(result).toHaveLength(1);
      expect(result[0].item_id).toBe(1);
      expect(result[0].net_qty).toBe(1); // 1 kg for 4 portions
      expect(result[0].base_uom).toBe('kg');
    });

    it('should scale recipe correctly', () => {
      const result = explodeRecipe(simpleRecipe, 8, allRecipes, allItems);
      expect(result[0].net_qty).toBe(2); // 2 kg for 8 portions (2x scale)
    });

    it('should explode complex recipe with subrecipes', () => {
      const result = explodeRecipe(complexRecipe, 2, allRecipes, allItems);
      expect(result).toHaveLength(1);
      expect(result[0].item_id).toBe(1);
      expect(result[0].net_qty).toBe(0.5); // 2 portions of complex recipe (yield 2) = 1x scale factor, subrecipe needs 2 portions which scales to 0.5x of simple recipe (yield 4), so 1kg * 0.5 = 0.5kg
    });

    it('should aggregate duplicate items', () => {
      const recipeWithDuplicates: RecipeData = {
        id: 3,
        name: 'Recipe with Duplicates',
        portion_yield: 1,
        bom: [
          {
            id: 3,
            component_type: 'item',
            component_id: 1,
            gross_qty: 0.5,
            uom: 'kg',
            trim_loss_pct: 0,
            cook_yield_pct: 100
          },
          {
            id: 4,
            component_type: 'item',
            component_id: 1,
            gross_qty: 0.3,
            uom: 'kg',
            trim_loss_pct: 0,
            cook_yield_pct: 100
          }
        ]
      };

      const result = explodeRecipe(recipeWithDuplicates, 1, allRecipes, allItems);
      expect(result).toHaveLength(1);
      expect(result[0].net_qty).toBe(0.8); // 0.5 + 0.3
    });

    it('should detect circular dependencies', () => {
      const circularRecipe: RecipeData = {
        id: 10,
        name: 'Circular Recipe',
        portion_yield: 1,
        bom: [
          {
            id: 10,
            component_type: 'subrecipe',
            component_id: 10, // References itself
            gross_qty: 1,
            uom: 'portion',
            trim_loss_pct: 0,
            cook_yield_pct: 100
          }
        ]
      };

      const circularRecipes = new Map([[10, circularRecipe]]);
      
      expect(() => explodeRecipe(circularRecipe, 1, circularRecipes, allItems))
        .toThrow('Circular recipe dependency');
    });
  });

  describe('unitCost', () => {
    it('should use preferred supplier', () => {
      const cost = unitCost(testItem, testSuppliers);
      expect(cost.amount_cents).toBe(200); // $12.00 / 6kg = $2.00/kg
      expect(cost.uom).toBe('kg');
    });

    it('should use lowest cost when no preferred supplier', () => {
      const noPreferredSuppliers = testSuppliers.map(s => ({ ...s, preferred: false }));
      const cost = unitCost(testItem, noPreferredSuppliers);
      expect(cost.amount_cents).toBe(200); // $10.00 / 5kg = $2.00/kg
    });

    it('should throw error when no suppliers', () => {
      expect(() => unitCost(testItem, [])).toThrow('No suppliers found');
    });
  });

  describe('costRecipePortion', () => {
    const allSuppliers = new Map([
      [1, testSuppliers]
    ]);

    it('should calculate recipe cost correctly', () => {
      const simpleRecipe: RecipeData = {
        id: 1,
        name: 'Test Recipe',
        portion_yield: 4,
        bom: [
          {
            id: 1,
            component_type: 'item',
            component_id: 1,
            gross_qty: 2,
            uom: 'kg',
            trim_loss_pct: 0,
            cook_yield_pct: 100
          }
        ]
      };

      const allRecipes = new Map([[1, simpleRecipe]]);
      const allItems = new Map([[1, testItem]]);

      const result = costRecipePortion(simpleRecipe, allRecipes, allItems, allSuppliers);
      
      expect(result.cost_per_portion_cents).toBe(100); // (2kg * $2.00/kg) / 4 portions = $1.00/portion
      expect(result.breakdown).toHaveLength(1);
      expect(result.breakdown[0].item_id).toBe(1);
      expect(result.breakdown[0].qty_base).toBe(0.5); // 2kg / 4 portions = 0.5kg per portion
      expect(result.breakdown[0].unit_cost_cents).toBe(200); // $2.00/kg
      expect(result.breakdown[0].line_cost_cents).toBe(100); // 0.5kg * $2.00/kg = $1.00
    });

    it('should handle recipes with losses', () => {
      const recipeWithLosses: RecipeData = {
        id: 1,
        name: 'Recipe with Losses',
        portion_yield: 1,
        bom: [
          {
            id: 1,
            component_type: 'item',
            component_id: 1,
            gross_qty: 1,
            uom: 'kg',
            trim_loss_pct: 20, // 20% trim loss
            cook_yield_pct: 80  // 80% cook yield
          }
        ]
      };

      const allRecipes = new Map([[1, recipeWithLosses]]);
      const allItems = new Map([[1, testItem]]);

      const result = costRecipePortion(recipeWithLosses, allRecipes, allItems, allSuppliers);
      
      // Net quantity: 1kg * 0.8 * 0.8 = 0.64kg per portion
      // Cost: 0.64kg * $2.00/kg = $1.28
      expect(result.cost_per_portion_cents).toBeCloseTo(128, 0);
      expect(result.breakdown[0].qty_base).toBeCloseTo(0.64, 2);
    });
  });
});
