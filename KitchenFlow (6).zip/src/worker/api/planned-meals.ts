import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const plannedMeals = new Hono<{ Bindings: Env }>();

// Zod schemas for validation
const MealComponentSchema = z.object({
  component_type: z.enum(['main', 'side', 'dessert']),
  component_order: z.number().default(1),
  recipe_id: z.number().positive(),
  portion_count: z.number().positive(),
  notes: z.string().optional(),
});

const CreatePlannedMealSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
  meal_type: z.enum(['lunch', 'dinner']),
  recipe_id: z.number().positive().optional(), // Make optional since we now have components
  portion_count: z.number().positive().optional(), // Make optional
  portion_profile: z.string().default('standard'),
  notes: z.string().optional(),
  // Extended fields for detailed meal planning
  total_portions: z.number().positive().optional(),
  vegetarian_portions: z.number().min(0).default(0),
  same_menu_both_services: z.boolean().default(false),
  lunch_portions: z.number().min(0).default(0),
  lunch_vegetarian: z.number().min(0).default(0), 
  dinner_portions: z.number().min(0).default(0),
  dinner_vegetarian: z.number().min(0).default(0),
  service_time: z.string().optional(),
  // Meal components support
  components: z.array(MealComponentSchema).optional(),
});

const UpdatePlannedMealSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  meal_type: z.enum(['lunch', 'dinner']).optional(),
  recipe_id: z.number().positive().optional(),
  portion_count: z.number().positive().optional(),
  portion_profile: z.string().optional(),
  notes: z.string().optional(),
  // Extended fields for detailed meal planning
  total_portions: z.number().positive().optional(),
  vegetarian_portions: z.number().min(0).optional(),
  same_menu_both_services: z.boolean().optional(),
  lunch_portions: z.number().min(0).optional(),
  lunch_vegetarian: z.number().min(0).optional(),
  dinner_portions: z.number().min(0).optional(),
  dinner_vegetarian: z.number().min(0).optional(),
  service_time: z.string().optional(),
});

// Get all planned meals with components
plannedMeals.get("/", async (c) => {
  const env = c.env;
  const { date_from, date_to } = c.req.query();
  
  try {
    let query = `
      SELECT pm.*, r.name as recipe_name, r.yield_amount, r.yield_unit,
             r.prep_time_minutes, r.hands_on_minutes
      FROM planned_meals pm
      LEFT JOIN recipes r ON pm.recipe_id = r.id
    `;
    
    const params: any[] = [];
    const conditions: string[] = [];
    
    if (date_from) {
      conditions.push("pm.date >= ?");
      params.push(date_from);
    }
    
    if (date_to) {
      conditions.push("pm.date <= ?");
      params.push(date_to);
    }
    
    if (conditions.length > 0) {
      query += " WHERE " + conditions.join(" AND ");
    }
    
    query += " ORDER BY pm.date ASC, pm.meal_type ASC";
    
    const result = await env.DB.prepare(query).bind(...params).all();
    const plannedMeals = result.results as any[];
    
    // Fetch components for each planned meal
    for (const meal of plannedMeals) {
      const componentsResult = await env.DB.prepare(`
        SELECT mc.*, r.name as recipe_name, r.yield_amount, r.yield_unit
        FROM meal_components mc
        JOIN recipes r ON mc.recipe_id = r.id
        WHERE mc.planned_meal_id = ?
        ORDER BY mc.component_type, mc.component_order
      `).bind(meal.id).all();
      
      meal.components = componentsResult.results;
    }
    
    return c.json(plannedMeals);
  } catch (error) {
    console.error("Failed to fetch planned meals:", error);
    return c.json({ error: "Failed to fetch planned meals" }, 500);
  }
});

// Get planned meals for a specific date
plannedMeals.get("/date/:date", async (c) => {
  const date = c.req.param("date");
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(`
      SELECT pm.*, r.name as recipe_name, r.yield_amount, r.yield_unit,
             r.prep_time_minutes, r.hands_on_minutes
      FROM planned_meals pm
      JOIN recipes r ON pm.recipe_id = r.id
      WHERE pm.date = ?
      ORDER BY pm.meal_type ASC
    `).bind(date).all();
    
    return c.json(result.results);
  } catch (error) {
    console.error("Failed to fetch planned meals for date:", error);
    return c.json({ error: "Failed to fetch planned meals" }, 500);
  }
});

// Get single planned meal
plannedMeals.get("/:id", async (c) => {
  const mealId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const meal = await env.DB.prepare(`
      SELECT pm.*, r.name as recipe_name, r.yield_amount, r.yield_unit,
             r.prep_time_minutes, r.hands_on_minutes
      FROM planned_meals pm
      JOIN recipes r ON pm.recipe_id = r.id
      WHERE pm.id = ?
    `).bind(mealId).first();
    
    if (!meal) {
      return c.json({ error: "Planned meal not found" }, 404);
    }

    return c.json(meal);
  } catch (error) {
    console.error("Failed to fetch planned meal:", error);
    return c.json({ error: "Failed to fetch planned meal" }, 500);
  }
});

// Create new planned meal with components
plannedMeals.post("/", zValidator("json", CreatePlannedMealSchema), async (c) => {
  const mealData = c.req.valid("json");
  const env = c.env;
  
  try {
    // Handle both legacy single recipe and new multi-component meals
    if (mealData.components && mealData.components.length > 0) {
      // New multi-component meal
      console.log("Creating multi-component meal with", mealData.components.length, "components");
      
      // Verify all component recipes exist
      for (const component of mealData.components) {
        const recipe = await env.DB.prepare("SELECT id, name, status FROM recipes WHERE id = ? AND status = 'active'").bind(component.recipe_id).first();
        if (!recipe) {
          return c.json({ 
            error: `Recipe with ID ${component.recipe_id} not found or not active`,
            recipe_id: component.recipe_id 
          }, 404);
        }
      }
      
      // Check for existing meal on same date/type
      const existing = await env.DB.prepare(
        "SELECT id FROM planned_meals WHERE date = ? AND meal_type = ?"
      ).bind(mealData.date, mealData.meal_type).first();
      
      if (existing) {
        return c.json({ 
          error: "A meal is already planned for this date and meal type",
          existing_meal_id: existing.id 
        }, 409);
      }

      // Create planned meal with null recipe_id for multi-component meals
      const result = await env.DB.prepare(`
        INSERT INTO planned_meals (
          date, meal_type, recipe_id, portion_count, portion_profile, notes,
          total_portions, vegetarian_portions, service_time, same_menu_both_services,
          lunch_portions, lunch_vegetarian, dinner_portions, dinner_vegetarian,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      `).bind(
        mealData.date,
        mealData.meal_type,
        null, // No single recipe for multi-component meals
        mealData.total_portions || mealData.lunch_portions + mealData.dinner_portions,
        mealData.portion_profile || 'standard',
        mealData.notes || null,
        mealData.total_portions || mealData.lunch_portions + mealData.dinner_portions,
        mealData.vegetarian_portions || 0,
        mealData.service_time || (mealData.meal_type === 'lunch' ? '12:30' : '16:00'),
        mealData.same_menu_both_services || false,
        mealData.lunch_portions || 0,
        mealData.lunch_vegetarian || 0,
        mealData.dinner_portions || 0,
        mealData.dinner_vegetarian || 0
      ).run();

      const plannedMealId = result.meta.last_row_id;

      // Insert meal components
      for (const component of mealData.components) {
        await env.DB.prepare(`
          INSERT INTO meal_components (
            planned_meal_id, component_type, component_order, recipe_id, portion_count, notes,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `).bind(
          plannedMealId,
          component.component_type,
          component.component_order || 1,
          component.recipe_id,
          component.portion_count,
          component.notes || null
        ).run();
      }

      return c.json({ 
        id: plannedMealId,
        message: "Multi-component meal created successfully" 
      }, 201);
      
    } else if (mealData.recipe_id) {
      // Legacy single recipe meal
      console.log("Creating single recipe meal with recipe_id:", mealData.recipe_id);
      
      // Verify recipe exists and is active
      const recipe = await env.DB.prepare("SELECT id, name, status FROM recipes WHERE id = ? AND status = 'active'").bind(mealData.recipe_id).first();
      
      if (!recipe) {
        return c.json({ 
          error: `Recipe with ID ${mealData.recipe_id} not found or not active`,
          recipe_id: mealData.recipe_id
        }, 404);
      }

      // Check for existing meal on same date/type
      const existing = await env.DB.prepare(
        "SELECT id FROM planned_meals WHERE date = ? AND meal_type = ?"
      ).bind(mealData.date, mealData.meal_type).first();
      
      if (existing) {
        return c.json({ 
          error: "A meal is already planned for this date and meal type",
          existing_meal_id: existing.id 
        }, 409);
      }

      const result = await env.DB.prepare(`
        INSERT INTO planned_meals (
          date, meal_type, recipe_id, portion_count, portion_profile, notes,
          total_portions, vegetarian_portions, service_time, same_menu_both_services,
          lunch_portions, lunch_vegetarian, dinner_portions, dinner_vegetarian,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      `).bind(
        mealData.date,
        mealData.meal_type,
        mealData.recipe_id,
        mealData.portion_count || mealData.total_portions,
        mealData.portion_profile || 'standard',
        mealData.notes || null,
        mealData.total_portions || mealData.portion_count,
        mealData.vegetarian_portions || 0,
        mealData.service_time || (mealData.meal_type === 'lunch' ? '12:30' : '16:00'),
        mealData.same_menu_both_services || false,
        mealData.lunch_portions || 0,
        mealData.lunch_vegetarian || 0,
        mealData.dinner_portions || 0,
        mealData.dinner_vegetarian || 0
      ).run();

      return c.json({ 
        id: result.meta.last_row_id,
        message: "Single recipe meal created successfully" 
      }, 201);
    } else {
      return c.json({ error: "Either recipe_id or components must be provided" }, 400);
    }
  } catch (error) {
    console.error("Planned meal creation error:", error);
    return c.json({ 
      error: "Failed to create planned meal", 
      details: error instanceof Error ? error.message : "Unknown error" 
    }, 500);
  }
});

// Update planned meal
plannedMeals.put("/:id", zValidator("json", UpdatePlannedMealSchema), async (c) => {
  const mealId = parseInt(c.req.param("id"));
  const mealData = c.req.valid("json");
  const env = c.env;
  
  try {
    // Build dynamic SQL based on provided fields
    const updates: string[] = [];
    const values: any[] = [];
    
    if (mealData.date !== undefined) {
      updates.push("date = ?");
      values.push(mealData.date);
    }
    
    if (mealData.meal_type !== undefined) {
      updates.push("meal_type = ?");
      values.push(mealData.meal_type);
    }
    
    if (mealData.recipe_id !== undefined) {
      // Verify recipe exists and is active
      const recipe = await env.DB.prepare("SELECT id, name, status FROM recipes WHERE id = ? AND status = 'active'").bind(mealData.recipe_id).first();
      if (!recipe) {
        const inactiveRecipe = await env.DB.prepare("SELECT id, name, status FROM recipes WHERE id = ?").bind(mealData.recipe_id).first();
        if (inactiveRecipe) {
          return c.json({ 
            error: `Recipe "${inactiveRecipe.name}" is not available (status: ${inactiveRecipe.status})`,
            recipe_id: mealData.recipe_id
          }, 404);
        } else {
          return c.json({ 
            error: `Recipe with ID ${mealData.recipe_id} not found`,
            recipe_id: mealData.recipe_id
          }, 404);
        }
      }
      updates.push("recipe_id = ?");
      values.push(mealData.recipe_id);
    }
    
    if (mealData.portion_count !== undefined) {
      updates.push("portion_count = ?");
      values.push(mealData.portion_count);
    }
    
    if (mealData.portion_profile !== undefined) {
      updates.push("portion_profile = ?");
      values.push(mealData.portion_profile);
    }
    
    if (mealData.notes !== undefined) {
      updates.push("notes = ?");
      values.push(mealData.notes);
    }
    
    if (mealData.total_portions !== undefined) {
      updates.push("total_portions = ?");
      values.push(mealData.total_portions);
    }
    
    if (mealData.vegetarian_portions !== undefined) {
      updates.push("vegetarian_portions = ?");
      values.push(mealData.vegetarian_portions);
    }
    
    if (mealData.same_menu_both_services !== undefined) {
      updates.push("same_menu_both_services = ?");
      values.push(mealData.same_menu_both_services);
    }
    
    if (mealData.lunch_portions !== undefined) {
      updates.push("lunch_portions = ?");
      values.push(mealData.lunch_portions);
    }
    
    if (mealData.lunch_vegetarian !== undefined) {
      updates.push("lunch_vegetarian = ?");
      values.push(mealData.lunch_vegetarian);
    }
    
    if (mealData.dinner_portions !== undefined) {
      updates.push("dinner_portions = ?");
      values.push(mealData.dinner_portions);
    }
    
    if (mealData.dinner_vegetarian !== undefined) {
      updates.push("dinner_vegetarian = ?");
      values.push(mealData.dinner_vegetarian);
    }
    
    if (mealData.service_time !== undefined) {
      updates.push("service_time = ?");
      values.push(mealData.service_time);
    }
    
    if (updates.length === 0) {
      return c.json({ error: "No fields to update" }, 400);
    }
    
    updates.push("updated_at = datetime('now')");
    values.push(mealId);
    
    const sql = `UPDATE planned_meals SET ${updates.join(", ")} WHERE id = ?`;
    const result = await env.DB.prepare(sql).bind(...values).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Planned meal not found" }, 404);
    }

    return c.json({ message: "Planned meal updated successfully" });
  } catch (error) {
    console.error("Planned meal update error:", error);
    return c.json({ error: "Failed to update planned meal" }, 500);
  }
});

// Delete planned meal
plannedMeals.delete("/:id", async (c) => {
  const mealId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(
      "DELETE FROM planned_meals WHERE id = ?"
    ).bind(mealId).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Planned meal not found" }, 404);
    }

    return c.json({ message: "Planned meal deleted successfully" });
  } catch (error) {
    console.error("Planned meal deletion error:", error);
    return c.json({ error: "Failed to delete planned meal" }, 500);
  }
});

export default plannedMeals;
