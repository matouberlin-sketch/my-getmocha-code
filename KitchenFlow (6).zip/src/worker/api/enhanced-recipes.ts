import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const enhancedRecipes = new Hono<{ Bindings: Env }>();

// Enhanced recipe schema
const EnhancedRecipeSchema = z.object({
  recipe_id: z.string().min(1),
  name: z.string().min(1),
  type: z.enum(['prep', 'component', 'final']),
  default_yield_qty: z.number().positive(),
  default_yield_uom: z.string().min(1),
  output_item_id: z.string().optional(),
  active_minutes: z.number().min(0).optional(),
  passive_minutes: z.number().min(0).optional(),
  lead_time_hours: z.number().min(0).optional(),
  station: z.string().optional(),
  notes: z.string().optional(),
  ingredients: z.array(z.object({
    line_no: z.number().positive(),
    item_id: z.string().min(1),
    qty: z.number().positive(),
    uom: z.string().min(1),
    scrap_pct: z.number().min(0).max(100).optional(),
    notes: z.string().optional(),
  })).optional(),
  components: z.array(z.object({
    component_recipe_id: z.string().min(1),
    qty: z.number().positive(),
    uom: z.string().min(1),
    notes: z.string().optional(),
  })).optional(),
});

const UpdateEnhancedRecipeSchema = EnhancedRecipeSchema.partial().omit({ recipe_id: true });

// Get all enhanced recipes
enhancedRecipes.get("/", async (c) => {
  const env = c.env;
  const url = new URL(c.req.url);
  
  const typeFilter = url.searchParams.get('type');
  const stationFilter = url.searchParams.get('station');
  const searchQuery = url.searchParams.get('search');
  
  let query = `
    SELECT er.*, 
           COUNT(DISTINCT eri.id) as ingredient_count,
           COUNT(DISTINCT rc.id) as component_count,
           i.name as output_item_name,
           GROUP_CONCAT(DISTINCT rt.tag) as tags
    FROM enhanced_recipes er
    LEFT JOIN enhanced_recipe_ingredients eri ON er.recipe_id = eri.recipe_id
    LEFT JOIN recipe_components rc ON er.recipe_id = rc.parent_recipe_id
    LEFT JOIN items i ON er.output_item_id = i.item_id
    LEFT JOIN recipe_tags rt ON CAST(SUBSTR(er.recipe_id, 3) AS INTEGER) = rt.recipe_id
  `;
  
  const conditions = [];
  const params = [];
  
  if (typeFilter) {
    conditions.push("er.type = ?");
    params.push(typeFilter);
  }
  
  if (stationFilter) {
    conditions.push("er.station = ?");
    params.push(stationFilter);
  }
  
  if (searchQuery) {
    conditions.push("(er.name LIKE ? OR er.recipe_id LIKE ?)");
    params.push(`%${searchQuery}%`, `%${searchQuery}%`);
  }
  
  if (conditions.length > 0) {
    query += " WHERE " + conditions.join(" AND ");
  }
  
  query += " GROUP BY er.id ORDER BY er.created_at DESC";
  
  try {
    const result = await env.DB.prepare(query).bind(...params).all();
    return c.json(result.results);
  } catch (error) {
    console.error("Failed to fetch enhanced recipes:", error);
    return c.json({ error: "Failed to fetch enhanced recipes" }, 500);
  }
});

// Get single enhanced recipe with full details
enhancedRecipes.get("/:recipeId", async (c) => {
  const recipeId = c.req.param("recipeId");
  const env = c.env;
  
  try {
    // Get recipe details
    const recipe = await env.DB.prepare(
      "SELECT * FROM enhanced_recipes WHERE recipe_id = ?"
    ).bind(recipeId).first();
    
    if (!recipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }
    
    // Get ingredients with item details
    const ingredients = await env.DB.prepare(`
      SELECT eri.*, i.name as item_name, i.item_type, i.base_uom, i.allergen_tags
      FROM enhanced_recipe_ingredients eri
      JOIN items i ON eri.item_id = i.item_id
      WHERE eri.recipe_id = ?
      ORDER BY eri.line_no ASC
    `).bind(recipeId).all();
    
    // Get components with recipe details
    const components = await env.DB.prepare(`
      SELECT rc.*, er.name as component_name, er.type as component_type
      FROM recipe_components rc
      JOIN enhanced_recipes er ON rc.component_recipe_id = er.recipe_id
      WHERE rc.parent_recipe_id = ?
      ORDER BY rc.id ASC
    `).bind(recipeId).all();
    
    // Get recipes that use this as a component
    const usedInRecipes = await env.DB.prepare(`
      SELECT rc.parent_recipe_id, er.name as parent_name, er.type as parent_type, rc.qty, rc.uom
      FROM recipe_components rc
      JOIN enhanced_recipes er ON rc.parent_recipe_id = er.recipe_id
      WHERE rc.component_recipe_id = ?
      ORDER BY er.name ASC
    `).bind(recipeId).all();
    
    return c.json({
      ...recipe,
      ingredients: ingredients.results,
      components: components.results,
      used_in_recipes: usedInRecipes.results
    });
  } catch (error) {
    console.error("Failed to fetch enhanced recipe:", error);
    return c.json({ error: "Failed to fetch enhanced recipe" }, 500);
  }
});

// Create new enhanced recipe
enhancedRecipes.post("/", zValidator("json", EnhancedRecipeSchema), async (c) => {
  const recipeData = c.req.valid("json");
  const env = c.env;
  
  try {
    // Create the recipe
    await env.DB.prepare(`
      INSERT INTO enhanced_recipes (
        recipe_id, name, type, default_yield_qty, default_yield_uom,
        output_item_id, active_minutes, passive_minutes, lead_time_hours,
        station, notes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      recipeData.recipe_id,
      recipeData.name,
      recipeData.type,
      recipeData.default_yield_qty,
      recipeData.default_yield_uom,
      recipeData.output_item_id || null,
      recipeData.active_minutes || 0,
      recipeData.passive_minutes || 0,
      recipeData.lead_time_hours || 0,
      recipeData.station || null,
      recipeData.notes || null
    ).run();
    
    // Add ingredients if provided
    if (recipeData.ingredients && recipeData.ingredients.length > 0) {
      for (const ingredient of recipeData.ingredients) {
        await env.DB.prepare(`
          INSERT INTO enhanced_recipe_ingredients (
            recipe_id, line_no, item_id, qty, uom, scrap_pct, notes,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `).bind(
          recipeData.recipe_id,
          ingredient.line_no,
          ingredient.item_id,
          ingredient.qty,
          ingredient.uom,
          ingredient.scrap_pct || 0,
          ingredient.notes || null
        ).run();
      }
    }
    
    // Add components if provided
    if (recipeData.components && recipeData.components.length > 0) {
      for (const component of recipeData.components) {
        await env.DB.prepare(`
          INSERT INTO recipe_components (
            parent_recipe_id, component_recipe_id, qty, uom, notes,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `).bind(
          recipeData.recipe_id,
          component.component_recipe_id,
          component.qty,
          component.uom,
          component.notes || null
        ).run();
      }
    }
    
    return c.json({ 
      message: "Enhanced recipe created successfully",
      recipe_id: recipeData.recipe_id 
    });
  } catch (error) {
    console.error("Enhanced recipe creation error:", error);
    return c.json({ error: "Failed to create enhanced recipe" }, 500);
  }
});

// Update enhanced recipe
enhancedRecipes.put("/:recipeId", zValidator("json", UpdateEnhancedRecipeSchema), async (c) => {
  const recipeId = c.req.param("recipeId");
  const recipeData = c.req.valid("json");
  const env = c.env;
  
  try {
    // Check if recipe exists
    const existingRecipe = await env.DB.prepare(
      "SELECT * FROM enhanced_recipes WHERE recipe_id = ?"
    ).bind(recipeId).first();
    
    if (!existingRecipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }
    
    // Update basic recipe info
    const updates = [];
    const values = [];
    
    Object.entries(recipeData).forEach(([key, value]) => {
      if (value !== undefined && key !== 'ingredients' && key !== 'components') {
        updates.push(`${key} = ?`);
        values.push(value);
      }
    });
    
    if (updates.length > 0) {
      updates.push("updated_at = datetime('now')");
      values.push(recipeId);
      
      await env.DB.prepare(
        `UPDATE enhanced_recipes SET ${updates.join(", ")} WHERE recipe_id = ?`
      ).bind(...values).run();
    }
    
    // Update ingredients if provided
    if (recipeData.ingredients) {
      // Clear existing ingredients
      await env.DB.prepare(
        "DELETE FROM enhanced_recipe_ingredients WHERE recipe_id = ?"
      ).bind(recipeId).run();
      
      // Insert new ingredients
      for (const ingredient of recipeData.ingredients) {
        await env.DB.prepare(`
          INSERT INTO enhanced_recipe_ingredients (
            recipe_id, line_no, item_id, qty, uom, scrap_pct, notes,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `).bind(
          recipeId,
          ingredient.line_no,
          ingredient.item_id,
          ingredient.qty,
          ingredient.uom,
          ingredient.scrap_pct || 0,
          ingredient.notes || null
        ).run();
      }
    }
    
    // Update components if provided
    if (recipeData.components) {
      // Clear existing components
      await env.DB.prepare(
        "DELETE FROM recipe_components WHERE parent_recipe_id = ?"
      ).bind(recipeId).run();
      
      // Insert new components
      for (const component of recipeData.components) {
        await env.DB.prepare(`
          INSERT INTO recipe_components (
            parent_recipe_id, component_recipe_id, qty, uom, notes,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `).bind(
          recipeId,
          component.component_recipe_id,
          component.qty,
          component.uom,
          component.notes || null
        ).run();
      }
    }
    
    return c.json({ message: "Enhanced recipe updated successfully" });
  } catch (error) {
    console.error("Enhanced recipe update error:", error);
    return c.json({ error: "Failed to update enhanced recipe" }, 500);
  }
});

// Calculate recipe costs and yields
enhancedRecipes.get("/:recipeId/costs", async (c) => {
  const recipeId = c.req.param("recipeId");
  const env = c.env;
  
  try {
    // Get recipe with ingredients and components
    const recipe = await env.DB.prepare(
      "SELECT * FROM enhanced_recipes WHERE recipe_id = ?"
    ).bind(recipeId).first();
    
    if (!recipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }
    
    // Calculate ingredient costs
    const ingredientCosts = await env.DB.prepare(`
      SELECT 
        eri.item_id,
        eri.qty,
        eri.uom,
        i.name as item_name,
        MIN(si.price / si.pack_qty) as min_unit_cost,
        AVG(si.price / si.pack_qty) as avg_unit_cost
      FROM enhanced_recipe_ingredients eri
      JOIN items i ON eri.item_id = i.item_id
      LEFT JOIN supplier_items si ON i.item_id = si.item_id
      WHERE eri.recipe_id = ?
      GROUP BY eri.item_id, eri.qty, eri.uom
    `).bind(recipeId).all();
    
    // Calculate component costs (recursive would be complex, simplified here)
    const componentCosts = await env.DB.prepare(`
      SELECT 
        rc.component_recipe_id,
        rc.qty,
        rc.uom,
        er.name as component_name,
        er.type as component_type
      FROM recipe_components rc
      JOIN enhanced_recipes er ON rc.component_recipe_id = er.recipe_id
      WHERE rc.parent_recipe_id = ?
    `).bind(recipeId).all();
    
    return c.json({
      recipe_id: recipeId,
      recipe_name: recipe.name,
      yield_qty: recipe.default_yield_qty,
      yield_uom: recipe.default_yield_uom,
      ingredient_costs: ingredientCosts.results,
      component_costs: componentCosts.results,
      total_active_minutes: recipe.active_minutes,
      total_passive_minutes: recipe.passive_minutes
    });
  } catch (error) {
    console.error("Failed to calculate recipe costs:", error);
    return c.json({ error: "Failed to calculate recipe costs" }, 500);
  }
});

export default enhancedRecipes;
