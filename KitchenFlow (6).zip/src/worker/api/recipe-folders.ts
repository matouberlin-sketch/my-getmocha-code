import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const recipeFolders = new Hono<{ Bindings: Env }>();

// Zod schemas for validation
const CreateFolderSchema = z.object({
  name: z.string().min(1).max(255),
  description: z.string().optional(),
  parent_folder_id: z.number().optional(),
});

const UpdateFolderSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  description: z.string().optional(),
  parent_folder_id: z.number().optional(),
});

const MoveRecipeSchema = z.object({
  recipe_id: z.number(),
  folder_id: z.number().optional(),
});

const UpdateRecipeStatusSchema = z.object({
  recipe_ids: z.array(z.number()),
  status: z.enum(['active', 'draft', 'archived']),
});

// Get all folders with hierarchy
recipeFolders.get("/", async (c) => {
  const env = c.env;
  
  try {
    const folders = await env.DB.prepare(`
      SELECT f.*, 
             COUNT(r.id) as recipe_count,
             COUNT(CASE WHEN r.status = 'active' THEN 1 END) as active_recipes,
             COUNT(CASE WHEN r.status = 'draft' THEN 1 END) as draft_recipes
      FROM recipe_folders f
      LEFT JOIN recipes r ON f.id = r.folder_id
      GROUP BY f.id
      ORDER BY f.parent_folder_id ASC, f.name ASC
    `).all();

    return c.json(folders.results);
  } catch (error) {
    console.error("Failed to fetch folders:", error);
    return c.json({ error: "Failed to fetch folders" }, 500);
  }
});

// Get single folder with recipes
recipeFolders.get("/:id", async (c) => {
  const folderId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const folder = await env.DB.prepare(
      "SELECT * FROM recipe_folders WHERE id = ?"
    ).bind(folderId).first();
    
    if (!folder) {
      return c.json({ error: "Folder not found" }, 404);
    }

    // Get recipes in this folder
    const recipes = await env.DB.prepare(`
      SELECT r.*, 
             COUNT(ri.id) as ingredient_count,
             COUNT(rs.id) as step_count
      FROM recipes r
      LEFT JOIN recipe_ingredients ri ON r.id = ri.recipe_id
      LEFT JOIN recipe_steps rs ON r.id = rs.recipe_id
      WHERE r.folder_id = ?
      GROUP BY r.id
      ORDER BY r.status ASC, r.name ASC
    `).bind(folderId).all();

    // Get subfolders
    const subfolders = await env.DB.prepare(`
      SELECT f.*,
             COUNT(r.id) as recipe_count,
             COUNT(CASE WHEN r.status = 'active' THEN 1 END) as active_recipes
      FROM recipe_folders f
      LEFT JOIN recipes r ON f.id = r.folder_id
      WHERE f.parent_folder_id = ?
      GROUP BY f.id
      ORDER BY f.name ASC
    `).bind(folderId).all();

    return c.json({
      ...folder,
      recipes: recipes.results,
      subfolders: subfolders.results,
    });
  } catch (error) {
    console.error("Failed to fetch folder:", error);
    return c.json({ error: "Failed to fetch folder" }, 500);
  }
});

// Create folder
recipeFolders.post("/", zValidator("json", CreateFolderSchema), async (c) => {
  const { name, description, parent_folder_id } = c.req.valid("json");
  const env = c.env;

  try {
    // Check if parent folder exists
    if (parent_folder_id) {
      const parentFolder = await env.DB.prepare(
        "SELECT id FROM recipe_folders WHERE id = ?"
      ).bind(parent_folder_id).first();
      
      if (!parentFolder) {
        return c.json({ error: "Parent folder not found" }, 404);
      }
    }

    // Create folder
    const result = await env.DB.prepare(`
      INSERT INTO recipe_folders (name, description, parent_folder_id, created_at, updated_at)
      VALUES (?, ?, ?, datetime('now'), datetime('now'))
    `).bind(name, description || null, parent_folder_id || null).run();

    const folderId = result.meta.last_row_id as number;

    // Return created folder
    const newFolder = await env.DB.prepare(
      "SELECT * FROM recipe_folders WHERE id = ?"
    ).bind(folderId).first();

    return c.json({
      id: folderId,
      message: "Folder created successfully",
      folder: newFolder
    });
  } catch (error) {
    console.error("Folder creation error:", error);
    return c.json({ error: "Failed to create folder" }, 500);
  }
});

// Update folder
recipeFolders.put("/:id", zValidator("json", UpdateFolderSchema), async (c) => {
  const folderId = parseInt(c.req.param("id"));
  const { name, description, parent_folder_id } = c.req.valid("json");
  const env = c.env;

  try {
    // Check if folder exists
    const folder = await env.DB.prepare(
      "SELECT * FROM recipe_folders WHERE id = ?"
    ).bind(folderId).first();
    
    if (!folder) {
      return c.json({ error: "Folder not found" }, 404);
    }

    // Check if parent folder exists (if changing)
    if (parent_folder_id && parent_folder_id !== folder.parent_folder_id) {
      const parentFolder = await env.DB.prepare(
        "SELECT id FROM recipe_folders WHERE id = ?"
      ).bind(parent_folder_id).first();
      
      if (!parentFolder) {
        return c.json({ error: "Parent folder not found" }, 404);
      }

      // Prevent circular references
      if (parent_folder_id === folderId) {
        return c.json({ error: "Folder cannot be its own parent" }, 400);
      }
    }

    // Update folder
    await env.DB.prepare(`
      UPDATE recipe_folders 
      SET name = COALESCE(?, name),
          description = COALESCE(?, description),
          parent_folder_id = COALESCE(?, parent_folder_id),
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      name || null,
      description || null,
      parent_folder_id || null,
      folderId
    ).run();

    // Return updated folder
    const updatedFolder = await env.DB.prepare(
      "SELECT * FROM recipe_folders WHERE id = ?"
    ).bind(folderId).first();

    return c.json({
      message: "Folder updated successfully",
      folder: updatedFolder
    });
  } catch (error) {
    console.error("Folder update error:", error);
    return c.json({ error: "Failed to update folder" }, 500);
  }
});

// Delete folder
recipeFolders.delete("/:id", async (c) => {
  const folderId = parseInt(c.req.param("id"));
  const env = c.env;

  try {
    // Check if folder exists
    const folder = await env.DB.prepare(
      "SELECT * FROM recipe_folders WHERE id = ?"
    ).bind(folderId).first();
    
    if (!folder) {
      return c.json({ error: "Folder not found" }, 404);
    }

    // Check if folder has subfolders
    const subfolders = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM recipe_folders WHERE parent_folder_id = ?"
    ).bind(folderId).first<{ count: number }>();
    
    if (subfolders?.count && subfolders.count > 0) {
      return c.json({ 
        error: "Cannot delete folder with subfolders. Move or delete subfolders first.",
        subfolder_count: subfolders.count
      }, 409);
    }

    // Check if folder has recipes
    const recipes = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM recipes WHERE folder_id = ?"
    ).bind(folderId).first<{ count: number }>();
    
    if (recipes?.count && recipes.count > 0) {
      return c.json({ 
        error: "Cannot delete folder with recipes. Move recipes to another folder first.",
        recipe_count: recipes.count
      }, 409);
    }

    // Delete folder
    await env.DB.prepare("DELETE FROM recipe_folders WHERE id = ?").bind(folderId).run();

    return c.json({ message: "Folder deleted successfully" });
  } catch (error) {
    console.error("Folder deletion error:", error);
    return c.json({ error: "Failed to delete folder" }, 500);
  }
});

// Move recipe to folder
recipeFolders.post("/move-recipe", zValidator("json", MoveRecipeSchema), async (c) => {
  const { recipe_id, folder_id } = c.req.valid("json");
  const env = c.env;

  try {
    // Check if recipe exists
    const recipe = await env.DB.prepare(
      "SELECT * FROM recipes WHERE id = ?"
    ).bind(recipe_id).first();
    
    if (!recipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }

    // Check if folder exists (if moving to a folder)
    if (folder_id) {
      const folder = await env.DB.prepare(
        "SELECT * FROM recipe_folders WHERE id = ?"
      ).bind(folder_id).first();
      
      if (!folder) {
        return c.json({ error: "Folder not found" }, 404);
      }
    }

    // Move recipe
    await env.DB.prepare(`
      UPDATE recipes 
      SET folder_id = ?, updated_at = datetime('now')
      WHERE id = ?
    `).bind(folder_id || null, recipe_id).run();

    return c.json({ 
      message: folder_id ? "Recipe moved to folder" : "Recipe moved to root"
    });
  } catch (error) {
    console.error("Recipe move error:", error);
    return c.json({ error: "Failed to move recipe" }, 500);
  }
});

// Update recipe status (shortlist management)
recipeFolders.post("/update-status", zValidator("json", UpdateRecipeStatusSchema), async (c) => {
  const { recipe_ids, status } = c.req.valid("json");
  const env = c.env;

  try {
    if (recipe_ids.length === 0) {
      return c.json({ error: "No recipes specified" }, 400);
    }

    // Update recipe statuses
    const placeholders = recipe_ids.map(() => '?').join(',');
    await env.DB.prepare(`
      UPDATE recipes 
      SET status = ?, updated_at = datetime('now')
      WHERE id IN (${placeholders})
    `).bind(status, ...recipe_ids).run();

    const statusMessages = {
      'active': 'added to shortlist',
      'draft': 'moved to drafts',
      'archived': 'archived'
    };

    return c.json({ 
      message: `${recipe_ids.length} recipe(s) ${statusMessages[status]}`,
      updated_count: recipe_ids.length
    });
  } catch (error) {
    console.error("Recipe status update error:", error);
    return c.json({ error: "Failed to update recipe status" }, 500);
  }
});

// Get recipes by status
recipeFolders.get("/status/:status", async (c) => {
  const status = c.req.param("status");
  const env = c.env;

  try {
    const recipes = await env.DB.prepare(`
      SELECT r.*, 
             f.name as folder_name,
             COUNT(ri.id) as ingredient_count,
             COUNT(rs.id) as step_count
      FROM recipes r
      LEFT JOIN recipe_folders f ON r.folder_id = f.id
      LEFT JOIN recipe_ingredients ri ON r.id = ri.recipe_id
      LEFT JOIN recipe_steps rs ON r.id = rs.recipe_id
      WHERE r.status = ?
      GROUP BY r.id
      ORDER BY r.updated_at DESC
    `).bind(status).all();

    return c.json(recipes.results);
  } catch (error) {
    console.error("Failed to fetch recipes by status:", error);
    return c.json({ error: "Failed to fetch recipes" }, 500);
  }
});

export default recipeFolders;
