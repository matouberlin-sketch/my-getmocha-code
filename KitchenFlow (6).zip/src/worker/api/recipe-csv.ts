import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const recipeCsv = new Hono<{ Bindings: Env }>();

// CSV Import Schema
const ImportCsvSchema = z.object({
  csv_data: z.string(),
  validate_only: z.boolean().default(false)
});

// Helper function to escape CSV values
function escapeCsvValue(value: any): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

// Helper function to parse CSV
function parseCsv(csvText: string): any[] {
  const lines = csvText.split('\n').map(line => line.trim()).filter(line => line);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());
  const rows: any[] = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line) continue;

    // Simple CSV parsing - handles quoted values
    const values: string[] = [];
    let currentValue = '';
    let inQuotes = false;
    
    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      
      if (char === '"') {
        if (inQuotes && line[j + 1] === '"') {
          currentValue += '"';
          j++; // skip next quote
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        values.push(currentValue.trim());
        currentValue = '';
      } else {
        currentValue += char;
      }
    }
    values.push(currentValue.trim());

    // Create row object
    const row: any = {};
    headers.forEach((header, index) => {
      row[header] = values[index] || '';
    });
    rows.push(row);
  }

  return rows;
}

// Helper function to group CSV rows by recipe with comprehensive parsing
function groupRecipeRows(rows: any[]): any[] {
  const recipeGroups = new Map();

  rows.forEach(row => {
    const recipeName = row.recipe_name?.trim();
    if (!recipeName) return;

    if (!recipeGroups.has(recipeName)) {
      recipeGroups.set(recipeName, {
        name: recipeName,
        description: row.description || '',
        yield_amount: parseFloat(row.yield_amount) || 4,
        yield_unit: row.yield_unit || 'servings',
        prep_time_minutes: row.prep_time_minutes ? parseInt(row.prep_time_minutes) : null,
        hands_on_minutes: row.hands_on_minutes ? parseInt(row.hands_on_minutes) : null,
        lead_time_hours: row.lead_time_hours ? parseInt(row.lead_time_hours) : 0,
        station: row.station || null,
        notes: row.notes || '',
        tags: row.tags ? row.tags.split('|').map((t: string) => t.trim()).filter(Boolean) : [],
        steps: [],
        cookingSteps: [],
        ingredients: []
      });
    }

    const recipe = recipeGroups.get(recipeName);
    
    // Parse steps (avoiding duplicates)
    if (row.step_number && row.step_instruction?.trim()) {
      const stepExists = recipe.steps.some((s: any) => s.step_number === parseInt(row.step_number));
      if (!stepExists) {
        recipe.steps.push({
          step_number: parseInt(row.step_number),
          instruction: row.step_instruction.trim()
        });
      }
    }
    
    // Parse cooking steps (avoiding duplicates)
    if (row.cooking_step_number && row.cooking_equipment?.trim() && row.cooking_method?.trim()) {
      const cookingStepExists = recipe.cookingSteps.some((cs: any) => cs.step_number === parseInt(row.cooking_step_number));
      if (!cookingStepExists) {
        recipe.cookingSteps.push({
          step_number: parseInt(row.cooking_step_number),
          equipment: row.cooking_equipment.trim(),
          method: row.cooking_method.trim(),
          temperature: row.cooking_temperature || null,
          duration: row.cooking_duration || null,
          notes: row.cooking_notes || null,
          process: row.cooking_process || null,
          timing: row.cooking_timing_type || 'sequential'
        });
      }
    }
    
    // Parse ingredients
    if (row.ingredient_name?.trim() && row.ingredient_amount && row.ingredient_unit) {
      recipe.ingredients.push({
        ingredient_name: row.ingredient_name.trim(),
        amount: parseFloat(row.ingredient_amount),
        unit: row.ingredient_unit.trim(),
        notes: row.ingredient_notes || null,
        is_subrecipe: row.ingredient_is_subrecipe === 'true',
        weight_grams: row.ingredient_weight_grams ? parseInt(row.ingredient_weight_grams) : null,
        ingredient_order: row.ingredient_order ? parseInt(row.ingredient_order) : 1
      });
    }
  });

  // Sort steps and ingredients by their order
  recipeGroups.forEach(recipe => {
    recipe.steps.sort((a: any, b: any) => a.step_number - b.step_number);
    recipe.cookingSteps.sort((a: any, b: any) => a.step_number - b.step_number);
    recipe.ingredients.sort((a: any, b: any) => a.ingredient_order - b.ingredient_order);
  });

  return Array.from(recipeGroups.values());
}

// Get CSV template
recipeCsv.get("/template", async () => {
  const headers = [
    // Basic Recipe Info
    'recipe_name',
    'description', 
    'yield_amount',
    'yield_unit',
    'prep_time_minutes',
    'hands_on_minutes',
    'lead_time_hours',
    'station',
    'notes',
    'tags', // pipe-separated (e.g., "pasta|dinner|vegetarian")
    
    // Step Instructions
    'step_number',
    'step_instruction',
    
    // Cooking Methods
    'cooking_step_number',
    'cooking_equipment',
    'cooking_method',
    'cooking_temperature',
    'cooking_duration',
    'cooking_notes',
    'cooking_process',
    'cooking_timing_type', // sequential, parallel
    
    // Ingredients
    'ingredient_order',
    'ingredient_name',
    'ingredient_amount',
    'ingredient_unit',
    'ingredient_notes',
    'ingredient_is_subrecipe', // true/false for sub-recipes
    'ingredient_weight_grams' // calculated weight
  ];

  const sampleData = [
    // First ingredient row with full recipe info and first step/cooking step
    {
      recipe_name: 'Pan-Seared Chicken with Lemon Sauce',
      description: 'Juicy chicken breast with a bright lemon pan sauce',
      yield_amount: '4',
      yield_unit: 'servings',
      prep_time_minutes: '15',
      hands_on_minutes: '25',
      lead_time_hours: '0',
      station: 'hot kitchen',
      notes: 'Best served immediately. Can prepare sauce ahead of time.',
      tags: 'chicken|dinner|protein|quick|lemon',
      step_number: '1',
      step_instruction: 'Season chicken breasts with salt and pepper on both sides',
      cooking_step_number: '1',
      cooking_equipment: 'large skillet',
      cooking_method: 'sear',
      cooking_temperature: 'medium-high heat',
      cooking_duration: '6-8 minutes per side',
      cooking_notes: 'Don\'t move chicken until ready to flip',
      cooking_process: 'protein cooking',
      cooking_timing_type: 'active',
      ingredient_order: '1',
      ingredient_name: 'Chicken breast',
      ingredient_amount: '4',
      ingredient_unit: 'piece',
      ingredient_notes: 'boneless, skinless, pounded to even thickness',
      ingredient_is_subrecipe: 'false',
      ingredient_weight_grams: '800'
    },
    // Second step and cooking step with next ingredient
    {
      recipe_name: 'Pan-Seared Chicken with Lemon Sauce',
      description: 'Juicy chicken breast with a bright lemon pan sauce',
      yield_amount: '4',
      yield_unit: 'servings',
      prep_time_minutes: '15',
      hands_on_minutes: '25',
      lead_time_hours: '0',
      station: 'hot kitchen',
      notes: 'Best served immediately. Can prepare sauce ahead of time.',
      tags: 'chicken|dinner|protein|quick|lemon',
      step_number: '2',
      step_instruction: 'Heat oil in large skillet over medium-high heat',
      cooking_step_number: '2',
      cooking_equipment: 'same skillet',
      cooking_method: 'sauté',
      cooking_temperature: 'medium heat',
      cooking_duration: '2-3 minutes',
      cooking_notes: 'Reduce heat to prevent burning',
      cooking_process: 'sauce making',
      cooking_timing_type: 'active',
      ingredient_order: '2',
      ingredient_name: 'Olive oil',
      ingredient_amount: '2',
      ingredient_unit: 'tbsp',
      ingredient_notes: 'extra virgin',
      ingredient_is_subrecipe: 'false',
      ingredient_weight_grams: '28'
    },
    // Third step with more ingredients
    {
      recipe_name: 'Pan-Seared Chicken with Lemon Sauce',
      description: 'Juicy chicken breast with a bright lemon pan sauce',
      yield_amount: '4',
      yield_unit: 'servings',
      prep_time_minutes: '15',
      hands_on_minutes: '25',
      lead_time_hours: '0',
      station: 'hot kitchen',
      notes: 'Best served immediately. Can prepare sauce ahead of time.',
      tags: 'chicken|dinner|protein|quick|lemon',
      step_number: '3',
      step_instruction: 'Add chicken to hot skillet and sear until golden brown',
      cooking_step_number: '3',
      cooking_equipment: 'same skillet',
      cooking_method: 'rest',
      cooking_temperature: 'room temperature',
      cooking_duration: '5 minutes',
      cooking_notes: 'Let chicken rest before slicing',
      cooking_process: 'resting',
      cooking_timing_type: 'passive',
      ingredient_order: '3',
      ingredient_name: 'Lemon',
      ingredient_amount: '2',
      ingredient_unit: 'piece',
      ingredient_notes: 'juiced, reserve zest',
      ingredient_is_subrecipe: 'false',
      ingredient_weight_grams: '160'
    },
    // Additional ingredients without repeating all recipe info
    {
      recipe_name: 'Pan-Seared Chicken with Lemon Sauce',
      description: '',
      yield_amount: '',
      yield_unit: '',
      prep_time_minutes: '',
      hands_on_minutes: '',
      lead_time_hours: '',
      station: '',
      notes: '',
      tags: '',
      step_number: '',
      step_instruction: '',
      cooking_step_number: '',
      cooking_equipment: '',
      cooking_method: '',
      cooking_temperature: '',
      cooking_duration: '',
      cooking_notes: '',
      cooking_process: '',
      cooking_timing_type: '',
      ingredient_order: '4',
      ingredient_name: 'Butter',
      ingredient_amount: '2',
      ingredient_unit: 'tbsp',
      ingredient_notes: 'unsalted',
      ingredient_is_subrecipe: 'false',
      ingredient_weight_grams: '28'
    },
    {
      recipe_name: 'Pan-Seared Chicken with Lemon Sauce',
      description: '',
      yield_amount: '',
      yield_unit: '',
      prep_time_minutes: '',
      hands_on_minutes: '',
      lead_time_hours: '',
      station: '',
      notes: '',
      tags: '',
      step_number: '',
      step_instruction: '',
      cooking_step_number: '',
      cooking_equipment: '',
      cooking_method: '',
      cooking_temperature: '',
      cooking_duration: '',
      cooking_notes: '',
      cooking_process: '',
      cooking_timing_type: '',
      ingredient_order: '5',
      ingredient_name: 'Garlic',
      ingredient_amount: '3',
      ingredient_unit: 'clove',
      ingredient_notes: 'minced',
      ingredient_is_subrecipe: 'false',
      ingredient_weight_grams: '9'
    },
    // Example with sub-recipe
    {
      recipe_name: 'Pasta with House Marinara',
      description: 'Fresh pasta with our signature marinara sauce',
      yield_amount: '6',
      yield_unit: 'servings',
      prep_time_minutes: '10',
      hands_on_minutes: '15',
      lead_time_hours: '0',
      station: 'pasta station',
      notes: 'Ensure marinara is hot before combining with pasta',
      tags: 'pasta|vegetarian|italian|sauce',
      step_number: '1',
      step_instruction: 'Bring large pot of salted water to boil',
      cooking_step_number: '1',
      cooking_equipment: 'large pot',
      cooking_method: 'boil',
      cooking_temperature: 'rolling boil',
      cooking_duration: '8-10 minutes',
      cooking_notes: 'Cook until al dente',
      cooking_process: 'pasta cooking',
      cooking_timing_type: 'active',
      ingredient_order: '1',
      ingredient_name: 'Fresh Pasta',
      ingredient_amount: '500',
      ingredient_unit: 'g',
      ingredient_notes: 'house-made linguine',
      ingredient_is_subrecipe: 'false',
      ingredient_weight_grams: '500'
    },
    {
      recipe_name: 'Pasta with House Marinara',
      description: '',
      yield_amount: '',
      yield_unit: '',
      prep_time_minutes: '',
      hands_on_minutes: '',
      lead_time_hours: '',
      station: '',
      notes: '',
      tags: '',
      step_number: '2',
      step_instruction: 'Heat marinara sauce in separate pan',
      cooking_step_number: '2',
      cooking_equipment: 'saucepan',
      cooking_method: 'simmer',
      cooking_temperature: 'low heat',
      cooking_duration: '5 minutes',
      cooking_notes: 'Stir occasionally',
      cooking_process: 'sauce heating',
      cooking_timing_type: 'active',
      ingredient_order: '2',
      ingredient_name: 'House Marinara Sauce',
      ingredient_amount: '2',
      ingredient_unit: 'cup',
      ingredient_notes: 'from marinara recipe',
      ingredient_is_subrecipe: 'true',
      ingredient_weight_grams: '480'
    }
  ];

  let csvContent = headers.join(',') + '\n';
  sampleData.forEach(row => {
    const values = headers.map(header => escapeCsvValue(row[header as keyof typeof row] || ''));
    csvContent += values.join(',') + '\n';
  });

  return new Response(csvContent, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="comprehensive_recipe_template.csv"'
    }
  });
});

// Export recipes as CSV
recipeCsv.get("/export", async (c) => {
  const env = c.env;
  const recipeIds = c.req.query('ids')?.split(',').map(Number).filter(Boolean);
  
  try {
    let query = `
      SELECT r.*, 
             GROUP_CONCAT(DISTINCT rt.tag, '|') as tags_concat,
             GROUP_CONCAT(DISTINCT rs.instruction, '|') as steps_concat
      FROM recipes r
      LEFT JOIN recipe_tags rt ON r.id = rt.recipe_id
      LEFT JOIN recipe_steps rs ON r.id = rs.recipe_id
    `;
    
    let params: any[] = [];
    
    if (recipeIds && recipeIds.length > 0) {
      query += ` WHERE r.id IN (${recipeIds.map(() => '?').join(',')})`;
      params = recipeIds;
    }
    
    query += ` GROUP BY r.id ORDER BY r.name`;

    const recipes = await env.DB.prepare(query).bind(...params).all();

    // Get ingredients for all recipes
    const allIngredients = await env.DB.prepare(`
      SELECT ri.*, 
             i.name as ingredient_name,
             r_sub.name as subrecipe_name
      FROM recipe_ingredients ri
      LEFT JOIN ingredients i ON ri.ingredient_id = i.id
      LEFT JOIN recipes r_sub ON ri.subrecipe_id = r_sub.id
      ${recipeIds && recipeIds.length > 0 ? 
        `WHERE ri.recipe_id IN (${recipeIds.map(() => '?').join(',')})` : ''}
      ORDER BY ri.recipe_id, ri.ingredient_order
    `).bind(...(recipeIds || [])).all();

    // Get steps for all recipes
    const allSteps = await env.DB.prepare(`
      SELECT * FROM recipe_steps 
      ${recipeIds && recipeIds.length > 0 ? 
        `WHERE recipe_id IN (${recipeIds.map(() => '?').join(',')})` : ''}
      ORDER BY recipe_id, step_number
    `).bind(...(recipeIds || [])).all();

    // Get cooking steps for all recipes
    const allCookingSteps = await env.DB.prepare(`
      SELECT * FROM recipe_cooking_steps 
      ${recipeIds && recipeIds.length > 0 ? 
        `WHERE recipe_id IN (${recipeIds.map(() => '?').join(',')})` : ''}
      ORDER BY recipe_id, step_number
    `).bind(...(recipeIds || [])).all();

    // Group ingredients by recipe ID
    const ingredientsByRecipe = new Map();
    allIngredients.results.forEach((ingredient: any) => {
      if (!ingredientsByRecipe.has(ingredient.recipe_id)) {
        ingredientsByRecipe.set(ingredient.recipe_id, []);
      }
      ingredientsByRecipe.get(ingredient.recipe_id).push(ingredient);
    });

    // Group steps by recipe ID
    const stepsByRecipe = new Map();
    allSteps.results.forEach((step: any) => {
      if (!stepsByRecipe.has(step.recipe_id)) {
        stepsByRecipe.set(step.recipe_id, []);
      }
      stepsByRecipe.get(step.recipe_id).push(step);
    });

    // Group cooking steps by recipe ID
    const cookingStepsByRecipe = new Map();
    allCookingSteps.results.forEach((cookingStep: any) => {
      if (!cookingStepsByRecipe.has(cookingStep.recipe_id)) {
        cookingStepsByRecipe.set(cookingStep.recipe_id, []);
      }
      cookingStepsByRecipe.get(cookingStep.recipe_id).push(cookingStep);
    });

    // Generate CSV headers - comprehensive format
    const headers = [
      // Basic Recipe Info
      'recipe_name',
      'description',
      'yield_amount', 
      'yield_unit',
      'prep_time_minutes',
      'hands_on_minutes',
      'lead_time_hours',
      'station',
      'notes',
      'tags', // pipe-separated
      
      // Step Instructions
      'step_number',
      'step_instruction',
      
      // Cooking Methods
      'cooking_step_number',
      'cooking_equipment',
      'cooking_method',
      'cooking_temperature',
      'cooking_duration',
      'cooking_notes',
      'cooking_process',
      'cooking_timing_type',
      
      // Ingredients
      'ingredient_order',
      'ingredient_name',
      'ingredient_amount',
      'ingredient_unit',
      'ingredient_notes',
      'ingredient_is_subrecipe',
      'ingredient_weight_grams'
    ];

    let csvContent = headers.join(',') + '\n';

    // Generate CSV rows - comprehensive format
    recipes.results.forEach((recipe: any) => {
      const ingredients = ingredientsByRecipe.get(recipe.id) || [];
      const steps = stepsByRecipe.get(recipe.id) || [];
      const cookingSteps = cookingStepsByRecipe.get(recipe.id) || [];
      
      // Create all combinations of data - we need one row per ingredient
      // but also need to capture all steps and cooking steps
      const maxRows = Math.max(ingredients.length, 1); // At least one row per recipe
      
      for (let i = 0; i < maxRows; i++) {
        const ingredient = ingredients[i];
        
        // Find corresponding step and cooking step for this row
        let step = null;
        let cookingStep = null;
        
        // Distribute steps and cooking steps across ingredient rows
        if (i < steps.length) {
          step = steps[i];
        }
        if (i < cookingSteps.length) {
          cookingStep = cookingSteps[i];
        }
        
        const rowData = {
          // Basic recipe info (only on first row to avoid repetition)
          recipe_name: recipe.name,
          description: i === 0 ? (recipe.description || '') : '',
          yield_amount: i === 0 ? recipe.yield_amount : '',
          yield_unit: i === 0 ? recipe.yield_unit : '',
          prep_time_minutes: i === 0 ? (recipe.prep_time_minutes || '') : '',
          hands_on_minutes: i === 0 ? (recipe.hands_on_minutes || '') : '',
          lead_time_hours: i === 0 ? (recipe.lead_time_hours || '') : '',
          station: i === 0 ? (recipe.station || '') : '',
          notes: i === 0 ? (recipe.notes || '') : '',
          tags: i === 0 ? (recipe.tags_concat || '') : '',
          
          // Step info
          step_number: step ? step.step_number : '',
          step_instruction: step ? step.instruction : '',
          
          // Cooking step info
          cooking_step_number: cookingStep ? cookingStep.step_number : '',
          cooking_equipment: cookingStep ? cookingStep.equipment : '',
          cooking_method: cookingStep ? cookingStep.method : '',
          cooking_temperature: cookingStep ? cookingStep.temperature : '',
          cooking_duration: cookingStep ? cookingStep.duration : '',
          cooking_notes: cookingStep ? cookingStep.notes : '',
          cooking_process: cookingStep ? cookingStep.process : '',
          cooking_timing_type: cookingStep ? cookingStep.timing : '',
          
          // Ingredient info
          ingredient_order: ingredient ? ingredient.ingredient_order : '',
          ingredient_name: ingredient ? (ingredient.ingredient_name || ingredient.subrecipe_name || '') : '',
          ingredient_amount: ingredient ? ingredient.amount : '',
          ingredient_unit: ingredient ? ingredient.unit : '',
          ingredient_notes: ingredient ? (ingredient.notes || '') : '',
          ingredient_is_subrecipe: ingredient ? (ingredient.subrecipe_id ? 'true' : 'false') : '',
          ingredient_weight_grams: ingredient ? (ingredient.weight_grams || '') : ''
        };

        const values = headers.map(header => escapeCsvValue(rowData[header as keyof typeof rowData] || ''));
        csvContent += values.join(',') + '\n';
      }
      
      // Add any remaining steps that didn't fit with ingredients
      for (let i = ingredients.length; i < steps.length; i++) {
        const step = steps[i];
        const cookingStep = cookingSteps[i];
        
        const rowData = {
          recipe_name: recipe.name,
          description: '',
          yield_amount: '',
          yield_unit: '',
          prep_time_minutes: '',
          hands_on_minutes: '',
          lead_time_hours: '',
          station: '',
          notes: '',
          tags: '',
          step_number: step.step_number,
          step_instruction: step.instruction,
          cooking_step_number: cookingStep ? cookingStep.step_number : '',
          cooking_equipment: cookingStep ? cookingStep.equipment : '',
          cooking_method: cookingStep ? cookingStep.method : '',
          cooking_temperature: cookingStep ? cookingStep.temperature : '',
          cooking_duration: cookingStep ? cookingStep.duration : '',
          cooking_notes: cookingStep ? cookingStep.notes : '',
          cooking_process: cookingStep ? cookingStep.process : '',
          cooking_timing_type: cookingStep ? cookingStep.timing : '',
          ingredient_order: '',
          ingredient_name: '',
          ingredient_amount: '',
          ingredient_unit: '',
          ingredient_notes: '',
          ingredient_is_subrecipe: '',
          ingredient_weight_grams: ''
        };
        
        const values = headers.map(header => escapeCsvValue(rowData[header as keyof typeof rowData] || ''));
        csvContent += values.join(',') + '\n';
      }
      
      // Add any remaining cooking steps
      for (let i = Math.max(ingredients.length, steps.length); i < cookingSteps.length; i++) {
        const cookingStep = cookingSteps[i];
        
        const rowData = {
          recipe_name: recipe.name,
          description: '',
          yield_amount: '',
          yield_unit: '',
          prep_time_minutes: '',
          hands_on_minutes: '',
          lead_time_hours: '',
          station: '',
          notes: '',
          tags: '',
          step_number: '',
          step_instruction: '',
          cooking_step_number: cookingStep.step_number,
          cooking_equipment: cookingStep.equipment,
          cooking_method: cookingStep.method,
          cooking_temperature: cookingStep.temperature || '',
          cooking_duration: cookingStep.duration || '',
          cooking_notes: cookingStep.notes || '',
          cooking_process: cookingStep.process || '',
          cooking_timing_type: cookingStep.timing,
          ingredient_order: '',
          ingredient_name: '',
          ingredient_amount: '',
          ingredient_unit: '',
          ingredient_notes: '',
          ingredient_is_subrecipe: '',
          ingredient_weight_grams: ''
        };
        
        const values = headers.map(header => escapeCsvValue(rowData[header as keyof typeof rowData] || ''));
        csvContent += values.join(',') + '\n';
      }
    });

    const filename = recipeIds && recipeIds.length === 1 
      ? `recipe_${String(recipes.results[0]?.name || 'export').replace(/[^a-zA-Z0-9]/g, '_')}.csv`
      : `recipes_export_${new Date().toISOString().split('T')[0]}.csv`;

    return new Response(csvContent, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="${filename}"`
      }
    });
  } catch (error) {
    console.error("CSV export error:", error);
    return c.json({ error: "Failed to export recipes" }, 500);
  }
});

// Validate or import CSV
recipeCsv.post("/import", zValidator("json", ImportCsvSchema), async (c) => {
  const { csv_data, validate_only } = c.req.valid("json");
  const env = c.env;

  try {
    const rows = parseCsv(csv_data);
    if (rows.length === 0) {
      return c.json({ error: "No data found in CSV" }, 400);
    }

    // Validate required headers
    const requiredHeaders = ['recipe_name', 'ingredient_name', 'ingredient_amount', 'ingredient_unit'];
    const firstRow = rows[0];
    const missingHeaders = requiredHeaders.filter(header => !firstRow.hasOwnProperty(header));
    
    if (missingHeaders.length > 0) {
      return c.json({ 
        error: `Missing required columns: ${missingHeaders.join(', ')}. Please use the comprehensive template.`,
        required_headers: requiredHeaders,
        available_headers: Object.keys(firstRow)
      }, 400);
    }

    // Group and validate recipes
    const recipes = groupRecipeRows(rows);
    const validationErrors: string[] = [];
    const validatedRecipes: any[] = [];

    recipes.forEach((recipe, index) => {
      const errors: string[] = [];
      
      // Validate basic recipe data
      if (!recipe.name?.trim()) {
        errors.push(`Recipe ${index + 1}: Missing recipe name`);
      }
      
      if (!recipe.yield_amount || recipe.yield_amount <= 0) {
        errors.push(`Recipe "${recipe.name}": Invalid yield amount`);
      }
      
      if (!recipe.yield_unit?.trim()) {
        errors.push(`Recipe "${recipe.name}": Missing yield unit`);
      }

      if (recipe.ingredients.length === 0) {
        errors.push(`Recipe "${recipe.name}": No ingredients found`);
      }

      // Validate ingredients
      recipe.ingredients.forEach((ingredient: any, ingIndex: number) => {
        if (!ingredient.ingredient_name?.trim()) {
          errors.push(`Recipe "${recipe.name}", ingredient ${ingIndex + 1}: Missing ingredient name`);
        }
        
        if (!ingredient.amount || isNaN(ingredient.amount) || ingredient.amount <= 0) {
          errors.push(`Recipe "${recipe.name}", ingredient "${ingredient.ingredient_name}": Invalid amount`);
        }
        
        if (!ingredient.unit?.trim()) {
          errors.push(`Recipe "${recipe.name}", ingredient "${ingredient.ingredient_name}": Missing unit`);
        }
      });

      // Validate steps if present
      if (recipe.steps.length === 0 && recipe.cookingSteps.length === 0) {
        errors.push(`Recipe "${recipe.name}": No cooking instructions found. Add either step_instruction or cooking_method columns.`);
      }

      if (errors.length > 0) {
        validationErrors.push(...errors);
      } else {
        validatedRecipes.push(recipe);
      }
    });

    if (validate_only) {
      return c.json({
        valid: validationErrors.length === 0,
        errors: validationErrors,
        recipes_found: recipes.length,
        valid_recipes: validatedRecipes.length,
        preview: validatedRecipes.slice(0, 3) // Show first 3 as preview
      });
    }

    // If there are validation errors, return them without importing
    if (validationErrors.length > 0) {
      return c.json({
        valid: false,
        errors: validationErrors,
        message: "Validation failed. Please fix errors and try again."
      }, 400);
    }

    // Import the recipes
    const importedRecipes: any[] = [];
    
    for (const recipe of validatedRecipes) {
      try {
        // Create the recipe
        const recipeResult = await env.DB.prepare(`
          INSERT INTO recipes (
            name, description, yield_amount, yield_unit,
            prep_time_minutes, hands_on_minutes, notes,
            status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', datetime('now'), datetime('now'))
        `).bind(
          recipe.name,
          recipe.description,
          recipe.yield_amount,
          recipe.yield_unit,
          recipe.prep_time_minutes,
          recipe.hands_on_minutes,
          recipe.notes
        ).run();

        const recipeId = recipeResult.meta.last_row_id as number;

        // Create ingredients
        for (let i = 0; i < recipe.ingredients.length; i++) {
          const ingredient = recipe.ingredients[i];
          
          // Find or create ingredient
          let ingredientId = null;
          const existing = await env.DB.prepare(
            "SELECT id FROM ingredients WHERE LOWER(name) = LOWER(?)"
          ).bind(ingredient.ingredient_name.trim()).first();
          
          if (existing) {
            ingredientId = existing.id;
          } else {
            const newIngredient = await env.DB.prepare(`
              INSERT INTO ingredients (name, unit_type, created_at, updated_at)
              VALUES (?, 'count', datetime('now'), datetime('now'))
            `).bind(ingredient.ingredient_name.trim()).run();
            ingredientId = newIngredient.meta.last_row_id;
          }

          // Insert recipe ingredient
          await env.DB.prepare(`
            INSERT INTO recipe_ingredients (
              recipe_id, ingredient_id, amount, unit, notes,
              ingredient_order, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            recipeId,
            ingredientId,
            ingredient.amount,
            ingredient.unit,
            ingredient.notes,
            i + 1
          ).run();
        }

        // Create steps
        if (recipe.steps && recipe.steps.length > 0) {
          for (const step of recipe.steps) {
            await env.DB.prepare(`
              INSERT INTO recipe_steps (recipe_id, step_number, instruction, created_at, updated_at)
              VALUES (?, ?, ?, datetime('now'), datetime('now'))
            `).bind(recipeId, step.step_number, step.instruction).run();
          }
        }

        // Create cooking steps
        if (recipe.cookingSteps && recipe.cookingSteps.length > 0) {
          for (const cookingStep of recipe.cookingSteps) {
            await env.DB.prepare(`
              INSERT INTO recipe_cooking_steps (
                recipe_id, step_number, equipment, method, temperature, 
                duration, notes, process, timing, created_at, updated_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
            `).bind(
              recipeId,
              cookingStep.step_number,
              cookingStep.equipment,
              cookingStep.method,
              cookingStep.temperature,
              cookingStep.duration,
              cookingStep.notes,
              cookingStep.process,
              cookingStep.timing
            ).run();
          }
        }

        // Create tags
        if (recipe.tags && recipe.tags.length > 0) {
          for (const tag of recipe.tags) {
            await env.DB.prepare(`
              INSERT INTO recipe_tags (recipe_id, tag, created_at, updated_at)
              VALUES (?, ?, datetime('now'), datetime('now'))
            `).bind(recipeId, tag.toLowerCase()).run();
          }
        }

        importedRecipes.push({
          id: recipeId,
          name: recipe.name,
          ingredients_count: recipe.ingredients.length,
          steps_count: recipe.steps.length,
          cooking_steps_count: recipe.cookingSteps?.length || 0,
          tags_count: recipe.tags.length
        });

      } catch (error) {
        console.error(`Failed to import recipe "${recipe.name}":`, error);
        validationErrors.push(`Failed to import recipe "${recipe.name}": ${error}`);
      }
    }

    return c.json({
      success: true,
      imported_count: importedRecipes.length,
      total_count: validatedRecipes.length,
      imported_recipes: importedRecipes,
      errors: validationErrors
    });

  } catch (error) {
    console.error("CSV import error:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to process CSV"
    }, 500);
  }
});

export default recipeCsv;
