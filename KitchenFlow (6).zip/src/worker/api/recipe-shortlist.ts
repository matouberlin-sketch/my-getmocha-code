import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const recipeShortlist = new Hono<{ Bindings: Env }>();

// Zod schemas for validation
const AddToShortlistSchema = z.object({
  recipe_id: z.number().positive()
});

// Get all shortlisted recipes
recipeShortlist.get("/", async (c) => {
  const env = c.env;
  
  try {
    // First check for any orphaned shortlist entries and clean them up
    await env.DB.prepare(`
      DELETE FROM recipe_shortlist 
      WHERE recipe_id NOT IN (SELECT id FROM recipes WHERE status = 'active')
    `).run();
    
    const result = await env.DB.prepare(`
      SELECT rs.*, r.name, r.description, r.yield_amount, r.yield_unit,
             r.prep_time_minutes, r.hands_on_minutes, r.station, r.is_subrecipe
      FROM recipe_shortlist rs
      JOIN recipes r ON rs.recipe_id = r.id
      WHERE r.status = 'active'
      ORDER BY rs.added_at DESC
    `).all();
    
    console.log("Shortlisted recipes found:", result.results.length);
    console.log("Shortlisted recipe IDs:", result.results.map((r: any) => `${r.recipe_id}: ${r.name}`));
    
    return c.json(result.results);
  } catch (error) {
    console.error("Failed to fetch shortlisted recipes:", error);
    return c.json({ error: "Failed to fetch shortlisted recipes" }, 500);
  }
});

// Check if recipe is in shortlist
recipeShortlist.get("/check/:recipe_id", async (c) => {
  const recipeId = parseInt(c.req.param("recipe_id"));
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(
      "SELECT id FROM recipe_shortlist WHERE recipe_id = ?"
    ).bind(recipeId).first();
    
    return c.json({ isShortlisted: !!result });
  } catch (error) {
    console.error("Failed to check shortlist status:", error);
    return c.json({ error: "Failed to check shortlist status" }, 500);
  }
});

// Add recipe to shortlist
recipeShortlist.post("/", zValidator("json", AddToShortlistSchema), async (c) => {
  const { recipe_id } = c.req.valid("json");
  const env = c.env;
  
  try {
    // Check if recipe exists and is active
    const recipe = await env.DB.prepare(
      "SELECT id FROM recipes WHERE id = ? AND status = 'active'"
    ).bind(recipe_id).first();
    
    if (!recipe) {
      return c.json({ error: "Recipe not found or not active" }, 404);
    }

    // Check if already in shortlist
    const existing = await env.DB.prepare(
      "SELECT id FROM recipe_shortlist WHERE recipe_id = ?"
    ).bind(recipe_id).first();
    
    if (existing) {
      return c.json({ error: "Recipe already in shortlist" }, 409);
    }

    // Add to shortlist
    const result = await env.DB.prepare(`
      INSERT INTO recipe_shortlist (recipe_id, added_at, updated_at)
      VALUES (?, datetime('now'), datetime('now'))
    `).bind(recipe_id).run();

    return c.json({ 
      id: result.meta.last_row_id,
      message: "Recipe added to shortlist" 
    }, 201);
  } catch (error) {
    console.error("Failed to add recipe to shortlist:", error);
    return c.json({ error: "Failed to add recipe to shortlist" }, 500);
  }
});

// Remove recipe from shortlist
recipeShortlist.delete("/:recipe_id", async (c) => {
  const recipeId = parseInt(c.req.param("recipe_id"));
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(
      "DELETE FROM recipe_shortlist WHERE recipe_id = ?"
    ).bind(recipeId).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Recipe not found in shortlist" }, 404);
    }

    return c.json({ message: "Recipe removed from shortlist" });
  } catch (error) {
    console.error("Failed to remove recipe from shortlist:", error);
    return c.json({ error: "Failed to remove recipe from shortlist" }, 500);
  }
});

// Get shortlist count
recipeShortlist.get("/count", async (c) => {
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM recipe_shortlist"
    ).first();
    
    return c.json({ count: result?.count || 0 });
  } catch (error) {
    console.error("Failed to get shortlist count:", error);
    return c.json({ error: "Failed to get shortlist count" }, 500);
  }
});

export default recipeShortlist;
