import { Hono } from 'hono';
import type { Env } from '../bindings';

const COSTING_DEFAULT: 'preferred' | 'lowest' = 'preferred';

interface SupplierLine {
  item_id: number;
  name: string;
  qty: number;
  uom: string;
  unit_cost: number | null;
  line_cost: number | null;
  requires_price?: boolean;
}

interface SupplierBucket {
  supplier_id: number | null;
  supplier_name: string;
  lines: SupplierLine[];
  subtotal: number | null;
}

interface OrderSnapshot {
  plan_id: number;
  week_start_date: string;
  currency: string;
  costing_strategy: 'preferred' | 'lowest';
  suppliers: SupplierBucket[];
  grand_total: number | null;
}

const app = new Hono<{ Bindings: Env }>();

function checkPlanNotLocked(plan: any) {
  if (plan.status === 'locked') {
    throw new Error('Plan is locked and cannot be modified');
  }
}

// GET /api/planner/plans
app.get('/', async (c) => {
  const db = c.env.DB;
  
  const plans = await db.prepare(`
    SELECT 
      id,
      week_start_date,
      status,
      name,
      notes,
      created_at,
      updated_at
    FROM planner_plans
    ORDER BY week_start_date DESC
  `).all();

  return c.json({ plans: plans.results });
});

// POST /api/planner/plans
app.post('/', async (c) => {
  const db = c.env.DB;
  const { week_start_date, name, notes } = await c.req.json();

  if (!week_start_date) {
    return c.json({ error: 'week_start_date is required' }, 400);
  }

  // Check if a plan already exists for this week
  const existing = await db.prepare(`
    SELECT id FROM planner_plans 
    WHERE week_start_date = ? AND status != 'archived'
  `).bind(week_start_date).first();

  if (existing) {
    return c.json({ error: 'A plan already exists for this week' }, 409);
  }

  const result = await db.prepare(`
    INSERT INTO planner_plans (week_start_date, status, name, notes)
    VALUES (?, 'draft', ?, ?)
  `).bind(week_start_date, name || null, notes || null).run();

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(result.meta.last_row_id).first();

  return c.json({ plan }, 201);
});

// GET /api/planner/plan/:planId
app.get('/:planId', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  return c.json({ plan });
});

// PUT /api/planner/plan/:planId
app.put('/:planId', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const { name, notes, status } = await c.req.json();

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  checkPlanNotLocked(plan);

  await db.prepare(`
    UPDATE planner_plans 
    SET name = ?, notes = ?, status = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(name || null, notes || null, status || plan.status, planId).run();

  const updatedPlan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  return c.json({ plan: updatedPlan });
});

// GET /api/planner/plan/:planId/slots
app.get('/:planId/slots', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');

  const slots = await db.prepare(`
    SELECT 
      ps.*,
      GROUP_CONCAT(
        json_object(
          'id', psr.id,
          'recipe_id', psr.recipe_id,
          'portions', psr.portions,
          'notes', psr.notes,
          'recipe_name', r.name
        )
      ) as recipes_json
    FROM planner_slots ps
    LEFT JOIN planner_slot_recipes psr ON ps.id = psr.slot_id
    LEFT JOIN recipes r ON psr.recipe_id = r.id
    WHERE ps.plan_id = ?
    GROUP BY ps.id
    ORDER BY ps.day_index, ps.position, ps.slot_label
  `).bind(planId).all();

  const slotsWithRecipes = slots.results.map((slot: any) => ({
    ...slot,
    recipes: slot.recipes_json ? 
      JSON.parse(`[${slot.recipes_json}]`).filter((r: any) => r.recipe_id) : []
  }));

  return c.json({ slots: slotsWithRecipes });
});

// POST /api/planner/plan/:planId/slots
app.post('/:planId/slots', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const { day_index, slot_label, notes, position } = await c.req.json();

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  checkPlanNotLocked(plan);

  if (day_index < 0 || day_index > 6) {
    return c.json({ error: 'day_index must be between 0 and 6' }, 400);
  }

  if (!slot_label) {
    return c.json({ error: 'slot_label is required' }, 400);
  }

  const result = await db.prepare(`
    INSERT INTO planner_slots (plan_id, day_index, slot_label, notes, position)
    VALUES (?, ?, ?, ?, ?)
  `).bind(planId, day_index, slot_label, notes || null, position || 0).run();

  const slot = await db.prepare(`
    SELECT * FROM planner_slots WHERE id = ?
  `).bind(result.meta.last_row_id).first();

  return c.json({ slot }, 201);
});

// PUT /api/planner/plan/:planId/slots/:slotId
app.put('/:planId/slots/:slotId', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const slotId = c.req.param('slotId');
  const { slot_label, notes, position } = await c.req.json();

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  checkPlanNotLocked(plan);

  const slot = await db.prepare(`
    SELECT * FROM planner_slots WHERE id = ? AND plan_id = ?
  `).bind(slotId, planId).first();

  if (!slot) {
    return c.json({ error: 'Slot not found' }, 404);
  }

  await db.prepare(`
    UPDATE planner_slots 
    SET slot_label = ?, notes = ?, position = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(slot_label || slot.slot_label, notes || slot.notes, position ?? slot.position, slotId).run();

  const updatedSlot = await db.prepare(`
    SELECT * FROM planner_slots WHERE id = ?
  `).bind(slotId).first();

  return c.json({ slot: updatedSlot });
});

// DELETE /api/planner/plan/:planId/slots/:slotId
app.delete('/:planId/slots/:slotId', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const slotId = c.req.param('slotId');
  const dayIndex = c.req.query('day_index');

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  checkPlanNotLocked(plan);

  if (dayIndex !== undefined) {
    // Delete slot only for specific day
    await db.prepare(`
      DELETE FROM planner_slots 
      WHERE plan_id = ? AND slot_label = (
        SELECT slot_label FROM planner_slots WHERE id = ?
      ) AND day_index = ?
    `).bind(planId, slotId, dayIndex).run();
  } else {
    // Delete slot entirely
    await db.prepare(`
      DELETE FROM planner_slots WHERE id = ? AND plan_id = ?
    `).bind(slotId, planId).run();
  }

  return c.json({ success: true });
});

// POST /api/planner/plan/:planId/slots/:slotId/recipes
app.post('/:planId/slots/:slotId/recipes', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const slotId = c.req.param('slotId');
  const { recipe_id, portions, notes } = await c.req.json();

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  checkPlanNotLocked(plan);

  const slot = await db.prepare(`
    SELECT * FROM planner_slots WHERE id = ? AND plan_id = ?
  `).bind(slotId, planId).first();

  if (!slot) {
    return c.json({ error: 'Slot not found' }, 404);
  }

  const result = await db.prepare(`
    INSERT INTO planner_slot_recipes (slot_id, recipe_id, portions, notes)
    VALUES (?, ?, ?, ?)
  `).bind(slotId, recipe_id, portions || 1, notes || null).run();

  const slotRecipe = await db.prepare(`
    SELECT psr.*, r.name as recipe_name
    FROM planner_slot_recipes psr
    JOIN recipes r ON psr.recipe_id = r.id
    WHERE psr.id = ?
  `).bind(result.meta.last_row_id).first();

  return c.json({ slot_recipe: slotRecipe }, 201);
});

// PUT /api/planner/plan/:planId/slots/:slotId/recipes/:recipeId
app.put('/:planId/slots/:slotId/recipes/:recipeId', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const slotId = c.req.param('slotId');
  const recipeId = c.req.param('recipeId');
  const { portions, notes } = await c.req.json();

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  checkPlanNotLocked(plan);

  await db.prepare(`
    UPDATE planner_slot_recipes 
    SET portions = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ? AND slot_id = ?
  `).bind(portions, notes || null, recipeId, slotId).run();

  const slotRecipe = await db.prepare(`
    SELECT psr.*, r.name as recipe_name
    FROM planner_slot_recipes psr
    JOIN recipes r ON psr.recipe_id = r.id
    WHERE psr.id = ?
  `).bind(recipeId).first();

  return c.json({ slot_recipe: slotRecipe });
});

// DELETE /api/planner/plan/:planId/slots/:slotId/recipes/:recipeId
app.delete('/:planId/slots/:slotId/recipes/:recipeId', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const slotId = c.req.param('slotId');
  const recipeId = c.req.param('recipeId');

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  checkPlanNotLocked(plan);

  await db.prepare(`
    DELETE FROM planner_slot_recipes 
    WHERE id = ? AND slot_id = ?
  `).bind(recipeId, slotId).run();

  return c.json({ success: true });
});

// POST /api/planner/plan/:planId/slots/reorder
app.post('/:planId/slots/reorder', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const { day_index, slot_orders } = await c.req.json();

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  checkPlanNotLocked(plan);

  // Update positions for all slots in the day
  for (const { slot_id, position } of slot_orders) {
    await db.prepare(`
      UPDATE planner_slots 
      SET position = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND plan_id = ? AND day_index = ?
    `).bind(position, slot_id, planId, day_index).run();
  }

  return c.json({ success: true });
});

// GET /api/planner/plan/:planId/components
app.get('/:planId/components', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const view = c.req.query('view') || 'components';

  if (view === 'items') {
    // Aggregate by items across the week
    const itemsQuery = await db.prepare(`
      WITH RECURSIVE recipe_expansion AS (
        -- Base case: direct ingredients
        SELECT 
          psr.slot_id,
          psr.recipe_id,
          psr.portions,
          rb.component_id as item_id,
          rb.gross_qty * (psr.portions::real / r.default_yield_qty) as scaled_qty,
          rb.uom,
          rb.trim_loss_pct,
          rb.cook_yield_pct,
          i.name as item_name,
          rb.stage,
          rb.note
        FROM planner_slot_recipes psr
        JOIN planner_slots ps ON psr.slot_id = ps.id
        JOIN recipes r ON psr.recipe_id = r.id
        JOIN recipe_bom rb ON r.id = rb.recipe_id AND rb.component_type = 'item'
        JOIN items i ON rb.component_id = i.id
        WHERE ps.plan_id = ?

        UNION ALL

        -- Recursive case: subrecipes
        SELECT 
          re.slot_id,
          sr.id as recipe_id,
          re.portions * (rb_sub.gross_qty / sr.default_yield_qty) as portions,
          rb_sub.component_id as item_id,
          rb_sub.gross_qty * (re.portions * rb_parent.gross_qty / sr.default_yield_qty / r_parent.default_yield_qty) as scaled_qty,
          rb_sub.uom,
          rb_sub.trim_loss_pct,
          rb_sub.cook_yield_pct,
          i.name as item_name,
          rb_sub.stage,
          rb_sub.note
        FROM recipe_expansion re
        JOIN recipe_bom rb_parent ON re.recipe_id = rb_parent.recipe_id AND rb_parent.component_type = 'subrecipe'
        JOIN recipes r_parent ON re.recipe_id = r_parent.id
        JOIN recipes sr ON rb_parent.component_id = sr.id
        JOIN recipe_bom rb_sub ON sr.id = rb_sub.recipe_id AND rb_sub.component_type = 'item'
        JOIN items i ON rb_sub.component_id = i.id
      )
      SELECT 
        item_id,
        item_name,
        uom,
        SUM(scaled_qty * (1 - trim_loss_pct/100.0) * (cook_yield_pct/100.0)) as net_qty
      FROM recipe_expansion
      GROUP BY item_id, uom
      ORDER BY item_name
    `).bind(planId).all();

    return c.json({ items: itemsQuery.results });
  }

  // Default components view
  const componentsQuery = await db.prepare(`
    SELECT 
      ps.day_index,
      ps.slot_label,
      psr.recipe_id,
      r.name as recipe_name,
      psr.portions,
      rc.component_recipe_id,
      cr.name as component_name,
      rc.qty,
      rc.uom,
      rc.prep_time_min,
      rc.cook_time_min,
      rc.notes
    FROM planner_slots ps
    JOIN planner_slot_recipes psr ON ps.id = psr.slot_id
    JOIN recipes r ON psr.recipe_id = r.id
    LEFT JOIN recipe_components rc ON r.recipe_id = rc.parent_recipe_id
    LEFT JOIN enhanced_recipes cr ON rc.component_recipe_id = cr.recipe_id
    WHERE ps.plan_id = ?
    ORDER BY ps.day_index, ps.position, ps.slot_label, r.name
  `).bind(planId).all();

  return c.json({ components: componentsQuery.results });
});

// GET /api/planner/plan/:planId/tasks
app.get('/:planId/tasks', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const dayIndex = c.req.query('day_index');

  let query = `
    SELECT 
      ps.day_index,
      ps.slot_label,
      psr.recipe_id,
      r.name as recipe_name,
      psr.portions,
      rc.component_recipe_id,
      cr.name as component_name,
      rc.qty * psr.portions as scaled_qty,
      rc.uom,
      rc.prep_time_min * psr.portions as total_prep_min,
      rc.cook_time_min * psr.portions as total_cook_min,
      rc.notes,
      CASE 
        WHEN rc.prep_time_min > 0 THEN 'prep'
        WHEN rc.cook_time_min > 0 THEN 'cook'
        ELSE 'order'
      END as task_type
    FROM planner_slots ps
    JOIN planner_slot_recipes psr ON ps.id = psr.slot_id
    JOIN recipes r ON psr.recipe_id = r.id
    LEFT JOIN recipe_components rc ON r.recipe_id = rc.parent_recipe_id
    LEFT JOIN enhanced_recipes cr ON rc.component_recipe_id = cr.recipe_id
    WHERE ps.plan_id = ?
  `;

  const params = [planId];
  if (dayIndex !== undefined) {
    query += ' AND ps.day_index = ?';
    params.push(dayIndex);
  }

  query += ' ORDER BY ps.day_index, ps.position, ps.slot_label, r.name';

  const tasksQuery = await db.prepare(query).bind(...params).all();

  return c.json({ tasks: tasksQuery.results });
});

// POST /api/planner/plan/:planId/lock
app.post('/:planId/lock', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  if (plan.status === 'locked') {
    return c.json({ error: 'Plan is already locked' }, 409);
  }

  // Validate plan has at least one slot recipe
  const hasRecipes = await db.prepare(`
    SELECT COUNT(*) as count
    FROM planner_slots ps
    JOIN planner_slot_recipes psr ON ps.id = psr.slot_id
    WHERE ps.plan_id = ?
  `).bind(planId).first();

  if (!hasRecipes || hasRecipes.count === 0) {
    return c.json({ error: 'Plan must have at least one recipe to lock' }, 400);
  }

  // Compute items aggregate for the entire week
  const itemsQuery = await db.prepare(`
    WITH RECURSIVE recipe_expansion AS (
      -- Base case: direct ingredients
      SELECT 
        psr.slot_id,
        psr.recipe_id,
        psr.portions,
        rb.component_id as item_id,
        rb.gross_qty * (psr.portions::real / r.default_yield_qty) as scaled_qty,
        rb.uom,
        rb.trim_loss_pct,
        rb.cook_yield_pct,
        i.name as item_name
      FROM planner_slot_recipes psr
      JOIN planner_slots ps ON psr.slot_id = ps.id
      JOIN recipes r ON psr.recipe_id = r.id
      JOIN recipe_bom rb ON r.id = rb.recipe_id AND rb.component_type = 'item'
      JOIN items i ON rb.component_id = i.id
      WHERE ps.plan_id = ?

      UNION ALL

      -- Recursive case: subrecipes
      SELECT 
        re.slot_id,
        sr.id as recipe_id,
        re.portions * (rb_sub.gross_qty / sr.default_yield_qty) as portions,
        rb_sub.component_id as item_id,
        rb_sub.gross_qty * (re.portions * rb_parent.gross_qty / sr.default_yield_qty / r_parent.default_yield_qty) as scaled_qty,
        rb_sub.uom,
        rb_sub.trim_loss_pct,
        rb_sub.cook_yield_pct,
        i.name as item_name
      FROM recipe_expansion re
      JOIN recipe_bom rb_parent ON re.recipe_id = rb_parent.recipe_id AND rb_parent.component_type = 'subrecipe'
      JOIN recipes r_parent ON re.recipe_id = r_parent.id
      JOIN recipes sr ON rb_parent.component_id = sr.id
      JOIN recipe_bom rb_sub ON sr.id = rb_sub.recipe_id AND rb_sub.component_type = 'item'
      JOIN items i ON rb_sub.component_id = i.id
    )
    SELECT 
      item_id,
      item_name,
      uom,
      SUM(scaled_qty * (1 - trim_loss_pct/100.0) * (cook_yield_pct/100.0)) as net_qty
    FROM recipe_expansion
    GROUP BY item_id, uom
    ORDER BY item_name
  `).bind(planId).all();

  const items = itemsQuery.results;
  const supplierBuckets = new Map<string, SupplierBucket>();

  // For each item, pick a supplier price based on COSTING_DEFAULT
  for (const item of items) {
    const pricesQuery = await db.prepare(`
      SELECT 
        isp.supplier_name,
        isp.price_cents,
        isp.pack_size_qty,
        isp.pack_size_unit,
        isp.currency,
        isp.preferred
      FROM item_suppliers isp
      WHERE isp.item_id = ?
      ORDER BY 
        CASE WHEN ? = 'preferred' THEN isp.preferred END DESC,
        CASE WHEN ? = 'lowest' THEN isp.price_cents / isp.pack_size_qty END ASC
    `).bind(item.item_id as number, COSTING_DEFAULT, COSTING_DEFAULT).all();

    const prices = pricesQuery.results as any[];
    let selectedPrice = prices[0] || null;
    
    const supplierKey = selectedPrice?.supplier_name || 'No Supplier';
    
    if (!supplierBuckets.has(supplierKey)) {
      supplierBuckets.set(supplierKey, {
        supplier_id: null,
        supplier_name: supplierKey,
        lines: [],
        subtotal: 0
      });
    }

    const bucket = supplierBuckets.get(supplierKey)!;
    
    let unitCost = null;
    let lineCost = null;
    let requiresPrice = false;

    if (selectedPrice) {
      unitCost = Number(selectedPrice.price_cents) / 100 / Number(selectedPrice.pack_size_qty);
      lineCost = unitCost * Number(item.net_qty);
      bucket.subtotal = (bucket.subtotal || 0) + lineCost;
    } else {
      requiresPrice = true;
    }

    bucket.lines.push({
      item_id: Number(item.item_id),
      name: String(item.item_name),
      qty: Number(item.net_qty),
      uom: String(item.uom),
      unit_cost: unitCost,
      line_cost: lineCost,
      requires_price: requiresPrice
    });
  }

  const suppliers = Array.from(supplierBuckets.values());
  const grandTotal = suppliers.reduce((sum, s) => sum + (s.subtotal || 0), 0);

  const orderSnapshot: OrderSnapshot = {
    plan_id: parseInt(planId),
    week_start_date: String(plan.week_start_date),
    currency: 'USD',
    costing_strategy: COSTING_DEFAULT,
    suppliers,
    grand_total: grandTotal > 0 ? grandTotal : null
  };

  // Save snapshot and lock plan in transaction
  try {
    await db.prepare(`
      INSERT INTO order_snapshots (plan_id, payload_json)
      VALUES (?, ?)
    `).bind(planId, JSON.stringify(orderSnapshot)).run();

    await db.prepare(`
      UPDATE planner_plans 
      SET status = 'locked', updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(planId).run();

    const snapshotResult = await db.prepare(`
      SELECT id FROM order_snapshots WHERE plan_id = ?
    `).bind(planId).first();

    return c.json({
      status: 'locked',
      order_snapshot_id: snapshotResult?.id || null,
      totals: {
        grand_total: grandTotal,
        suppliers: suppliers.length
      }
    });
  } catch (error) {
    return c.json({ error: 'Failed to lock plan' }, 500);
  }
});

// GET /api/planner/plan/:planId/order-list
app.get('/:planId/order-list', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  if (plan.status !== 'locked') {
    return c.json({ error: 'Plan is not locked' }, 409);
  }

  const snapshot = await db.prepare(`
    SELECT payload_json FROM order_snapshots WHERE plan_id = ?
  `).bind(planId).first();

  if (!snapshot) {
    return c.json({ error: 'Order snapshot not found' }, 404);
  }

  return c.json(JSON.parse(String(snapshot.payload_json)));
});

// GET /api/planner/plan/:planId/order-list.csv
app.get('/:planId/order-list.csv', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');

  const plan = await db.prepare(`
    SELECT * FROM planner_plans WHERE id = ?
  `).bind(planId).first();

  if (!plan) {
    return c.json({ error: 'Plan not found' }, 404);
  }

  if (plan.status !== 'locked') {
    return c.json({ error: 'Plan is not locked' }, 409);
  }

  const snapshot = await db.prepare(`
    SELECT payload_json FROM order_snapshots WHERE plan_id = ?
  `).bind(planId).first();

  if (!snapshot) {
    return c.json({ error: 'Order snapshot not found' }, 404);
  }

  const orderData: OrderSnapshot = JSON.parse(String(snapshot.payload_json));
  
  let csv = 'Supplier,Item,Qty,UoM,UnitCost,LineCost\n';
  
  for (const supplier of orderData.suppliers) {
    for (const line of supplier.lines) {
      csv += `"${supplier.supplier_name}","${line.name}",${line.qty},"${line.uom}",${line.unit_cost || ''},${line.line_cost || ''}\n`;
    }
  }

  return new Response(csv, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="order-list-week-${plan.week_start_date}.csv"`
    }
  });
});

// POST /api/planner/plan/:planId/consume - Record lot consumption for batch traceability
app.post('/:planId/consume', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  
  try {
    const { entries } = await c.req.json();

    if (!entries || !Array.isArray(entries)) {
      return c.json({ error: 'entries array is required' }, 400);
    }

    const plan = await db.prepare(`
      SELECT * FROM planner_plans WHERE id = ?
    `).bind(planId).first();

    if (!plan) {
      return c.json({ error: 'Plan not found' }, 404);
    }

    // Allow consumption even if plan is locked (for execution/production tracking)
    // but could add time-based restrictions here if needed

    const consumptionResults = [];
    const warnings = [];

    for (const entry of entries) {
      const { day_index, recipe_id, item_id, lot_id, qty, uom } = entry;

      // Validation
      if (day_index < 0 || day_index > 6) {
        warnings.push(`Invalid day_index ${day_index} for entry`);
        continue;
      }

      if (!recipe_id || !item_id || !qty || !uom) {
        warnings.push('recipe_id, item_id, qty, and uom are required for each entry');
        continue;
      }

      if (qty <= 0) {
        warnings.push(`Quantity must be greater than 0 for item ${item_id}`);
        continue;
      }

      // Check if lot exists and has sufficient quantity (if lot_id provided)
      if (lot_id) {
        const lot = await db.prepare(`
          SELECT qty, uom FROM lots WHERE id = ? AND item_id = ?
        `).bind(lot_id, item_id).first();

        if (!lot) {
          warnings.push(`Lot ${lot_id} not found for item ${item_id}`);
          continue;
        }

        // Check available quantity vs already consumed
        const consumed = await db.prepare(`
          SELECT COALESCE(SUM(qty_used), 0) as total_consumed
          FROM batch_consumption 
          WHERE lot_id = ?
        `).bind(lot_id).first();

        const availableQty = Number(lot.qty) - Number(consumed?.total_consumed || 0);
        
        if (availableQty < qty) {
          warnings.push(`Insufficient quantity in lot ${lot_id}. Available: ${availableQty}, Requested: ${qty}`);
          // Continue with partial consumption or block entirely based on config
          // For now, we'll allow it but flag as warning
        }
      }

      // Record consumption
      const result = await db.prepare(`
        INSERT INTO batch_consumption (plan_id, day_index, recipe_id, item_id, lot_id, qty_used, uom)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(planId, day_index, recipe_id, item_id, lot_id || null, qty, uom).run();

      consumptionResults.push({
        id: result.meta.last_row_id,
        day_index,
        recipe_id,
        item_id,
        lot_id,
        qty_used: qty,
        uom
      });
    }

    return c.json({
      message: 'Consumption recorded',
      consumption_entries: consumptionResults,
      warnings: warnings.length > 0 ? warnings : undefined
    });

  } catch (error) {
    console.error('Failed to record consumption:', error);
    return c.json({ error: 'Failed to record consumption' }, 500);
  }
});

// GET /api/planner/plan/:planId/consumption - Get consumption records for a plan
app.get('/:planId/consumption', async (c) => {
  const db = c.env.DB;
  const planId = c.req.param('planId');
  const dayIndex = c.req.query('day_index');

  try {
    let query = `
      SELECT 
        bc.*,
        i.name as item_name,
        r.name as recipe_name,
        l.lot_code,
        l.supplier_id,
        s.name as supplier_name
      FROM batch_consumption bc
      JOIN items i ON bc.item_id = i.id
      JOIN recipes r ON bc.recipe_id = r.id
      LEFT JOIN lots l ON bc.lot_id = l.id
      LEFT JOIN suppliers s ON l.supplier_id = s.id
      WHERE bc.plan_id = ?
    `;

    const params = [planId];
    if (dayIndex !== undefined) {
      query += ' AND bc.day_index = ?';
      params.push(dayIndex);
    }

    query += ' ORDER BY bc.day_index, bc.recipe_id, bc.item_id';

    const consumption = await db.prepare(query).bind(...params).all();

    return c.json({ consumption: consumption.results });
  } catch (error) {
    console.error('Failed to get consumption records:', error);
    return c.json({ error: 'Failed to get consumption records' }, 500);
  }
});

export default app;
