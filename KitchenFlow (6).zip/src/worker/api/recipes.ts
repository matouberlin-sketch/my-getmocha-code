import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { ScaleRecipeSchema } from "@/shared/types";
import { convertToWeight } from "@/shared/utils/weightConversion";
import type { Env } from "../bindings";

const recipes = new Hono<{ Bindings: Env }>();

// Recipe scraping endpoint - NEW VERSION
recipes.post("/scrape", async (c) => {
  const env = c.env;
  
  try {
    const body = await c.req.json();
    const { url } = body;

    if (!url) {
      return c.json({ error: "URL is required" }, 400);
    }

    // Validate URL format
    try {
      new URL(url);
    } catch {
      return c.json({ error: "Invalid URL format" }, 400);
    }

    // Use OpenAI to scrape and analyze the recipe
    if (!env.OPENAI_API_KEY) {
      return c.json({ error: "OpenAI API key not configured" }, 500);
    }

    const { default: OpenAI } = await import('openai');
    
    const openai = new OpenAI({
      apiKey: env.OPENAI_API_KEY,
    });

    // First, fetch the webpage content
    let pageContent;
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });
      
      if (!response.ok) {
        throw new Error(`Failed to fetch page: ${response.status}`);
      }
      
      pageContent = await response.text();
    } catch (error) {
      console.error('Failed to fetch webpage:', error);
      return c.json({ error: "Failed to fetch recipe webpage" }, 400);
    }

    // Use OpenAI to extract recipe data
    const recipeExtractionPrompt = `You are an expert chef and recipe analyst. Extract recipe information from the following webpage content and return it as JSON.

**MISSION:** Parse the webpage to extract complete recipe data including ingredients with measurements, detailed instructions, and cooking specifications.

**Required JSON Structure:**
{
  "name": "Recipe Name",
  "description": "Brief description",
  "yield_amount": number,
  "yield_unit": "servings/portions/kg/etc",
  "prep_time_minutes": number or null,
  "hands_on_minutes": number or null,
  "ingredients": [
    {
      "ingredient_name": "clean ingredient name",
      "amount": "1.5",
      "unit": "cup/g/ml/piece/etc",
      "notes": "preparation notes like 'diced' or 'room temperature'"
    }
  ],
  "steps": [
    {
      "instruction": "Clear step-by-step instruction"
    }
  ],
  "cookingSteps": [
    {
      "equipment": "oven/stove/pan/etc",
      "method": "bake/sauté/simmer/etc",
      "temperature": "350°F/medium heat/etc",
      "duration": "25 minutes",
      "notes": "additional notes"
    }
  ],
  "tags": ["italian", "dinner", "vegetarian", "easy"],
  "notes": "Additional recipe notes"
}

**INGREDIENT PARSING RULES:**
- Clean ingredient names (remove brands, remove preparation from name)
- Standardize units (cups, tbsp, tsp, g, kg, ml, l, pieces, cloves)
- Parse fractions and ranges properly (1/2 = 0.5, 1-2 = 1.5)
- Put preparation in notes field (diced, chopped, room temperature)

**COOKING METHOD EXTRACTION:**
- Identify equipment used (oven, stove, grill, pan, pot, etc.)
- Extract cooking methods (bake, sauté, simmer, boil, etc.)
- Parse temperatures and times
- Group related cooking steps

**TIME ESTIMATION:**
- Extract prep time and cooking time separately
- Convert to minutes
- Estimate if not explicitly stated

**TAG GENERATION:**
- Add cuisine type if identifiable
- Add meal type (breakfast, lunch, dinner, dessert, snack)
- Add dietary tags (vegetarian, vegan, gluten-free if obvious)
- Add difficulty level (easy, medium, hard)

Return ONLY the JSON object, no additional text.`;

    let response;
    try {
      response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "user",
            content: `${recipeExtractionPrompt}\n\nWebpage Content:\n${pageContent.substring(0, 16000)}` // Limit content size
          }
        ],
        max_tokens: 4000,
        temperature: 0.1,
      });
    } catch (apiError: any) {
      if (apiError.status === 429) {
        throw new Error("OpenAI API quota exceeded. Please check your OpenAI billing and usage limits.");
      } else if (apiError.status === 401) {
        throw new Error("OpenAI API authentication failed. Please check your API key configuration.");
      } else if (apiError.status >= 500) {
        throw new Error("OpenAI service is temporarily unavailable. Please try again in a few minutes.");
      } else {
        throw new Error(`OpenAI API error: ${apiError.message || 'Unknown error'}`);
      }
    }

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("No response from OpenAI");
    }

    try {
      // Find JSON in the response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? jsonMatch[0] : content;
      const recipeData = JSON.parse(jsonString);
      
      // Validate required fields
      if (!recipeData.name) {
        throw new Error("Recipe name not found");
      }
      
      if (!recipeData.ingredients || !Array.isArray(recipeData.ingredients) || recipeData.ingredients.length === 0) {
        throw new Error("No ingredients found");
      }
      
      if (!recipeData.steps || !Array.isArray(recipeData.steps) || recipeData.steps.length === 0) {
        throw new Error("No instructions found");
      }

      // Set defaults for missing fields
      const processedRecipe = {
        name: recipeData.name,
        description: recipeData.description || "",
        yield_amount: recipeData.yield_amount || 4,
        yield_unit: recipeData.yield_unit || "servings",
        prep_time_minutes: recipeData.prep_time_minutes || null,
        hands_on_minutes: recipeData.hands_on_minutes || null,
        ingredients: recipeData.ingredients.map((ing: any) => ({
          ingredient_name: ing.ingredient_name || "",
          amount: ing.amount || "1",
          unit: ing.unit || "piece",
          notes: ing.notes || "",
          weight_grams: null
        })),
        steps: recipeData.steps.map((step: any, index: number) => ({
          step_number: index + 1,
          instruction: step.instruction || ""
        })),
        cookingSteps: (recipeData.cookingSteps || []).map((step: any, index: number) => ({
          step_number: index + 1,
          equipment: step.equipment || "",
          method: step.method || "",
          temperature: step.temperature || "",
          duration: step.duration || "",
          notes: step.notes || ""
        })),
        tags: recipeData.tags || [],
        notes: recipeData.notes || ""
      };

      return c.json(processedRecipe);
      
    } catch (parseError) {
      console.error("Failed to parse AI recipe response:", content);
      throw new Error("Failed to parse recipe data from webpage");
    }
    
  } catch (error) {
    console.error("Recipe scraping error:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to scrape recipe"
    }, 500);
  }
});

// Get all recipes
recipes.get("/", async (c) => {
  const env = c.env;
  
  try {
    const recipes = await env.DB.prepare(`
      SELECT r.*, 
             COUNT(ri.id) as ingredient_count,
             COUNT(rs.id) as step_count
      FROM recipes r
      LEFT JOIN recipe_ingredients ri ON r.id = ri.recipe_id
      LEFT JOIN recipe_steps rs ON r.id = rs.recipe_id
      GROUP BY r.id
      ORDER BY r.created_at DESC
    `).all();

    return c.json(recipes.results);
  } catch (error) {
    console.error("Failed to fetch recipes:", error);
    return c.json({ error: "Failed to fetch recipes" }, 500);
  }
});

// Get recipe versions - disabled since we're not using versioning
recipes.get("/:id/versions", async (c) => {
  // Return empty array since versioning is disabled
  return c.json([]);
});

// Get specific recipe version - disabled since we're not using versioning
recipes.get("/:id/versions/:versionNumber", async (c) => {
  return c.json({ error: "Recipe versioning not available" }, 404);
});

// Get single recipe with details
recipes.get("/:id", async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    console.log("Fetching recipe with ID:", recipeId);
    
    const recipe = await env.DB.prepare(
      "SELECT * FROM recipes WHERE id = ?"
    ).bind(recipeId).first();
    
    if (!recipe) {
      console.log("Recipe not found for ID:", recipeId);
      return c.json({ error: "Recipe not found" }, 404);
    }

    console.log("Found recipe:", recipe.name);

    // Get ingredients with weight calculation
    const ingredients = await env.DB.prepare(`
      SELECT ri.*, 
             i.name as ingredient_name,
             i.unit_type,
             i.grams_per_piece,
             r.name as subrecipe_name,
             ri.weight_grams,
             CASE 
               WHEN ri.ingredient_id IS NOT NULL THEN i.name
               WHEN ri.subrecipe_id IS NOT NULL THEN r.name
               ELSE 'Unknown ingredient'
             END as display_name
      FROM recipe_ingredients ri
      LEFT JOIN ingredients i ON ri.ingredient_id = i.id
      LEFT JOIN recipes r ON ri.subrecipe_id = r.id
      WHERE ri.recipe_id = ?
      ORDER BY ri.ingredient_order ASC
    `).bind(recipeId).all();

    // Calculate weights for ingredients that don't have them stored
    const ingredientsWithWeights = ingredients.results.map((ingredient: any) => {
      // Use display_name if ingredient_name is null (for ingredients without proper DB entries)
      const nameToUse = ingredient.ingredient_name || ingredient.display_name || 'Unknown';
      
      // Set the ingredient_name to the display name for missing ingredients
      if (!ingredient.ingredient_name && ingredient.notes) {
        ingredient.ingredient_name = ingredient.notes; // Use notes field as ingredient name for temporary ingredients
      } else if (!ingredient.ingredient_name) {
        ingredient.ingredient_name = nameToUse;
      }
      
      if (!ingredient.weight_grams && ingredient.ingredient_name && ingredient.amount && ingredient.unit) {
        const weightResult = convertToWeight(
          ingredient.amount,
          ingredient.unit,
          ingredient.ingredient_name,
          ingredient.grams_per_piece
        );
        
        if (weightResult.weight_grams !== null) {
          ingredient.weight_grams = weightResult.weight_grams;
        }
      }
      return ingredient;
    });

    // Get steps
    const steps = await env.DB.prepare(`
      SELECT * FROM recipe_steps 
      WHERE recipe_id = ? 
      ORDER BY step_number ASC
    `).bind(recipeId).all();

    // Get cooking steps
    const cookingSteps = await env.DB.prepare(`
      SELECT * FROM recipe_cooking_steps 
      WHERE recipe_id = ? 
      ORDER BY step_number ASC
    `).bind(recipeId).all();

    // Get sub-recipes
    const subRecipes = await env.DB.prepare(`
      SELECT DISTINCT r.*
      FROM recipes r
      INNER JOIN recipe_ingredients ri ON r.id = ri.subrecipe_id
      WHERE ri.recipe_id = ?
    `).bind(recipeId).all();

    // Get tags
    const tags = await env.DB.prepare(`
      SELECT tag FROM recipe_tags 
      WHERE recipe_id = ? 
      ORDER BY tag ASC
    `).bind(recipeId).all();

    return c.json({
      ...recipe,
      ingredients: ingredientsWithWeights,
      steps: steps.results,
      cookingSteps: cookingSteps.results,
      subRecipes: subRecipes.results,
      tags: tags.results.map(t => t.tag)
    });
  } catch (error) {
    console.error("Failed to fetch recipe:", error);
    return c.json({ error: "Failed to fetch recipe" }, 500);
  }
});

// Create recipe - IMPROVED VERSION
recipes.post("/", async (c) => {
  try {
    const body = await c.req.json();
    const env = c.env;
    
    console.log("Creating recipe with data:", JSON.stringify(body, null, 2));
    
    // Basic validation
    if (!body.name?.trim()) {
      return c.json({ error: "Recipe name is required" }, 400);
    }
    
    if (!body.yield_amount || body.yield_amount <= 0) {
      return c.json({ error: "Yield amount must be greater than 0" }, 400);
    }
    
    if (!body.yield_unit?.trim()) {
      return c.json({ error: "Yield unit is required" }, 400);
    }
    
    if (!body.ingredients?.length) {
      return c.json({ error: "At least one ingredient is required" }, 400);
    }
    
    if (!body.steps?.length) {
      return c.json({ error: "At least one instruction step is required" }, 400);
    }
  
    // Create the recipe
    const recipeResult = await env.DB.prepare(`
      INSERT INTO recipes (
        name, description, yield_amount, yield_unit, 
        prep_time_minutes, hands_on_minutes, lead_time_hours,
        notes, is_subrecipe, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      String(body.name || '').trim(),
      body.description || null,
      Number(body.yield_amount),
      String(body.yield_unit || '').trim(),
      body.prep_time_minutes ? Number(body.prep_time_minutes) : null,
      body.hands_on_minutes ? Number(body.hands_on_minutes) : null,
      0, // lead_time_hours
      body.notes || null,
      false // is_subrecipe
    ).run();

    const recipeId = recipeResult.meta.last_row_id as number;
    console.log("Created recipe with ID:", recipeId);

    // Create ingredients
    for (let i = 0; i < body.ingredients.length; i++) {
      const ingredient = body.ingredients[i];
      
      // Skip invalid ingredients
      if (!ingredient.ingredient_name?.trim() || !ingredient.amount || !ingredient.unit?.trim()) {
        console.warn(`Skipping invalid ingredient at index ${i}:`, ingredient);
        continue;
      }
      
      // Create or find ingredient
      let ingredientId = null;
      try {
        // Try to find existing ingredient first
        const existing = await env.DB.prepare(
          "SELECT id FROM ingredients WHERE LOWER(name) = LOWER(?)"
        ).bind(String(ingredient.ingredient_name || '').trim()).first();
        
        if (existing) {
          ingredientId = existing.id;
        } else {
          // Create new ingredient with basic defaults
          const newIngredient = await env.DB.prepare(`
            INSERT INTO ingredients (name, unit_type, created_at, updated_at) 
            VALUES (?, ?, datetime('now'), datetime('now'))
          `).bind(
            String(ingredient.ingredient_name).trim(),
            'count' // default unit type
          ).run();
          ingredientId = newIngredient.meta.last_row_id;
        }
        
        // Calculate weight for the ingredient
        let weightGrams = null;
        if (ingredient.ingredient_name && ingredient.amount && ingredient.unit) {
          const weightResult = convertToWeight(
            Number(ingredient.amount),
            String(ingredient.unit || '').trim(),
            String(ingredient.ingredient_name || '').trim(),
            null // We'll get grams_per_piece from the ingredient if needed
          );
          
          if (weightResult.weight_grams !== null) {
            weightGrams = weightResult.weight_grams;
          }
        }

        // Insert recipe ingredient with calculated weight
        await env.DB.prepare(`
          INSERT INTO recipe_ingredients (
            recipe_id, ingredient_id, amount, unit, notes, ingredient_order, weight_grams, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `).bind(
          recipeId,
          ingredientId,
          Number(ingredient.amount),
          String(ingredient.unit || '').trim(),
          ingredient.notes ? String(ingredient.notes) : null,
          i + 1,
          weightGrams
        ).run();
        
      } catch (error) {
        console.error(`Failed to create ingredient ${ingredient.ingredient_name}:`, error);
        // Continue with other ingredients
      }
    }
    
    console.log(`Created ${body.ingredients.length} ingredients`);

    // Create steps
    for (const step of body.steps) {
      try {
        await env.DB.prepare(`
          INSERT INTO recipe_steps (recipe_id, step_number, instruction, created_at, updated_at)
          VALUES (?, ?, ?, datetime('now'), datetime('now'))
        `).bind(
          recipeId, 
          step.step_number, 
          String(step.instruction || '').trim()
        ).run();
      } catch (error) {
        console.error(`Failed to create step ${step.step_number}:`, error);
      }
    }
    
    console.log(`Created ${body.steps.length} steps`);

    // Create cooking steps if provided
    if (body.cookingSteps && Array.isArray(body.cookingSteps)) {
      for (let i = 0; i < body.cookingSteps.length; i++) {
        const cookingStep = body.cookingSteps[i];
        if (cookingStep.equipment?.trim() && cookingStep.method?.trim()) {
          try {
            await env.DB.prepare(`
              INSERT INTO recipe_cooking_steps (
                recipe_id, step_number, equipment, method, temperature, duration, 
                notes, process, timing, created_at, updated_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
            `).bind(
              recipeId,
              i + 1,
              cookingStep.equipment.trim(),
              cookingStep.method.trim(),
              cookingStep.temperature?.trim() || null,
              cookingStep.duration?.trim() || null,
              cookingStep.notes?.trim() || null,
              cookingStep.process?.trim() || null,
              cookingStep.timing || 'sequential'
            ).run();
          } catch (error) {
            console.error(`Failed to create cooking step ${i + 1}:`, error);
          }
        }
      }
      console.log(`Created ${body.cookingSteps.length} cooking steps`);
    }

    // Create tags
    if (body.tags && Array.isArray(body.tags)) {
      for (const tag of body.tags) {
        if (tag && typeof tag === 'string') {
          try {
            await env.DB.prepare(`
              INSERT INTO recipe_tags (recipe_id, tag, created_at, updated_at)
              VALUES (?, ?, datetime('now'), datetime('now'))
            `).bind(recipeId, String(tag).trim().toLowerCase()).run();
          } catch (error) {
            console.error(`Failed to create tag ${tag}:`, error);
          }
        }
      }
      console.log(`Created ${body.tags.length} tags`);
    }
    
    return c.json({ 
      id: recipeId,
      message: "Recipe created successfully" 
    });
    
  } catch (error) {
    console.error("Recipe creation error:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to create recipe"
    }, 500);
  }
});

// Scale recipe
recipes.post("/:id/scale", zValidator("json", ScaleRecipeSchema), async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const { scaleFactor } = c.req.valid("json");
  const env = c.env;
  
  try {
    // Get recipe details
    const recipe = await env.DB.prepare(
      "SELECT * FROM recipes WHERE id = ?"
    ).bind(recipeId).first();
    
    if (!recipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }
    
    // Calculate scaled timing
    const adjustedTiming = calculateScaledTiming(scaleFactor, {
      base_prep_time: recipe.prep_time_minutes || 0,
      base_hands_on_time: recipe.hands_on_minutes || 0
    });
    
    const scaledRecipe = {
      id: recipeId,
      scaleFactor,
      adjustedTiming,
      newYieldAmount: (recipe.yield_amount as number) * scaleFactor
    };
    
    return c.json(scaledRecipe);
  } catch (error) {
    console.error("Recipe scaling error:", error);
    return c.json({ error: "Failed to scale recipe" }, 500);
  }
});

function calculateScaledTiming(scaleFactor: number, baseProfile?: any) {
  const profile = baseProfile || { base_prep_time: 30, base_hands_on_time: 20 };
  
  // Timing scales sublinearly - larger batches are more efficient per portion
  const prepMultiplier = Math.pow(scaleFactor, 0.7);
  const handsOnMultiplier = Math.pow(scaleFactor, 0.8);
  
  return {
    scaledPrepTime: Math.round(profile.base_prep_time * prepMultiplier + 15),
    scaledHandsOnTime: Math.round(profile.base_hands_on_time * handsOnMultiplier),
    efficiencyGain: scaleFactor > 1 ? Math.round((1 - (prepMultiplier / scaleFactor)) * 100) : 0
  };
}

// Update recipe - IMPROVED VERSION
recipes.put("/:id", async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const body = await c.req.json();
    
    console.log("Updating recipe:", recipeId, "with data:", JSON.stringify(body, null, 2));
    
    // Basic validation
    if (!body.name?.trim()) {
      return c.json({ error: "Recipe name is required" }, 400);
    }
    
    if (!body.yield_amount || body.yield_amount <= 0) {
      return c.json({ error: "Yield amount must be greater than 0" }, 400);
    }
    
    if (!body.yield_unit?.trim()) {
      return c.json({ error: "Yield unit is required" }, 400);
    }

    // Check if recipe exists
    const existingRecipe = await env.DB.prepare("SELECT * FROM recipes WHERE id = ?").bind(recipeId).first();
    
    if (!existingRecipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }

    console.log("Starting recipe update transaction...");

    // Update basic recipe info first
    const updateRecipeResult = await env.DB.prepare(`
      UPDATE recipes 
      SET name = ?, description = ?, yield_amount = ?, yield_unit = ?,
          prep_time_minutes = ?, hands_on_minutes = ?, notes = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      body.name.trim(),
      body.description?.trim() || null,
      Number(body.yield_amount),
      body.yield_unit.trim(),
      body.prep_time_minutes ? Number(body.prep_time_minutes) : null,
      body.hands_on_minutes ? Number(body.hands_on_minutes) : null,
      body.notes?.trim() || null,
      recipeId
    ).run();

    console.log("Updated basic recipe info, changes:", updateRecipeResult.meta.changes);

    // Update ingredients if provided
    if (body.ingredients && Array.isArray(body.ingredients)) {
      console.log("Updating ingredients...");
      
      // Delete existing ingredients first
      const deleteIngredientsResult = await env.DB.prepare("DELETE FROM recipe_ingredients WHERE recipe_id = ?").bind(recipeId).run();
      console.log("Deleted existing ingredients, changes:", deleteIngredientsResult.meta.changes);
      
      // Insert new ingredients
      for (let i = 0; i < body.ingredients.length; i++) {
        const ingredient = body.ingredients[i];
        
        if (!ingredient.ingredient_name?.trim() || !ingredient.amount || !ingredient.unit?.trim()) {
          console.warn(`Skipping invalid ingredient at index ${i}:`, ingredient);
          continue;
        }

        // Handle ingredient identification
        let ingredientId = null;
        let subrecipeId = null;

        if (ingredient.is_subrecipe || ingredient.subrecipe_id) {
          // This is a sub-recipe
          subrecipeId = ingredient.subrecipe_id || ingredient.ingredient_id;
          console.log(`Using sub-recipe ID: ${subrecipeId}`);
        } else if (ingredient.ingredient_id) {
          // This is an existing ingredient
          ingredientId = ingredient.ingredient_id;
          console.log(`Using existing ingredient ID: ${ingredientId}`);
        } else {
          // Try to find or create ingredient by name
          console.log(`Looking for ingredient: "${ingredient.ingredient_name.trim()}"`);
          
          const existing = await env.DB.prepare(
            "SELECT id FROM ingredients WHERE LOWER(name) = LOWER(?)"
          ).bind(ingredient.ingredient_name.trim()).first();
          
          if (existing) {
            ingredientId = existing.id;
            console.log(`Found existing ingredient with ID: ${ingredientId}`);
          } else {
            // Create new ingredient
            console.log(`Creating new ingredient: "${ingredient.ingredient_name.trim()}"`);
            const newIngredient = await env.DB.prepare(`
              INSERT INTO ingredients (name, unit_type, created_at, updated_at) 
              VALUES (?, ?, datetime('now'), datetime('now'))
            `).bind(
              ingredient.ingredient_name.trim(),
              'count' // default unit type
            ).run();
            ingredientId = newIngredient.meta.last_row_id;
            console.log(`Created new ingredient with ID: ${ingredientId}`);
          }
        }

        // Calculate weight if possible
        let weightGrams = null;
        if (ingredient.weight_grams) {
          weightGrams = ingredient.weight_grams;
        } else if (ingredient.ingredient_name && ingredient.amount && ingredient.unit) {
          const weightResult = convertToWeight(
            Number(ingredient.amount),
            ingredient.unit.trim(),
            ingredient.ingredient_name.trim(),
            ingredient.grams_per_piece || null
          );
          
          if (weightResult.weight_grams !== null) {
            weightGrams = weightResult.weight_grams;
          }
        }

        // Insert recipe ingredient
        const insertResult = await env.DB.prepare(`
          INSERT INTO recipe_ingredients (
            recipe_id, ingredient_id, subrecipe_id, amount, unit, notes, 
            ingredient_order, weight_grams, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `).bind(
          recipeId,
          ingredientId,
          subrecipeId,
          Number(ingredient.amount),
          ingredient.unit.trim(),
          ingredient.notes?.trim() || null,
          i + 1,
          weightGrams
        ).run();

        console.log(`Inserted ingredient ${i + 1}, ID: ${insertResult.meta.last_row_id}`);
      }
      
      console.log(`Updated ${body.ingredients.length} ingredients`);
    }

    // Update steps if provided
    if (body.steps && Array.isArray(body.steps)) {
      console.log("Updating steps...");
      
      // Clear existing steps
      const deleteStepsResult = await env.DB.prepare("DELETE FROM recipe_steps WHERE recipe_id = ?").bind(recipeId).run();
      console.log("Deleted existing steps, changes:", deleteStepsResult.meta.changes);
      
      // Insert new steps
      for (let i = 0; i < body.steps.length; i++) {
        const step = body.steps[i];
        if (step.instruction?.trim()) {
          const insertStepResult = await env.DB.prepare(`
            INSERT INTO recipe_steps (recipe_id, step_number, instruction, created_at, updated_at)
            VALUES (?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            recipeId, 
            i + 1, 
            step.instruction.trim()
          ).run();
          console.log(`Inserted step ${i + 1}, ID: ${insertStepResult.meta.last_row_id}`);
        }
      }
      
      console.log(`Updated ${body.steps.length} steps`);
    }

    // Update cooking steps if provided
    if (body.cookingSteps && Array.isArray(body.cookingSteps)) {
      console.log("Updating cooking steps...");
      
      // Clear existing cooking steps
      const deleteCookingStepsResult = await env.DB.prepare("DELETE FROM recipe_cooking_steps WHERE recipe_id = ?").bind(recipeId).run();
      console.log("Deleted existing cooking steps, changes:", deleteCookingStepsResult.meta.changes);
      
      // Insert new cooking steps
      for (let i = 0; i < body.cookingSteps.length; i++) {
        const cookingStep = body.cookingSteps[i];
        if (cookingStep.equipment?.trim() && cookingStep.method?.trim()) {
          const insertCookingStepResult = await env.DB.prepare(`
            INSERT INTO recipe_cooking_steps (
              recipe_id, step_number, equipment, method, temperature, duration, 
              notes, process, timing, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            recipeId,
            i + 1,
            cookingStep.equipment.trim(),
            cookingStep.method.trim(),
            cookingStep.temperature?.trim() || null,
            cookingStep.duration?.trim() || null,
            cookingStep.notes?.trim() || null,
            cookingStep.process?.trim() || null,
            cookingStep.timing || 'sequential'
          ).run();
          console.log(`Inserted cooking step ${i + 1}, ID: ${insertCookingStepResult.meta.last_row_id}`);
        }
      }
      
      console.log(`Updated ${body.cookingSteps.length} cooking steps`);
    }

    // Update tags if provided
    if (body.tags && Array.isArray(body.tags)) {
      console.log("Updating tags...");
      
      // Clear existing tags
      const deleteTagsResult = await env.DB.prepare("DELETE FROM recipe_tags WHERE recipe_id = ?").bind(recipeId).run();
      console.log("Deleted existing tags, changes:", deleteTagsResult.meta.changes);
      
      // Insert new tags
      for (const tag of body.tags) {
        if (tag && typeof tag === 'string' && tag.trim()) {
          const insertTagResult = await env.DB.prepare(`
            INSERT INTO recipe_tags (recipe_id, tag, created_at, updated_at)
            VALUES (?, ?, datetime('now'), datetime('now'))
          `).bind(recipeId, tag.trim().toLowerCase()).run();
          console.log(`Inserted tag "${tag}", ID: ${insertTagResult.meta.last_row_id}`);
        }
      }
      
      console.log(`Updated ${body.tags.length} tags`);
    }

    console.log(`Recipe ${recipeId} updated successfully`);
    return c.json({ 
      message: "Recipe updated successfully",
      id: recipeId 
    });
      
  } catch (error) {
    console.error("Recipe update error:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to update recipe",
      details: error instanceof Error ? error.stack : undefined
    }, 500);
  }
});

// Archive recipe
recipes.patch("/:id", async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const body = await c.req.json();
    
    if (body.archived !== undefined) {
      await env.DB.prepare(`
        UPDATE recipes 
        SET notes = CASE 
          WHEN ? = true THEN COALESCE(notes, '') || '\n[ARCHIVED]'
          ELSE REPLACE(COALESCE(notes, ''), '\n[ARCHIVED]', '')
        END,
        updated_at = datetime('now')
        WHERE id = ?
      `).bind(body.archived, recipeId).run();
      
      return c.json({ message: body.archived ? "Recipe archived" : "Recipe restored" });
    }

    return c.json({ error: "Invalid archive request" }, 400);
  } catch (error) {
    console.error("Recipe archive error:", error);
    return c.json({ error: "Failed to archive recipe" }, 500);
  }
});

// Parse instructions for cooking method detection
recipes.post("/parse-instructions", async (c) => {
  const env = c.env;
  
  try {
    const body = await c.req.json();
    const { instructions } = body;

    if (!instructions || !Array.isArray(instructions) || instructions.length === 0) {
      return c.json({ error: "No instructions provided" }, 400);
    }

    // Use OpenAI to parse instructions if API key is available
    if (env.OPENAI_API_KEY) {
      const { default: OpenAI } = await import('openai');
      
      const openai = new OpenAI({
        apiKey: env.OPENAI_API_KEY,
      });

      const instructionParsingPrompt = `You are an expert chef assistant specializing in parsing recipe instructions to extract detailed cooking information and timing estimates.

**MISSION:** Analyze instructions to understand WHEN each action happens, HOW LONG it takes, and estimate realistic cooking timelines.

**Input:** Raw instruction text from a recipe
**Output:** JSON array of step objects with detailed timing analysis

**For each step, extract:**
1. **step_number**: Sequential number (1, 2, 3, etc.)
2. **instruction**: Clean, clear instruction text
3. **equipment**: Primary equipment (stove, oven, grill, pan, pot, etc.)
4. **temperature**: Cooking temperature (medium heat, 350°F, high, etc.)
5. **cooking_time**: Time in format "5'" for 5 minutes, "1'30'" for 1 hour 30 minutes
6. **cooking_method**: Primary cooking action (sauté, simmer, bake, prep, etc.)
7. **timing_type**: "active" (hands-on) or "passive" (unattended) or "prep" (preparation)

**TIMING ANALYSIS - CRITICAL FOR PROFESSIONAL KITCHENS:**

**Time Extraction Rules:**
- Range times: "5-7 minutes" = "7'" (use longer time)
- "About 10 minutes" = "10'"
- "Until golden brown" = estimate based on cooking method:
  * Sautéing vegetables: "5'"
  * Browning meat: "8'"
  * Baking until golden: "25'"
  * Toasting: "3'"

**Timing Type Classification:**
- **"active"**: Direct hands-on work (stirring, chopping, sautéing, flipping)
- **"passive"**: Unattended cooking (baking, simmering, resting, chilling)
- **"prep"**: Preparation work (chopping, measuring, mixing)

**Method-Based Time Estimates:**
- **Prep work**: "prep" method
  * Chop onion: "3'", dice vegetables: "5'", measure ingredients: "2'"
- **Active cooking**: "active" timing
  * Sauté onions: "5'", brown meat: "8'", stir-fry: "6'"
- **Passive cooking**: "passive" timing
  * Simmer sauce: "20'", bake: "30'", rest dough: "60'"

**Equipment Detection:**
- Look for: skillet, pan, pot, oven, grill, food processor, mixer, bowl
- Default to "stove" for stovetop cooking, "prep" for preparation

**Temperature Analysis:**
- Extract: "medium heat", "350°F", "high heat", "low simmer"
- Estimate if not given: sautéing = "medium", baking = "350°F"

**Realistic Time Estimation:**
- Consider ingredient quantities for timing
- Account for equipment heating time
- Estimate based on cooking science principles

Analyze these instructions and return detailed timing information:`;

      let response;
      try {
        response = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            {
              role: "user",
              content: `${instructionParsingPrompt}\n\n${JSON.stringify(instructions)}`
            }
          ],
          max_tokens: 3000,
          temperature: 0.1,
        });
      } catch (apiError: any) {
        if (apiError.status === 429) {
          throw new Error("OpenAI API quota exceeded. Please check your OpenAI billing and usage limits. You may need to upgrade your plan or wait for quota reset.");
        } else if (apiError.status === 401) {
          throw new Error("OpenAI API authentication failed. Please check your API key configuration.");
        } else if (apiError.status >= 500) {
          throw new Error("OpenAI service is temporarily unavailable. Please try again in a few minutes.");
        } else {
          throw new Error(`OpenAI API error: ${apiError.message || 'Unknown error'}`);
        }
      }

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error("No response from OpenAI");
      }

      try {
        // Find JSON in the response
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        const jsonString = jsonMatch ? jsonMatch[0] : content;
        const parsedInstructions = JSON.parse(jsonString);
        
        return c.json(parsedInstructions.map((step: any) => ({
          step_number: step.step_number,
          instruction: step.instruction,
          equipment: step.equipment || null,
          temperature: step.temperature || null,
          cooking_time: step.cooking_time || null,
          cooking_method: step.cooking_method || null,
          timing_type: step.timing_type || null
        })));
      } catch (parseError) {
        console.error("Failed to parse AI instruction response:", content);
        throw new Error("Failed to parse AI response");
      }
    } else {
      // Fallback to simple parsing without AI
      const parsedInstructions = instructions.map((instruction: string, index: number) => ({
        step_number: index + 1,
        instruction: instruction,
        equipment: extractEquipmentFromText(instruction),
        temperature: extractTemperatureFromText(instruction),
        cooking_time: extractTimeFromText(instruction),
        cooking_method: extractMethodFromText(instruction),
        timing_type: 'active'
      }));

      return c.json(parsedInstructions);
    }
  } catch (error) {
    console.error("Instruction parsing error:", error);
    return c.json({ error: "Failed to parse instructions" }, 500);
  }
});

// Simple text extraction functions for fallback
function extractEquipmentFromText(text: string): string | null {
  const equipmentKeywords = ['oven', 'stove', 'pan', 'pot', 'skillet', 'grill', 'saucepan', 'stockpot'];
  const lowerText = text.toLowerCase();
  
  for (const equipment of equipmentKeywords) {
    if (lowerText.includes(equipment)) {
      return equipment;
    }
  }
  
  return null;
}

function extractTemperatureFromText(text: string): string | null {
  const tempMatch = text.match(/(\d+°[CF]|medium|high|low)(?:\s+heat)?/i);
  return tempMatch ? tempMatch[1] : null;
}

function extractTimeFromText(text: string): string | null {
  const timeMatch = text.match(/(\d+(?:-\d+)?)\s*(?:minute|min|hour|hr)/i);
  if (timeMatch) {
    const timeStr = timeMatch[1];
    if (timeStr.includes('-')) {
      const [min, max] = timeStr.split('-').map(Number);
      return `${Math.round((min + max) / 2)}'`;
    } else {
      return `${timeStr}'`;
    }
  }
  return null;
}

function extractMethodFromText(text: string): string | null {
  const methodKeywords = ['bake', 'roast', 'sauté', 'fry', 'simmer', 'boil', 'grill', 'steam', 'braise'];
  const lowerText = text.toLowerCase();
  
  for (const method of methodKeywords) {
    if (lowerText.includes(method)) {
      return method;
    }
  }
  
  return 'cook';
}

// Get recipe allergens - union of item allergen codes from exploded items
recipes.get("/:id/allergens", async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    // Get recipe ingredients and their allergens
    const allergens = await env.DB.prepare(`
      SELECT DISTINCT 
        TRIM(allergen.value) as allergen_code,
        a.label as allergen_label
      FROM recipe_ingredients ri
      JOIN ingredients i ON ri.ingredient_id = i.id
      JOIN json_each(COALESCE(i.allergen_codes, '')) allergen ON allergen.value != ''
      LEFT JOIN allergens a ON TRIM(allergen.value) = a.code
      WHERE ri.recipe_id = ? AND i.allergen_codes IS NOT NULL
      
      UNION
      
      -- Include allergens from items table if exists  
      SELECT DISTINCT
        TRIM(item_allergen.value) as allergen_code,
        a.label as allergen_label
      FROM recipe_bom rb
      JOIN items it ON rb.component_id = it.id AND rb.component_type = 'item'
      JOIN json_each(COALESCE(it.allergen_codes, '')) item_allergen ON item_allergen.value != ''
      LEFT JOIN allergens a ON TRIM(item_allergen.value) = a.code
      WHERE rb.recipe_id = ? AND it.allergen_codes IS NOT NULL
      
      ORDER BY allergen_code
    `).bind(recipeId, recipeId).all();
    
    return c.json({
      recipe_id: recipeId,
      allergens: allergens.results.map((a: any) => ({
        code: a.allergen_code,
        label: a.allergen_label || a.allergen_code
      }))
    });
  } catch (error) {
    console.error("Failed to get recipe allergens:", error);
    return c.json({ error: "Failed to get recipe allergens" }, 500);
  }
});

// Get recipe nutrition - roll up per portion using net item quantities
recipes.get("/:id/nutrition", async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    // Get recipe details for yield calculation
    const recipe = await env.DB.prepare(
      "SELECT yield_amount FROM recipes WHERE id = ?"
    ).bind(recipeId).first();
    
    if (!recipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }
    
    // Calculate nutrition from ingredients
    const nutrition = await env.DB.prepare(`
      SELECT 
        SUM(
          CASE WHEN ri.weight_grams IS NOT NULL 
          THEN (ri.weight_grams / 100.0) * COALESCE(i.kcal_per_100, 0)
          ELSE 0 END
        ) / ? as kcal_per_portion,
        SUM(
          CASE WHEN ri.weight_grams IS NOT NULL 
          THEN (ri.weight_grams / 100.0) * COALESCE(i.protein_g_per_100, 0)
          ELSE 0 END
        ) / ? as protein_g_per_portion,
        SUM(
          CASE WHEN ri.weight_grams IS NOT NULL 
          THEN (ri.weight_grams / 100.0) * COALESCE(i.carbs_g_per_100, 0)
          ELSE 0 END
        ) / ? as carbs_g_per_portion,
        SUM(
          CASE WHEN ri.weight_grams IS NOT NULL 
          THEN (ri.weight_grams / 100.0) * COALESCE(i.fat_g_per_100, 0)
          ELSE 0 END
        ) / ? as fat_g_per_portion
      FROM recipe_ingredients ri
      JOIN ingredients i ON ri.ingredient_id = i.id
      WHERE ri.recipe_id = ?
    `).bind(recipe.yield_amount, recipe.yield_amount, recipe.yield_amount, recipe.yield_amount, recipeId).first();

    // Also check items table for enhanced recipes
    const itemNutrition = await env.DB.prepare(`
      SELECT 
        SUM(
          (rb.gross_qty * (1 - rb.trim_loss_pct/100.0) * (rb.cook_yield_pct/100.0) / 100.0) * COALESCE(it.kcal_per_100, 0)
        ) / ? as kcal_per_portion,
        SUM(
          (rb.gross_qty * (1 - rb.trim_loss_pct/100.0) * (rb.cook_yield_pct/100.0) / 100.0) * COALESCE(it.protein_g_per_100, 0)
        ) / ? as protein_g_per_portion,
        SUM(
          (rb.gross_qty * (1 - rb.trim_loss_pct/100.0) * (rb.cook_yield_pct/100.0) / 100.0) * COALESCE(it.carbs_g_per_100, 0)
        ) / ? as carbs_g_per_portion,
        SUM(
          (rb.gross_qty * (1 - rb.trim_loss_pct/100.0) * (rb.cook_yield_pct/100.0) / 100.0) * COALESCE(it.fat_g_per_100, 0)
        ) / ? as fat_g_per_portion
      FROM recipe_bom rb
      JOIN items it ON rb.component_id = it.id AND rb.component_type = 'item'
      WHERE rb.recipe_id = ?
    `).bind(recipe.yield_amount, recipe.yield_amount, recipe.yield_amount, recipe.yield_amount, recipeId).first();
    
    // Combine results from both tables
    const finalNutrition = {
      kcal_per_portion: Math.round((nutrition?.kcal_per_portion || 0) + (itemNutrition?.kcal_per_portion || 0)),
      protein_g_per_portion: Math.round(((nutrition?.protein_g_per_portion || 0) + (itemNutrition?.protein_g_per_portion || 0)) * 10) / 10,
      carbs_g_per_portion: Math.round(((nutrition?.carbs_g_per_portion || 0) + (itemNutrition?.carbs_g_per_portion || 0)) * 10) / 10,
      fat_g_per_portion: Math.round(((nutrition?.fat_g_per_portion || 0) + (itemNutrition?.fat_g_per_portion || 0)) * 10) / 10
    };
    
    return c.json({
      recipe_id: recipeId,
      per_portion: finalNutrition
    });
  } catch (error) {
    console.error("Failed to get recipe nutrition:", error);
    return c.json({ error: "Failed to get recipe nutrition" }, 500);
  }
});

// Get recipe supplier matrix with per-portion cost analysis
recipes.get("/:id/suppliers", async (c) => {
  const recipeId = c.req.param("id");
  const env = c.env;
  
  try {
    // Get recipe details
    const recipe = await env.DB.prepare(
      "SELECT recipe_id, name, default_yield_qty, default_yield_uom FROM enhanced_recipes WHERE recipe_id = ?"
    ).bind(recipeId).first();
    
    if (!recipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }
    
    // Get all items used in this recipe (including from sub-recipes)
    const recipeItems = await env.DB.prepare(`
      SELECT 
        eri.item_id,
        eri.qty,
        eri.uom,
        i.name as item_name,
        i.base_uom
      FROM enhanced_recipe_ingredients eri
      JOIN items i ON eri.item_id = i.item_id
      WHERE eri.recipe_id = ?
      ORDER BY eri.line_no
    `).bind(recipeId).all();
    
    const items = [];
    let totalPerPortionCost = 0;
    
    for (const recipeItem of recipeItems.results) {
      // Get suppliers for this item
      const suppliers = await env.DB.prepare(`
        SELECT 
          ROW_NUMBER() OVER (ORDER BY (sie.price / sie.pack_qty)) as id,
          sie.supplier_name as name,
          (sie.price / sie.pack_qty) as unit_cost,
          CASE WHEN ROW_NUMBER() OVER (ORDER BY (sie.price / sie.pack_qty)) = 1 THEN true ELSE false END as preferred
        FROM supplier_items_enhanced sie
        WHERE sie.item_id = ?
        ORDER BY unit_cost ASC
      `).bind(recipeItem.item_id).all();
      
      // Calculate per-portion net quantity
      // Assume recipe yields default_yield_qty portions
      const portionQty = recipeItem.qty / (recipe.default_yield_qty || 1);
      
      // Get preferred supplier (lowest cost)
      const preferredSupplier = suppliers.results[0];
      if (preferredSupplier) {
        totalPerPortionCost += preferredSupplier.unit_cost * portionQty;
      }
      
      items.push({
        item_id: recipeItem.item_id,
        name: recipeItem.item_name,
        base_uom: recipeItem.base_uom,
        per_portion_qty: portionQty,
        suppliers: suppliers.results
      });
    }
    
    return c.json({
      recipe_id: recipe.recipe_id,
      name: recipe.name,
      per_portion_cost: totalPerPortionCost > 0 ? totalPerPortionCost : null,
      items
    });
  } catch (error) {
    console.error("Failed to get recipe suppliers:", error);
    return c.json({ error: "Failed to get recipe suppliers" }, 500);
  }
});

// Delete recipe - IMPROVED VERSION with better error handling
recipes.delete("/:id", async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    console.log(`Starting deletion of recipe ${recipeId}...`);
    
    // Check if recipe exists first
    const existingRecipe = await env.DB.prepare("SELECT * FROM recipes WHERE id = ?").bind(recipeId).first();
    
    if (!existingRecipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }

    console.log(`Recipe ${recipeId} exists: ${existingRecipe.name}`);

    // Check if recipe is used as a sub-recipe in other recipes
    const usageCheck = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM recipe_ingredients WHERE subrecipe_id = ?"
    ).bind(recipeId).first<{ count: number }>();
    
    if (usageCheck?.count && usageCheck.count > 0) {
      console.log(`Recipe ${recipeId} is used as sub-recipe in ${usageCheck.count} other recipes`);
      return c.json({ 
        error: "Cannot delete recipe - it is used as a sub-recipe in other recipes",
        usage_count: usageCheck.count 
      }, 409);
    }

    // Check if recipe has been used in planned meals (production history)
    const plannedMealsCheck = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM planned_meals WHERE recipe_id = ?"
    ).bind(recipeId).first<{ count: number }>();
    
    if (plannedMealsCheck?.count && plannedMealsCheck.count > 0) {
      console.log(`Recipe ${recipeId} has been used in ${plannedMealsCheck.count} planned meals`);
      return c.json({ 
        error: "Cannot delete recipe - it has been used in meal planning or production",
        planned_meals_count: plannedMealsCheck.count 
      }, 409);
    }

    // Check for meal components usage
    const mealComponentsCheck = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM meal_components WHERE recipe_id = ?"
    ).bind(recipeId).first<{ count: number }>();
    
    if (mealComponentsCheck?.count && mealComponentsCheck.count > 0) {
      console.log(`Recipe ${recipeId} has been used in ${mealComponentsCheck.count} meal components`);
      return c.json({ 
        error: "Cannot delete recipe - it has been used in meal planning components",
        meal_components_count: mealComponentsCheck.count 
      }, 409);
    }

    // Proceed with deletion - delete in proper order to avoid foreign key constraints
    console.log(`Recipe ${recipeId} is safe to delete, proceeding with deletion...`);
    
    try {
      // Delete from shortlist first
      const shortlistResult = await env.DB.prepare("DELETE FROM recipe_shortlist WHERE recipe_id = ?").bind(recipeId).run();
      console.log(`Deleted from shortlist: ${shortlistResult.meta.changes} rows`);
      
      // Delete tags
      const tagsResult = await env.DB.prepare("DELETE FROM recipe_tags WHERE recipe_id = ?").bind(recipeId).run();
      console.log(`Deleted tags: ${tagsResult.meta.changes} rows`);
      
      // Delete cooking steps
      const cookingStepsResult = await env.DB.prepare("DELETE FROM recipe_cooking_steps WHERE recipe_id = ?").bind(recipeId).run();
      console.log(`Deleted cooking steps: ${cookingStepsResult.meta.changes} rows`);
      
      // Delete recipe ingredients
      const ingredientsResult = await env.DB.prepare("DELETE FROM recipe_ingredients WHERE recipe_id = ?").bind(recipeId).run();
      console.log(`Deleted ingredients: ${ingredientsResult.meta.changes} rows`);
      
      // Delete recipe steps
      const stepsResult = await env.DB.prepare("DELETE FROM recipe_steps WHERE recipe_id = ?").bind(recipeId).run();
      console.log(`Deleted steps: ${stepsResult.meta.changes} rows`);
      
      // Finally delete the recipe itself
      const recipeResult = await env.DB.prepare("DELETE FROM recipes WHERE id = ?").bind(recipeId).run();
      console.log(`Deleted recipe: ${recipeResult.meta.changes} rows`);

      if (recipeResult.meta.changes === 0) {
        console.error(`Recipe ${recipeId} was not deleted - no changes made`);
        return c.json({ error: "Recipe not found or already deleted" }, 404);
      }

      console.log(`Recipe ${recipeId} deleted successfully`);
      return c.json({ 
        message: "Recipe deleted successfully",
        id: recipeId 
      });
      
    } catch (deleteError) {
      console.error("Error during recipe deletion:", deleteError);
      
      // Check for foreign key constraint errors
      if (deleteError instanceof Error && deleteError.message.includes('FOREIGN KEY constraint failed')) {
        return c.json({ 
          error: "Cannot delete recipe - it has dependencies that need to be removed first",
          details: "This recipe may be referenced by other data in the system"
        }, 409);
      }
      
      throw deleteError;
    }
    
  } catch (error) {
    console.error("Recipe deletion error:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to delete recipe",
      details: error instanceof Error ? error.stack : undefined
    }, 500);
  }
});

export default recipes;
