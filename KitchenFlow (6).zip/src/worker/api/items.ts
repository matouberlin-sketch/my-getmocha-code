import { Hono } from "hono";
import type { Env } from "../bindings";

const items = new Hono<{ Bindings: Env }>();

// GET /api/items/:itemId/where-used - Find which recipes use this item
items.get("/:itemId/where-used", async (c) => {
  const itemId = parseInt(c.req.param("itemId"));
  const env = c.env;
  
  try {
    // Get item details
    const item = await env.DB.prepare("SELECT id, name FROM items WHERE id = ?").bind(itemId).first();
    
    if (!item) {
      return c.json({ error: "Item not found" }, 404);
    }

    const recipes: any[] = [];
    const subrecipes: any[] = [];
    const visited = new Set<number>();

    // Function to recursively find recipes that use this item
    async function findUsage(targetItemId: number, depth = 0, maxDepth = 10) {
      if (depth > maxDepth || visited.has(targetItemId)) {
        return;
      }
      visited.add(targetItemId);

      // Find direct usage in enhanced recipes
      const directUsage = await env.DB.prepare(`
        SELECT DISTINCT 
          er.recipe_id,
          er.name,
          er.type
        FROM enhanced_recipe_ingredients eri
        JOIN enhanced_recipes er ON eri.recipe_id = er.recipe_id
        WHERE eri.item_id = ?
      `).bind(targetItemId).all();

      for (const usage of directUsage.results) {
        if (usage.type === 'subrecipe') {
          subrecipes.push({
            id: usage.recipe_id,
            name: usage.name,
            via_subrecipe: depth > 0
          });
        } else {
          recipes.push({
            id: usage.recipe_id,
            name: usage.name,
            via_subrecipe: depth > 0
          });
        }
      }

      // Find indirect usage through recipe components (subrecipes)
      const subrecipeUsage = await env.DB.prepare(`
        SELECT DISTINCT 
          rc.parent_recipe_id as recipe_id
        FROM enhanced_recipe_ingredients eri
        JOIN recipe_components rc ON eri.recipe_id = rc.component_recipe_id
        WHERE eri.item_id = ?
      `).bind(targetItemId).all();

      for (const usage of subrecipeUsage.results) {
        // Get the parent recipe details
        const parentRecipe = await env.DB.prepare(`
          SELECT recipe_id, name, type FROM enhanced_recipes WHERE recipe_id = ?
        `).bind(usage.recipe_id).first();

        if (parentRecipe) {
          if (parentRecipe.type === 'subrecipe') {
            subrecipes.push({
              id: parentRecipe.recipe_id,
              name: parentRecipe.name,
              via_subrecipe: true
            });
            // Continue searching up the chain
            await findUsage(parseInt(parentRecipe.recipe_id), depth + 1, maxDepth);
          } else {
            recipes.push({
              id: parentRecipe.recipe_id,
              name: parentRecipe.name,
              via_subrecipe: true
            });
          }
        }
      }

      // Also check legacy recipe_bom table
      const bomUsage = await env.DB.prepare(`
        SELECT DISTINCT 
          r.id,
          r.name,
          'recipe' as type
        FROM recipe_bom rb
        JOIN recipes r ON rb.recipe_id = r.id
        WHERE rb.component_type = 'item' AND rb.component_id = ?
      `).bind(targetItemId).all();

      for (const usage of bomUsage.results) {
        recipes.push({
          id: usage.id,
          name: usage.name,
          via_subrecipe: depth > 0
        });
      }

      // Check for subrecipe usage in legacy tables
      const legacySubrecipeUsage = await env.DB.prepare(`
        SELECT DISTINCT 
          rb.recipe_id
        FROM recipe_bom rb1
        JOIN recipe_bom rb ON rb1.recipe_id = rb.component_id AND rb.component_type = 'subrecipe'
        WHERE rb1.component_type = 'item' AND rb1.component_id = ?
      `).bind(targetItemId).all();

      for (const usage of legacySubrecipeUsage.results) {
        const parentRecipe = await env.DB.prepare(`
          SELECT id, name, is_subrecipe FROM recipes WHERE id = ?
        `).bind(usage.recipe_id).first();

        if (parentRecipe) {
          if (parentRecipe.is_subrecipe) {
            subrecipes.push({
              id: parentRecipe.id,
              name: parentRecipe.name,
              via_subrecipe: true
            });
          } else {
            recipes.push({
              id: parentRecipe.id,
              name: parentRecipe.name,
              via_subrecipe: true
            });
          }
        }
      }
    }

    await findUsage(itemId);

    // Remove duplicates based on ID
    const uniqueRecipes = Array.from(
      new Map(recipes.map(r => [r.id, r])).values()
    );
    const uniqueSubrecipes = Array.from(
      new Map(subrecipes.map(r => [r.id, r])).values()
    );

    return c.json({
      item: {
        id: item.id,
        name: item.name
      },
      recipes: uniqueRecipes,
      subrecipes: uniqueSubrecipes
    });
  } catch (error) {
    console.error("Failed to get where-used data:", error);
    return c.json({ error: "Failed to get where-used data" }, 500);
  }
});

// GET /api/items - Get all items
items.get("/", async (c) => {
  const env = c.env;
  
  try {
    const items = await env.DB.prepare(`
      SELECT * FROM items 
      ORDER BY name ASC
    `).all();

    return c.json({ items: items.results });
  } catch (error) {
    console.error("Failed to fetch items:", error);
    return c.json({ error: "Failed to fetch items" }, 500);
  }
});

// GET /api/items/:id - Get single item
items.get("/:id", async (c) => {
  const itemId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const item = await env.DB.prepare("SELECT * FROM items WHERE id = ?").bind(itemId).first();
    
    if (!item) {
      return c.json({ error: "Item not found" }, 404);
    }

    // Get supplier items
    const supplierItems = await env.DB.prepare(`
      SELECT * FROM supplier_items_enhanced WHERE item_id = ? ORDER BY price ASC
    `).bind(item.item_id).all();

    // Get UOM conversions
    const uomConversions = await env.DB.prepare(`
      SELECT * FROM item_uom_conversions WHERE item_id = ? ORDER BY from_uom, to_uom
    `).bind(item.item_id).all();

    // Get recipes that use this item
    const usedInRecipes = await env.DB.prepare(`
      SELECT eri.*, er.name as recipe_name, er.type 
      FROM enhanced_recipe_ingredients eri
      JOIN enhanced_recipes er ON eri.recipe_id = er.recipe_id
      WHERE eri.item_id = ?
      ORDER BY er.name
    `).bind(item.item_id).all();

    // Get recipes that output this item
    const outputRecipes = await env.DB.prepare(`
      SELECT er.* FROM enhanced_recipes er WHERE er.output_item_id = ?
      ORDER BY er.name
    `).bind(item.item_id).all();

    return c.json({
      ...item,
      supplier_items: supplierItems.results,
      uom_conversions: uomConversions.results,
      used_in_recipes: usedInRecipes.results,
      output_recipes: outputRecipes.results
    });
  } catch (error) {
    console.error("Failed to fetch item:", error);
    return c.json({ error: "Failed to fetch item" }, 500);
  }
});

// POST /api/items - Create new item
items.post("/", async (c) => {
  const env = c.env;
  
  try {
    const body = await c.req.json();
    const { 
      item_id, name, item_type, base_uom, category, default_state, 
      edible_yield_pct, density_g_per_ml, allergen_codes, notes,
      kcal_per_100, protein_g_per_100, carbs_g_per_100, fat_g_per_100
    } = body;

    // Validation
    if (!item_id || !name || !item_type || !base_uom) {
      return c.json({ error: "item_id, name, item_type, and base_uom are required" }, 400);
    }

    const result = await env.DB.prepare(`
      INSERT INTO items (
        item_id, name, item_type, base_uom, category, default_state,
        edible_yield_pct, density_g_per_ml, allergen_codes, notes,
        kcal_per_100, protein_g_per_100, carbs_g_per_100, fat_g_per_100
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      item_id, name, item_type, base_uom, category || null, default_state || null,
      edible_yield_pct || 100, density_g_per_ml || null, allergen_codes || null, notes || null,
      kcal_per_100 || null, protein_g_per_100 || null, carbs_g_per_100 || null, fat_g_per_100 || null
    ).run();

    const item = await env.DB.prepare("SELECT * FROM items WHERE id = ?").bind(result.meta.last_row_id).first();

    return c.json({ item }, 201);
  } catch (error) {
    console.error("Failed to create item:", error);
    return c.json({ error: "Failed to create item" }, 500);
  }
});

// PUT /api/items/:id - Update item
items.put("/:id", async (c) => {
  const itemId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const body = await c.req.json();
    const { 
      name, item_type, base_uom, category, default_state, 
      edible_yield_pct, density_g_per_ml, allergen_codes, notes,
      kcal_per_100, protein_g_per_100, carbs_g_per_100, fat_g_per_100
    } = body;

    const existingItem = await env.DB.prepare("SELECT * FROM items WHERE id = ?").bind(itemId).first();
    if (!existingItem) {
      return c.json({ error: "Item not found" }, 404);
    }

    await env.DB.prepare(`
      UPDATE items 
      SET name = ?, item_type = ?, base_uom = ?, category = ?, default_state = ?,
          edible_yield_pct = ?, density_g_per_ml = ?, allergen_codes = ?, notes = ?,
          kcal_per_100 = ?, protein_g_per_100 = ?, carbs_g_per_100 = ?, fat_g_per_100 = ?,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      name || existingItem.name,
      item_type || existingItem.item_type,
      base_uom || existingItem.base_uom,
      category !== undefined ? category : existingItem.category,
      default_state !== undefined ? default_state : existingItem.default_state,
      edible_yield_pct !== undefined ? edible_yield_pct : existingItem.edible_yield_pct,
      density_g_per_ml !== undefined ? density_g_per_ml : existingItem.density_g_per_ml,
      allergen_codes !== undefined ? allergen_codes : existingItem.allergen_codes,
      notes !== undefined ? notes : existingItem.notes,
      kcal_per_100 !== undefined ? kcal_per_100 : existingItem.kcal_per_100,
      protein_g_per_100 !== undefined ? protein_g_per_100 : existingItem.protein_g_per_100,
      carbs_g_per_100 !== undefined ? carbs_g_per_100 : existingItem.carbs_g_per_100,
      fat_g_per_100 !== undefined ? fat_g_per_100 : existingItem.fat_g_per_100,
      itemId
    ).run();

    const updatedItem = await env.DB.prepare("SELECT * FROM items WHERE id = ?").bind(itemId).first();

    return c.json({ item: updatedItem });
  } catch (error) {
    console.error("Failed to update item:", error);
    return c.json({ error: "Failed to update item" }, 500);
  }
});

// DELETE /api/items/:id - Delete item
items.delete("/:id", async (c) => {
  const itemId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const existingItem = await env.DB.prepare("SELECT * FROM items WHERE id = ?").bind(itemId).first();
    if (!existingItem) {
      return c.json({ error: "Item not found" }, 404);
    }

    // Check if item is used in recipes
    const recipeUsage = await env.DB.prepare(`
      SELECT COUNT(*) as count FROM enhanced_recipe_ingredients WHERE item_id = ?
    `).bind(existingItem.item_id).first<{ count: number }>();
    
    if (recipeUsage?.count && recipeUsage.count > 0) {
      return c.json({ 
        error: "Cannot delete item - it is used in recipes",
        usage_count: recipeUsage.count 
      }, 409);
    }

    // Check if item is used in BOM
    const bomUsage = await env.DB.prepare(`
      SELECT COUNT(*) as count FROM recipe_bom WHERE component_type = 'item' AND component_id = ?
    `).bind(itemId).first<{ count: number }>();
    
    if (bomUsage?.count && bomUsage.count > 0) {
      return c.json({ 
        error: "Cannot delete item - it is used in recipe BOMs",
        bom_usage_count: bomUsage.count 
      }, 409);
    }

    const result = await env.DB.prepare("DELETE FROM items WHERE id = ?").bind(itemId).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Item not found or already deleted" }, 404);
    }

    return c.json({ message: "Item deleted successfully" });
  } catch (error) {
    console.error("Failed to delete item:", error);
    return c.json({ error: "Failed to delete item" }, 500);
  }
});

export default items;
