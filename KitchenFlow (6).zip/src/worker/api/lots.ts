import { Hono } from "hono";
import type { Env } from "../bindings";

const lots = new Hono<{ Bindings: Env }>();

// GET /api/lots - Get all lots
lots.get("/", async (c) => {
  const env = c.env;
  
  try {
    const lots = await env.DB.prepare(`
      SELECT 
        l.*,
        i.name as item_name,
        i.base_uom,
        s.name as supplier_name
      FROM lots l
      JOIN items i ON l.item_id = i.id
      LEFT JOIN suppliers s ON l.supplier_id = s.id
      ORDER BY l.received_at DESC
    `).all();

    return c.json({ lots: lots.results });
  } catch (error) {
    console.error("Failed to fetch lots:", error);
    return c.json({ error: "Failed to fetch lots" }, 500);
  }
});

// GET /api/lots/:itemId - Get lots for specific item
lots.get("/:itemId", async (c) => {
  const itemId = parseInt(c.req.param("itemId"));
  const env = c.env;
  
  try {
    const lots = await env.DB.prepare(`
      SELECT 
        l.*,
        i.name as item_name,
        i.base_uom,
        s.name as supplier_name
      FROM lots l
      JOIN items i ON l.item_id = i.id
      LEFT JOIN suppliers s ON l.supplier_id = s.id
      WHERE l.item_id = ?
      ORDER BY l.received_at DESC
    `).bind(itemId).all();

    return c.json({ lots: lots.results });
  } catch (error) {
    console.error("Failed to fetch lots for item:", error);
    return c.json({ error: "Failed to fetch lots for item" }, 500);
  }
});

// POST /api/lots - Create new lot record
lots.post("/", async (c) => {
  const env = c.env;
  
  try {
    const body = await c.req.json();
    const { item_id, lot_code, received_at, qty, uom, supplier_id } = body;

    // Validation
    if (!item_id || !lot_code || !received_at || !qty || !uom) {
      return c.json({ error: "item_id, lot_code, received_at, qty, and uom are required" }, 400);
    }

    if (qty <= 0) {
      return c.json({ error: "Quantity must be greater than 0" }, 400);
    }

    // Check if item exists
    const item = await env.DB.prepare("SELECT id FROM items WHERE id = ?").bind(item_id).first();
    if (!item) {
      return c.json({ error: "Item not found" }, 404);
    }

    // Check if supplier exists (if provided)
    if (supplier_id) {
      const supplier = await env.DB.prepare("SELECT id FROM suppliers WHERE id = ?").bind(supplier_id).first();
      if (!supplier) {
        return c.json({ error: "Supplier not found" }, 404);
      }
    }

    // Create lot record
    const result = await env.DB.prepare(`
      INSERT INTO lots (item_id, lot_code, received_at, qty, uom, supplier_id)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(item_id, lot_code, received_at, qty, uom, supplier_id || null).run();

    const lot = await env.DB.prepare(`
      SELECT 
        l.*,
        i.name as item_name,
        i.base_uom,
        s.name as supplier_name
      FROM lots l
      JOIN items i ON l.item_id = i.id
      LEFT JOIN suppliers s ON l.supplier_id = s.id
      WHERE l.id = ?
    `).bind(result.meta.last_row_id).first();

    return c.json({ lot }, 201);
  } catch (error) {
    console.error("Failed to create lot:", error);
    return c.json({ error: "Failed to create lot" }, 500);
  }
});

// PUT /api/lots/:id - Update lot
lots.put("/:id", async (c) => {
  const lotId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const body = await c.req.json();
    const { lot_code, received_at, qty, uom, supplier_id } = body;

    // Check if lot exists
    const existingLot = await env.DB.prepare("SELECT * FROM lots WHERE id = ?").bind(lotId).first();
    if (!existingLot) {
      return c.json({ error: "Lot not found" }, 404);
    }

    // Validation
    if (qty !== undefined && qty <= 0) {
      return c.json({ error: "Quantity must be greater than 0" }, 400);
    }

    // Check if supplier exists (if provided)
    if (supplier_id) {
      const supplier = await env.DB.prepare("SELECT id FROM suppliers WHERE id = ?").bind(supplier_id).first();
      if (!supplier) {
        return c.json({ error: "Supplier not found" }, 404);
      }
    }

    // Update lot
    await env.DB.prepare(`
      UPDATE lots 
      SET lot_code = ?, received_at = ?, qty = ?, uom = ?, supplier_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      lot_code || existingLot.lot_code,
      received_at || existingLot.received_at,
      qty !== undefined ? qty : existingLot.qty,
      uom || existingLot.uom,
      supplier_id !== undefined ? supplier_id : existingLot.supplier_id,
      lotId
    ).run();

    const updatedLot = await env.DB.prepare(`
      SELECT 
        l.*,
        i.name as item_name,
        i.base_uom,
        s.name as supplier_name
      FROM lots l
      JOIN items i ON l.item_id = i.id
      LEFT JOIN suppliers s ON l.supplier_id = s.id
      WHERE l.id = ?
    `).bind(lotId).first();

    return c.json({ lot: updatedLot });
  } catch (error) {
    console.error("Failed to update lot:", error);
    return c.json({ error: "Failed to update lot" }, 500);
  }
});

// DELETE /api/lots/:id - Delete lot
lots.delete("/:id", async (c) => {
  const lotId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    // Check if lot exists
    const existingLot = await env.DB.prepare("SELECT * FROM lots WHERE id = ?").bind(lotId).first();
    if (!existingLot) {
      return c.json({ error: "Lot not found" }, 404);
    }

    // Check if lot has been consumed
    const consumptionCheck = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM batch_consumption WHERE lot_id = ?"
    ).bind(lotId).first<{ count: number }>();
    
    if (consumptionCheck?.count && consumptionCheck.count > 0) {
      return c.json({ 
        error: "Cannot delete lot - it has been used in batch consumption records",
        consumption_count: consumptionCheck.count 
      }, 409);
    }

    // Delete lot
    const result = await env.DB.prepare("DELETE FROM lots WHERE id = ?").bind(lotId).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Lot not found or already deleted" }, 404);
    }

    return c.json({ message: "Lot deleted successfully" });
  } catch (error) {
    console.error("Failed to delete lot:", error);
    return c.json({ error: "Failed to delete lot" }, 500);
  }
});

export default lots;
