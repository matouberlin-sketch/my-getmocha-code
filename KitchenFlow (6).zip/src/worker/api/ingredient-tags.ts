import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const ingredientTags = new Hono<{ Bindings: Env }>();

// Zod schemas for validation
const AddTagSchema = z.object({
  ingredient_id: z.number(),
  tag: z.string().min(1).toLowerCase().trim(),
});

const RemoveTagSchema = z.object({
  ingredient_id: z.number(),
  tag: z.string().min(1).toLowerCase().trim(),
});

const BulkTagSchema = z.object({
  ingredient_ids: z.array(z.number()),
  tags_to_add: z.array(z.string()).optional(),
  tags_to_remove: z.array(z.string()).optional(),
});

// Get all unique tags
ingredientTags.get("/", async (c) => {
  const env = c.env;
  
  try {
    const tags = await env.DB.prepare(`
      SELECT tag, COUNT(*) as usage_count
      FROM ingredient_tags
      GROUP BY tag
      ORDER BY usage_count DESC, tag ASC
    `).all();

    return c.json(tags.results);
  } catch (error) {
    console.error("Failed to fetch ingredient tags:", error);
    return c.json({ error: "Failed to fetch ingredient tags" }, 500);
  }
});

// Get tags for a specific ingredient
ingredientTags.get("/ingredient/:id", async (c) => {
  const ingredientId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const tags = await env.DB.prepare(`
      SELECT tag FROM ingredient_tags 
      WHERE ingredient_id = ?
      ORDER BY tag ASC
    `).bind(ingredientId).all();

    return c.json(tags.results.map((row: any) => row.tag));
  } catch (error) {
    console.error("Failed to fetch ingredient tags:", error);
    return c.json({ error: "Failed to fetch ingredient tags" }, 500);
  }
});

// Add tag to ingredient
ingredientTags.post("/add", zValidator("json", AddTagSchema), async (c) => {
  const { ingredient_id, tag } = c.req.valid("json");
  const env = c.env;
  
  try {
    await env.DB.prepare(`
      INSERT OR IGNORE INTO ingredient_tags (ingredient_id, tag, created_at, updated_at)
      VALUES (?, ?, datetime('now'), datetime('now'))
    `).bind(ingredient_id, tag.toLowerCase().trim()).run();

    return c.json({ message: "Tag added successfully" });
  } catch (error) {
    console.error("Failed to add ingredient tag:", error);
    return c.json({ error: "Failed to add ingredient tag" }, 500);
  }
});

// Remove tag from ingredient
ingredientTags.post("/remove", zValidator("json", RemoveTagSchema), async (c) => {
  const { ingredient_id, tag } = c.req.valid("json");
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(`
      DELETE FROM ingredient_tags 
      WHERE ingredient_id = ? AND tag = ?
    `).bind(ingredient_id, tag.toLowerCase().trim()).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Tag not found on this ingredient" }, 404);
    }

    return c.json({ message: "Tag removed successfully" });
  } catch (error) {
    console.error("Failed to remove ingredient tag:", error);
    return c.json({ error: "Failed to remove ingredient tag" }, 500);
  }
});

// Bulk tag operations
ingredientTags.post("/bulk", zValidator("json", BulkTagSchema), async (c) => {
  const { ingredient_ids, tags_to_add, tags_to_remove } = c.req.valid("json");
  const env = c.env;
  
  try {
    // Add tags to all selected ingredients
    if (tags_to_add && tags_to_add.length > 0) {
      for (const ingredientId of ingredient_ids) {
        for (const tag of tags_to_add) {
          await env.DB.prepare(`
            INSERT OR IGNORE INTO ingredient_tags (ingredient_id, tag, created_at, updated_at)
            VALUES (?, ?, datetime('now'), datetime('now'))
          `).bind(ingredientId, tag.toLowerCase().trim()).run();
        }
      }
    }

    // Remove tags from all selected ingredients
    if (tags_to_remove && tags_to_remove.length > 0) {
      for (const ingredientId of ingredient_ids) {
        for (const tag of tags_to_remove) {
          await env.DB.prepare(`
            DELETE FROM ingredient_tags 
            WHERE ingredient_id = ? AND tag = ?
          `).bind(ingredientId, tag.toLowerCase().trim()).run();
        }
      }
    }

    return c.json({ 
      message: "Bulk tag operations completed successfully",
      ingredients_updated: ingredient_ids.length,
      tags_added: tags_to_add?.length || 0,
      tags_removed: tags_to_remove?.length || 0
    });
  } catch (error) {
    console.error("Failed to perform bulk tag operations:", error);
    return c.json({ error: "Failed to perform bulk tag operations" }, 500);
  }
});

// Get ingredients by tag
ingredientTags.get("/tag/:tag", async (c) => {
  const tag = c.req.param("tag").toLowerCase().trim();
  const env = c.env;
  
  try {
    const ingredients = await env.DB.prepare(`
      SELECT i.*, it.tag
      FROM ingredients i
      JOIN ingredient_tags it ON i.id = it.ingredient_id
      WHERE it.tag = ?
      ORDER BY i.name ASC
    `).bind(tag).all();

    return c.json(ingredients.results);
  } catch (error) {
    console.error("Failed to fetch ingredients by tag:", error);
    return c.json({ error: "Failed to fetch ingredients by tag" }, 500);
  }
});

export default ingredientTags;
