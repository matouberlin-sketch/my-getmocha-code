import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const locations = new Hono<{ Bindings: Env }>();

// Zod schema for validation when creating a new location
const CreateLocationSchema = z.object({
  name: z.string().min(1, "Location name cannot be empty"),
  type: z.string().optional(),
  description: z.string().optional(),
});

const UpdateLocationSchema = z.object({
  name: z.string().min(1).optional(),
  type: z.string().optional(),
  description: z.string().optional(),
});

// Get all locations
locations.get("/", async (c) => {
  const env = c.env;
  try {
    const result = await env.DB.prepare("SELECT * FROM locations ORDER BY name ASC").all();
    return c.json(result.results);
  } catch (error) {
    console.error("Failed to fetch locations:", error);
    return c.json({ error: "Failed to fetch locations" }, 500);
  }
});

// Get single location
locations.get("/:id", async (c) => {
  const locationId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const location = await env.DB.prepare(
      "SELECT * FROM locations WHERE id = ?"
    ).bind(locationId).first();
    
    if (!location) {
      return c.json({ error: "Location not found" }, 404);
    }

    return c.json(location);
  } catch (error) {
    console.error("Failed to fetch location:", error);
    return c.json({ error: "Failed to fetch location" }, 500);
  }
});

// Create a new location
locations.post("/", zValidator("json", CreateLocationSchema), async (c) => {
  const locationData = c.req.valid("json");
  const env = c.env;
  try {
    const result = await env.DB.prepare(`
      INSERT INTO locations (name, type, description, created_at, updated_at)
      VALUES (?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      locationData.name,
      locationData.type || null,
      locationData.description || null
    ).run();

    return c.json({ 
      id: result.meta.last_row_id,
      message: "Location created successfully" 
    }, 201);
  } catch (error) {
    console.error("Location creation error:", error);
    if (error instanceof Error && error.message.includes('UNIQUE constraint failed')) {
      return c.json({ error: "Location name already exists" }, 409);
    }
    return c.json({ error: "Failed to create location" }, 500);
  }
});

// Update location
locations.put("/:id", zValidator("json", UpdateLocationSchema), async (c) => {
  const locationId = parseInt(c.req.param("id"));
  const locationData = c.req.valid("json");
  const env = c.env;
  
  try {
    // Build dynamic SQL based on provided fields
    const updates: string[] = [];
    const values: any[] = [];
    
    if (locationData.name !== undefined) {
      updates.push("name = ?");
      values.push(locationData.name);
    }
    
    if (locationData.type !== undefined) {
      updates.push("type = ?");
      values.push(locationData.type);
    }
    
    if (locationData.description !== undefined) {
      updates.push("description = ?");
      values.push(locationData.description);
    }
    
    if (updates.length === 0) {
      return c.json({ error: "No fields to update" }, 400);
    }
    
    updates.push("updated_at = datetime('now')");
    values.push(locationId);
    
    const sql = `UPDATE locations SET ${updates.join(", ")} WHERE id = ?`;
    const result = await env.DB.prepare(sql).bind(...values).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Location not found" }, 404);
    }

    return c.json({ message: "Location updated successfully" });
  } catch (error) {
    console.error("Location update error:", error);
    if (error instanceof Error && error.message.includes('UNIQUE constraint failed')) {
      return c.json({ error: "Location name already exists" }, 409);
    }
    return c.json({ error: "Failed to update location" }, 500);
  }
});

// Delete location
locations.delete("/:id", async (c) => {
  const locationId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(
      "DELETE FROM locations WHERE id = ?"
    ).bind(locationId).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Location not found" }, 404);
    }

    return c.json({ message: "Location deleted successfully" });
  } catch (error) {
    console.error("Location deletion error:", error);
    return c.json({ error: "Failed to delete location" }, 500);
  }
});

export default locations;
