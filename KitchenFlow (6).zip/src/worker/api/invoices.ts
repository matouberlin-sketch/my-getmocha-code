import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import OpenAI from "openai";
import type { Env } from "../bindings";

const invoices = new Hono<{ Bindings: Env }>();

// Zod schemas for validation
const UploadInvoiceSchema = z.object({
  image_data: z.string(), // Base64 encoded image
  filename: z.string(),
});

const ReviewInvoiceSchema = z.object({
  invoice_id: z.number(),
  confirmed_data: z.object({
    supplier_name: z.string(),
    invoice_date: z.string(),
    total_amount: z.number(),
    currency: z.string().default('USD'),
    line_items: z.array(z.object({
      product_name: z.string(),
      quantity: z.number(),
      unit: z.string(),
      unit_price: z.number(),
      line_item_total: z.number(),
    })),
  }),
});

// AI prompt for invoice data extraction
const INVOICE_EXTRACTION_PROMPT = `You are an expert assistant for extracting structured data from supplier invoices.
Your goal is to parse the provided invoice text or image and return a JSON object containing key details.

**Extraction Requirements:**
1. **Supplier Name:** The name of the company that issued the invoice.
2. **Invoice Date:** The date the invoice was issued (YYYY-MM-DD format).
3. **Total Amount Due:** The grand total amount of the invoice, including taxes and shipping.
4. **Currency:** The currency of the total amount (e.g., "USD", "EUR", "GBP").
5. **Line Items:** A list of all individual products/services purchased. For each line item, extract:
   * **Product Name:** The specific name of the item.
   * **Quantity:** The number of units purchased.
   * **Unit:** The unit of measure for the quantity (e.g., "kg", "box", "each", "liter").
   * **Unit Price:** The price per single unit of the item.
   * **Line Item Total:** The total cost for that specific line item.

**Instructions:**
* Read the entire invoice document carefully.
* Extract all specified fields. If a field is not found, return null for its value.
* Ensure numerical values are parsed as numbers (floats or integers).
* Format the output as a single JSON object.
* Be precise with product names - include brand, size, and specifications when available.

**Example JSON Output Structure:**
{
  "supplier_name": "Metro Wholesale Foods Ltd",
  "invoice_date": "2025-09-18",
  "total_amount_due": 1234.56,
  "currency": "USD",
  "line_items": [
    {
      "product_name": "Organic Beef Chuck Roast 2kg",
      "quantity": 5,
      "unit": "piece",
      "unit_price": 24.99,
      "line_item_total": 124.95
    },
    {
      "product_name": "Free Range Eggs Large (12ct)",
      "quantity": 10,
      "unit": "dozen",
      "unit_price": 4.50,
      "line_item_total": 45.00
    }
  ]
}

Please analyze the provided invoice and return the extracted data in the exact JSON format above.`;

// Upload and process invoice
invoices.post("/upload", zValidator("json", UploadInvoiceSchema), async (c) => {
  const { image_data, filename } = c.req.valid("json");
  const env = c.env;

  if (!env.OPENAI_API_KEY) {
    return c.json({ error: "OpenAI API key not configured" }, 500);
  }

  try {
    const openai = new OpenAI({
      apiKey: env.OPENAI_API_KEY,
    });

    // Use GPT-4 Vision to analyze the invoice image
    let response;
    try {
      response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: INVOICE_EXTRACTION_PROMPT,
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${image_data}`,
                  detail: "high"
                },
              },
            ],
          },
        ],
        max_tokens: 2000,
        temperature: 0.1, // Low temperature for consistent extraction
      });
    } catch (apiError: any) {
      if (apiError.status === 429) {
        throw new Error("OpenAI API quota exceeded. Please check your OpenAI billing and usage limits. You may need to upgrade your plan or wait for quota reset.");
      } else if (apiError.status === 401) {
        throw new Error("OpenAI API authentication failed. Please check your API key configuration.");
      } else if (apiError.status >= 500) {
        throw new Error("OpenAI service is temporarily unavailable. Please try again in a few minutes.");
      } else {
        throw new Error(`OpenAI API error: ${apiError.message || 'Unknown error'}`);
      }
    }

    const extractedText = response.choices[0]?.message?.content;
    
    if (!extractedText) {
      throw new Error("No response from OpenAI");
    }

    // Parse the JSON response from OpenAI
    let extractedData;
    try {
      // Find JSON in the response (in case there's extra text)
      const jsonMatch = extractedText.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? jsonMatch[0] : extractedText;
      extractedData = JSON.parse(jsonString);
    } catch (parseError) {
      console.error("Failed to parse OpenAI response as JSON:", extractedText);
      throw new Error("Failed to parse extracted data");
    }

    // Validate extracted data structure
    if (!extractedData.supplier_name || !extractedData.line_items) {
      throw new Error("Invalid invoice data extracted");
    }

    // Store the invoice record
    const invoiceResult = await env.DB.prepare(`
      INSERT INTO invoices (
        supplier_id, invoice_date, total_amount, currency, 
        file_path, processed_data, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'pending', datetime('now'), datetime('now'))
    `).bind(
      null, // Will be set when supplier is matched/created
      extractedData.invoice_date || null,
      extractedData.total_amount_due || null,
      extractedData.currency || 'USD',
      filename,
      JSON.stringify(extractedData),
    ).run();

    const invoiceId = invoiceResult.meta.last_row_id as number;

    // Try to find matching supplier
    let matchedSupplier = null;
    if (extractedData.supplier_name) {
      const supplier = await env.DB.prepare(
        "SELECT * FROM suppliers WHERE LOWER(name) LIKE LOWER(?)"
      ).bind(`%${extractedData.supplier_name}%`).first();
      matchedSupplier = supplier;
    }

    return c.json({
      invoice_id: invoiceId,
      extracted_data: extractedData,
      matched_supplier: matchedSupplier,
      message: "Invoice processed successfully",
    });
  } catch (error) {
    console.error("Invoice processing error:", error);
    
    // Store failed attempt
    try {
      await env.DB.prepare(`
        INSERT INTO invoices (
          file_path, processed_data, status, created_at, updated_at
        ) VALUES (?, ?, 'failed', datetime('now'), datetime('now'))
      `).bind(
        filename,
        JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      ).run();
    } catch (dbError) {
      console.error("Failed to store error invoice:", dbError);
    }

    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to process invoice"
    }, 500);
  }
});

// Review and confirm invoice data
invoices.post("/review", zValidator("json", ReviewInvoiceSchema), async (c) => {
  const { invoice_id, confirmed_data } = c.req.valid("json");
  const env = c.env;

  try {
    // Get the invoice
    const invoice = await env.DB.prepare(
      "SELECT * FROM invoices WHERE id = ?"
    ).bind(invoice_id).first();

    if (!invoice) {
      return c.json({ error: "Invoice not found" }, 404);
    }

    // Find or create supplier
    let supplierId: number;
    const existingSupplier = await env.DB.prepare(
      "SELECT id FROM suppliers WHERE LOWER(name) = LOWER(?)"
    ).bind(confirmed_data.supplier_name).first<{ id: number }>();

    if (existingSupplier) {
      supplierId = existingSupplier.id;
    } else {
      // Create new supplier
      const supplierResult = await env.DB.prepare(`
        INSERT INTO suppliers (name, created_at, updated_at)
        VALUES (?, datetime('now'), datetime('now'))
      `).bind(confirmed_data.supplier_name).run();
      supplierId = supplierResult.meta.last_row_id as number;
    }

    // Process each line item
    const processedItems = [];
    
    for (const lineItem of confirmed_data.line_items) {
      // Try to match ingredient by name
      let ingredientId: number | null = null;
      
      const existingIngredient = await env.DB.prepare(
        "SELECT id FROM ingredients WHERE LOWER(name) LIKE LOWER(?)"
      ).bind(`%${lineItem.product_name}%`).first<{ id: number }>();

      if (existingIngredient) {
        ingredientId = existingIngredient.id;
      } else {
        // Create new ingredient (basic info)
        const unitType = inferUnitType(lineItem.unit);
        const ingredientResult = await env.DB.prepare(`
          INSERT INTO ingredients (name, unit_type, created_at, updated_at)
          VALUES (?, ?, datetime('now'), datetime('now'))
        `).bind(lineItem.product_name, unitType).run();
        ingredientId = ingredientResult.meta.last_row_id as number;
      }

      // Add/update supplier pricing
      if (ingredientId) {
        await env.DB.prepare(`
          INSERT OR REPLACE INTO ingredient_supplier_prices (
            ingredient_id, supplier_id, pack_size, pack_unit, cost_per_pack,
            last_updated_price, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), datetime('now'))
        `).bind(
          ingredientId,
          supplierId,
          lineItem.quantity,
          lineItem.unit,
          lineItem.line_item_total
        ).run();
      }

      processedItems.push({
        ingredient_id: ingredientId,
        product_name: lineItem.product_name,
        quantity: lineItem.quantity,
        unit: lineItem.unit,
        unit_price: lineItem.unit_price,
        total_price: lineItem.line_item_total,
      });
    }

    // Update invoice status
    await env.DB.prepare(`
      UPDATE invoices 
      SET supplier_id = ?, invoice_date = ?, total_amount = ?, currency = ?,
          processed_data = ?, status = 'processed', updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      supplierId,
      confirmed_data.invoice_date,
      confirmed_data.total_amount,
      confirmed_data.currency,
      JSON.stringify({ confirmed_data, processed_items: processedItems }),
      invoice_id
    ).run();

    return c.json({
      message: "Invoice data confirmed and processed",
      supplier_id: supplierId,
      processed_items: processedItems.length,
    });
  } catch (error) {
    console.error("Invoice review error:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to process invoice review"
    }, 500);
  }
});

// Get all invoices
invoices.get("/", async (c) => {
  const env = c.env;
  
  try {
    const invoices = await env.DB.prepare(`
      SELECT i.*, s.name as supplier_name
      FROM invoices i
      LEFT JOIN suppliers s ON i.supplier_id = s.id
      ORDER BY i.created_at DESC
    `).all();

    return c.json(invoices.results);
  } catch (error) {
    console.error("Failed to fetch invoices:", error);
    return c.json({ error: "Failed to fetch invoices" }, 500);
  }
});

// Get single invoice
invoices.get("/:id", async (c) => {
  const invoiceId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const invoice = await env.DB.prepare(`
      SELECT i.*, s.name as supplier_name, s.contact_person, s.phone, s.email
      FROM invoices i
      LEFT JOIN suppliers s ON i.supplier_id = s.id
      WHERE i.id = ?
    `).bind(invoiceId).first();
    
    if (!invoice) {
      return c.json({ error: "Invoice not found" }, 404);
    }

    // Parse processed data
    let processedData = null;
    if (invoice.processed_data) {
      try {
        processedData = JSON.parse(invoice.processed_data as string);
      } catch (e) {
        console.error("Failed to parse processed data:", e);
      }
    }

    return c.json({
      ...invoice,
      processed_data: processedData,
    });
  } catch (error) {
    console.error("Failed to fetch invoice:", error);
    return c.json({ error: "Failed to fetch invoice" }, 500);
  }
});

// Helper function to infer unit type
function inferUnitType(unit: string): 'weight' | 'volume' | 'count' {
  const weightUnits = ['g', 'kg', 'gram', 'grams', 'kilogram', 'kilograms', 'oz', 'ounce', 'ounces', 'lb', 'pound', 'pounds'];
  const volumeUnits = ['ml', 'l', 'liter', 'liters', 'milliliter', 'milliliters', 'cup', 'cups', 'tbsp', 'tablespoon', 'tablespoons', 'tsp', 'teaspoon', 'teaspoons', 'fl oz', 'fluid ounce', 'fluid ounces'];
  
  const lowerUnit = unit.toLowerCase().trim();
  
  if (weightUnits.includes(lowerUnit)) return 'weight';
  if (volumeUnits.includes(lowerUnit)) return 'volume';
  return 'count';
}

export default invoices;
