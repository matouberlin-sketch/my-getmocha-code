import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";
import {
  explodeRecipe,
  costRecipePortion,
  convertQty,
  unitCost,
  netQty,
  type RecipeData,
  type ItemData,
  type SupplierPrice
} from "@/shared/utils/bomHelpers";

const bom = new Hono<{ Bindings: Env }>();

// Get BOM tree for a recipe with computed costs
bom.get("/recipes/:id/bom", async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const env = c.env;
  const showCosts = c.req.query('show_costs') === 'true';
  
  try {
    // Load recipe with BOM
    const recipe = await env.DB.prepare(`
      SELECT r.*, r.yield_amount as portion_yield
      FROM recipes r 
      WHERE r.id = ?
    `).bind(recipeId).first();
    
    if (!recipe) {
      return c.json({ error: "Recipe not found" }, 404);
    }
    
    // Load BOM components
    const bomComponents = await env.DB.prepare(`
      SELECT rb.*, 
             CASE 
               WHEN rb.component_type = 'item' THEN i.name
               WHEN rb.component_type = 'subrecipe' THEN r.name
             END as component_name
      FROM recipe_bom rb
      LEFT JOIN items i ON rb.component_type = 'item' AND rb.component_id = i.id
      LEFT JOIN recipes r ON rb.component_type = 'subrecipe' AND rb.component_id = r.id
      WHERE rb.recipe_id = ?
      ORDER BY rb.sort_order ASC
    `).bind(recipeId).all();
    
    const bomTree = [];
    let totalCostCents = 0;
    
    for (const component of bomComponents.results) {
      const netQuantity = netQty(
        component.gross_qty as number,
        component.trim_loss_pct as number,
        component.cook_yield_pct as number
      );
      
      let unitCostCents = 0;
      let lineCostCents = 0;
      
      if (showCosts && component.component_type === 'item') {
        try {
          // Load item and supplier data for costing
          const item = await loadItemWithConversions(env, component.component_id as number);
          const suppliers = await loadItemSuppliers(env, component.component_id as number);
          
          if (item && suppliers.length > 0) {
            const cost = unitCost(item, suppliers);
            const qtyInBase = convertQty(item, netQuantity, component.uom as string, item.base_uom);
            unitCostCents = cost.amount_cents;
            lineCostCents = unitCostCents * qtyInBase;
          }
        } catch (error) {
          console.warn(`Could not calculate cost for component ${component.id}:`, error);
        }
      } else if (showCosts && component.component_type === 'subrecipe') {
        // Recursively calculate subrecipe cost
        try {
          const subrecipeData = await loadRecipeData(env, component.component_id as number);
          const allRecipes = new Map<number, RecipeData>();
          const allItems = new Map<number, ItemData>();
          const allSuppliers = new Map<number, SupplierPrice[]>();
          
          // Load dependencies (simplified for this endpoint)
          // In a real implementation, we'd load all needed data
          const subrecipeCost = costRecipePortion(subrecipeData, allRecipes, allItems, allSuppliers);
          lineCostCents = subrecipeCost.cost_per_portion_cents * netQuantity;
        } catch (error) {
          console.warn(`Could not calculate cost for subrecipe ${component.component_id}:`, error);
        }
      }
      
      totalCostCents += lineCostCents;
      
      const bomNode = {
        id: component.id,
        component_type: component.component_type,
        component_id: component.component_id,
        component_name: component.component_name,
        gross_qty: component.gross_qty,
        net_qty: netQuantity,
        uom: component.uom,
        trim_loss_pct: component.trim_loss_pct,
        cook_yield_pct: component.cook_yield_pct,
        stage: component.stage,
        note: component.note,
        ...(showCosts && {
          unit_cost_cents: unitCostCents,
          line_cost_cents: lineCostCents
        })
      };
      
      bomTree.push(bomNode);
    }
    
    const result = {
      recipe_id: recipeId,
      recipe_name: recipe.name,
      portion_yield: recipe.portion_yield,
      bom: bomTree,
      ...(showCosts && {
        total_cost_cents: totalCostCents,
        cost_per_portion_cents: totalCostCents / (recipe.portion_yield as number)
      })
    };
    
    return c.json(result);
  } catch (error) {
    console.error("Failed to load BOM:", error);
    return c.json({ error: "Failed to load BOM" }, 500);
  }
});

// Get where-used information for an item
bom.get("/items/:id/where-used", async (c) => {
  const itemId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    // Find direct usage in recipes
    const directUsage = await env.DB.prepare(`
      SELECT DISTINCT r.id as recipe_id, r.name as recipe_name, r.is_subrecipe,
             rb.gross_qty, rb.uom, rb.note
      FROM recipe_bom rb
      JOIN recipes r ON rb.recipe_id = r.id
      WHERE rb.component_type = 'item' AND rb.component_id = ?
      ORDER BY r.name ASC
    `).bind(itemId).all();
    
    // Find indirect usage through subrecipes (this would need recursive logic)
    const indirectUsage = await env.DB.prepare(`
      SELECT DISTINCT parent.id as recipe_id, parent.name as recipe_name,
             sub.id as via_subrecipe_id, sub.name as via_subrecipe_name
      FROM recipe_bom rb1
      JOIN recipes sub ON rb1.recipe_id = sub.id
      JOIN recipe_bom rb2 ON rb2.component_type = 'subrecipe' AND rb2.component_id = sub.id
      JOIN recipes parent ON rb2.recipe_id = parent.id
      WHERE rb1.component_type = 'item' AND rb1.component_id = ? AND sub.is_subrecipe = TRUE
      ORDER BY parent.name ASC
    `).bind(itemId).all();
    
    return c.json({
      item_id: itemId,
      direct_usage: directUsage.results,
      indirect_usage: indirectUsage.results
    });
  } catch (error) {
    console.error("Failed to load where-used:", error);
    return c.json({ error: "Failed to load where-used information" }, 500);
  }
});

// Get detailed cost breakdown for a recipe
bom.get("/cost/recipes/:id", async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    // Load recipe data
    const recipeData = await loadRecipeData(env, recipeId);
    
    // Load all dependencies (this is simplified - in production we'd optimize this)
    const allRecipes = new Map<number, RecipeData>();
    const allItems = new Map<number, ItemData>();
    const allSuppliers = new Map<number, SupplierPrice[]>();
    
    // Load items and suppliers for this recipe and all subrecipes
    const exploded = explodeRecipe(recipeData, 1, allRecipes, allItems);
    
    for (const component of exploded) {
      if (!allItems.has(component.item_id)) {
        const item = await loadItemWithConversions(env, component.item_id);
        if (item) allItems.set(component.item_id, item);
      }
      
      if (!allSuppliers.has(component.item_id)) {
        const suppliers = await loadItemSuppliers(env, component.item_id);
        allSuppliers.set(component.item_id, suppliers);
      }
    }
    
    const costResult = costRecipePortion(recipeData, allRecipes, allItems, allSuppliers);
    
    return c.json(costResult);
  } catch (error) {
    console.error("Failed to calculate recipe cost:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to calculate recipe cost"
    }, 500);
  }
});

// Create or update BOM component
const BomComponentSchema = z.object({
  component_type: z.enum(['item', 'subrecipe']),
  component_id: z.number().int().positive(),
  gross_qty: z.number().positive(),
  uom: z.string().min(1),
  trim_loss_pct: z.number().min(0).max(100).default(0),
  cook_yield_pct: z.number().min(0).max(200).default(100),
  stage: z.string().optional(),
  note: z.string().optional(),
  sort_order: z.number().int().default(1)
});

bom.post("/recipes/:id/bom", zValidator("json", BomComponentSchema), async (c) => {
  const recipeId = parseInt(c.req.param("id"));
  const componentData = c.req.valid("json");
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(`
      INSERT INTO recipe_bom (
        recipe_id, component_type, component_id, gross_qty, uom,
        trim_loss_pct, cook_yield_pct, stage, note, sort_order,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      recipeId,
      componentData.component_type,
      componentData.component_id,
      componentData.gross_qty,
      componentData.uom,
      componentData.trim_loss_pct,
      componentData.cook_yield_pct,
      componentData.stage || null,
      componentData.note || null,
      componentData.sort_order
    ).run();
    
    return c.json({ 
      id: result.meta.last_row_id,
      message: "BOM component added successfully" 
    });
  } catch (error) {
    console.error("Failed to add BOM component:", error);
    return c.json({ error: "Failed to add BOM component" }, 500);
  }
});

// Helper functions

async function loadRecipeData(env: Env, recipeId: number): Promise<RecipeData> {
  const recipe = await env.DB.prepare(`
    SELECT r.*, r.yield_amount as portion_yield
    FROM recipes r 
    WHERE r.id = ?
  `).bind(recipeId).first();
  
  if (!recipe) {
    throw new Error(`Recipe ${recipeId} not found`);
  }
  
  const bomComponents = await env.DB.prepare(`
    SELECT * FROM recipe_bom 
    WHERE recipe_id = ? 
    ORDER BY sort_order ASC
  `).bind(recipeId).all();
  
  return {
    id: recipeId,
    name: recipe.name as string,
    portion_yield: recipe.portion_yield as number,
    bom: bomComponents.results.map(c => ({
      id: c.id as number,
      component_type: c.component_type as 'item' | 'subrecipe',
      component_id: c.component_id as number,
      gross_qty: c.gross_qty as number,
      uom: c.uom as string,
      trim_loss_pct: (c.trim_loss_pct as number) || 0,
      cook_yield_pct: (c.cook_yield_pct as number) || 100,
      stage: c.stage as string,
      note: c.note as string
    }))
  };
}

async function loadItemWithConversions(env: Env, itemId: number): Promise<ItemData | null> {
  const item = await env.DB.prepare(`
    SELECT * FROM items WHERE id = ?
  `).bind(itemId).first();
  
  if (!item) return null;
  
  const conversions = await env.DB.prepare(`
    SELECT from_uom, to_uom, factor FROM item_uom WHERE item_id = ?
  `).bind(itemId).all();
  
  return {
    id: itemId,
    base_uom: (item.base_uom as string) || 'ea',
    density_g_per_ml: item.density_g_per_ml as number,
    each_to_base: item.each_to_base as number,
    conversions: conversions.results.map(c => ({
      from_uom: c.from_uom as string,
      to_uom: c.to_uom as string,
      factor: c.factor as number
    }))
  };
}

async function loadItemSuppliers(env: Env, itemId: number): Promise<SupplierPrice[]> {
  const suppliers = await env.DB.prepare(`
    SELECT price_cents, pack_size_qty, pack_size_unit, preferred
    FROM item_suppliers 
    WHERE item_id = ? 
    AND (valid_to IS NULL OR valid_to >= date('now'))
    ORDER BY preferred DESC, price_cents ASC
  `).bind(itemId).all();
  
  return suppliers.results.map(s => ({
    price_cents: s.price_cents as number,
    pack_size_qty: s.pack_size_qty as number,
    pack_size_unit: s.pack_size_unit as string,
    preferred: Boolean(s.preferred)
  }));
}

export default bom;
