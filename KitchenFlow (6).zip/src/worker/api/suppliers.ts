import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const suppliers = new Hono<{ Bindings: Env }>();

// Zod schemas for validation
const CreateSupplierSchema = z.object({
  name: z.string().min(1),
  contact_person: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  address: z.string().optional(),
  notes: z.string().optional(),
});

const CreateSupplierPriceSchema = z.object({
  ingredient_id: z.number(),
  supplier_id: z.number(),
  pack_size: z.number().positive(),
  pack_unit: z.string().min(1),
  cost_per_pack: z.number().positive(),
});

// Get all suppliers
suppliers.get("/", async (c) => {
  const env = c.env;
  
  try {
    const suppliers = await env.DB.prepare(`
      SELECT s.*, 
             COUNT(isp.id) as ingredient_count,
             AVG(isp.cost_per_pack) as avg_cost_per_pack
      FROM suppliers s
      LEFT JOIN ingredient_supplier_prices isp ON s.id = isp.supplier_id
      GROUP BY s.id
      ORDER BY s.name ASC
    `).all();

    return c.json(suppliers.results);
  } catch (error) {
    console.error("Failed to fetch suppliers:", error);
    return c.json({ error: "Failed to fetch suppliers" }, 500);
  }
});

// Get single supplier with pricing details
suppliers.get("/:id", async (c) => {
  const supplierId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const supplier = await env.DB.prepare(
      "SELECT * FROM suppliers WHERE id = ?"
    ).bind(supplierId).first();
    
    if (!supplier) {
      return c.json({ error: "Supplier not found" }, 404);
    }

    // Get pricing for this supplier
    const prices = await env.DB.prepare(`
      SELECT isp.*, i.name as ingredient_name, i.unit_type
      FROM ingredient_supplier_prices isp
      JOIN ingredients i ON isp.ingredient_id = i.id
      WHERE isp.supplier_id = ?
      ORDER BY i.name ASC
    `).bind(supplierId).all();

    return c.json({
      ...supplier,
      prices: prices.results
    });
  } catch (error) {
    console.error("Failed to fetch supplier:", error);
    return c.json({ error: "Failed to fetch supplier" }, 500);
  }
});

// Create new supplier
suppliers.post("/", zValidator("json", CreateSupplierSchema), async (c) => {
  const supplierData = c.req.valid("json");
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(`
      INSERT INTO suppliers (name, contact_person, phone, email, address, notes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      supplierData.name,
      supplierData.contact_person || null,
      supplierData.phone || null,
      supplierData.email || null,
      supplierData.address || null,
      supplierData.notes || null
    ).run();

    return c.json({ 
      id: result.meta.last_row_id,
      message: "Supplier created successfully" 
    });
  } catch (error) {
    console.error("Supplier creation error:", error);
    if (error instanceof Error && error.message.includes('UNIQUE constraint failed')) {
      return c.json({ error: "Supplier name already exists" }, 409);
    }
    return c.json({ error: "Failed to create supplier" }, 500);
  }
});

// Update supplier
suppliers.put("/:id", zValidator("json", CreateSupplierSchema), async (c) => {
  const supplierId = parseInt(c.req.param("id"));
  const supplierData = c.req.valid("json");
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(`
      UPDATE suppliers 
      SET name = ?, contact_person = ?, phone = ?, email = ?, address = ?, notes = ?, updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      supplierData.name,
      supplierData.contact_person || null,
      supplierData.phone || null,
      supplierData.email || null,
      supplierData.address || null,
      supplierData.notes || null,
      supplierId
    ).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Supplier not found" }, 404);
    }

    return c.json({ message: "Supplier updated successfully" });
  } catch (error) {
    console.error("Supplier update error:", error);
    if (error instanceof Error && error.message.includes('UNIQUE constraint failed')) {
      return c.json({ error: "Supplier name already exists" }, 409);
    }
    return c.json({ error: "Failed to update supplier" }, 500);
  }
});

// Delete supplier
suppliers.delete("/:id", async (c) => {
  const supplierId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(
      "DELETE FROM suppliers WHERE id = ?"
    ).bind(supplierId).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Supplier not found" }, 404);
    }

    return c.json({ message: "Supplier deleted successfully" });
  } catch (error) {
    console.error("Supplier deletion error:", error);
    return c.json({ error: "Failed to delete supplier" }, 500);
  }
});

// Add/update ingredient pricing for a supplier
suppliers.post("/:id/prices", zValidator("json", CreateSupplierPriceSchema), async (c) => {
  const supplierId = parseInt(c.req.param("id"));
  const priceData = c.req.valid("json");
  const env = c.env;
  
  // Ensure the supplier exists
  const supplier = await env.DB.prepare("SELECT id FROM suppliers WHERE id = ?").bind(supplierId).first();
  if (!supplier) {
    return c.json({ error: "Supplier not found" }, 404);
  }

  // Ensure the ingredient exists
  const ingredient = await env.DB.prepare("SELECT id FROM ingredients WHERE id = ?").bind(priceData.ingredient_id).first();
  if (!ingredient) {
    return c.json({ error: "Ingredient not found" }, 404);
  }

  try {
    // Use UPSERT (INSERT OR REPLACE) to handle updates
    const result = await env.DB.prepare(`
      INSERT OR REPLACE INTO ingredient_supplier_prices 
      (ingredient_id, supplier_id, pack_size, pack_unit, cost_per_pack, last_updated_price, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), datetime('now'))
    `).bind(
      priceData.ingredient_id,
      supplierId,
      priceData.pack_size,
      priceData.pack_unit,
      priceData.cost_per_pack
    ).run();

    return c.json({ 
      id: result.meta.last_row_id,
      message: "Supplier pricing added/updated successfully" 
    });
  } catch (error) {
    console.error("Supplier pricing error:", error);
    return c.json({ error: "Failed to add/update supplier pricing" }, 500);
  }
});

// Get pricing for all suppliers for a specific ingredient
suppliers.get("/ingredient/:ingredientId/prices", async (c) => {
  const ingredientId = parseInt(c.req.param("ingredientId"));
  const env = c.env;
  
  try {
    const prices = await env.DB.prepare(`
      SELECT isp.*, s.name as supplier_name, s.contact_person, s.phone
      FROM ingredient_supplier_prices isp
      JOIN suppliers s ON isp.supplier_id = s.id
      WHERE isp.ingredient_id = ?
      ORDER BY isp.cost_per_pack ASC
    `).bind(ingredientId).all();

    return c.json(prices.results);
  } catch (error) {
    console.error("Failed to fetch ingredient prices:", error);
    return c.json({ error: "Failed to fetch ingredient prices" }, 500);
  }
});

export default suppliers;
