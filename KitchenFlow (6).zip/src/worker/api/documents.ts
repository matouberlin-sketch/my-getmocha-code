import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import OpenAI from "openai";
import type { Env } from "../bindings";

const documents = new Hono<{ Bindings: Env }>();

// Zod schemas for validation
const DocumentUploadSchema = z.object({
  file_data: z.string(), // Base64 encoded file
  filename: z.string(),
  file_type: z.enum(['pdf', 'docx', 'xlsx', 'doc']),
});

const ParsedRecipeSelectSchema = z.object({
  import_id: z.number(),
  selected_recipes: z.array(z.number()),
  folder_id: z.number().optional(),
});

// AI prompt for document recipe extraction
const DOCUMENT_RECIPE_EXTRACTION_PROMPT = `You are an expert chef and recipe analysis assistant. Your task is to analyze uploaded documents (PDFs, Word docs, Excel files) and extract ALL individual recipes found within them.

**MISSION:** Extract every distinct recipe from the document, parse each one completely, and return a structured JSON array.

**DOCUMENT TYPES TO HANDLE:**
- **PDF Recipe Books/Collections:** Multiple recipes per document
- **Word Documents:** Recipe collections, catering menus, prep lists
- **Excel Spreadsheets:** Recipe databases, ingredient lists, menu planning sheets

**EXTRACTION REQUIREMENTS:**

For EACH recipe found, extract:
1. **name**: Recipe title/name
2. **description**: Brief description if available  
3. **yield_amount**: Serving size (numeric)
4. **yield_unit**: Unit for servings ("servings", "portions", "kg", etc.)
5. **prep_time_minutes**: Estimated prep time in minutes
6. **hands_on_minutes**: Active cooking time in minutes
7. **ingredients**: Array of ingredient objects (see format below)
8. **steps**: Array of instruction steps
9. **tags**: Relevant tags (cuisine, meal type, cooking method, etc.)
10. **notes**: Any additional notes, source info, or special instructions

**INGREDIENT FORMAT (CRITICAL FOR COSTING):**
For each ingredient:
- **ingredient_name**: Standardized name (singular, no brands unless essential)
- **amount**: Precise numeric value (convert fractions: 1/2=0.5, 1¼=1.25)  
- **unit**: Standardized unit (kg, g, l, ml, cup, tbsp, tsp, piece, clove, large, medium, small)
- **notes**: Preparation notes (diced, chopped, organic, etc.)

**INSTRUCTION FORMAT:**
For each step:
- **step_number**: Sequential number (1, 2, 3, etc.)
- **instruction**: Clear, detailed instruction text

**MULTI-RECIPE DETECTION:**
Look for clear separators indicating multiple recipes:
- New recipe titles/headers
- Page breaks or section dividers
- Different ingredient lists
- Separate instruction sets
- Recipe numbering (Recipe 1, Recipe 2, etc.)

**EXCEL SPECIFIC HANDLING:**
- Each row may be a different recipe
- Columns might represent: Recipe Name, Ingredients, Instructions, Yield, etc.
- Look for header rows to understand the structure
- Handle merged cells and formatting

**TAG GENERATION:**
Generate 3-6 relevant tags per recipe from:
- **Course:** main, appetizer, dessert, side, sauce
- **Meal:** breakfast, lunch, dinner, snack
- **Cuisine:** italian, chinese, mexican, indian, thai, french, etc.
- **Method:** baked, grilled, fried, slow-cooked, raw
- **Dietary:** vegetarian, vegan, gluten-free
- **Difficulty:** easy, medium, advanced

**OUTPUT FORMAT:**
Return a JSON object with:
{
  "recipes_found": number,
  "recipes": [
    {
      "name": "Recipe Name",
      "description": "Brief description",
      "yield_amount": 4,
      "yield_unit": "servings", 
      "prep_time_minutes": 30,
      "hands_on_minutes": 20,
      "ingredients": [
        {
          "ingredient_name": "chicken breast",
          "amount": 1.5,
          "unit": "lb",
          "notes": "boneless, skinless"
        }
      ],
      "steps": [
        {
          "step_number": 1,
          "instruction": "Detailed instruction text"
        }
      ],
      "tags": ["main", "dinner", "chicken", "easy"],
      "notes": "Additional recipe notes"
    }
  ]
}

**CRITICAL RULES:**
1. **Extract ALL recipes found** - don't miss any
2. **Standardize measurements** - convert fractions, use consistent units
3. **Clean ingredient names** - remove brands, use generic terms
4. **Estimate times** - if not provided, estimate based on complexity
5. **Generate accurate tags** - be precise with cuisine and dietary classifications
6. **Handle formatting** - work with tables, lists, paragraphs, any document structure

Analyze this document and extract all recipes:`;

// Upload and parse document
documents.post("/upload", zValidator("json", DocumentUploadSchema), async (c) => {
  const { file_data, filename, file_type } = c.req.valid("json");
  const env = c.env;

  if (!env.OPENAI_API_KEY) {
    return c.json({ error: "OpenAI API key not configured" }, 500);
  }

  try {
    // Create document import record
    const importResult = await env.DB.prepare(`
      INSERT INTO document_imports (
        filename, file_type, file_size, status, created_at, updated_at
      ) VALUES (?, ?, ?, 'processing', datetime('now'), datetime('now'))
    `).bind(
      filename,
      file_type,
      file_data.length
    ).run();

    const importId = importResult.meta.last_row_id as number;

    try {
      const openai = new OpenAI({
        apiKey: env.OPENAI_API_KEY,
      });

      let extractedText = '';
      
      // Handle different file types
      if (file_type === 'pdf') {
        // For PDFs, use GPT-4 Vision to analyze the document
        let response;
        try {
          response = await openai.chat.completions.create({
            model: "gpt-4o",
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "text",
                    text: DOCUMENT_RECIPE_EXTRACTION_PROMPT,
                  },
                  {
                    type: "image_url",
                    image_url: {
                      url: `data:application/pdf;base64,${file_data}`,
                      detail: "high"
                    },
                  },
                ],
              },
            ],
            max_tokens: 4000,
            temperature: 0.1,
          });
        } catch (apiError: any) {
          if (apiError.status === 429) {
            throw new Error("OpenAI API quota exceeded. Please check your OpenAI billing and usage limits. You may need to upgrade your plan or wait for quota reset.");
          } else if (apiError.status === 401) {
            throw new Error("OpenAI API authentication failed. Please check your API key configuration.");
          } else if (apiError.status >= 500) {
            throw new Error("OpenAI service is temporarily unavailable. Please try again in a few minutes.");
          } else {
            throw new Error(`OpenAI API error: ${apiError.message || 'Unknown error'}`);
          }
        }

        extractedText = response.choices[0]?.message?.content || '';
      } else {
        // For Word/Excel files, we'll treat them as text and process with GPT-4
        // Note: In a real implementation, you'd want to use proper parsers
        // For now, we'll ask the user to convert to text or use OCR
        let response;
        try {
          response = await openai.chat.completions.create({
            model: "gpt-4o",
            messages: [
              {
                role: "user",
                content: `${DOCUMENT_RECIPE_EXTRACTION_PROMPT}\n\nDocument Content (${file_type.toUpperCase()}):\n${Buffer.from(file_data, 'base64').toString('utf-8')}`
              }
            ],
            max_tokens: 4000,
            temperature: 0.1,
          });
        } catch (apiError: any) {
          if (apiError.status === 429) {
            throw new Error("OpenAI API quota exceeded. Please check your OpenAI billing and usage limits. You may need to upgrade your plan or wait for quota reset.");
          } else if (apiError.status === 401) {
            throw new Error("OpenAI API authentication failed. Please check your API key configuration.");
          } else if (apiError.status >= 500) {
            throw new Error("OpenAI service is temporarily unavailable. Please try again in a few minutes.");
          } else {
            throw new Error(`OpenAI API error: ${apiError.message || 'Unknown error'}`);
          }
        }

        extractedText = response.choices[0]?.message?.content || '';
      }

      if (!extractedText) {
        throw new Error("No response from OpenAI");
      }

      // Parse the JSON response from OpenAI
      let extractedData;
      try {
        const jsonMatch = extractedText.match(/\{[\s\S]*\}/);
        const jsonString = jsonMatch ? jsonMatch[0] : extractedText;
        extractedData = JSON.parse(jsonString);
      } catch (parseError) {
        console.error("Failed to parse OpenAI response as JSON:", extractedText);
        throw new Error("Failed to parse extracted recipes");
      }

      // Validate extracted data structure
      if (!extractedData.recipes || !Array.isArray(extractedData.recipes)) {
        throw new Error("No valid recipes found in document");
      }

      // Update import record with success
      await env.DB.prepare(`
        UPDATE document_imports 
        SET status = 'completed', 
            extracted_recipes_count = ?, 
            processed_data = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `).bind(
        extractedData.recipes.length,
        JSON.stringify(extractedData),
        importId
      ).run();

      return c.json({
        import_id: importId,
        recipes_found: extractedData.recipes_found || extractedData.recipes.length,
        recipes: extractedData.recipes,
        message: "Document processed successfully",
      });

    } catch (processingError) {
      console.error("Document processing error:", processingError);
      
      // Update import record with error
      await env.DB.prepare(`
        UPDATE document_imports 
        SET status = 'failed', 
            error_message = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `).bind(
        processingError instanceof Error ? processingError.message : 'Processing failed',
        importId
      ).run();

      throw processingError;
    }
  } catch (error) {
    console.error("Document upload error:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to process document"
    }, 500);
  }
});

// Get import status
documents.get("/import/:id", async (c) => {
  const importId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const importRecord = await env.DB.prepare(
      "SELECT * FROM document_imports WHERE id = ?"
    ).bind(importId).first();
    
    if (!importRecord) {
      return c.json({ error: "Import not found" }, 404);
    }

    // Parse processed data if available
    let processedData = null;
    if (importRecord.processed_data) {
      try {
        processedData = JSON.parse(importRecord.processed_data as string);
      } catch (e) {
        console.error("Failed to parse processed data:", e);
      }
    }

    return c.json({
      ...importRecord,
      processed_data: processedData,
    });
  } catch (error) {
    console.error("Failed to fetch import:", error);
    return c.json({ error: "Failed to fetch import" }, 500);
  }
});

// Create recipes from selected parsed recipes
documents.post("/create-recipes", zValidator("json", ParsedRecipeSelectSchema), async (c) => {
  const { import_id, selected_recipes, folder_id } = c.req.valid("json");
  const env = c.env;

  try {
    // Get the import data
    const importRecord = await env.DB.prepare(
      "SELECT * FROM document_imports WHERE id = ?"
    ).bind(import_id).first();

    if (!importRecord || !importRecord.processed_data) {
      return c.json({ error: "Import data not found" }, 404);
    }

    const processedData = JSON.parse(importRecord.processed_data as string);
    const allRecipes = processedData.recipes;

    if (!allRecipes || !Array.isArray(allRecipes)) {
      return c.json({ error: "No recipes found in import data" }, 400);
    }

    const createdRecipes = [];

    // Create each selected recipe
    for (const recipeIndex of selected_recipes) {
      if (recipeIndex < 0 || recipeIndex >= allRecipes.length) {
        console.warn(`Invalid recipe index: ${recipeIndex}`);
        continue;
      }

      const recipeData = allRecipes[recipeIndex];

      try {
        // Create the recipe
        const recipeResult = await env.DB.prepare(`
          INSERT INTO recipes (
            name, description, yield_amount, yield_unit, 
            prep_time_minutes, hands_on_minutes, lead_time_hours,
            notes, is_subrecipe, folder_id, status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', datetime('now'), datetime('now'))
        `).bind(
          recipeData.name || 'Imported Recipe',
          recipeData.description || '',
          recipeData.yield_amount || 4,
          recipeData.yield_unit || 'servings',
          recipeData.prep_time_minutes || null,
          recipeData.hands_on_minutes || null,
          0,
          recipeData.notes ? `${recipeData.notes}\n\nImported from: ${importRecord.filename}` : `Imported from: ${importRecord.filename}`,
          false,
          folder_id || null
        ).run();

        const recipeId = recipeResult.meta.last_row_id as number;

        // Create ingredients
        if (recipeData.ingredients && Array.isArray(recipeData.ingredients)) {
          for (let i = 0; i < recipeData.ingredients.length; i++) {
            const ingredient = recipeData.ingredients[i];
            
            try {
              // Try to find existing ingredient
              let ingredientId = null;
              const existing = await env.DB.prepare(
                "SELECT id FROM ingredients WHERE LOWER(name) = LOWER(?)"
              ).bind(ingredient.ingredient_name).first();
              
              if (existing) {
                ingredientId = existing.id;
              } else {
                // Create new ingredient
                const newIngredient = await env.DB.prepare(`
                  INSERT INTO ingredients (name, unit_type, created_at, updated_at) 
                  VALUES (?, 'count', datetime('now'), datetime('now'))
                `).bind(ingredient.ingredient_name).run();
                ingredientId = newIngredient.meta.last_row_id;
              }

              // Insert recipe ingredient
              await env.DB.prepare(`
                INSERT INTO recipe_ingredients (
                  recipe_id, ingredient_id, amount, unit, notes, ingredient_order, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
              `).bind(
                recipeId,
                ingredientId,
                ingredient.amount || 1,
                ingredient.unit || 'piece',
                ingredient.notes || null,
                i + 1
              ).run();
            } catch (error) {
              console.error(`Failed to create ingredient for recipe ${recipeId}:`, error);
            }
          }
        }

        // Create steps
        if (recipeData.steps && Array.isArray(recipeData.steps)) {
          for (const step of recipeData.steps) {
            try {
              await env.DB.prepare(`
                INSERT INTO recipe_steps (recipe_id, step_number, instruction, created_at, updated_at)
                VALUES (?, ?, ?, datetime('now'), datetime('now'))
              `).bind(
                recipeId,
                step.step_number || 1,
                step.instruction || ''
              ).run();
            } catch (error) {
              console.error(`Failed to create step for recipe ${recipeId}:`, error);
            }
          }
        }

        // Create tags
        if (recipeData.tags && Array.isArray(recipeData.tags)) {
          for (const tag of recipeData.tags) {
            try {
              await env.DB.prepare(`
                INSERT INTO recipe_tags (recipe_id, tag, created_at, updated_at)
                VALUES (?, ?, datetime('now'), datetime('now'))
              `).bind(recipeId, tag).run();
            } catch (error) {
              console.error(`Failed to create tag for recipe ${recipeId}:`, error);
            }
          }
        }

        createdRecipes.push({
          id: recipeId,
          name: recipeData.name,
          index: recipeIndex
        });

      } catch (error) {
        console.error(`Failed to create recipe ${recipeIndex}:`, error);
      }
    }

    return c.json({
      message: `Created ${createdRecipes.length} recipes successfully`,
      created_recipes: createdRecipes,
      import_id
    });

  } catch (error) {
    console.error("Recipe creation error:", error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Failed to create recipes"
    }, 500);
  }
});

// Get all imports
documents.get("/imports", async (c) => {
  const env = c.env;
  
  try {
    const imports = await env.DB.prepare(`
      SELECT id, filename, file_type, file_size, status, 
             extracted_recipes_count, error_message, created_at, updated_at
      FROM document_imports 
      ORDER BY created_at DESC
    `).all();

    return c.json(imports.results);
  } catch (error) {
    console.error("Failed to fetch imports:", error);
    return c.json({ error: "Failed to fetch imports" }, 500);
  }
});

export default documents;
