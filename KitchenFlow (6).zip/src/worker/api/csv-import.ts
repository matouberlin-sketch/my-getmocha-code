import { Hono } from "hono";
import type { Env } from "../bindings";
import * as XLSX from 'xlsx';

const csvImport = new Hono<{ Bindings: Env }>();

// Upload and process Excel file
csvImport.post("/upload-excel", async (c) => {
  const env = c.env;
  
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ error: "No file uploaded" }, 400);
    }
    
    // Read Excel file
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    
    // Extract data from each sheet
    const csvData: any = {};
    
    const expectedSheets = [
      'suppliers', 'items', 'supplier_items', 'item_uom_conversions',
      'recipes', 'recipe_ingredients', 'recipe_components'
    ];
    
    for (const sheetName of expectedSheets) {
      if (workbook.SheetNames.includes(sheetName)) {
        const worksheet = workbook.Sheets[sheetName];
        const data = XLSX.utils.sheet_to_json(worksheet);
        csvData[sheetName] = data;
        console.log(`Extracted ${data.length} rows from ${sheetName} sheet`);
      } else {
        console.warn(`Sheet ${sheetName} not found in Excel file`);
        csvData[sheetName] = [];
      }
    }
    
    // Validate that we have some data
    const totalRows = Object.values(csvData).reduce((sum: number, arr: any) => sum + arr.length, 0);
    if (totalRows === 0) {
      return c.json({ 
        error: "No data found in Excel file. Please ensure your file has sheets named: " + expectedSheets.join(', ')
      }, 400);
    }
    
    console.log(`Total rows extracted: ${totalRows}`);
    
    // Process the data using the same logic as bulk-import
    let importResults = {
      suppliers: 0,
      items: 0,
      supplier_items: 0,
      recipes: 0,
      recipe_ingredients: 0,
      recipe_components: 0,
      errors: [] as string[]
    };
    
    // Import suppliers
    if (csvData.suppliers && csvData.suppliers.length > 0) {
      for (const supplier of csvData.suppliers) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO suppliers (
              name, contact_person, phone, email, address, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            supplier.name || supplier.Name,
            supplier.contact_person || supplier.ContactPerson || null,
            supplier.phone || supplier.Phone || null,
            supplier.email || supplier.Email || null,
            supplier.address || supplier.Address || null,
            supplier.notes || supplier.Notes || null
          ).run();
          importResults.suppliers++;
        } catch (error) {
          importResults.errors.push(`Supplier ${supplier.name || supplier.Name}: ${error}`);
        }
      }
    }
    
    // Import items
    if (csvData.items && csvData.items.length > 0) {
      for (const item of csvData.items) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO items (
              item_id, name, item_type, base_uom, category, default_state,
              edible_yield_pct, density_g_per_ml, allergen_tags, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            item.item_id || item.ItemID || item.ID,
            item.name || item.Name,
            item.item_type || item.ItemType || item.Type,
            item.base_uom || item.BaseUOM || item.UOM,
            item.category || item.Category || null,
            item.default_state || item.DefaultState || null,
            item.edible_yield_pct || item.EdibleYieldPct || 100,
            item.density_g_per_ml || item.DensityGPerML || null,
            item.allergen_tags || item.AllergenTags || null,
            item.notes || item.Notes || null
          ).run();
          importResults.items++;
        } catch (error) {
          importResults.errors.push(`Item ${item.item_id || item.ItemID || item.ID}: ${error}`);
        }
      }
    }
    
    // Import supplier items
    if (csvData.supplier_items && csvData.supplier_items.length > 0) {
      for (const supplierItem of csvData.supplier_items) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO supplier_items_enhanced (
              supplier_item_id, supplier_name, item_id, name_on_invoice, order_code,
              pack_qty, pack_uom, price, currency, vat_pct, deposit,
              price_valid_from, price_valid_to, moq_packs, order_multiple_packs,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            supplierItem.supplier_item_id || supplierItem.SupplierItemID || supplierItem.ID,
            supplierItem.supplier_name || supplierItem.SupplierName || supplierItem.supplier_id || 'Unknown',
            supplierItem.item_id || supplierItem.ItemID,
            supplierItem.name_on_invoice || supplierItem.NameOnInvoice || null,
            supplierItem.order_code || supplierItem.OrderCode || null,
            supplierItem.pack_qty || supplierItem.PackQty || 1,
            supplierItem.pack_uom || supplierItem.PackUOM || 'each',
            supplierItem.price || supplierItem.Price || 0,
            supplierItem.currency || supplierItem.Currency || 'EUR',
            supplierItem.vat_pct || supplierItem.VATPercent || 19,
            supplierItem.deposit || supplierItem.Deposit || 0,
            supplierItem.price_valid_from || supplierItem.PriceValidFrom || null,
            supplierItem.price_valid_to || supplierItem.PriceValidTo || null,
            supplierItem.moq_packs || supplierItem.MOQPacks || 1,
            supplierItem.order_multiple_packs || supplierItem.OrderMultiplePacks || 1
          ).run();
          importResults.supplier_items++;
        } catch (error) {
          importResults.errors.push(`Supplier item ${supplierItem.supplier_item_id || supplierItem.SupplierItemID || supplierItem.ID}: ${error}`);
        }
      }
    }
    
    // Import UOM conversions
    if (csvData.item_uom_conversions && csvData.item_uom_conversions.length > 0) {
      for (const conversion of csvData.item_uom_conversions) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO item_uom_conversions (
              item_id, from_uom, to_uom, factor, method, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            conversion.item_id || conversion.ItemID,
            conversion.from_uom || conversion.FromUOM,
            conversion.to_uom || conversion.ToUOM,
            conversion.factor || conversion.Factor,
            conversion.method || conversion.Method || 'multiply',
            conversion.notes || conversion.Notes || null
          ).run();
        } catch (error) {
          importResults.errors.push(`UOM conversion ${conversion.item_id || conversion.ItemID}: ${error}`);
        }
      }
    }
    
    // Import recipes
    if (csvData.recipes && csvData.recipes.length > 0) {
      for (const recipe of csvData.recipes) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO enhanced_recipes (
              recipe_id, name, type, default_yield_qty, default_yield_uom,
              output_item_id, active_minutes, passive_minutes, lead_time_hours,
              station, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            recipe.recipe_id || recipe.RecipeID || recipe.ID,
            recipe.name || recipe.Name,
            recipe.type || recipe.Type || 'final',
            recipe.default_yield_qty || recipe.DefaultYieldQty || 1,
            recipe.default_yield_uom || recipe.DefaultYieldUOM || 'portion',
            recipe.output_item_id || recipe.OutputItemID || null,
            recipe.active_minutes || recipe.ActiveMinutes || 0,
            recipe.passive_minutes || recipe.PassiveMinutes || 0,
            recipe.lead_time_hours || recipe.LeadTimeHours || 0,
            recipe.station || recipe.Station || null,
            recipe.notes || recipe.Notes || null
          ).run();
          importResults.recipes++;
        } catch (error) {
          importResults.errors.push(`Recipe ${recipe.recipe_id || recipe.RecipeID || recipe.ID}: ${error}`);
        }
      }
    }
    
    // Import recipe ingredients
    if (csvData.recipe_ingredients && csvData.recipe_ingredients.length > 0) {
      for (const ingredient of csvData.recipe_ingredients) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO enhanced_recipe_ingredients (
              recipe_id, line_no, item_id, qty, uom, scrap_pct, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            ingredient.recipe_id || ingredient.RecipeID,
            ingredient.line_no || ingredient.LineNo || ingredient.Line || 1,
            ingredient.item_id || ingredient.ItemID,
            ingredient.qty || ingredient.Qty || ingredient.Quantity || 1,
            ingredient.uom || ingredient.UOM || 'each',
            ingredient.scrap_pct || ingredient.ScrapPercent || 0,
            ingredient.notes || ingredient.Notes || null
          ).run();
          importResults.recipe_ingredients++;
        } catch (error) {
          importResults.errors.push(`Recipe ingredient ${ingredient.recipe_id || ingredient.RecipeID}-${ingredient.line_no || ingredient.LineNo}: ${error}`);
        }
      }
    }
    
    // Import recipe components
    if (csvData.recipe_components && csvData.recipe_components.length > 0) {
      for (const component of csvData.recipe_components) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO recipe_components (
              parent_recipe_id, component_recipe_id, qty, uom, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            component.parent_recipe_id || component.ParentRecipeID,
            component.component_recipe_id || component.ComponentRecipeID,
            component.qty || component.Qty || component.Quantity || 1,
            component.uom || component.UOM || 'portion',
            component.notes || component.Notes || null
          ).run();
          importResults.recipe_components++;
        } catch (error) {
          importResults.errors.push(`Recipe component ${component.parent_recipe_id || component.ParentRecipeID}-${component.component_recipe_id || component.ComponentRecipeID}: ${error}`);
        }
      }
    }
    
    return c.json({
      message: "Excel file processed successfully",
      results: importResults,
      sheets_found: workbook.SheetNames,
      total_rows_processed: totalRows
    });
    
  } catch (error) {
    console.error("Excel upload error:", error);
    return c.json({ error: `Failed to process Excel file: ${error}` }, 500);
  }
});

// Import CSV data from the comprehensive ERP system
csvImport.post("/bulk-import", async (c) => {
  const env = c.env;
  
  try {
    const body = await c.req.json();
    const { csvData } = body;
    
    if (!csvData || !csvData.suppliers || !csvData.items || !csvData.recipes) {
      return c.json({ error: "Missing required CSV data" }, 400);
    }
    
    let importResults = {
      suppliers: 0,
      items: 0,
      supplier_items: 0,
      recipes: 0,
      recipe_ingredients: 0,
      recipe_components: 0,
      errors: [] as string[]
    };
    
    // Import suppliers (note: using existing suppliers table structure)
    if (csvData.suppliers) {
      for (const supplier of csvData.suppliers) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO suppliers (
              name, contact_person, phone, email, address, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            supplier.name,
            supplier.contact_person || null,
            supplier.phone || null,
            supplier.email || null,
            supplier.address || null,
            supplier.notes || null
          ).run();
          importResults.suppliers++;
        } catch (error) {
          importResults.errors.push(`Supplier ${supplier.name}: ${error}`);
        }
      }
    }
    
    // Import items
    if (csvData.items) {
      for (const item of csvData.items) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO items (
              item_id, name, item_type, base_uom, category, default_state,
              edible_yield_pct, density_g_per_ml, allergen_tags, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            item.item_id,
            item.name,
            item.item_type,
            item.base_uom,
            item.category || null,
            item.default_state || null,
            item.edible_yield_pct || 100,
            item.density_g_per_ml || null,
            item.allergen_tags || null,
            item.notes || null
          ).run();
          importResults.items++;
        } catch (error) {
          importResults.errors.push(`Item ${item.item_id}: ${error}`);
        }
      }
    }
    
    // Import supplier items
    if (csvData.supplier_items) {
      for (const supplierItem of csvData.supplier_items) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO supplier_items_enhanced (
              supplier_item_id, supplier_name, item_id, name_on_invoice, order_code,
              pack_qty, pack_uom, price, currency, vat_pct, deposit,
              price_valid_from, price_valid_to, moq_packs, order_multiple_packs,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            supplierItem.supplier_item_id,
            supplierItem.supplier_id || 'Unknown',
            supplierItem.item_id,
            supplierItem.name_on_invoice || null,
            supplierItem.order_code || null,
            supplierItem.pack_qty,
            supplierItem.pack_uom,
            supplierItem.price,
            supplierItem.currency || 'EUR',
            supplierItem.vat_pct || 19,
            supplierItem.deposit || 0,
            supplierItem.price_valid_from || null,
            supplierItem.price_valid_to || null,
            supplierItem.moq_packs || 1,
            supplierItem.order_multiple_packs || 1
          ).run();
          importResults.supplier_items++;
        } catch (error) {
          importResults.errors.push(`Supplier item ${supplierItem.supplier_item_id}: ${error}`);
        }
      }
    }
    
    // Import UOM conversions
    if (csvData.item_uom_conversions) {
      for (const conversion of csvData.item_uom_conversions) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO item_uom_conversions (
              item_id, from_uom, to_uom, factor, method, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            conversion.item_id,
            conversion.from_uom,
            conversion.to_uom,
            conversion.factor,
            conversion.method,
            conversion.notes || null
          ).run();
        } catch (error) {
          importResults.errors.push(`UOM conversion ${conversion.item_id}: ${error}`);
        }
      }
    }
    
    // Import recipes
    if (csvData.recipes) {
      for (const recipe of csvData.recipes) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO enhanced_recipes (
              recipe_id, name, type, default_yield_qty, default_yield_uom,
              output_item_id, active_minutes, passive_minutes, lead_time_hours,
              station, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            recipe.recipe_id,
            recipe.name,
            recipe.type,
            recipe.default_yield_qty,
            recipe.default_yield_uom,
            recipe.output_item_id || null,
            recipe.active_minutes || 0,
            recipe.passive_minutes || 0,
            recipe.lead_time_hours || 0,
            recipe.station || null,
            recipe.notes || null
          ).run();
          importResults.recipes++;
        } catch (error) {
          importResults.errors.push(`Recipe ${recipe.recipe_id}: ${error}`);
        }
      }
    }
    
    // Import recipe ingredients
    if (csvData.recipe_ingredients) {
      for (const ingredient of csvData.recipe_ingredients) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO enhanced_recipe_ingredients (
              recipe_id, line_no, item_id, qty, uom, scrap_pct, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            ingredient.recipe_id,
            ingredient.line_no,
            ingredient.item_id,
            ingredient.qty,
            ingredient.uom,
            ingredient.scrap_pct || 0,
            ingredient.notes || null
          ).run();
          importResults.recipe_ingredients++;
        } catch (error) {
          importResults.errors.push(`Recipe ingredient ${ingredient.recipe_id}-${ingredient.line_no}: ${error}`);
        }
      }
    }
    
    // Import recipe components
    if (csvData.recipe_components) {
      for (const component of csvData.recipe_components) {
        try {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO recipe_components (
              parent_recipe_id, component_recipe_id, qty, uom, notes,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          `).bind(
            component.parent_recipe_id,
            component.component_recipe_id,
            component.qty,
            component.uom,
            component.notes || null
          ).run();
          importResults.recipe_components++;
        } catch (error) {
          importResults.errors.push(`Recipe component ${component.parent_recipe_id}-${component.component_recipe_id}: ${error}`);
        }
      }
    }
    
    return c.json({
      message: "Bulk import completed",
      results: importResults
    });
    
  } catch (error) {
    console.error("Bulk import error:", error);
    return c.json({ error: "Failed to import CSV data" }, 500);
  }
});

// Export current data to CSV format
csvImport.get("/export", async (c) => {
  const env = c.env;
  
  try {
    const exportData: any = {};
    
    // Export suppliers
    const suppliers = await env.DB.prepare("SELECT * FROM suppliers ORDER BY supplier_id").all();
    exportData.suppliers = suppliers.results;
    
    // Export items
    const items = await env.DB.prepare("SELECT * FROM items ORDER BY item_id").all();
    exportData.items = items.results;
    
    // Export supplier items
    const supplierItems = await env.DB.prepare("SELECT * FROM supplier_items_enhanced ORDER BY supplier_item_id").all();
    exportData.supplier_items = supplierItems.results;
    
    // Export UOM conversions
    const conversions = await env.DB.prepare("SELECT * FROM item_uom_conversions ORDER BY item_id, from_uom").all();
    exportData.item_uom_conversions = conversions.results;
    
    // Export recipes
    const recipes = await env.DB.prepare("SELECT * FROM enhanced_recipes ORDER BY recipe_id").all();
    exportData.recipes = recipes.results;
    
    // Export recipe ingredients
    const recipeIngredients = await env.DB.prepare("SELECT * FROM enhanced_recipe_ingredients ORDER BY recipe_id, line_no").all();
    exportData.recipe_ingredients = recipeIngredients.results;
    
    // Export recipe components
    const recipeComponents = await env.DB.prepare("SELECT * FROM recipe_components ORDER BY parent_recipe_id").all();
    exportData.recipe_components = recipeComponents.results;
    
    return c.json(exportData);
    
  } catch (error) {
    console.error("Export error:", error);
    return c.json({ error: "Failed to export data" }, 500);
  }
});

export default csvImport;
