import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import type { Env } from "../bindings";

const ingredients = new Hono<{ Bindings: Env }>();

// Zod schemas for validation
const CreateIngredientSchema = z.object({
  name: z.string().min(1),
  unit_type: z.enum(['weight', 'volume', 'count']),
  grams_per_piece: z.number().optional(),
  waste_percentage: z.number().min(0).max(100).optional(),
  tags: z.array(z.string()).optional(),
});

const UpdateIngredientSchema = z.object({
  name: z.string().min(1).optional(),
  unit_type: z.enum(['weight', 'volume', 'count']).optional(),
  grams_per_piece: z.number().optional(),
  waste_percentage: z.number().min(0).max(100).optional(),
  tags: z.array(z.string()).optional(),
});

// Get all ingredients with supplier pricing summary and tags
ingredients.get("/", async (c) => {
  const env = c.env;
  
  // Parse query parameters for filtering
  const url = new URL(c.req.url);
  const tagFilter = url.searchParams.get('tags'); // Comma-separated tags
  const unitTypeFilter = url.searchParams.get('unit_types'); // Comma-separated unit types
  const sortBy = url.searchParams.get('sort') || 'name';
  const sortOrder = url.searchParams.get('order') || 'asc';
  
  try {
    let baseQuery = `
      SELECT i.*, 
             COUNT(DISTINCT isp.supplier_id) as supplier_count,
             MIN(isp.cost_per_pack / isp.pack_size) as min_unit_cost,
             MAX(isp.cost_per_pack / isp.pack_size) as max_unit_cost,
             GROUP_CONCAT(DISTINCT s.name) as supplier_names,
             GROUP_CONCAT(DISTINCT it.tag) as tags
      FROM ingredients i
      LEFT JOIN ingredient_supplier_prices isp ON i.id = isp.ingredient_id
      LEFT JOIN suppliers s ON isp.supplier_id = s.id
      LEFT JOIN ingredient_tags it ON i.id = it.ingredient_id
    `;
    
    const conditions = [];
    const params = [];
    
    // Filter by tags if specified
    if (tagFilter) {
      const tags = tagFilter.split(',').map(tag => tag.trim().toLowerCase());
      conditions.push(`i.id IN (
        SELECT DISTINCT ingredient_id FROM ingredient_tags 
        WHERE tag IN (${tags.map(() => '?').join(',')})
      )`);
      params.push(...tags);
    }
    
    // Filter by unit types if specified
    if (unitTypeFilter) {
      const unitTypes = unitTypeFilter.split(',').map(type => type.trim());
      conditions.push(`i.unit_type IN (${unitTypes.map(() => '?').join(',')})`);
      params.push(...unitTypes);
    }
    
    if (conditions.length > 0) {
      baseQuery += ' WHERE ' + conditions.join(' AND ');
    }
    
    baseQuery += ` GROUP BY i.id`;
    
    // Add sorting
    const validSortFields = ['name', 'unit_type', 'created_at', 'updated_at', 'supplier_count', 'min_unit_cost'];
    const validSortField = validSortFields.includes(sortBy) ? sortBy : 'name';
    const validSortOrder = ['asc', 'desc'].includes(sortOrder.toLowerCase()) ? sortOrder.toUpperCase() : 'ASC';
    
    baseQuery += ` ORDER BY ${validSortField === 'name' ? 'i.name' : validSortField} ${validSortOrder}`;
    
    const ingredients = await env.DB.prepare(baseQuery).bind(...params).all();

    return c.json(ingredients.results);
  } catch (error) {
    console.error("Failed to fetch ingredients:", error);
    return c.json({ error: "Failed to fetch ingredients" }, 500);
  }
});

// Get single ingredient with all supplier pricing, tags, and usage
ingredients.get("/:id", async (c) => {
  const ingredientId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    const ingredient = await env.DB.prepare(
      "SELECT * FROM ingredients WHERE id = ?"
    ).bind(ingredientId).first();
    
    if (!ingredient) {
      return c.json({ error: "Ingredient not found" }, 404);
    }

    // Get all supplier pricing for this ingredient
    const prices = await env.DB.prepare(`
      SELECT isp.*, s.name as supplier_name, s.contact_person, s.phone, s.email
      FROM ingredient_supplier_prices isp
      JOIN suppliers s ON isp.supplier_id = s.id
      WHERE isp.ingredient_id = ?
      ORDER BY isp.cost_per_pack / isp.pack_size ASC
    `).bind(ingredientId).all();

    // Get tags for this ingredient
    const tags = await env.DB.prepare(`
      SELECT tag FROM ingredient_tags 
      WHERE ingredient_id = ?
      ORDER BY tag ASC
    `).bind(ingredientId).all();

    // Get recipes that use this ingredient
    const recipeUsage = await env.DB.prepare(`
      SELECT DISTINCT r.id, r.name, r.yield_amount, r.yield_unit, ri.amount, ri.unit
      FROM recipes r
      JOIN recipe_ingredients ri ON r.id = ri.recipe_id
      WHERE ri.ingredient_id = ?
      ORDER BY r.name ASC
      LIMIT 20
    `).bind(ingredientId).all();

    return c.json({
      ...ingredient,
      supplier_prices: prices.results,
      tags: tags.results.map((row: any) => row.tag),
      recipe_usage: recipeUsage.results
    });
  } catch (error) {
    console.error("Failed to fetch ingredient:", error);
    return c.json({ error: "Failed to fetch ingredient" }, 500);
  }
});

// Create new ingredient
ingredients.post("/", zValidator("json", CreateIngredientSchema), async (c) => {
  const ingredientData = c.req.valid("json");
  const env = c.env;
  
  try {
    const result = await env.DB.prepare(`
      INSERT INTO ingredients (name, unit_type, grams_per_piece, waste_percentage, created_at, updated_at)
      VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      ingredientData.name,
      ingredientData.unit_type,
      ingredientData.grams_per_piece || null,
      ingredientData.waste_percentage || 0
    ).run();

    const ingredientId = result.meta.last_row_id;

    // Add tags if provided
    if (ingredientData.tags && ingredientData.tags.length > 0) {
      for (const tag of ingredientData.tags) {
        await env.DB.prepare(`
          INSERT INTO ingredient_tags (ingredient_id, tag, created_at, updated_at)
          VALUES (?, ?, datetime('now'), datetime('now'))
        `).bind(ingredientId, tag.toLowerCase().trim()).run();
      }
    }

    return c.json({ 
      id: ingredientId,
      message: "Ingredient created successfully" 
    });
  } catch (error) {
    console.error("Ingredient creation error:", error);
    return c.json({ error: "Failed to create ingredient" }, 500);
  }
});

// Update ingredient
ingredients.put("/:id", zValidator("json", UpdateIngredientSchema), async (c) => {
  const ingredientId = parseInt(c.req.param("id"));
  const ingredientData = c.req.valid("json");
  const env = c.env;
  
  try {
    // Build dynamic SQL based on provided fields
    const updates: string[] = [];
    const values: any[] = [];
    
    if (ingredientData.name !== undefined) {
      updates.push("name = ?");
      values.push(ingredientData.name);
    }
    
    if (ingredientData.unit_type !== undefined) {
      updates.push("unit_type = ?");
      values.push(ingredientData.unit_type);
    }
    
    if (ingredientData.grams_per_piece !== undefined) {
      updates.push("grams_per_piece = ?");
      values.push(ingredientData.grams_per_piece);
    }
    
    if (ingredientData.waste_percentage !== undefined) {
      updates.push("waste_percentage = ?");
      values.push(ingredientData.waste_percentage);
    }
    
    if (updates.length === 0) {
      return c.json({ error: "No fields to update" }, 400);
    }
    
    updates.push("updated_at = datetime('now')");
    values.push(ingredientId);
    
    const sql = `UPDATE ingredients SET ${updates.join(", ")} WHERE id = ?`;
    const result = await env.DB.prepare(sql).bind(...values).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Ingredient not found" }, 404);
    }

    // Update tags if provided
    if (ingredientData.tags !== undefined) {
      // Remove existing tags
      await env.DB.prepare(`DELETE FROM ingredient_tags WHERE ingredient_id = ?`).bind(ingredientId).run();
      
      // Add new tags
      for (const tag of ingredientData.tags) {
        await env.DB.prepare(`
          INSERT INTO ingredient_tags (ingredient_id, tag, created_at, updated_at)
          VALUES (?, ?, datetime('now'), datetime('now'))
        `).bind(ingredientId, tag.toLowerCase().trim()).run();
      }
    }

    return c.json({ message: "Ingredient updated successfully" });
  } catch (error) {
    console.error("Ingredient update error:", error);
    return c.json({ error: "Failed to update ingredient" }, 500);
  }
});

// Delete ingredient (and all associated pricing)
ingredients.delete("/:id", async (c) => {
  const ingredientId = parseInt(c.req.param("id"));
  const env = c.env;
  
  try {
    // Check if ingredient is used in any recipes
    const recipeUsage = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM recipe_ingredients WHERE ingredient_id = ?"
    ).bind(ingredientId).first<{ count: number }>();
    
    if (recipeUsage?.count && recipeUsage.count > 0) {
      return c.json({ 
        error: "Cannot delete ingredient - it is used in recipes",
        recipes_using: recipeUsage.count 
      }, 409);
    }

    // Check if ingredient has been used in shopping/procurement (production history)
    const shoppingUsage = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM shopping_items WHERE ingredient_id = ?"
    ).bind(ingredientId).first<{ count: number }>();
    
    if (shoppingUsage?.count && shoppingUsage.count > 0) {
      return c.json({ 
        error: "Cannot delete ingredient - it has been used in shopping lists or procurement",
        shopping_records: shoppingUsage.count 
      }, 409);
    }

    const result = await env.DB.prepare(
      "DELETE FROM ingredients WHERE id = ?"
    ).bind(ingredientId).run();

    if (result.meta.changes === 0) {
      return c.json({ error: "Ingredient not found" }, 404);
    }

    return c.json({ message: "Ingredient deleted successfully" });
  } catch (error) {
    console.error("Ingredient deletion error:", error);
    return c.json({ error: "Failed to delete ingredient" }, 500);
  }
});

// Search ingredients by name (for recipe creation autocomplete)
ingredients.get("/search/:query", async (c) => {
  const query = c.req.param("query");
  const env = c.env;
  
  try {
    const ingredients = await env.DB.prepare(`
      SELECT i.*, COUNT(isp.id) as supplier_count
      FROM ingredients i
      LEFT JOIN ingredient_supplier_prices isp ON i.id = isp.ingredient_id
      WHERE i.name LIKE ?
      GROUP BY i.id
      ORDER BY i.name ASC
      LIMIT 10
    `).bind(`%${query}%`).all();

    return c.json(ingredients.results);
  } catch (error) {
    console.error("Failed to search ingredients:", error);
    return c.json({ error: "Failed to search ingredients" }, 500);
  }
});

// Bulk operations on ingredients
const BulkOperationSchema = z.object({
  ingredient_ids: z.array(z.number()),
  operation: z.enum(['delete', 'archive', 'tag_add', 'tag_remove', 'update_waste']),
  tags: z.array(z.string()).optional(),
  waste_percentage: z.number().min(0).max(100).optional(),
});

ingredients.post("/bulk", zValidator("json", BulkOperationSchema), async (c) => {
  const { ingredient_ids, operation, tags, waste_percentage } = c.req.valid("json");
  const env = c.env;
  
  if (ingredient_ids.length === 0) {
    return c.json({ error: "No ingredients selected" }, 400);
  }
  
  try {
    let affectedCount = 0;
    
    switch (operation) {
      case 'delete':
        // Check if any ingredients are used in recipes
        const usageCheck = await env.DB.prepare(`
          SELECT COUNT(*) as count FROM recipe_ingredients 
          WHERE ingredient_id IN (${ingredient_ids.map(() => '?').join(',')})
        `).bind(...ingredient_ids).first<{ count: number }>();
        
        if (usageCheck?.count && usageCheck.count > 0) {
          return c.json({ 
            error: "Cannot delete ingredients - some are used in recipes",
            recipes_using: usageCheck.count 
          }, 409);
        }
        
        // Delete ingredients and their tags
        for (const id of ingredient_ids) {
          await env.DB.prepare("DELETE FROM ingredient_tags WHERE ingredient_id = ?").bind(id).run();
          const result = await env.DB.prepare("DELETE FROM ingredients WHERE id = ?").bind(id).run();
          affectedCount += result.meta.changes || 0;
        }
        break;
        
      case 'tag_add':
        if (!tags || tags.length === 0) {
          return c.json({ error: "No tags specified for tag_add operation" }, 400);
        }
        
        for (const ingredientId of ingredient_ids) {
          for (const tag of tags) {
            await env.DB.prepare(`
              INSERT OR IGNORE INTO ingredient_tags (ingredient_id, tag, created_at, updated_at)
              VALUES (?, ?, datetime('now'), datetime('now'))
            `).bind(ingredientId, tag.toLowerCase().trim()).run();
          }
        }
        affectedCount = ingredient_ids.length;
        break;
        
      case 'tag_remove':
        if (!tags || tags.length === 0) {
          return c.json({ error: "No tags specified for tag_remove operation" }, 400);
        }
        
        for (const ingredientId of ingredient_ids) {
          for (const tag of tags) {
            await env.DB.prepare(`
              DELETE FROM ingredient_tags 
              WHERE ingredient_id = ? AND tag = ?
            `).bind(ingredientId, tag.toLowerCase().trim()).run();
          }
        }
        affectedCount = ingredient_ids.length;
        break;
        
      case 'update_waste':
        if (waste_percentage === undefined) {
          return c.json({ error: "No waste_percentage specified for update_waste operation" }, 400);
        }
        
        for (const id of ingredient_ids) {
          const result = await env.DB.prepare(`
            UPDATE ingredients SET waste_percentage = ?, updated_at = datetime('now')
            WHERE id = ?
          `).bind(waste_percentage, id).run();
          affectedCount += result.meta.changes || 0;
        }
        break;
        
      default:
        return c.json({ error: "Invalid operation" }, 400);
    }
    
    return c.json({ 
      message: `Bulk ${operation} completed successfully`,
      affected_count: affectedCount
    });
  } catch (error) {
    console.error("Bulk operation error:", error);
    return c.json({ error: "Failed to perform bulk operation" }, 500);
  }
});

export default ingredients;
