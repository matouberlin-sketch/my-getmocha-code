import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { ScrapeRecipeSchema } from "@/shared/types";
import { convertToWeight } from "@/shared/utils/weightConversion";
import OpenAI from "openai";
import recipes from "./api/recipes";
import suppliers from "./api/suppliers";
import ingredients from "./api/ingredients";
import ingredientTags from "./api/ingredient-tags";
import invoices from "./api/invoices";
import locations from "./api/locations";
import plannedMeals from "./api/planned-meals";
import documents from "./api/documents";
import recipeFolders from "./api/recipe-folders";
import recipeShortlist from "./api/recipe-shortlist";
import recipeCsv from "./api/recipe-csv";
import items from "./api/items";
import enhancedRecipes from "./api/enhanced-recipes";
import csvImport from "./api/csv-import";
import bom from "./api/bom";
import plannerPlans from "./api/planner-plans";
import lots from "./api/lots";
import type { Env } from "./bindings";

const app = new Hono<{ Bindings: Env }>();

// Mount API routes
app.route("/api/recipes", recipes);
app.route("/api/suppliers", suppliers);
app.route("/api/ingredients", ingredients);
app.route("/api/ingredient-tags", ingredientTags);
app.route("/api/invoices", invoices);
app.route("/api/locations", locations);
app.route("/api/planned-meals", plannedMeals);
app.route("/api/documents", documents);
app.route("/api/recipe-folders", recipeFolders);
app.route("/api/recipe-shortlist", recipeShortlist);
app.route("/api/recipe-csv", recipeCsv);
app.route("/api/items", items);
app.route("/api/enhanced-recipes", enhancedRecipes);
app.route("/api/csv-import", csvImport);
app.route("/api/bom", bom);
app.route("/api/planner", plannerPlans);
app.route("/api/lots", lots);

// Context-aware AI prompt that leverages existing database structure
const ENHANCED_RECIPE_PARSING_PROMPT = `You are an expert chef and culinary cost management assistant. Parse this recipe completely and accurately for professional kitchen use, leveraging existing database structure and cooking knowledge.

**CONTEXT:** You are parsing a recipe for a restaurant kitchen management system. The system already has:
- An existing ingredient database with standardized names, units, and portion weights
- Common culinary tags for meal types, cuisines, cooking methods, and dietary restrictions
- Professional kitchen workflow and timing requirements

**EXISTING INGREDIENT DATABASE STRUCTURE:**
- Each ingredient has: name, unit_type (weight/volume/count), grams_per_piece (for count items)
- Common ingredients likely already exist: chicken, beef, onion, garlic, tomatoes, flour, etc.
- Unit types are standardized: kg/g for weight, l/ml for volume, piece/clove/large/medium/small for count

**REQUIRED OUTPUT FORMAT:**
{
  "name": "Recipe name",
  "description": "Brief compelling description (2-3 sentences)",
  "yield_amount": number,
  "yield_unit": "servings|portions|kg|etc",
  "prep_time_minutes": number (estimated if not given),
  "hands_on_minutes": number (estimated active cooking time),
  "total_time_minutes": number (prep + cooking + resting),
  "station": "prep|grill|pastry|sauce|salad",
  "ingredients": [...],
  "steps": [...],
  "cookingSteps": [...],
  "tags": [...],
  "notes": "Additional recipe notes"
}

**INGREDIENT PARSING (CRITICAL FOR COSTING):**
- **amount**: Precise numeric (convert fractions: 1/2=0.5, 1¼=1.25)
- **unit**: ONLY these units: kg, g, l, ml, cup, tbsp, tsp, oz, lb, piece, clove, large, medium, small
- **ingredient_name**: Standardized name (singular, no brands unless essential)
- **notes**: Prep methods, quality specs (organic, fresh, etc.)
- **is_sub_recipe**: true for complex components (pastes, sauces, stocks)

**TIMING ESTIMATES (if not specified):**
- Simple dishes: 15-30 min prep, 10-20 min hands-on
- Complex dishes: 45-90 min prep, 30-60 min hands-on  
- Consider: prep work, active cooking, passive cooking, resting

**UNIT STANDARDIZATION (CRITICAL FOR COSTING):**
- **Weight**: kg, g, lb, oz (prefer metric)
- **Volume**: l, ml, cup, tbsp, tsp, fl oz (prefer metric)  
- **Count**: piece, clove, whole, each
- **Size**: large, medium, small (only for produce)
- **Never use**: "a pinch", "dash", "some", "handful" - convert to measurable units

**INGREDIENT NAME STANDARDIZATION:**
- Remove brand names, quality descriptors unless essential for costing
- Use singular form: "tomato" not "tomatoes"
- Use generic names: "onion" not "yellow onion" unless variety affects cost
- Remove preparation unless it affects ingredient cost: "chicken breast" not "diced chicken breast"
- Keep essential specifications: "all-purpose flour", "extra virgin olive oil", "kosher salt"

**MEASUREMENT CONVERSION PRIORITIES:**
1. Convert vague amounts to specific measurements:
   - "a bunch" of herbs = 50g
   - "a head" of lettuce = 500g
   - "a can" = specify size (400g, 14oz, etc.)
2. Standardize fractional measurements precisely
3. Convert compound measurements: "1 lb 8 oz" = 1.5 lb or 680g

**SUB-RECIPE DETECTION:**
- Mark as sub-recipe: pastes, sauces, marinades, stocks, dressings, compound preparations
- NOT sub-recipes: simple seasonings, single-ingredient items, store-bought items

**QUALITY SPECIFICATIONS (for notes field):**
- Include quality specs that affect cost: "organic", "free-range", "aged"
- Include preparation that affects purchasing: "boneless", "skinless", "peeled"
- Include ripeness/freshness specs: "ripe", "fresh", "dried"

**Example Input:**
["2 1/2 cups organic all-purpose flour", "1/2 a large yellow onion, diced", "2 cloves fresh garlic, minced", "1 lb 8 oz beef chuck, cubed", "400g tin chopped tomatoes", "bunch fresh basil", "homemade chicken stock"]

**Example Output:**
[
  {"amount": 315, "unit": "g", "ingredient_name": "all-purpose flour", "notes": "organic", "is_sub_recipe": false},
  {"amount": 0.5, "unit": "large", "ingredient_name": "onion", "notes": "diced", "is_sub_recipe": false},
  {"amount": 2, "unit": "clove", "ingredient_name": "garlic", "notes": "fresh, minced", "is_sub_recipe": false},
  {"amount": 680, "unit": "g", "ingredient_name": "beef chuck", "notes": "cubed", "is_sub_recipe": false},
  {"amount": 400, "unit": "g", "ingredient_name": "tomato", "notes": "tinned, chopped", "is_sub_recipe": false},
  {"amount": 50, "unit": "g", "ingredient_name": "basil", "notes": "fresh", "is_sub_recipe": false},
  {"amount": 1, "unit": "l", "ingredient_name": "chicken stock", "notes": "homemade", "is_sub_recipe": true}
]

**CRITICAL:** Focus on creating standardized, cost-trackable ingredient entries that can be matched against supplier catalogs and scaled accurately.

**ALWAYS PRIORITIZE ACCURACY:** Every ingredient must have a precise measurement that can be converted to grams for professional kitchen use.

Parse the following ingredients and return only the JSON array:`;

// Enhanced AI prompt for instruction parsing with detailed timing analysis
const INSTRUCTION_PARSING_PROMPT = `You are an expert chef assistant specializing in parsing recipe instructions to extract detailed cooking information and timing estimates for professional kitchen workflows.

**CRITICAL MISSION:** You MUST extract cooking details from EVERY step that involves actual cooking. Focus on detecting MULTIPLE PARALLEL PROCESSES and equipment requirements.

**Input:** Raw instruction text from a recipe
**Output:** JSON array of step objects with detailed timing analysis and process organization

**For each step, you MUST extract:**
1. **step_number**: Sequential number (1, 2, 3, etc.)
2. **instruction**: Clean, clear instruction text
3. **equipment**: Primary equipment - REQUIRED if any cooking happens (oven, pan, pot, skillet, grill, stove, etc.)
4. **temperature**: Cooking temperature - EXTRACT whenever mentioned (350°F, medium heat, high, low, gentle, etc.)
5. **cooking_time**: Time in format "5'" for 5 minutes, "2'30'" for 2.5 hours - EXTRACT all time references
6. **cooking_method**: Primary cooking action - REQUIRED for cooking steps (bake, sauté, simmer, fry, grill, roast, etc.)
7. **timing_type**: "active" (hands-on) or "passive" (unattended) or "prep" (preparation)
8. **process**: Process name if this is part of a distinct sub-process (e.g., "bolognese", "bechamel", "sauce preparation", "assembly")
9. **parallel_capable**: "parallel" if this can be done simultaneously with other processes, "sequential" if it must be done in order

**TIMING ANALYSIS - CRITICAL FOR PROFESSIONAL KITCHENS:**

**Time Extraction Rules - HANDLE COMPLEX RANGES:**
- Range times: "2 - 2 1/2 hours" = "2'30'" (use longer time, convert properly)
- "5-7 minutes" = "7'" (use longer time)
- "About 10 minutes" = "10'"
- "1 hour 30 minutes" = "1'30'"
- "2.5 hours" = "2'30'"
- "Until golden brown" = estimate based on cooking method:
  * Sautéing vegetables: "5'"
  * Browning meat: "8'"
  * Baking until golden: "25'"
  * Toasting: "3'"
  * Simmering until tender: "2'00'" (for long braises)

**Timing Type Classification:**
- **"active"**: Direct hands-on work (stirring, chopping, sautéing, flipping)
- **"passive"**: Unattended cooking (baking, simmering, resting, chilling, braising)
- **"prep"**: Preparation work (chopping, measuring, mixing)

**Method-Based Time Estimates:**
- **Prep work**: "prep" method
  * Chop onion: "3'", dice vegetables: "5'", measure ingredients: "2'"
- **Active cooking**: "active" timing
  * Sauté onions: "5'", brown meat: "8'", stir-fry: "6'"
- **Passive cooking**: "passive" timing
  * Simmer sauce: "20'", bake: "30'", rest dough: "60'", long braise: "2'00'"

**EQUIPMENT DETECTION (CRITICAL - DO NOT MISS):**
- ALWAYS identify equipment when cooking happens: oven, pan, skillet, pot, saucepan, grill, stove, wok, dutch oven, etc.
- Look for phrases: "in a large pan", "place in oven", "heat oil in skillet", "bring to boil in pot"
- If equipment isn't explicitly stated but cooking is happening, infer: 
  * baking = "oven", sautéing = "pan", boiling/simmering = "pot"
  * "submerged" + liquid = "pot" (for braising/stewing)

**COOKING METHOD DETECTION (CRITICAL - DO NOT MISS):**
- ALWAYS identify the cooking action: bake, roast, sauté, fry, simmer, boil, grill, steam, braise, etc.
- Look for action verbs: "bake for", "sauté until", "simmer gently", "fry in oil", "grill over"
- Extract from context: "until golden brown" + "in pan" = sauté method
- "submerged" + "simmer" = braising/stewing method

**TEMPERATURE EXTRACTION (CRITICAL):**
- Extract ALL temperature references: "350°F", "medium heat", "high heat", "low heat", "medium-high", "gently"
- Don't skip vague temperatures: "medium", "hot", "gentle heat", "gently"
- "gently" = "low heat" for simmering
- Oven temperatures: always extract exact degrees

**TIME EXTRACTION (CRITICAL - HANDLE COMPLEX FORMATS):**
- Extract ALL time references: "25 minutes", "1 hour", "30-45 minutes", "2 - 2 1/2 hours"
- Convert to format: "25'" for 25 minutes, "1'00'" for 1 hour, "2'30'" for 2.5 hours
- For ranges like "2 - 2 1/2 hours" use longer time: "2'30'" (2.5 hours = 150 minutes)
- For ranges like "30-45 minutes" use longer time: "45'"
- For "until done" descriptions, estimate based on cooking method and context

**MULTI-PROCESS DETECTION (CRITICAL FOR COMPLEX RECIPES):**
- **Process Recognition**: Identify distinct cooking processes:
  * "For the bolognese..." = process: "bolognese"
  * "Make the bechamel..." = process: "bechamel"  
  * "Meanwhile, prepare..." = process: (infer from context)
  * "Assembly: Layer the..." = process: "assembly"
  * Multiple sauces, multiple proteins, side preparations

- **Parallel Cooking Detection**: Look for indicators of simultaneous processes:
  * "Meanwhile", "While that cooks", "At the same time", "In another pot"
  * Multiple equipment mentions: "2 pots", "separate pan", "different saucepan"
  * Time overlaps: If step A takes 30 min and step B takes 20 min and starts during A

**EQUIPMENT QUANTITY DETECTION:**
- Look for quantity indicators: "2 pots", "large and small saucepan", "separate pans"
- When multiple similar equipment needed, specify: "pot (large)", "pot (medium)"
- Different equipment types: "pot for sauce, oven for baking"

**PROCESS EXAMPLES:**
- Bolognese + Bechamel + Assembly + Baking = 4 processes, some parallel
- Protein + Sauce + Vegetables = 3 processes, often parallel
- Base + Topping + Garnish = 3 processes, usually sequential

**SPECIFIC EXAMPLES TO HANDLE:**

**Input:** "Add 1/2 cup of coconut milk and just enough water to keep everything submerged. Add 1 Tbsp of the curry paste, 1 Tbsp fish sauce, and simmer gently for 2 - 2 1/2 hours or until the beef is fork tender. Set it aside."

**REQUIRED Output:**
{"step_number": 1, "instruction": "Add coconut milk, water, curry paste, fish sauce, and simmer gently until beef is fork tender", "equipment": "pot", "temperature": "low heat", "cooking_time": "2'30'", "cooking_method": "simmer", "timing_type": "passive", "process": "main curry", "parallel_capable": "parallel"}

**Input:** "Meanwhile, in a separate large saucepan, melt butter and whisk in flour to make a roux. Gradually add milk, whisking constantly until thick."

**REQUIRED Output:**  
{"step_number": 2, "instruction": "Make roux with butter and flour, then add milk for bechamel", "equipment": "saucepan (large)", "temperature": "medium heat", "cooking_time": "10'", "cooking_method": "simmer", "timing_type": "active", "process": "bechamel", "parallel_capable": "parallel"}

**CRITICAL:** Extract equipment, method, temperature, time, process, and parallel capability from EVERY step that contains this information. Focus especially on detecting multiple processes and equipment requirements.

Analyze these instructions and return detailed cooking information with process organization:`;

// Recipe scraping endpoint with enhanced AI parsing
app.post("/api/recipes/scrape", zValidator("json", ScrapeRecipeSchema), async (c) => {
  const { url } = c.req.valid("json");
  const env = c.env;

  try {
    // Fetch the webpage
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    if (!response.ok) {
      return c.json({ error: "Failed to fetch webpage" }, 400);
    }

    const html = await response.text();
    
    // Parse recipe data from HTML with improved error handling
    const recipeData = await parseRecipeFromHTML(html, env);
    
    if (!recipeData) {
      return c.json({ error: "No recipe data found on this page" }, 400);
    }

    // Enhance the recipe data with weight conversions and sub-recipe detection
    const enhancedData = enhanceRecipeData(recipeData, url);

    return c.json(enhancedData);
  } catch (error) {
    console.error("Recipe scraping error:", error);
    
    // Provide more specific error messages
    if (error instanceof Error) {
      if (error.message.includes('quota') || error.message.includes('rate limit')) {
        return c.json({ 
          error: "AI features temporarily unavailable due to quota limits. Recipe parsed using fallback methods.",
          warning: "Some advanced parsing features may be limited." 
        }, 200); // Return 200 since fallback parsing should work
      }
    }
    
    return c.json({ error: "Failed to scrape recipe" }, 500);
  }
});

async function parseRecipeFromHTML(html: string, env: Env): Promise<any> {
  console.log("Starting recipe parsing from HTML");
  
  // First try to find JSON-LD structured data
  const jsonLdMatch = html.match(/<script[^>]*type="application\/ld\+json"[^>]*>(.*?)<\/script>/gis);
  
  if (jsonLdMatch) {
    console.log(`Found ${jsonLdMatch.length} JSON-LD scripts`);
    
    for (const script of jsonLdMatch) {
      try {
        // Extract JSON content more carefully
        const jsonContent = script
          .replace(/<script[^>]*>/i, '')
          .replace(/<\/script>/i, '')
          .trim();
        
        const data = JSON.parse(jsonContent);
        
        // Handle complex nested structures
        let items = [];
        if (Array.isArray(data)) {
          items = data;
        } else if (data['@graph'] && Array.isArray(data['@graph'])) {
          items = data['@graph'];
        } else {
          items = [data];
        }
        
        // Look for Recipe items
        for (const item of items) {
          const type = item['@type'];
          const isRecipe = type === 'Recipe' || 
                          (Array.isArray(type) && type.includes('Recipe')) ||
                          (typeof type === 'string' && type.toLowerCase().includes('recipe'));
          
          if (isRecipe && item.name && (item.recipeIngredient || item.recipeInstructions)) {
            console.log(`Found structured recipe: ${item.name}`);
            return await parseStructuredRecipe(item, env);
          }
        }
      } catch (e) {
        console.warn("Failed to parse JSON-LD script:", e);
        continue;
      }
    }
  }

  console.log("No structured data found, falling back to HTML parsing");
  // Fallback to enhanced HTML parsing with AI assistance
  return await parseHTMLFallback(html, env);
}

async function parseStructuredRecipe(recipe: any, env: Env): Promise<any> {
  console.log("Parsing structured recipe:", recipe.name);
  
  // Use comprehensive AI parsing if available
  if (env.OPENAI_API_KEY) {
    try {
      console.log("Using comprehensive AI parsing for complete recipe");
      const recipeContent = {
        name: recipe.name || '',
        description: recipe.description || '',
        yield: recipe.recipeYield || '',
        ingredients: recipe.recipeIngredient || [],
        instructions: recipe.recipeInstructions || [],
        prepTime: recipe.prepTime || '',
        cookTime: recipe.cookTime || '',
        totalTime: recipe.totalTime || '',
        category: recipe.recipeCategory || '',
        cuisine: recipe.recipeCuisine || ''
      };
      
      const aiParsedRecipe = await parseCompleteRecipeWithAI(recipeContent, env);
      if (aiParsedRecipe) {
        console.log("AI parsed complete recipe successfully");
        return aiParsedRecipe;
      }
    } catch (error) {
      console.warn("Comprehensive AI parsing failed, falling back to manual parsing:", error);
    }
  }
  
  // Fallback to manual parsing
  console.log("Using manual parsing approach");
  
  const name = recipe.name || '';
  const rawDescription = recipe.description || '';
  
  // Parse yield
  let yieldAmount = 4;
  let yieldUnit = 'servings';
  if (recipe.recipeYield) {
    const yieldStr = Array.isArray(recipe.recipeYield) ? recipe.recipeYield[0] : recipe.recipeYield;
    const yieldMatch = String(yieldStr).match(/(\d+(?:\.\d+)?)\s*(.+)?/);
    if (yieldMatch) {
      yieldAmount = parseFloat(yieldMatch[1]);
      yieldUnit = yieldMatch[2]?.trim() || 'servings';
    }
  }

  // Parse times with better estimation
  const prepTime = parseDuration(recipe.prepTime);
  const cookTime = parseDuration(recipe.cookTime);
  const totalTime = parseDuration(recipe.totalTime);
  
  // Better time estimation
  const estimatedPrepTime = prepTime || estimateTimeFromIngredients(recipe.recipeIngredient || []);
  const estimatedCookTime = cookTime || estimateTimeFromInstructions(recipe.recipeInstructions || []);
  const estimatedTotalTime = totalTime || (estimatedPrepTime + estimatedCookTime);
  const handsOnMinutes = Math.round(estimatedPrepTime + (estimatedCookTime * 0.4));

  console.log(`Found ${recipe.recipeIngredient?.length || 0} ingredients`);
  
  // Enhanced ingredient parsing with AI assistance
  let ingredients = [];
  if (recipe.recipeIngredient && Array.isArray(recipe.recipeIngredient) && recipe.recipeIngredient.length > 0) {
    console.log("Raw ingredients:", recipe.recipeIngredient);
    
    if (env.OPENAI_API_KEY) {
      try {
        console.log("Using AI to parse ingredients");
        ingredients = await parseIngredientsWithAI(recipe.recipeIngredient, env);
        console.log("AI parsed ingredients:", ingredients.length, "items");
      } catch (error) {
        console.warn("AI ingredient parsing failed, falling back to regex:", error);
        ingredients = parseIngredientsWithRegex(recipe.recipeIngredient);
        console.log("Regex parsed ingredients:", ingredients.length, "items");
      }
    } else {
      console.log("No OpenAI key, using regex parsing");
      ingredients = parseIngredientsWithRegex(recipe.recipeIngredient);
      console.log("Regex parsed ingredients:", ingredients.length, "items");
    }
  }

  console.log(`Found ${recipe.recipeInstructions?.length || 0} instructions`);
  
  // Enhanced instruction parsing with cooking details
  let steps = [];
  if (recipe.recipeInstructions && Array.isArray(recipe.recipeInstructions)) {
    const instructionTexts = recipe.recipeInstructions.map((instruction: any) => {
      if (typeof instruction === 'string') {
        return instruction;
      } else if (instruction.text) {
        return instruction.text;
      } else if (instruction.name) {
        return instruction.name;
      }
      return '';
    }).filter((text: string) => text.trim());

    if (env.OPENAI_API_KEY && instructionTexts.length > 0) {
      try {
        console.log("Using AI to parse instructions with cooking details");
        steps = await parseInstructionsWithAI(instructionTexts, env);
        console.log("AI parsed instructions:", steps.length, "items");
      } catch (error) {
        console.warn("AI instruction parsing failed, falling back to basic parsing:", error);
        steps = instructionTexts.map((text: string, i: number) => ({
          step_number: i + 1,
          instruction: text.trim(),
          equipment: null,
          temperature: null,
          cooking_time: null,
          cooking_method: null
        }));
      }
    } else {
      steps = instructionTexts.map((text: string, i: number) => ({
        step_number: i + 1,
        instruction: text.trim(),
        equipment: null,
        temperature: null,
        cooking_time: null,
        cooking_method: null
      }));
    }
  }

  // Generate enhanced description based on recipe content
  let description = rawDescription;
  if (env.OPENAI_API_KEY && (ingredients.length > 0 || steps.length > 0)) {
    try {
      description = await generateEnhancedDescription(name, rawDescription, ingredients, steps, env);
    } catch (error) {
      console.warn("Failed to enhance description:", error);
    }
  }

  // Extract cooking steps from parsed instructions
  const cookingSteps = extractCookingSteps(steps);
  
  // Clean instructions by removing cooking details
  const cleanedSteps = steps.map((step: any) => ({
    step_number: step.step_number,
    instruction: step.instruction
  }));

  // Generate tags based on recipe content using AI
  const tags = await generateRecipeTagsWithAI(name, description, ingredients, recipe, env);

  console.log("Final parsed recipe:", {
    name: name.trim(),
    ingredients: ingredients.length,
    steps: cleanedSteps.length,
    cookingSteps: cookingSteps.length,
    yield: `${yieldAmount} ${yieldUnit}`,
    times: { prep: estimatedPrepTime, cook: estimatedCookTime, total: estimatedTotalTime, handsOn: handsOnMinutes },
    tags: tags
  });

  return {
    name: name.trim(),
    description: description.trim(),
    yield_amount: yieldAmount,
    yield_unit: yieldUnit,
    prep_time_minutes: estimatedTotalTime || null,
    hands_on_minutes: handsOnMinutes || null,
    station: inferStation(ingredients, cleanedSteps),
    ingredients,
    steps: cleanedSteps,
    cookingSteps,
    tags
  };
}

async function parseHTMLFallback(html: string, env: Env): Promise<any> {
  // Extract basic recipe information using common CSS selectors and patterns
  const name = extractText(html, [
    'h1.recipe-title',
    'h1[class*="title"]',
    'h1[class*="recipe"]',
    '.recipe-header h1',
    '.entry-title',
    'h1'
  ]) || 'Imported Recipe';

  const description = extractText(html, [
    '.recipe-description',
    '.recipe-summary',
    '[class*="description"]',
    '.entry-summary'
  ]) || '';

  // Enhanced ingredient extraction
  const rawIngredients = extractIngredients(html);
  let ingredients = [];
  
  if (env.OPENAI_API_KEY && rawIngredients.length > 0) {
    try {
      const ingredientTexts = rawIngredients.map(ing => ing.raw_text).filter(Boolean);
      if (ingredientTexts.length > 0) {
        ingredients = await parseIngredientsWithAI(ingredientTexts, env);
      }
    } catch (error) {
      console.warn("AI ingredient parsing failed, using extracted ingredients:", error);
      ingredients = rawIngredients;
    }
  } else {
    ingredients = rawIngredients;
  }
  
  // Try to extract instructions
  const rawSteps = extractInstructions(html);
  
  // Try to parse cooking steps from instructions if available
  let steps = rawSteps;
  let cookingSteps: any[] = [];
  
  if (env.OPENAI_API_KEY && rawSteps.length > 0) {
    try {
      const instructionTexts = rawSteps.map(step => step.instruction);
      const aiParsedSteps = await parseInstructionsWithAI(instructionTexts, env);
      cookingSteps = extractCookingSteps(aiParsedSteps);
      steps = aiParsedSteps.map((step: any) => ({
        step_number: step.step_number,
        instruction: step.instruction
      }));
    } catch (error) {
      console.warn("AI instruction parsing failed in fallback:", error);
      // Keep original steps
    }
  }

  return {
    name: name.trim(),
    description: description.trim(),
    yield_amount: 4,
    yield_unit: 'servings',
    prep_time_minutes: null,
    hands_on_minutes: null,
    ingredients,
    steps,
    cookingSteps
  };
}

// Context-aware ingredient parsing that matches against existing database
const ENHANCED_INGREDIENT_PARSING_PROMPT = `You are parsing recipe ingredients for a professional kitchen management system with an existing ingredient database. Your goal is to create ingredient entries that can be easily matched against existing database records.

**EXISTING DATABASE CONTEXT:**
The system likely already contains common ingredients like:
- Proteins: chicken breast, ground beef, salmon, eggs
- Vegetables: onion, tomato, carrot, garlic, bell pepper, potato
- Pantry: olive oil, salt, black pepper, flour, sugar, butter
- Herbs/Spices: basil, oregano, cumin, paprika, ginger

**INGREDIENT MATCHING PRIORITY:**
1. Use SINGULAR, GENERIC forms: "onion" not "onions" or "yellow onion" 
2. Remove brand names and unnecessary qualifiers
3. Use standardized culinary terms: "chicken breast" not "boneless skinless chicken breast"
4. Preserve essential distinctions: "extra virgin olive oil" vs "olive oil"

**CRITICAL PARSING RULES:**

**RANGE HANDLING:**
- "2-3 tbsp" → amount: 2.5, unit: "tbsp" (use middle of range)
- "1-2 large onions" → amount: 1.5, unit: "large" 
- "3 to 4 cups" → amount: 3.5, unit: "cup"

**FRACTION CONVERSIONS:**
- "half an onion" → amount: 0.5, unit: "medium", ingredient_name: "onion"
- "quarter cup" → amount: 0.25, unit: "cup"
- "1½ tbsp" → amount: 1.5, unit: "tbsp"
- "2 1/4 cups" → amount: 2.25, unit: "cup"

**UNIT EXTRACTION (CRITICAL - NEVER put units in ingredient_name):**
- "2-3 tablespoons olive oil" → amount: 2.5, unit: "tbsp", ingredient_name: "olive oil"
- "1 pound ground beef" → amount: 1, unit: "lb", ingredient_name: "ground beef"
- "4 medium carrots" → amount: 4, unit: "medium", ingredient_name: "carrot"

**STANDARDIZED UNITS ONLY:**
kg, g, l, ml, cup, tbsp, tsp, oz, lb, piece, clove, large, medium, small, whole, can, bunch, head

**SUB-RECIPE DETECTION:**
Mark as sub-recipe ONLY if: homemade/fresh + (paste, sauce, stock, marinade, dressing)
Examples: "homemade chicken stock" = true, "store-bought pesto" = false

**OUTPUT FORMAT:**
[
  {"amount": number, "unit": "standardized_unit", "ingredient_name": "database_friendly_name", "notes": "prep_and_quality_specs", "is_sub_recipe": boolean}
]

**EXAMPLES:**
- "2 lbs boneless skinless organic chicken breasts" → amount: 2, unit: "lb", ingredient_name: "chicken breast", notes: "boneless, skinless, organic"
- "1 large yellow onion, diced" → amount: 1, unit: "large", ingredient_name: "onion", notes: "diced"
- "400g tin of chopped tomatoes" → amount: 400, unit: "g", ingredient_name: "tomato", notes: "tinned, chopped"

Parse these ingredients for database matching:`;

async function parseIngredientsWithAI(ingredientTexts: string[], env: Env): Promise<any[]> {
  if (!env.OPENAI_API_KEY) {
    console.warn("OpenAI API key not available, falling back to regex parsing");
    throw new Error("OpenAI API key not available");
  }

  // Fetch existing ingredients from database for context
  let existingIngredients: any[] = [];
  try {
    const dbIngredients = await env.DB.prepare(`
      SELECT name, unit_type, grams_per_piece 
      FROM ingredients 
      ORDER BY name ASC 
      LIMIT 500
    `).all();
    existingIngredients = dbIngredients.results as any[];
    console.log(`Found ${existingIngredients.length} existing ingredients in database`);
  } catch (error) {
    console.warn("Failed to fetch existing ingredients:", error);
  }

  const openai = new OpenAI({
    apiKey: env.OPENAI_API_KEY,
  });

  // Create enhanced prompt with database context
  const databaseContext = existingIngredients.length > 0 
    ? `\n\n**EXISTING INGREDIENTS IN DATABASE (prioritize matching these):**\n${existingIngredients.map(ing => 
        `- ${ing.name} (${ing.unit_type}${ing.grams_per_piece ? `, ${ing.grams_per_piece}g/piece` : ''})`
      ).slice(0, 100).join('\n')}\n\n**If ingredients closely match existing ones, use the exact database name.**`
    : '';

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "user",
        content: `${ENHANCED_INGREDIENT_PARSING_PROMPT}${databaseContext}\n\n${JSON.stringify(ingredientTexts)}`
      }
    ],
    max_tokens: 2500,
    temperature: 0.1,
  });

  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error("No response from OpenAI");
  }

  try {
    // Find JSON in the response
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    const jsonString = jsonMatch ? jsonMatch[0] : content;
    const parsedIngredients = JSON.parse(jsonString);
    
    // Enhance with database matching and weight calculations
    return parsedIngredients.map((ingredient: any, index: number) => {
      // Ensure required fields
      if (!ingredient.ingredient_name || !ingredient.amount || !ingredient.unit) {
        console.warn(`Invalid ingredient at index ${index}, missing required fields:`, ingredient);
        return null;
      }
      
      // Standardize unit
      const standardUnit = standardizeUnit(ingredient.unit);
      
      // Ensure amount is numeric
      const numericAmount = typeof ingredient.amount === 'string' ? parseFloat(ingredient.amount) : ingredient.amount;
      if (isNaN(numericAmount) || numericAmount <= 0) {
        console.warn(`Invalid amount for ingredient ${ingredient.ingredient_name}:`, ingredient.amount);
        return null;
      }
      
      // Try to match against existing database ingredients
      const matchedIngredient = findBestIngredientMatch(ingredient.ingredient_name, existingIngredients);
      const finalIngredientName = matchedIngredient ? matchedIngredient.name : standardizeIngredientName(ingredient.ingredient_name);
      const gramsPerPiece = matchedIngredient?.grams_per_piece || null;
      
      // Recalculate weight with database context
      const weightResult = convertToWeight(
        numericAmount,
        standardUnit,
        finalIngredientName,
        gramsPerPiece
      );
      
      return {
        ingredient_name: finalIngredientName,
        amount: numericAmount,
        unit: standardUnit,
        notes: ingredient.notes || null,
        weight_grams: weightResult.weight_grams,
        is_sub_recipe: ingredient.is_sub_recipe || false,
        ingredient_id: matchedIngredient?.id || undefined,
        grams_per_piece: gramsPerPiece,
        order: index + 1
      };
    }).filter(Boolean); // Remove any null entries from validation failures
  } catch (parseError) {
    console.error("Failed to parse AI ingredient response:", content, parseError);
    
    // If it's a quota error, provide a more graceful fallback
    if (content && content.includes('quota')) {
      console.warn("OpenAI quota exceeded during ingredient parsing, falling back to regex");
      throw new Error("OpenAI quota exceeded");
    }
    
    throw new Error("Failed to parse AI response");
  }
}

function parseIngredientsWithRegex(ingredientTexts: string[]): any[] {
  const ingredients = [];
  
  console.log("Parsing ingredients with regex, total items:", ingredientTexts.length);
  
  for (let i = 0; i < ingredientTexts.length; i++) {
    const rawText = ingredientTexts[i];
    console.log(`Parsing ingredient ${i + 1}: "${rawText}"`);
    
    const ingredient = parseIngredientLine(rawText);
    if (ingredient) {
      const weightResult = convertToWeight(
        ingredient.amount,
        ingredient.unit,
        ingredient.name
      );
      
      // Check if it's a sub-recipe
      const isSubRecipe = detectSubRecipeFromText(ingredient.name, ingredient.notes);
      
      const parsed = {
        ingredient_name: ingredient.name,
        amount: ingredient.amount,
        unit: ingredient.unit,
        notes: ingredient.notes,
        weight_grams: weightResult.weight_grams,
        is_sub_recipe: isSubRecipe,
        order: i + 1
      };
      
      console.log(`Parsed: ${parsed.amount} ${parsed.unit} ${parsed.ingredient_name} ${parsed.notes ? '(' + parsed.notes + ')' : ''} [${parsed.weight_grams}g] ${isSubRecipe ? '[SUB-RECIPE]' : ''}`);
      
      ingredients.push(parsed);
    } else {
      console.warn(`Failed to parse ingredient: "${rawText}"`);
    }
  }
  
  console.log(`Successfully parsed ${ingredients.length}/${ingredientTexts.length} ingredients`);
  return ingredients;
}

async function parseInstructionsWithAI(instructionTexts: string[], env: Env): Promise<any[]> {
  if (!env.OPENAI_API_KEY) {
    console.warn("OpenAI API key not available, falling back to basic parsing");
    throw new Error("OpenAI API key not available");
  }

  const openai = new OpenAI({
    apiKey: env.OPENAI_API_KEY,
  });

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "user",
        content: `${INSTRUCTION_PARSING_PROMPT}\n\n${JSON.stringify(instructionTexts)}`
      }
    ],
    max_tokens: 3000,
    temperature: 0.1,
  });

  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error("No response from OpenAI");
  }

  try {
    // Find JSON in the response
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    const jsonString = jsonMatch ? jsonMatch[0] : content;
    const parsedInstructions = JSON.parse(jsonString);
    
    console.log("AI Raw Parsed Instructions:", parsedInstructions);
    
    const processedInstructions = parsedInstructions.map((step: any) => ({
      step_number: step.step_number,
      instruction: step.instruction,
      equipment: step.equipment || null,
      temperature: step.temperature || null,
      cooking_time: step.cooking_time || null,
      cooking_method: step.cooking_method || null,
      timing_type: step.timing_type || null,
      process: step.process || null,
      parallel_capable: step.parallel_capable || null
    }));
    
    console.log("Processed Instructions with cooking data:", processedInstructions);
    return processedInstructions;
  } catch (parseError) {
    console.error("Failed to parse AI instruction response:", content);
    throw new Error("Failed to parse AI response");
  }
}

async function generateEnhancedDescription(name: string, originalDescription: string, ingredients: any[], steps: any[], env: Env): Promise<string> {
  if (!env.OPENAI_API_KEY) {
    console.warn("OpenAI API key not available, using original description");
    return originalDescription;
  }

  const openai = new OpenAI({
    apiKey: env.OPENAI_API_KEY,
  });

  const keyIngredients = ingredients.slice(0, 8).map(ing => ing.ingredient_name).join(', ');
  const cookingMethods = steps.map(step => step.cooking_method).filter(Boolean).join(', ');
  const equipment = steps.map(step => step.equipment).filter(Boolean).join(', ');

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "user",
        content: `Create a compelling 2-sentence description for the dish "${name}" based on its cooking techniques and ingredients. Focus on what makes this dish special, its flavors, textures, and cooking methods.

Key ingredients: ${keyIngredients}
Cooking methods: ${cookingMethods || 'various techniques'}
Equipment used: ${equipment || 'standard kitchen tools'}
Original description: ${originalDescription}

Write a description that captures the essence of the dish, its cooking techniques, and what diners can expect. Focus on the food, not the recipe source or author. Keep it concise and appetizing.`
      }
    ],
    max_tokens: 200,
    temperature: 0.3,
  });

  const content = response.choices[0]?.message?.content?.trim();
  return content || originalDescription;
}

function detectSubRecipeFromText(name: string, notes: string | null): boolean {
  const fullText = `${name} ${notes || ''}`.toLowerCase();
  
  const subRecipeKeywords = [
    'paste', 'sauce', 'marinade', 'dressing', 'stock', 'broth', 'curry paste',
    'masala', 'mixture', 'blend', 'base', 'roux', 'vinaigrette',
    'pesto', 'chimichurri', 'salsa', 'chutney', 'relish'
  ];
  
  const preparationWords = [
    'homemade', 'fresh made', 'house-made', 'from scratch', 'prepared'
  ];
  
  // Direct keyword match
  const hasSubRecipeKeyword = subRecipeKeywords.some(keyword => fullText.includes(keyword));
  
  // Preparation word + common ingredient combination
  const hasPreparationAndIngredient = preparationWords.some(prep => fullText.includes(prep)) &&
    subRecipeKeywords.some(keyword => fullText.includes(keyword));
  
  return hasSubRecipeKeyword || hasPreparationAndIngredient;
}

function extractText(html: string, selectors: string[]): string | null {
  for (const selector of selectors) {
    // Simple regex-based extraction (in a real implementation, you'd use a proper HTML parser)
    const classMatch = selector.match(/\.([^.\s]+)/);
    const tagMatch = selector.match(/^(\w+)/);
    
    let regex;
    if (classMatch) {
      regex = new RegExp(`<[^>]*class="[^"]*${classMatch[1]}[^"]*"[^>]*>([^<]+)`, 'i');
    } else if (tagMatch) {
      regex = new RegExp(`<${tagMatch[1]}[^>]*>([^<]+)`, 'i');
    }
    
    if (regex) {
      const match = html.match(regex);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
  }
  return null;
}

function extractIngredients(html: string) {
  const ingredients = [];
  
  // Enhanced ingredient list patterns
  const ingredientPatterns = [
    // Structured ingredient lists
    /<li[^>]*class="[^"]*ingredient[^"]*"[^>]*>([^<]+)</gi,
    /<li[^>]*class="[^"]*recipe-ingredient[^"]*"[^>]*>([^<]+)</gi,
    /<span[^>]*class="[^"]*ingredient[^"]*"[^>]*>([^<]+)</gi,
    // Common measurement patterns
    /<li[^>]*>([^<]*\d+[^<]*(?:cup|tsp|tbsp|teaspoon|tablespoon|pound|oz|ounce|gram|kg|ml|liter|clove|piece)[^<]*)</gi,
    // Fallback for any list items with cooking terms
    /<li[^>]*>([^<]*(?:chopped|diced|minced|sliced|grated|fresh|dried|cooked)[^<]*)</gi
  ];

  for (const pattern of ingredientPatterns) {
    let match;
    let order = 1;
    while ((match = pattern.exec(html)) !== null && order <= 30) {
      const rawText = match[1].trim();
      if (rawText && rawText.length > 2) {
        ingredients.push({
          raw_text: rawText,
          ingredient_name: extractIngredientNameFromText(rawText),
          amount: 1,
          unit: 'piece',
          notes: null,
          order: order++
        });
      }
    }
    if (ingredients.length > 0) break;
  }

  return ingredients;
}

function extractIngredientNameFromText(text: string): string {
  // Simple extraction of likely ingredient name
  const cleanText = text.replace(/^\d+[\d\s\/\.\-]*/, '').trim(); // Remove leading numbers/fractions
  const words = cleanText.split(/\s+/);
  
  // Skip common measurement words
  const measurementWords = ['cup', 'cups', 'tsp', 'tbsp', 'teaspoon', 'tablespoon', 'oz', 'ounce', 'pound', 'lb', 'gram', 'kg', 'ml', 'liter'];
  const filtered = words.filter(word => !measurementWords.includes(word.toLowerCase()));
  
  return filtered.slice(0, 3).join(' '); // Take first few words as ingredient name
}

function extractInstructions(html: string) {
  const steps = [];
  
  // Enhanced instruction patterns
  const instructionPatterns = [
    /<li[^>]*class="[^"]*instruction[^"]*"[^>]*>([^<]+)</gi,
    /<li[^>]*class="[^"]*step[^"]*"[^>]*>([^<]+)</gi,
    /<p[^>]*class="[^"]*step[^"]*"[^>]*>([^<]+)</gi,
    /<li[^>]*class="[^"]*method[^"]*"[^>]*>([^<]+)</gi,
    /<div[^>]*class="[^"]*instruction[^"]*"[^>]*>([^<]+)</gi
  ];

  for (const pattern of instructionPatterns) {
    let match;
    let stepNumber = 1;
    while ((match = pattern.exec(html)) !== null && stepNumber <= 25) {
      const instruction = match[1].trim();
      if (instruction && instruction.length > 15) { // More substantial instructions
        steps.push({
          step_number: stepNumber++,
          instruction: instruction
        });
      }
    }
    if (steps.length > 0) break;
  }

  return steps;
}

function parseIngredientLine(line: string) {
  if (!line || line.trim().length === 0) return null;
  
  const cleanLine = line.trim().replace(/\s+/g, ' ');
  
  // Enhanced patterns for ingredient parsing including ranges and fractional descriptors
  const patterns = [
    // Range amounts with units: "2-3 tbsp", "1 to 2 cups", "3-4 large onions"
    /^(\d+(?:\.\d+)?\s*(?:to|-)\s*\d+(?:\.\d+)?)\s+(cup|cups|tbsp|tablespoon|tablespoons|tsp|teaspoon|teaspoons|oz|ounce|ounces|lb|lbs|pound|pounds|g|gram|grams|kg|kilogram|kilograms|ml|milliliter|milliliters|l|liter|liters|fl\s*oz|fluid\s*ounce|fluid\s*ounces|pint|pints|quart|quarts|gallon|gallons|clove|cloves|piece|pieces|large|medium|small|whole|each|inch|inches)\s+(.+)$/i,
    
    // Fractional descriptors: "half an onion", "quarter cup", "half a large onion"
    /^(half|quarter|third)\s+(?:a\s+|an\s+)?(?:(large|medium|small|whole)\s+)?(.+)$/i,
    
    // Complex fractions with units: "2 ½ cup", "1 1/2 cups", "3/4 tbsp"
    /^(\d+\s*[½¼¾]|\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:\.\d+)?)\s+(cup|cups|tbsp|tablespoon|tablespoons|tsp|teaspoon|teaspoons|oz|ounce|ounces|lb|lbs|pound|pounds|g|gram|grams|kg|kilogram|kilograms|ml|milliliter|milliliters|l|liter|liters|fl\s*oz|fluid\s*ounce|fluid\s*ounces|pint|pints|quart|quarts|gallon|gallons|clove|cloves|piece|pieces|large|medium|small|whole|each|inch|inches)\s+(.+)$/i,
    
    // Range amounts with descriptive units: "2-3 large onions", "1 to 2 medium potatoes"
    /^(\d+(?:\.\d+)?\s*(?:to|-)\s*\d+(?:\.\d+)?)\s+(large|medium|small|whole|each)\s+(.+)$/i,
    
    // Amount with descriptive units: "2 large onions", "1 medium potato"
    /^(\d+(?:\.\d+)?)\s+(large|medium|small|whole|each)\s+(.+)$/i,
    
    // Simple amount + unit + ingredient: "2 cups flour"
    /^(\d+(?:\.\d+)?)\s+([a-zA-Z]+)\s+(.+)$/,
    
    // Amount + ingredient (no explicit unit): "2 eggs", "6 carrots"
    /^(\d+(?:\.\d+)?)\s+(.+)$/,
    
    // Fractional amounts without space: "½ cup", "¼ teaspoon"
    /^([½¼¾])\s+([a-zA-Z]+)\s+(.+)$/,
    
    // Just ingredient name with possible prep notes
    /^(.+)$/
  ];

  for (let i = 0; i < patterns.length; i++) {
    const pattern = patterns[i];
    const match = cleanLine.match(pattern);
    
    if (match) {
      if (match.length === 4) {
        // Handle different pattern types
        if (i === 0 || i === 3) {
          // Range patterns: "2-3 tbsp" or "2-3 large onions"
          let amount = parseRange(match[1]);
          const unit = match[2].trim().toLowerCase();
          const standardUnit = standardizeUnit(unit);
          const { name, notes } = extractNotesFromIngredient(match[3]);
          
          return {
            amount: amount,
            unit: standardUnit,
            name: name,
            notes: notes
          };
        } else if (i === 1) {
          // Fractional descriptors: "half a large onion"
          let amount = parseFractionalDescriptor(match[1]);
          const sizeUnit = match[2] ? standardizeUnit(match[2].trim().toLowerCase()) : 'medium';
          const { name, notes } = extractNotesFromIngredient(match[3]);
          
          return {
            amount: amount,
            unit: sizeUnit,
            name: name,
            notes: notes
          };
        } else {
          // Regular amount + unit + ingredient
          let amount = parseFraction(match[1]);
          const unit = match[2].trim().toLowerCase();
          const standardUnit = standardizeUnit(unit);
          const { name, notes } = extractNotesFromIngredient(match[3]);
          
          return {
            amount: amount,
            unit: standardUnit,
            name: name,
            notes: notes
          };
        }
      } else if (match.length === 3) {
        if (i === 1) {
          // Fractional descriptors without size: "half an onion"
          let amount = parseFractionalDescriptor(match[1]);
          const { name, notes } = extractNotesFromIngredient(match[2]);
          
          return {
            amount: amount,
            unit: 'medium',
            name: name,
            notes: notes
          };
        } else if (i === 7) {
          // Fractional pattern: "½ cup flour"
          let amount = parseFraction(match[1]);
          const unit = standardizeUnit(match[2].trim().toLowerCase());
          const { name, notes } = extractNotesFromIngredient(match[3]);
          
          return {
            amount: amount,
            unit: unit,
            name: name,
            notes: notes
          };
        } else {
          // amount + ingredient (no unit)
          const amount = parseFloat(match[1]);
          if (!isNaN(amount)) {
            const { name, notes } = extractNotesFromIngredient(match[2]);
            return {
              amount: amount,
              unit: 'piece',
              name: name,
              notes: notes
            };
          }
        }
      }
      
      // Just ingredient name
      const { name, notes } = extractNotesFromIngredient(match[1]);
      return {
        amount: 1,
        unit: 'piece',
        name: name,
        notes: notes
      };
    }
  }

  return null;
}

function parseFraction(fractionStr: string): number {
  const cleanStr = fractionStr.trim();
  
  // Handle Unicode fractions
  const unicodeFractions: Record<string, number> = {
    '½': 0.5,
    '¼': 0.25,
    '¾': 0.75,
    '⅓': 0.333,
    '⅔': 0.667,
    '⅛': 0.125,
    '⅜': 0.375,
    '⅝': 0.625,
    '⅞': 0.875
  };
  
  // Check for pure unicode fraction
  if (unicodeFractions[cleanStr]) {
    return unicodeFractions[cleanStr];
  }
  
  // Handle mixed unicode fractions like "2½"
  const unicodeMixedMatch = cleanStr.match(/(\d+)\s*([½¼¾⅓⅔⅛⅜⅝⅞])/);
  if (unicodeMixedMatch) {
    const whole = parseInt(unicodeMixedMatch[1]);
    const fraction = unicodeFractions[unicodeMixedMatch[2]];
    return whole + fraction;
  }
  
  // Handle mixed fractions like "2 1/2" or "2½"
  const mixedMatch = cleanStr.match(/(\d+)\s+(\d+)\/(\d+)/);
  if (mixedMatch) {
    const whole = parseInt(mixedMatch[1]);
    const numerator = parseInt(mixedMatch[2]);
    const denominator = parseInt(mixedMatch[3]);
    return whole + (numerator / denominator);
  }
  
  // Handle simple fractions like "1/2"
  const simpleMatch = cleanStr.match(/(\d+)\/(\d+)/);
  if (simpleMatch) {
    const numerator = parseInt(simpleMatch[1]);
    const denominator = parseInt(simpleMatch[2]);
    return numerator / denominator;
  }
  
  // Handle decimal numbers
  const numberMatch = cleanStr.match(/(\d+(?:\.\d+)?)/);
  if (numberMatch) {
    return parseFloat(numberMatch[1]);
  }
  
  return 1; // Default fallback
}

function parseRange(rangeStr: string): number {
  const cleanStr = rangeStr.trim();
  
  // Handle range patterns like "2-3", "1 to 2", "2.5-4"
  const rangeMatch = cleanStr.match(/(\d+(?:\.\d+)?)\s*(?:to|-)\s*(\d+(?:\.\d+)?)/);
  if (rangeMatch) {
    const min = parseFloat(rangeMatch[1]);
    const max = parseFloat(rangeMatch[2]);
    return (min + max) / 2; // Return middle of range
  }
  
  // Fallback to regular number parsing
  return parseFloat(cleanStr) || 1;
}

function parseFractionalDescriptor(descriptor: string): number {
  const cleanDescriptor = descriptor.toLowerCase().trim();
  
  const fractionMap: Record<string, number> = {
    'half': 0.5,
    'quarter': 0.25,
    'third': 0.333
  };
  
  return fractionMap[cleanDescriptor] || 1;
}

function standardizeUnit(unit: string): string {
  const unitMap: Record<string, string> = {
    // Weight units
    'grams': 'g', 'gram': 'g',
    'kilograms': 'kg', 'kilogram': 'kg', 'kgs': 'kg',
    'ounces': 'oz', 'ounce': 'oz', 'ozs': 'oz',
    'pounds': 'lb', 'pound': 'lb', 'lbs': 'lb',
    
    // Volume units  
    'milliliters': 'ml', 'milliliter': 'ml', 'mls': 'ml',
    'liters': 'l', 'liter': 'l', 'litres': 'l', 'litre': 'l',
    'cups': 'cup', 'c': 'cup',
    'tablespoons': 'tbsp', 'tablespoon': 'tbsp', 'tbs': 'tbsp', 'T': 'tbsp',
    'teaspoons': 'tsp', 'teaspoon': 'tsp', 'ts': 'tsp', 't': 'tsp',
    'fluid ounces': 'fl oz', 'fluid ounce': 'fl oz', 'floz': 'fl oz',
    'pints': 'pint', 'pt': 'pint',
    'quarts': 'quart', 'qt': 'quart',
    'gallons': 'gallon', 'gal': 'gallon',
    
    // Count units
    'pieces': 'piece', 'pcs': 'piece', 'pc': 'piece',
    'cloves': 'clove',
    'items': 'each', 'item': 'each',
    'wholes': 'whole',
    
    // Size descriptors
    'large': 'large',
    'medium': 'medium', 'med': 'medium',
    'small': 'small', 'sm': 'small',
    
    // Package units
    'cans': 'can', 'tins': 'tin', 'tin': 'can',
    'packages': 'package', 'pkg': 'package', 'pack': 'package',
    'bunches': 'bunch',
    'heads': 'head'
  };
  
  const cleaned = unit.toLowerCase().trim();
  return unitMap[cleaned] || cleaned;
}

function findBestIngredientMatch(ingredientName: string, existingIngredients: any[]) {
  const cleanName = ingredientName.toLowerCase().trim();
  
  // Exact match
  let match = existingIngredients.find(ing => 
    ing.name.toLowerCase() === cleanName
  );
  
  if (match) return match;
  
  // Partial match - ingredient name contains existing ingredient
  match = existingIngredients.find(ing => 
    cleanName.includes(ing.name.toLowerCase()) || 
    ing.name.toLowerCase().includes(cleanName)
  );
  
  if (match) return match;
  
  // Fuzzy matching for common variations
  const variations: Record<string, string> = {
    'onions': 'onion',
    'tomatoes': 'tomato', 
    'potatoes': 'potato',
    'carrots': 'carrot',
    'eggs': 'egg',
    'mushrooms': 'mushroom'
  };
  
  const variation = variations[cleanName];
  if (variation) {
    match = existingIngredients.find(ing => 
      ing.name.toLowerCase() === variation
    );
  }
  
  return match;
}

function standardizeIngredientName(name: string): string {
  let clean = name.toLowerCase().trim();
  
  // Remove common qualifiers that don't affect ingredient identity
  const qualifiersToRemove = [
    'fresh', 'dried', 'frozen', 'canned', 'tinned', 'organic', 'free-range',
    'grass-fed', 'wild-caught', 'raw', 'cooked', 'prepared', 'store-bought',
    'homemade', 'unsalted', 'salted', 'plain', 'whole', 'skim', 'low-fat'
  ];
  
  for (const qualifier of qualifiersToRemove) {
    clean = clean.replace(new RegExp(`\\b${qualifier}\\b`, 'g'), '').trim();
  }
  
  // Standardize common ingredient names
  const nameMap: Record<string, string> = {
    // Proteins
    'chicken breast': 'chicken breast',
    'chicken thigh': 'chicken thigh', 
    'beef chuck': 'beef chuck',
    'ground beef': 'ground beef',
    'pork shoulder': 'pork shoulder',
    
    // Vegetables
    'yellow onion': 'onion',
    'white onion': 'onion',
    'red onion': 'red onion',
    'spanish onion': 'onion',
    'brown onion': 'onion',
    
    // Tomatoes
    'plum tomato': 'tomato',
    'roma tomato': 'tomato',
    'cherry tomato': 'cherry tomato',
    'grape tomato': 'cherry tomato',
    
    // Common plurals to singular
    'tomatoes': 'tomato',
    'onions': 'onion',
    'carrots': 'carrot',
    'potatoes': 'potato',
    'peppers': 'bell pepper',
    'mushrooms': 'mushroom',
    'eggs': 'egg',
    
    // Oils and fats
    'olive oil': 'olive oil',
    'vegetable oil': 'vegetable oil',
    'coconut oil': 'coconut oil',
    'butter': 'butter',
    
    // Herbs and spices
    'black pepper': 'black pepper',
    'sea salt': 'salt',
    'table salt': 'salt',
    'kosher salt': 'salt',
    'ground cumin': 'cumin',
    'ground coriander': 'coriander'
  };
  
  // Check for exact mapping
  if (nameMap[clean]) {
    clean = nameMap[clean];
  }
  
  // Clean up extra spaces
  clean = clean.replace(/\s+/g, ' ').trim();
  
  // Capitalize first letter
  return clean.charAt(0).toUpperCase() + clean.slice(1);
}

function extractNotesFromIngredient(ingredientText: string): { name: string, notes: string | null } {
  // Extract parenthetical notes and preparation instructions
  const parenMatch = ingredientText.match(/^([^,(]+)(?:[,(]\s*(.+))?$/);
  
  if (parenMatch) {
    const name = parenMatch[1].trim();
    const notes = parenMatch[2] ? parenMatch[2].replace(/[)]/g, '').trim() : null;
    return { name, notes };
  }
  
  return { name: ingredientText.trim(), notes: null };
}

function parseDuration(duration: string): number {
  if (!duration) return 0;
  
  // Parse ISO 8601 duration (PT15M) or simple formats
  if (duration.startsWith('PT')) {
    const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?/);
    if (match) {
      const hours = parseInt(match[1]) || 0;
      const minutes = parseInt(match[2]) || 0;
      return hours * 60 + minutes;
    }
  }
  
  // Parse simple formats like "15 minutes", "1 hour 30 minutes"
  const hourMatch = duration.match(/(\d+)\s*(?:hour|hr)/i);
  const minuteMatch = duration.match(/(\d+)\s*(?:minute|min)/i);
  
  const hours = hourMatch ? parseInt(hourMatch[1]) : 0;
  const minutes = minuteMatch ? parseInt(minuteMatch[1]) : 0;
  
  return hours * 60 + minutes;
}

function enhanceRecipeData(recipeData: any, sourceUrl: string): any {
  // Convert ingredients to weights and detect sub-recipes
  const { mainIngredients, subRecipes } = detectAndSeparateSubRecipes(recipeData.ingredients || []);

  // Calculate timing multipliers for scaling
  const timingProfile = calculateTimingProfile(recipeData.prep_time_minutes, recipeData.hands_on_minutes);

  // Add source URL to notes if not already present
  const notes = recipeData.notes || '';
  const enhancedNotes = notes.includes(sourceUrl) ? notes : `${notes}\nSource: ${sourceUrl}`.trim();

  return {
    ...recipeData,
    ingredients: mainIngredients,
    subRecipes: subRecipes,
    timingProfile: timingProfile,
    notes: enhancedNotes,
    sourceUrl: sourceUrl
  };
}

function detectAndSeparateSubRecipes(ingredients: any[]): { mainIngredients: any[], subRecipes: any[] } {
  const subRecipeKeywords = [
    'paste', 'sauce', 'marinade', 'dressing', 'stock', 'broth', 'curry paste',
    'masala', 'mixture', 'blend', 'base', 'roux', 'garnish', 'vinaigrette',
    'pesto', 'chimichurri', 'salsa', 'chutney', 'relish', 'compote',
    'reduction', 'glaze', 'emulsion', 'foam', 'gel', 'puree'
  ];

  const preparationWords = [
    'homemade', 'fresh', 'prepared', 'made', 'house-made', 'from scratch'
  ];

  const subRecipes: any[] = [];
  const mainIngredients: any[] = [];

  ingredients.forEach(ingredient => {
    const name = ingredient.ingredient_name?.toLowerCase() || '';
    const notes = ingredient.notes?.toLowerCase() || '';
    const fullText = `${name} ${notes}`.toLowerCase();
    
    // Check if it's marked as sub-recipe by AI or matches patterns
    const isSubRecipe = ingredient.is_sub_recipe || 
      subRecipeKeywords.some(keyword => name.includes(keyword)) ||
      (preparationWords.some(word => fullText.includes(word)) && 
       subRecipeKeywords.some(keyword => fullText.includes(keyword)));

    if (isSubRecipe && !name.includes('store-bought') && !name.includes('ready-made')) {
      // Create a sub-recipe with estimated components
      const subRecipeComponents = estimateSubRecipeComponents(ingredient.ingredient_name);
      
      subRecipes.push({
        name: ingredient.ingredient_name,
        description: `Homemade ${ingredient.ingredient_name.toLowerCase()}`,
        yield_amount: ingredient.amount || 1,
        yield_unit: ingredient.unit || 'portion',
        is_subrecipe: true,
        station: 'prep',
        estimated_prep_time: estimateSubRecipeTime(ingredient.ingredient_name),
        ingredients: subRecipeComponents,
        steps: generateSubRecipeSteps(ingredient.ingredient_name, subRecipeComponents),
        notes: `Component for main recipe. ${ingredient.notes || ''}`
      });

      // Add reference to sub-recipe in main ingredients
      mainIngredients.push({
        ...ingredient,
        is_subrecipe_reference: true,
        subrecipe_name: ingredient.ingredient_name
      });
    } else {
      mainIngredients.push(ingredient);
    }
  });

  return { mainIngredients, subRecipes };
}

function estimateSubRecipeComponents(subRecipeName: string): any[] {
  const name = subRecipeName.toLowerCase();
  
  // Common sub-recipe component patterns
  const componentMap: Record<string, any[]> = {
    'curry paste': [
      { ingredient_name: 'dried chilies', amount: 6, unit: 'piece', notes: 'soaked and deseeded' },
      { ingredient_name: 'garlic', amount: 4, unit: 'clove', notes: 'peeled' },
      { ingredient_name: 'shallots', amount: 2, unit: 'piece', notes: 'peeled' },
      { ingredient_name: 'ginger', amount: 1, unit: 'inch', notes: 'fresh, peeled' },
      { ingredient_name: 'lemongrass', amount: 2, unit: 'stalk', notes: 'tender parts only' }
    ],
    'marinara sauce': [
      { ingredient_name: 'tomatoes', amount: 2, unit: 'lb', notes: 'crushed or whole peeled' },
      { ingredient_name: 'garlic', amount: 4, unit: 'clove', notes: 'minced' },
      { ingredient_name: 'onion', amount: 1, unit: 'medium', notes: 'diced' },
      { ingredient_name: 'olive oil', amount: 2, unit: 'tbsp', notes: 'extra virgin' },
      { ingredient_name: 'basil', amount: 0.25, unit: 'cup', notes: 'fresh leaves' }
    ],
    'pesto': [
      { ingredient_name: 'basil', amount: 2, unit: 'cup', notes: 'fresh leaves' },
      { ingredient_name: 'pine nuts', amount: 0.5, unit: 'cup', notes: 'toasted' },
      { ingredient_name: 'parmesan cheese', amount: 0.5, unit: 'cup', notes: 'grated' },
      { ingredient_name: 'garlic', amount: 2, unit: 'clove', notes: 'peeled' },
      { ingredient_name: 'olive oil', amount: 0.5, unit: 'cup', notes: 'extra virgin' }
    ]
  };

  // Find matching pattern
  for (const [pattern, components] of Object.entries(componentMap)) {
    if (name.includes(pattern)) {
      return components;
    }
  }

  // Generic fallback components
  return [
    { ingredient_name: 'base ingredients', amount: 1, unit: 'portion', notes: 'as needed' }
  ];
}

function estimateSubRecipeTime(subRecipeName: string): number {
  const name = subRecipeName.toLowerCase();
  
  const timeMap: Record<string, number> = {
    'paste': 15,
    'sauce': 30,
    'marinade': 10,
    'dressing': 5,
    'stock': 180,
    'broth': 60,
    'pesto': 10,
    'salsa': 15,
    'vinaigrette': 5
  };

  for (const [pattern, time] of Object.entries(timeMap)) {
    if (name.includes(pattern)) {
      return time;
    }
  }

  return 20; // Default estimate
}

function generateSubRecipeSteps(subRecipeName: string, _components: any[]): any[] {
  const name = subRecipeName.toLowerCase();
  
  if (name.includes('paste')) {
    return [
      { step_number: 1, instruction: 'Prepare all ingredients by cleaning, peeling, and roughly chopping as needed.' },
      { step_number: 2, instruction: 'In a food processor or mortar and pestle, blend all ingredients until a smooth paste forms.' },
      { step_number: 3, instruction: 'Adjust seasoning and consistency as needed. Store covered in refrigerator.' }
    ];
  }
  
  if (name.includes('sauce')) {
    return [
      { step_number: 1, instruction: 'Heat oil in a saucepan over medium heat.' },
      { step_number: 2, instruction: 'Add aromatics and cook until fragrant.' },
      { step_number: 3, instruction: 'Add remaining ingredients and simmer until desired consistency.' },
      { step_number: 4, instruction: 'Season to taste and strain if needed.' }
    ];
  }
  
  if (name.includes('marinade') || name.includes('dressing')) {
    return [
      { step_number: 1, instruction: 'Combine all ingredients in a bowl.' },
      { step_number: 2, instruction: 'Whisk until well combined and emulsified.' },
      { step_number: 3, instruction: 'Taste and adjust seasoning as needed.' }
    ];
  }

  // Generic steps
  return [
    { step_number: 1, instruction: `Prepare all ingredients for the ${subRecipeName}.` },
    { step_number: 2, instruction: `Combine and process ingredients according to traditional methods.` },
    { step_number: 3, instruction: `Adjust seasoning and consistency to taste.` }
  ];
}

function extractCookingSteps(steps: any[]): any[] {
  const cookingSteps: any[] = [];
  
  console.log("Extracting cooking steps from:", steps.length, "parsed steps");
  
  steps.forEach((step: any, index: number) => {
    console.log(`Step ${index + 1} raw data:`, JSON.stringify(step, null, 2));
    
    // Check what cooking details we have
    const hasEquipment = step.equipment && step.equipment.trim();
    const hasMethod = step.cooking_method && step.cooking_method.trim();
    const hasTemperature = step.temperature && step.temperature.trim();
    const hasTime = step.cooking_time && step.cooking_time.trim();
    
    console.log(`Step ${index + 1} cooking details:`, {
      hasEquipment,
      hasMethod, 
      hasTemperature,
      hasTime,
      equipment: step.equipment,
      method: step.cooking_method,
      temperature: step.temperature,
      time: step.cooking_time
    });
    
    // Extract steps that have ANY cooking details - be more permissive
    if (hasEquipment || hasMethod || hasTemperature || hasTime) {
      // Parse equipment - handle multiple equipment mentions
      let equipment = '';
      if (step.equipment) {
        const equipmentList = step.equipment.split(',').map((eq: string) => eq.trim().toLowerCase());
        // Take the primary equipment (first one, or most specific)
        equipment = equipmentList[0] || '';
        // Clean up equipment names
        equipment = equipment.replace(/with lid|covered|uncovered/g, '').trim();
        if (equipment.includes('skillet') || equipment.includes('pan')) equipment = 'pan';
        else if (equipment.includes('pot') || equipment.includes('saucepan')) equipment = 'pot';
        else if (equipment.includes('oven')) equipment = 'oven';
        else if (equipment.includes('stove')) equipment = 'stove';
        else if (equipment.includes('grill')) equipment = 'grill';
        else equipment = equipment || 'stove'; // Default fallback
      }
      
      // Parse cooking method
      let method = step.cooking_method || '';
      if (method) {
        method = method.toLowerCase().trim();
        // Standardize common methods
        const methodMap: Record<string, string> = {
          'cook': 'simmer',
          'heat': 'heat',
          'fry': 'fry',
          'sauté': 'sauté',
          'saute': 'sauté',
          'simmer': 'simmer',
          'boil': 'boil',
          'bake': 'bake',
          'roast': 'roast',
          'grill': 'grill',
          'steam': 'steam',
          'braise': 'braise'
        };
        method = methodMap[method] || method;
      }
      
      // Parse temperature
      let temperature = step.temperature || '';
      if (temperature) {
        temperature = temperature.trim();
        // Standardize temperature formats
        if (temperature.includes('°')) {
          // Keep temperature as is if it has degrees
        } else if (temperature.includes('high')) {
          temperature = 'high heat';
        } else if (temperature.includes('medium')) {
          temperature = 'medium heat';
        } else if (temperature.includes('low')) {
          temperature = 'low heat';
        }
      }
      
      // Parse duration - convert to standard format
      let duration = step.cooking_time || '';
      if (duration) {
        duration = duration.trim();
        // The AI should already be providing in the correct format (5', 1'30', etc.)
        // But let's clean up any inconsistencies
        duration = duration.replace(/minutes?/i, "'").replace(/hours?/i, "'").replace(/mins?/i, "'");
      }
      
      // Create notes from additional context
      let notes = '';
      if (step.instruction) {
        // Extract notes from instruction context
        if (step.instruction.toLowerCase().includes('covered')) notes += 'covered ';
        if (step.instruction.toLowerCase().includes('uncovered')) notes += 'uncovered ';
        if (step.instruction.toLowerCase().includes('with lid')) notes += 'with lid ';
        if (step.instruction.toLowerCase().includes('stirring')) notes += 'stirring occasionally ';
        if (step.instruction.toLowerCase().includes('until golden')) notes += 'until golden ';
        if (step.instruction.toLowerCase().includes('until tender')) notes += 'until tender ';
      }
      notes = notes.trim();
      
      // Detect process name from instruction context
      let processName = step.process || '';
      if (!processName && step.instruction) {
        const instructionLower = step.instruction.toLowerCase();
        if (instructionLower.includes('bolognese') || instructionLower.includes('meat sauce')) processName = 'bolognese';
        else if (instructionLower.includes('bechamel') || instructionLower.includes('white sauce')) processName = 'bechamel';
        else if (instructionLower.includes('assembly') || instructionLower.includes('layer')) processName = 'assembly';
        else if (instructionLower.includes('sauce') && !instructionLower.includes('meat')) processName = 'sauce preparation';
        else if (instructionLower.includes('meanwhile') || instructionLower.includes('separate')) processName = 'parallel process';
      }

      // Determine if parallel capable
      let timing = step.parallel_capable || 'sequential';
      if (step.instruction) {
        const instructionLower = step.instruction.toLowerCase();
        if (instructionLower.includes('meanwhile') || instructionLower.includes('at the same time') || 
            instructionLower.includes('while') || instructionLower.includes('separate')) {
          timing = 'parallel';
        }
      }

      // Create cooking step with better defaults
      const cookingStep = {
        equipment: equipment || (method ? inferEquipmentFromMethod(method) : 'stove'),
        method: method || (equipment ? inferMethodFromEquipment(equipment) : 'prep'),
        temperature: temperature || '',
        duration: duration || '',
        notes: notes || '',
        process: processName || '',
        timing: timing
      };
      
      console.log("Adding cooking step:", cookingStep);
      cookingSteps.push(cookingStep);
    } else {
      console.log(`Step ${index + 1} skipped - no cooking details found`);
    }
  });
  
  console.log("Final cooking steps:", cookingSteps);
  
  // If we don't have any cooking steps but we have instructions, try to create at least one basic step
  if (cookingSteps.length === 0 && steps.length > 0) {
    console.log("No cooking steps extracted, attempting to create basic steps from instructions");
    
    // Look for cooking-related instructions
    for (const step of steps) {
      const instruction = step.instruction?.toLowerCase() || '';
      let equipment = '';
      let method = '';
      let temperature = '';
      let duration = '';
      
      console.log(`Analyzing instruction for cooking patterns: "${instruction}"`);
      
      // Enhanced pattern matching for complex cooking instructions
      if (instruction.includes('oven') || instruction.includes('bake')) {
        equipment = 'oven';
        method = 'bake';
        const tempMatch = instruction.match(/(\d+)°?[fc]?/i);
        if (tempMatch) temperature = tempMatch[0] + (tempMatch[0].includes('°') ? '' : '°F');
        const timeMatch = instruction.match(/(\d+)(?:\s*(?:minute|min|hour|hr))/i);
        if (timeMatch) duration = timeMatch[1] + "'";
      } else if (instruction.includes('pan') || instruction.includes('skillet') || instruction.includes('fry') || instruction.includes('sauté')) {
        equipment = 'pan';
        method = instruction.includes('fry') ? 'fry' : 'sauté';
        if (instruction.includes('medium')) temperature = 'medium heat';
        else if (instruction.includes('high')) temperature = 'high heat';
        else if (instruction.includes('low')) temperature = 'low heat';
        const timeMatch = instruction.match(/(\d+)(?:\s*(?:minute|min))/i);
        if (timeMatch) duration = timeMatch[1] + "'";
      } else if (instruction.includes('simmer') || instruction.includes('boil')) {
        equipment = 'pot';
        method = instruction.includes('boil') ? 'boil' : 'simmer';
        
        // Enhanced time extraction for complex ranges
        const timeMatch = instruction.match(/(\d+)(?:\s*-\s*(\d+)(?:\s*1\/2)?)?\s*(?:hour|hr|minute|min)/i);
        if (timeMatch) {
          if (timeMatch[2]) {
            // Handle ranges like "2 - 2 1/2 hours"
            let maxTime = parseInt(timeMatch[2]);
            if (instruction.includes('1/2')) maxTime += 0.5;
            
            if (instruction.includes('hour')) {
              duration = Math.floor(maxTime) + "'" + String(Math.round((maxTime % 1) * 60)).padStart(2, '0') + "'";
            } else {
              duration = maxTime + "'";
            }
          } else {
            // Single time value
            let time = parseInt(timeMatch[1]);
            if (instruction.includes('hour')) {
              duration = time * 60 + "'";
            } else {
              duration = time + "'";
            }
          }
        }
        
        // Temperature detection
        if (instruction.includes('gently') || instruction.includes('gentle')) {
          temperature = 'low heat';
        } else if (instruction.includes('medium')) {
          temperature = 'medium heat';
        } else if (instruction.includes('high')) {
          temperature = 'high heat';
        }
        
        // Check for indicators of braising/stewing (submerged cooking)
        if (instruction.includes('submerged') || instruction.includes('covered')) {
          method = 'braise';
        }
      } else if (instruction.includes('grill')) {
        equipment = 'grill';
        method = 'grill';
        if (instruction.includes('medium')) temperature = 'medium heat';
        else if (instruction.includes('high')) temperature = 'high heat';
        const timeMatch = instruction.match(/(\d+)(?:\s*(?:minute|min))/i);
        if (timeMatch) duration = timeMatch[1] + "'";
      }
      
      if (equipment && method) {
        // Enhanced process detection for fallback
        let processName = '';
        if (instruction.includes('bolognese') || instruction.includes('meat sauce')) processName = 'bolognese';
        else if (instruction.includes('bechamel') || instruction.includes('white sauce')) processName = 'bechamel';
        else if (instruction.includes('assembly') || instruction.includes('layer')) processName = 'assembly';
        else if (instruction.includes('sauce') && !instruction.includes('meat')) processName = 'sauce preparation';
        else if (instruction.includes('meanwhile') || instruction.includes('separate')) processName = 'parallel process';

        let timing = 'sequential';
        if (instruction.includes('meanwhile') || instruction.includes('at the same time') || 
            instruction.includes('while') || instruction.includes('separate')) {
          timing = 'parallel';
        }

        const fallbackStep = {
          equipment,
          method,
          temperature,
          duration,
          notes: '',
          process: processName,
          timing: timing
        };
        console.log("Created fallback cooking step:", fallbackStep);
        cookingSteps.push(fallbackStep);
      } else {
        console.log("No cooking patterns detected in this instruction");
      }
    }
  }
  
  return cookingSteps;
}

// Helper functions for inferring equipment and methods
function inferEquipmentFromMethod(method: string): string {
  const methodMap: Record<string, string> = {
    'bake': 'oven',
    'roast': 'oven', 
    'broil': 'oven',
    'sauté': 'pan',
    'fry': 'pan',
    'sear': 'pan',
    'boil': 'pot',
    'simmer': 'pot',
    'steam': 'steamer',
    'grill': 'grill',
    'poach': 'pot'
  };
  return methodMap[method.toLowerCase()] || 'stove';
}

function inferMethodFromEquipment(equipment: string): string {
  const equipmentMap: Record<string, string> = {
    'oven': 'bake',
    'pan': 'sauté',
    'skillet': 'sauté',
    'pot': 'simmer',
    'grill': 'grill',
    'steamer': 'steam'
  };
  return equipmentMap[equipment.toLowerCase()] || 'cook';
}

// Enhanced comprehensive AI parsing that leverages database context
async function parseCompleteRecipeWithAI(recipeContent: any, env: Env): Promise<any> {
  if (!env.OPENAI_API_KEY) {
    console.warn("OpenAI API key not available, falling back to manual parsing");
    throw new Error("OpenAI API key not available");
  }

  // Fetch existing ingredients for context
  let existingIngredients: any[] = [];
  try {
    const dbIngredients = await env.DB.prepare(`
      SELECT name, unit_type, grams_per_piece 
      FROM ingredients 
      ORDER BY name ASC 
      LIMIT 200
    `).all();
    existingIngredients = dbIngredients.results as any[];
  } catch (error) {
    console.warn("Failed to fetch ingredients for AI context:", error);
  }

  const openai = new OpenAI({
    apiKey: env.OPENAI_API_KEY,
  });

  const databaseContext = existingIngredients.length > 0 
    ? `\n\n**EXISTING INGREDIENTS DATABASE (prioritize matching these names exactly):**\n${existingIngredients.slice(0, 50).map(ing => 
        `- ${ing.name} (${ing.unit_type}${ing.grams_per_piece ? `, ${ing.grams_per_piece}g/piece` : ''})`
      ).join('\n')}`
    : '';

  const enhancedPrompt = `${ENHANCED_RECIPE_PARSING_PROMPT}${databaseContext}

**INTELLIGENT TAG GENERATION:**
Generate 4-8 relevant tags from these categories, prioritizing accuracy:
- **Course:** main, appetizer, dessert, side, sauce, component
- **Meal:** breakfast, lunch, dinner, snack  
- **Cuisine:** thai, chinese, italian, mexican, indian, mediterranean, french, etc.
- **Protein:** chicken, beef, pork, seafood, vegetable
- **Method:** baked, grilled, fried, curry, etc.
- **Dietary:** vegetarian, vegan, gluten-free, dairy-free
- **Difficulty:** easy, medium, advanced

**CRITICAL:** Avoid wrong categorizations like "dessert" for savory dishes!

Parse this recipe completely:

**Recipe Name:** ${recipeContent.name}
**Description:** ${recipeContent.description}
**Yield:** ${recipeContent.yield}
**Prep Time:** ${recipeContent.prepTime}
**Cook Time:** ${recipeContent.cookTime}
**Category:** ${recipeContent.category}
**Cuisine:** ${recipeContent.cuisine}

**Ingredients:**
${JSON.stringify(recipeContent.ingredients)}

**Instructions:**
${JSON.stringify(recipeContent.instructions)}

Return a complete JSON recipe object with ALL fields properly filled:`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: enhancedPrompt }],
    max_tokens: 4000,
    temperature: 0.1,
  });

  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error("No response from OpenAI");
  }

  try {
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    const jsonString = jsonMatch ? jsonMatch[0] : content;
    const parsedRecipe = JSON.parse(jsonString);
    
    // Validate and enhance the parsed recipe with database context
    return validateAndEnhanceParsedRecipe(parsedRecipe, existingIngredients);
  } catch (parseError) {
    console.error("Failed to parse AI recipe response:", content);
    throw new Error("Failed to parse AI response");
  }
}

function validateAndEnhanceParsedRecipe(recipe: any, existingIngredients: any[] = []): any {
  // Ensure all required fields are present
  const validated = {
    name: recipe.name || 'Imported Recipe',
    description: recipe.description || '',
    yield_amount: recipe.yield_amount || 4,
    yield_unit: recipe.yield_unit || 'servings',
    prep_time_minutes: recipe.prep_time_minutes || 30,
    hands_on_minutes: recipe.hands_on_minutes || 20,
    station: recipe.station || 'prep',
    ingredients: recipe.ingredients || [],
    steps: recipe.steps || [],
    cookingSteps: recipe.cookingSteps || [],
    tags: recipe.tags || ['main'],
    notes: recipe.notes || ''
  };

  // Validate and convert ingredients with database matching
  validated.ingredients = validated.ingredients.map((ing: any, index: number) => {
    // Ensure ingredient has valid data
    if (!ing.ingredient_name || !ing.amount || !ing.unit) {
      console.warn(`Invalid ingredient at index ${index}:`, ing);
      return null;
    }

    // Try to match against existing database ingredients
    const matchedIngredient = findBestIngredientMatch(ing.ingredient_name, existingIngredients);
    const finalIngredientName = matchedIngredient ? matchedIngredient.name : standardizeIngredientName(ing.ingredient_name);
    const gramsPerPiece = matchedIngredient?.grams_per_piece || null;

    // Ensure amount is numeric
    const numericAmount = typeof ing.amount === 'string' ? parseFloat(ing.amount) : ing.amount;
    if (isNaN(numericAmount) || numericAmount <= 0) {
      console.warn(`Invalid amount for ingredient ${ing.ingredient_name}:`, ing.amount);
      return null;
    }

    // Standardize unit
    const standardUnit = standardizeUnit(ing.unit);

    // Calculate weight with database context
    const weightResult = convertToWeight(
      numericAmount,
      standardUnit,
      finalIngredientName,
      gramsPerPiece
    );
    
    return {
      ingredient_name: finalIngredientName,
      amount: numericAmount,
      unit: standardUnit,
      notes: ing.notes || null,
      weight_grams: weightResult.weight_grams,
      is_sub_recipe: ing.is_sub_recipe || false,
      ingredient_id: matchedIngredient?.id || undefined,
      grams_per_piece: gramsPerPiece,
      order: index + 1
    };
  }).filter(Boolean); // Remove any null entries

  // Validate steps
  validated.steps = validated.steps.map((step: any, index: number) => ({
    step_number: index + 1,
    instruction: String(step.instruction || step).trim()
  })).filter((step: any) => step.instruction.length > 0);

  // Validate cooking steps
  validated.cookingSteps = (validated.cookingSteps || []).map((step: any) => ({
    equipment: String(step.equipment || '').trim(),
    method: String(step.method || '').trim(),
    temperature: step.temperature ? String(step.temperature).trim() : null,
    duration: step.duration ? String(step.duration).trim() : null,
    notes: step.notes ? String(step.notes).trim() : null
  })).filter((step: any) => step.equipment && step.method);

  // Ensure tags are strings
  validated.tags = (validated.tags || []).map((tag: any) => String(tag).toLowerCase().trim()).filter(Boolean);

  return validated;
}

function estimateTimeFromIngredients(ingredients: any[]): number {
  if (!ingredients || ingredients.length === 0) return 30;
  
  // Base time + time per ingredient
  const baseTime = 15;
  const timePerIngredient = 3;
  const complexityBonus = ingredients.length > 10 ? 15 : 0;
  
  return Math.min(baseTime + (ingredients.length * timePerIngredient) + complexityBonus, 90);
}

function estimateTimeFromInstructions(instructions: any[]): number {
  if (!instructions || instructions.length === 0) return 20;
  
  let totalTime = 0;
  
  instructions.forEach((instruction: any) => {
    const text = (instruction.text || instruction.name || instruction).toLowerCase();
    
    // Look for time indicators
    if (text.includes('hour')) totalTime += 60;
    else if (text.includes('30') && text.includes('min')) totalTime += 30;
    else if (text.includes('15') && text.includes('min')) totalTime += 15;
    else if (text.includes('bake') || text.includes('roast')) totalTime += 25;
    else if (text.includes('simmer') || text.includes('cook')) totalTime += 15;
    else if (text.includes('fry') || text.includes('sauté')) totalTime += 8;
    else if (text.includes('mix') || text.includes('combine')) totalTime += 3;
    else totalTime += 5; // Default per step
  });
  
  return Math.max(totalTime, 10);
}

// AI-powered tag generation using existing tag structure
async function generateRecipeTagsWithAI(name: string, description: string, ingredients: any[], recipe: any, env: Env): Promise<string[]> {
  if (!env.OPENAI_API_KEY) {
    console.warn("OpenAI API key not available, using fallback tag generation");
    return generateRecipeTagsFallback(name, description, ingredients, recipe);
  }

  const openai = new OpenAI({
    apiKey: env.OPENAI_API_KEY,
  });

  const ingredientList = ingredients.map(ing => ing.ingredient_name).join(', ');
  const cuisine = recipe.recipeCuisine || '';
  const category = recipe.recipeCategory || '';

  const tagGenerationPrompt = `You are a professional chef and culinary expert analyzing a recipe for a restaurant kitchen management system. Generate appropriate tags based on the recipe content and existing tag categories.

**RECIPE TO ANALYZE:**
Name: "${name}"
Description: "${description}"
Cuisine: "${cuisine}"
Category: "${category}" 
Key Ingredients: ${ingredientList}

**EXISTING TAG CATEGORIES (use these as your primary options):**
**Course Types:** main, appetizer, dessert, side, sauce, component
**Meal Times:** breakfast, lunch, dinner, snack
**Dietary:** vegetarian, vegan, gluten-free, dairy-free
**Difficulty:** quick, easy, advanced, make-ahead
**Cuisines:** italian, asian, mexican, indian, mediterranean, french, thai, chinese, japanese, korean
**Proteins:** chicken, beef, pork, seafood, vegetable, lamb, turkey
**Cooking Methods:** baked, grilled, fried, slow-cooked, raw, steamed, sautéed, roasted
**Characteristics:** hot, cold, spicy, sweet, savory, comfort, healthy, rich

**CRITICAL RULES:**
1. **MEAL TYPE ACCURACY:** Be very careful with course classification
   - "Thai Massaman" = main dish, NOT dessert
   - "Chicken Curry" = main, dinner, NOT appetizer
   - Only tag as "dessert" if it's actually a sweet dish served after meals
   
2. **CUISINE ACCURACY:** 
   - Use specific cuisine tags when clear: "thai" for Thai dishes, "italian" for pasta/pizza
   - "asian" only as fallback for unclear Asian cuisines
   
3. **PROTEIN DETECTION:** Tag main protein ingredients
   - Chicken dishes get "chicken"
   - Vegetable-only dishes get "vegetable" 
   
4. **DIETARY RESTRICTIONS:** Only tag if clearly true
   - "vegetarian" only if no meat/fish
   - "vegan" only if no animal products at all
   
5. **DIFFICULTY:** Base on ingredient count and technique complexity
   - <= 5 ingredients + simple methods = "easy"
   - Complex techniques or many steps = "advanced"

**OUTPUT:** Return a JSON array of 4-8 relevant tags, prioritizing accuracy over quantity.
**EXAMPLE:** ["main", "dinner", "thai", "chicken", "curry", "spicy", "medium"]

Analyze this recipe and return appropriate tags:`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: tagGenerationPrompt }],
      max_tokens: 200,
      temperature: 0.1,
    });

    const content = response.choices[0]?.message?.content?.trim();
    if (content) {
      try {
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        const jsonString = jsonMatch ? jsonMatch[0] : content;
        const aiTags = JSON.parse(jsonString);
        
        if (Array.isArray(aiTags)) {
          return aiTags.map(tag => String(tag).toLowerCase().trim()).filter(Boolean);
        }
      } catch (parseError) {
        console.warn("Failed to parse AI tag response, using fallback:", content);
      }
    }
  } catch (error) {
    console.warn("AI tag generation failed, using fallback:", error);
  }

  return generateRecipeTagsFallback(name, description, ingredients, recipe);
}

function generateRecipeTagsFallback(name: string, description: string, ingredients: any[], _recipe: any): string[] {
  const tags: string[] = [];
  const text = `${name} ${description}`.toLowerCase();
  const ingredientText = ingredients.map(ing => ing.ingredient_name).join(' ').toLowerCase();
  const allText = `${text} ${ingredientText}`;
  
  // Meal type analysis (more careful)
  if (allText.includes('breakfast') || allText.includes('brunch') || allText.includes('morning')) {
    tags.push('breakfast');
  }
  if (allText.includes('lunch') || allText.includes('sandwich') || allText.includes('salad')) {
    tags.push('lunch');
  }
  if (allText.includes('dinner') || allText.includes('supper') || allText.includes('evening')) {
    tags.push('dinner');
  }
  // More careful dessert detection
  if ((allText.includes('dessert') || allText.includes('sweet') || allText.includes('cake') || 
      allText.includes('cookie') || allText.includes('ice cream') || allText.includes('chocolate') ||
      allText.includes('pudding') || allText.includes('tart') || allText.includes('pie')) &&
      !allText.includes('chicken') && !allText.includes('beef') && !allText.includes('curry')) {
    tags.push('dessert');
  }
  if (allText.includes('appetizer') || allText.includes('starter') || allText.includes('hors') ||
      allText.includes('dip') || allText.includes('bruschetta')) {
    tags.push('appetizer');
  }
  if (allText.includes('snack') || allText.includes('bite') || allText.includes('nibble')) {
    tags.push('snack');
  }
  
  // Cuisine detection (more specific)
  const cuisineKeywords = {
    'thai': ['thai', 'massaman', 'pad thai', 'tom yum', 'green curry', 'red curry', 'lemongrass', 'galangal', 'fish sauce'],
    'chinese': ['chinese', 'szechuan', 'stir fry', 'soy sauce', 'oyster sauce', 'five spice', 'wok'],
    'italian': ['italian', 'pasta', 'pizza', 'risotto', 'parmesan', 'basil', 'mozzarella', 'prosciutto'],
    'mexican': ['mexican', 'taco', 'burrito', 'salsa', 'cilantro', 'lime', 'cumin', 'jalapeño'],
    'indian': ['indian', 'curry', 'turmeric', 'garam masala', 'naan', 'basmati', 'cardamom'],
    'mediterranean': ['mediterranean', 'olive oil', 'feta', 'olives', 'oregano', 'lemon', 'hummus'],
    'french': ['french', 'beurre', 'wine', 'shallot', 'thyme', 'gruyere', 'baguette']
  };
  
  for (const [cuisine, keywords] of Object.entries(cuisineKeywords)) {
    const matchCount = keywords.filter(keyword => allText.includes(keyword)).length;
    if (matchCount >= 1) { // Lower threshold for specific cuisines
      tags.push(cuisine);
      break; // Only assign one primary cuisine
    }
  }
  
  // Dietary restrictions (careful detection)
  const meatKeywords = ['chicken', 'beef', 'pork', 'lamb', 'turkey', 'fish', 'salmon', 'shrimp', 'bacon', 'ham'];
  const hasMeat = meatKeywords.some(keyword => allText.includes(keyword));
  
  if (!hasMeat) tags.push('vegetarian');
  
  // Protein identification
  if (allText.includes('chicken')) tags.push('chicken');
  if (allText.includes('beef')) tags.push('beef');
  if (allText.includes('pork')) tags.push('pork');
  if (allText.includes('fish') || allText.includes('salmon') || allText.includes('shrimp')) tags.push('seafood');
  
  // Cooking method analysis
  if (allText.includes('curry')) tags.push('curry');
  if (allText.includes('bake') || allText.includes('oven')) tags.push('baked');
  if (allText.includes('grill')) tags.push('grilled');
  if (allText.includes('fry')) tags.push('fried');
  
  // Difficulty based on ingredient count
  const totalIngredients = ingredients.length;
  if (totalIngredients <= 5) tags.push('easy');
  else if (totalIngredients <= 10) tags.push('medium');
  else tags.push('advanced');
  
  // Default meal type if none detected
  if (!tags.some(tag => ['breakfast', 'lunch', 'dinner', 'appetizer', 'dessert', 'snack'].includes(tag))) {
    tags.push('main');
  }
  
  return [...new Set(tags)]; // Remove duplicates
}

function inferStation(ingredients: any[], steps: any[]): string {
  const text = ingredients.map(ing => ing.ingredient_name).join(' ').toLowerCase();
  const stepText = steps.map(step => step.instruction).join(' ').toLowerCase();
  
  if (stepText.includes('grill') || stepText.includes('barbecue')) return 'grill';
  if (stepText.includes('bake') || stepText.includes('pastry') || text.includes('flour')) return 'pastry';
  if (text.includes('salad') || stepText.includes('raw') || stepText.includes('fresh')) return 'salad';
  if (stepText.includes('sauce') || stepText.includes('reduce') || stepText.includes('simmer')) return 'sauce';
  
  return 'prep';
}

function calculateTimingProfile(prepTime: number | null, handsOnTime: number | null) {
  return {
    base_prep_time: prepTime || 0,
    base_hands_on_time: handsOnTime || 0,
    scaling_factor: {
      prep_multiplier: 0.7, // Prep time scales sublinearly
      hands_on_multiplier: 0.8, // Hands-on time scales more linearly
      setup_overhead: 15, // Fixed setup time regardless of batch size
    }
  };
}

export { app as default };
