import z from "zod";

// Ingredient types
export const IngredientSchema = z.object({
  id: z.number(),
  name: z.string(),
  unit_type: z.enum(['weight', 'volume', 'count']),
  cost_per_unit: z.number().nullable(),
  pack_size: z.number().nullable(),
  supplier: z.string().nullable(),
  grams_per_piece: z.number().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Ingredient = z.infer<typeof IngredientSchema>;

// Recipe types
export const RecipeSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  yield_amount: z.number(),
  yield_unit: z.string(),
  prep_time_minutes: z.number().nullable(),
  hands_on_minutes: z.number().nullable(),
  lead_time_hours: z.number().default(0),
  station: z.string().nullable(),
  notes: z.string().nullable(),
  is_subrecipe: z.boolean().default(false),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Recipe = z.infer<typeof RecipeSchema>;

export const RecipeIngredientSchema = z.object({
  id: z.number(),
  recipe_id: z.number(),
  ingredient_id: z.number().nullable(),
  subrecipe_id: z.number().nullable(),
  amount: z.number(),
  unit: z.string(),
  notes: z.string().nullable(),
  ingredient_order: z.number().default(1),
  created_at: z.string(),
  updated_at: z.string(),
});

export type RecipeIngredient = z.infer<typeof RecipeIngredientSchema>;

export const RecipeStepSchema = z.object({
  id: z.number(),
  recipe_id: z.number(),
  step_number: z.number(),
  instruction: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CookingStepSchema = z.object({
  id: z.number(),
  recipe_id: z.number(),
  step_number: z.number(),
  equipment: z.string(),
  method: z.string(),
  temperature: z.string().nullable(),
  duration: z.string().nullable(),
  notes: z.string().nullable(),
  process: z.string().nullable(),
  timing: z.string().default('sequential'),
  created_at: z.string(),
  updated_at: z.string(),
});

export type RecipeStep = z.infer<typeof RecipeStepSchema>;
export type CookingStep = z.infer<typeof CookingStepSchema>;

// Planning types
export const PlannedMealSchema = z.object({
  id: z.number(),
  date: z.string(),
  meal_type: z.enum(['lunch', 'dinner']),
  recipe_id: z.number(),
  portion_count: z.number(),
  portion_profile: z.string().default('standard'),
  notes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type PlannedMeal = z.infer<typeof PlannedMealSchema>;

export const PortionProfileSchema = z.object({
  id: z.number(),
  name: z.string(),
  lunch_portions: z.number().default(1.0),
  dinner_portions: z.number().default(1.0),
  dessert_factor: z.number().default(1.0),
  created_at: z.string(),
  updated_at: z.string(),
});

export type PortionProfile = z.infer<typeof PortionProfileSchema>;

// Shopping types
export const ShoppingItemSchema = z.object({
  id: z.number(),
  ingredient_id: z.number(),
  amount: z.number(),
  unit: z.string(),
  needed_by_date: z.string(),
  supplier: z.string().nullable(),
  estimated_cost: z.number().nullable(),
  is_ordered: z.boolean().default(false),
  ordered_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type ShoppingItem = z.infer<typeof ShoppingItemSchema>;

// API request/response types
export const CreateRecipeIngredientSchema = z.object({
  ingredient_name: z.string().min(1),
  ingredient_id: z.number().optional(),
  subrecipe_id: z.number().optional(),
  amount: z.number().positive(),
  unit: z.string().min(1),
  notes: z.string().optional(),
  weight_grams: z.number().optional(),
});

export const CreateRecipeSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  yield_amount: z.number().positive(),
  yield_unit: z.string().min(1),
  prep_time_minutes: z.number().optional(),
  hands_on_minutes: z.number().optional(),
  lead_time_hours: z.number().default(0),
  station: z.string().optional(),
  notes: z.string().optional(),
  is_subrecipe: z.boolean().default(false),
  ingredients: z.array(CreateRecipeIngredientSchema),
  steps: z.array(z.object({
    step_number: z.number().positive(),
    instruction: z.string().min(1),
  })),
  cookingSteps: z.array(z.object({
    equipment: z.string().min(1),
    method: z.string().min(1),
    temperature: z.string().optional(),
    duration: z.string().optional(),
    notes: z.string().optional(),
    process: z.string().optional(),
    timing: z.string().optional(),
  })).optional(),
  tags: z.array(z.string()).optional(),
});

export type CreateRecipe = z.infer<typeof CreateRecipeSchema>;
export type CreateRecipeIngredient = z.infer<typeof CreateRecipeIngredientSchema>;

export const CreateIngredientSchema = z.object({
  name: z.string().min(1),
  unit_type: z.enum(['weight', 'volume', 'count']),
  cost_per_unit: z.number().optional(),
  pack_size: z.number().optional(),
  supplier: z.string().optional(),
  grams_per_piece: z.number().optional(),
});

export type CreateIngredient = z.infer<typeof CreateIngredientSchema>;

// Recipe scaling types
export const ScaleRecipeSchema = z.object({
  scaleFactor: z.number().positive(),
});

export type ScaleRecipe = z.infer<typeof ScaleRecipeSchema>;

// Recipe scraping types
export const ScrapeRecipeSchema = z.object({
  url: z.string().url(),
});

export type ScrapeRecipe = z.infer<typeof ScrapeRecipeSchema>;

// Planner types
export const PlannerPlanSchema = z.object({
  id: z.number(),
  week_start_date: z.string(),
  status: z.enum(['draft', 'locked']),
  name: z.string().nullable(),
  notes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const PlannerSlotSchema = z.object({
  id: z.number(),
  plan_id: z.number(),
  day_index: z.number().min(0).max(6),
  slot_label: z.string(),
  notes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const PlannerSlotRecipeSchema = z.object({
  id: z.number(),
  slot_id: z.number(),
  recipe_id: z.number(),
  portions: z.number(),
  notes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
  recipe_name: z.string().optional(),
  yield_amount: z.number().optional(),
  yield_unit: z.string().optional(),
});

export type PlannerPlan = z.infer<typeof PlannerPlanSchema>;
export type PlannerSlot = z.infer<typeof PlannerSlotSchema>;
export type PlannerSlotRecipe = z.infer<typeof PlannerSlotRecipeSchema>;

export const CreatePlanFromWeekSchema = z.object({
  week_start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
  name: z.string().optional(),
  notes: z.string().optional(),
});

export type CreatePlanFromWeek = z.infer<typeof CreatePlanFromWeekSchema>;
