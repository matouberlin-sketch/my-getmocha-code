// Pure functions for BOM math helpers
// All functions are pure and unit testable

export interface UomConversion {
  from_uom: string;
  to_uom: string;
  factor: number;
}

export interface ItemData {
  id: number;
  base_uom: string;
  density_g_per_ml?: number;
  each_to_base?: number;
  conversions: UomConversion[];
}

export interface SupplierPrice {
  price_cents: number;
  pack_size_qty: number;
  pack_size_unit: string;
  preferred: boolean;
}

export interface BomComponent {
  id: number;
  component_type: 'item' | 'subrecipe';
  component_id: number;
  gross_qty: number;
  uom: string;
  trim_loss_pct: number;
  cook_yield_pct: number;
  stage?: string;
  note?: string;
}

export interface RecipeData {
  id: number;
  name: string;
  portion_yield: number;
  bom: BomComponent[];
}

export interface ExplodedComponent {
  item_id: number;
  net_qty: number;
  base_uom: string;
  source_recipe_id?: number;
  source_component_path?: string[];
}

export interface CostBreakdown {
  item_id: number;
  item_name: string;
  qty_base: number;
  uom: string;
  unit_cost_cents: number;
  line_cost_cents: number;
}

/**
 * Convert quantity from one UoM to another for a specific item
 * Uses item-specific conversions, density, or each_to_base ratios
 */
export function convertQty(
  item: ItemData,
  qty: number,
  from_uom: string,
  to_uom: string
): number {
  if (from_uom === to_uom) return qty;

  // Try direct conversion from item_uom table
  const directConversion = item.conversions.find(
    c => c.from_uom === from_uom && c.to_uom === to_uom
  );
  if (directConversion) {
    return qty * directConversion.factor;
  }

  // Try reverse conversion
  const reverseConversion = item.conversions.find(
    c => c.from_uom === to_uom && c.to_uom === from_uom
  );
  if (reverseConversion) {
    return qty / reverseConversion.factor;
  }

  // Try converting through base unit
  const fromToBase = convertToBase(item, qty, from_uom);
  if (fromToBase !== null) {
    const baseToTarget = convertFromBase(item, fromToBase, to_uom);
    if (baseToTarget !== null) {
      return baseToTarget;
    }
  }

  // Try density-based conversion (volume <-> mass)
  if (item.density_g_per_ml) {
    const volumeUnits = ['ml', 'l', 'cup', 'fl_oz', 'pint', 'quart', 'gallon'];
    const massUnits = ['g', 'kg', 'oz', 'lb'];
    
    const fromIsVolume = volumeUnits.includes(from_uom);
    const toIsMass = massUnits.includes(to_uom);
    const fromIsMass = massUnits.includes(from_uom);
    const toIsVolume = volumeUnits.includes(to_uom);
    
    if (fromIsVolume && toIsMass) {
      // Convert volume to mass
      const mlQty = convertVolumeToMl(qty, from_uom);
      const gramQty = mlQty * item.density_g_per_ml;
      return convertMassFromGrams(gramQty, to_uom);
    } else if (fromIsMass && toIsVolume) {
      // Convert mass to volume
      const gramQty = convertMassToGrams(qty, from_uom);
      const mlQty = gramQty / item.density_g_per_ml;
      return convertVolumeFromMl(mlQty, to_uom);
    }
  }

  throw new Error(
    `Cannot convert ${from_uom} to ${to_uom} for item ${item.id}. ` +
    'Missing conversion factor, density, or each_to_base configuration.'
  );
}

/**
 * Calculate net quantity after trim losses and cook yield
 */
export function netQty(
  gross_qty: number,
  trim_loss_pct: number,
  cook_yield_pct: number
): number {
  const afterTrim = gross_qty * (1 - trim_loss_pct / 100);
  const final = afterTrim * (cook_yield_pct / 100);
  return final;
}

/**
 * Recursively explode a recipe into its component items
 * Returns flattened list with aggregated quantities
 */
export function explodeRecipe(
  recipeData: RecipeData,
  neededPortions: number,
  allRecipes: Map<number, RecipeData>,
  allItems: Map<number, ItemData>,
  path: string[] = []
): ExplodedComponent[] {
  const scaleFactor = neededPortions / recipeData.portion_yield;
  const results: ExplodedComponent[] = [];
  
  // Prevent infinite recursion
  if (path.includes(recipeData.id.toString())) {
    throw new Error(`Circular recipe dependency detected: ${path.join(' -> ')} -> ${recipeData.id}`);
  }
  
  const currentPath = [...path, recipeData.id.toString()];
  
  for (const component of recipeData.bom) {
    const scaledGrossQty = component.gross_qty * scaleFactor;
    const scaledNetQty = netQty(scaledGrossQty, component.trim_loss_pct, component.cook_yield_pct);
    
    if (component.component_type === 'item') {
      const item = allItems.get(component.component_id);
      if (!item) {
        throw new Error(`Item ${component.component_id} not found`);
      }
      
      // Convert to item's base UoM
      let qtyInBase: number;
      try {
        qtyInBase = convertQty(item, scaledNetQty, component.uom, item.base_uom);
      } catch (error) {
        throw new Error(
          `Failed to convert ${component.uom} to ${item.base_uom} for item ${item.id}: ${error}`
        );
      }
      
      // Check if this item already exists in results (for aggregation)
      const existingIndex = results.findIndex(r => r.item_id === component.component_id);
      if (existingIndex >= 0) {
        results[existingIndex].net_qty += qtyInBase;
      } else {
        results.push({
          item_id: component.component_id,
          net_qty: qtyInBase,
          base_uom: item.base_uom,
          source_recipe_id: recipeData.id,
          source_component_path: currentPath
        });
      }
    } else if (component.component_type === 'subrecipe') {
      const subrecipe = allRecipes.get(component.component_id);
      if (!subrecipe) {
        throw new Error(`Subrecipe ${component.component_id} not found`);
      }
      
      // Calculate how many portions of the subrecipe we need
      const subrecipePortions = scaledNetQty; // Assuming uom is 'portion' or equivalent
      
      // Recursively explode the subrecipe
      const subResults = explodeRecipe(
        subrecipe,
        subrecipePortions,
        allRecipes,
        allItems,
        currentPath
      );
      
      // Merge results with aggregation
      for (const subResult of subResults) {
        const existingIndex = results.findIndex(r => r.item_id === subResult.item_id);
        if (existingIndex >= 0) {
          results[existingIndex].net_qty += subResult.net_qty;
        } else {
          results.push({
            ...subResult,
            source_recipe_id: recipeData.id
          });
        }
      }
    }
  }
  
  return results;
}

/**
 * Calculate unit cost for an item from supplier data
 */
export function unitCost(
  item: ItemData,
  suppliers: SupplierPrice[],
  atDate?: Date
): { amount_cents: number; uom: string } {
  if (!suppliers.length) {
    throw new Error(`No suppliers found for item ${item.id}`);
  }
  
  // Filter by date if provided
  let validSuppliers = suppliers;
  if (atDate) {
    // This would need valid_from/valid_to filtering in a real implementation
    validSuppliers = suppliers;
  }
  
  // Find preferred supplier first
  let selectedSupplier = validSuppliers.find(s => s.preferred);
  
  // If no preferred supplier, use lowest price
  if (!selectedSupplier) {
    selectedSupplier = validSuppliers.reduce((lowest, current) => {
      const lowestUnitCost = lowest.price_cents / lowest.pack_size_qty;
      const currentUnitCost = current.price_cents / current.pack_size_qty;
      return currentUnitCost < lowestUnitCost ? current : lowest;
    });
  }
  
  // Convert pack to base UoM
  const packQtyInBase = convertQty(
    item,
    selectedSupplier.pack_size_qty,
    selectedSupplier.pack_size_unit,
    item.base_uom
  );
  
  const unitCostCents = selectedSupplier.price_cents / packQtyInBase;
  
  return {
    amount_cents: unitCostCents,
    uom: item.base_uom
  };
}

/**
 * Calculate cost per portion for a recipe
 */
export function costRecipePortion(
  recipeData: RecipeData,
  allRecipes: Map<number, RecipeData>,
  allItems: Map<number, ItemData>,
  allSuppliers: Map<number, SupplierPrice[]>
): { cost_per_portion_cents: number; breakdown: CostBreakdown[] } {
  const exploded = explodeRecipe(recipeData, 1, allRecipes, allItems);
  const breakdown: CostBreakdown[] = [];
  let totalCostCents = 0;
  
  for (const component of exploded) {
    const item = allItems.get(component.item_id);
    const suppliers = allSuppliers.get(component.item_id) || [];
    
    if (!item) {
      throw new Error(`Item ${component.item_id} not found`);
    }
    
    let unitCostCents = 0;
    let lineCostCents = 0;
    
    try {
      const cost = unitCost(item, suppliers);
      unitCostCents = cost.amount_cents;
      lineCostCents = unitCostCents * component.net_qty;
    } catch (error) {
      console.warn(`Could not calculate cost for item ${component.item_id}: ${error}`);
      // Continue with zero cost rather than failing
    }
    
    breakdown.push({
      item_id: component.item_id,
      item_name: `Item ${component.item_id}`, // Would be loaded from database in real implementation
      qty_base: component.net_qty,
      uom: component.base_uom,
      unit_cost_cents: unitCostCents,
      line_cost_cents: lineCostCents
    });
    
    totalCostCents += lineCostCents;
  }
  
  return {
    cost_per_portion_cents: totalCostCents,
    breakdown
  };
}

// Helper functions for unit conversions

function convertToBase(item: ItemData, qty: number, from_uom: string): number | null {
  if (from_uom === item.base_uom) return qty;
  
  // Try each_to_base for count units
  if (from_uom === 'ea' && item.each_to_base) {
    return qty * item.each_to_base;
  }
  
  // Try conversions table
  const conversion = item.conversions.find(c => 
    c.from_uom === from_uom && c.to_uom === item.base_uom
  );
  if (conversion) {
    return qty * conversion.factor;
  }
  
  return null;
}

function convertFromBase(item: ItemData, qty: number, to_uom: string): number | null {
  if (to_uom === item.base_uom) return qty;
  
  // Try each_to_base for count units
  if (to_uom === 'ea' && item.each_to_base) {
    return qty / item.each_to_base;
  }
  
  // Try conversions table
  const conversion = item.conversions.find(c => 
    c.from_uom === item.base_uom && c.to_uom === to_uom
  );
  if (conversion) {
    return qty * conversion.factor;
  }
  
  return null;
}

function convertVolumeToMl(qty: number, from_uom: string): number {
  const conversions: Record<string, number> = {
    'ml': 1,
    'l': 1000,
    'cup': 240,
    'fl_oz': 30,
    'pint': 473,
    'quart': 946,
    'gallon': 3785
  };
  
  const factor = conversions[from_uom];
  if (!factor) {
    throw new Error(`Unknown volume unit: ${from_uom}`);
  }
  
  return qty * factor;
}

function convertVolumeFromMl(qty: number, to_uom: string): number {
  const conversions: Record<string, number> = {
    'ml': 1,
    'l': 1000,
    'cup': 240,
    'fl_oz': 30,
    'pint': 473,
    'quart': 946,
    'gallon': 3785
  };
  
  const factor = conversions[to_uom];
  if (!factor) {
    throw new Error(`Unknown volume unit: ${to_uom}`);
  }
  
  return qty / factor;
}

function convertMassToGrams(qty: number, from_uom: string): number {
  const conversions: Record<string, number> = {
    'g': 1,
    'kg': 1000,
    'oz': 28.35,
    'lb': 453.6
  };
  
  const factor = conversions[from_uom];
  if (!factor) {
    throw new Error(`Unknown mass unit: ${from_uom}`);
  }
  
  return qty * factor;
}

function convertMassFromGrams(qty: number, to_uom: string): number {
  const conversions: Record<string, number> = {
    'g': 1,
    'kg': 1000,
    'oz': 28.35,
    'lb': 453.6
  };
  
  const factor = conversions[to_uom];
  if (!factor) {
    throw new Error(`Unknown mass unit: ${to_uom}`);
  }
  
  return qty / factor;
}
