// Comprehensive weight conversion utilities for professional kitchen use
export interface WeightConversionResult {
  weight_grams: number | null;
  confidence: 'high' | 'medium' | 'low';
  source: 'direct' | 'density' | 'piece_weight' | 'estimated';
}

// Common weight conversions (to grams)
export const WEIGHT_CONVERSIONS: Record<string, number> = {
  // Metric weight
  'g': 1, 'gram': 1, 'grams': 1,
  'kg': 1000, 'kilogram': 1000, 'kilograms': 1000,
  
  // Imperial weight
  'oz': 28.35, 'ounce': 28.35, 'ounces': 28.35,
  'lb': 453.6, 'lbs': 453.6, 'pound': 453.6, 'pounds': 453.6,
  
  // Volume to weight (water density = 1g/ml)
  'ml': 1, 'milliliter': 1, 'milliliters': 1,
  'l': 1000, 'liter': 1000, 'liters': 1000,
  'cup': 240, 'cups': 240,
  'tbsp': 15, 'tablespoon': 15, 'tablespoons': 15, 'tbs': 15,
  'tsp': 5, 'teaspoon': 5, 'teaspoons': 5, 'ts': 5,
  'fl oz': 30, 'fluid ounce': 30, 'fluid ounces': 30,
  'pint': 473, 'pints': 473,
  'quart': 946, 'quarts': 946,
  'gallon': 3785, 'gallons': 3785,
};

// Ingredient-specific density adjustments (multiplier for volume-to-weight)
export const INGREDIENT_DENSITIES: Record<string, number> = {
  // Oils and fats (lighter than water)
  'oil': 0.92, 'olive oil': 0.91, 'vegetable oil': 0.92, 'butter': 0.91,
  'coconut oil': 0.92, 'lard': 0.92,
  
  // Dairy
  'milk': 1.03, 'cream': 1.01, 'heavy cream': 0.99, 'sour cream': 1.02,
  'yogurt': 1.04, 'cheese': 1.1,
  
  // Sugars and syrups (heavier than water)
  'sugar': 1.59, 'brown sugar': 1.4, 'honey': 1.4, 'maple syrup': 1.3,
  'molasses': 1.4, 'corn syrup': 1.4,
  
  // Flours and dry goods
  'flour': 0.59, 'all-purpose flour': 0.59, 'bread flour': 0.6, 'cake flour': 0.57,
  'rice': 0.75, 'pasta': 0.67, 'oats': 0.4, 'quinoa': 0.85,
  'salt': 1.2, 'baking powder': 0.9, 'baking soda': 1.3,
  
  // Nuts and seeds
  'nuts': 0.6, 'almonds': 0.6, 'walnuts': 0.52, 'peanuts': 0.72,
  'seeds': 0.55, 'sesame seeds': 0.57,
  
  // Vegetables and fruits (mostly water-based)
  'tomatoes': 0.95, 'onions': 0.98, 'carrots': 0.97, 'potatoes': 1.08,
  'apples': 0.96, 'bananas': 0.94,
};

// Common ingredient piece weights (grams per piece)
export const PIECE_WEIGHTS: Record<string, number> = {
  'egg': 50, 'eggs': 50, 'large egg': 55, 'medium egg': 45,
  'onion': 150, 'onions': 150, 'medium onion': 150, 'large onion': 200, 'small onion': 100,
  'garlic clove': 3, 'garlic cloves': 3, 'clove garlic': 3,
  'lemon': 80, 'lemons': 80, 'lime': 60, 'limes': 60,
  'orange': 150, 'oranges': 150,
  'apple': 180, 'apples': 180, 'medium apple': 180,
  'banana': 120, 'bananas': 120, 'medium banana': 120,
  'tomato': 150, 'tomatoes': 150, 'medium tomato': 150,
  'potato': 150, 'potatoes': 150, 'medium potato': 150,
  'carrot': 80, 'carrots': 80, 'medium carrot': 80,
  'bell pepper': 120, 'bell peppers': 120,
  'cucumber': 300, 'cucumbers': 300,
  'avocado': 150, 'avocados': 150,
};

// Normalize unit strings for comparison
function normalizeUnit(unit: string): string {
  return unit.toLowerCase().trim().replace(/[.,]/g, '');
}

// Normalize ingredient name for density/piece weight lookup
function normalizeIngredientName(name: string): string {
  return name.toLowerCase().trim().replace(/[^a-z\s]/g, '').replace(/\s+/g, ' ');
}

// Find best matching density for an ingredient
function findIngredientDensity(ingredientName: string): number {
  const normalized = normalizeIngredientName(ingredientName);
  
  // Direct match
  if (INGREDIENT_DENSITIES[normalized]) {
    return INGREDIENT_DENSITIES[normalized];
  }
  
  // Partial match - find the longest matching key
  let bestMatch = '';
  let bestDensity = 1.0; // Default to water density
  
  for (const [key, density] of Object.entries(INGREDIENT_DENSITIES)) {
    if (normalized.includes(key) && key.length > bestMatch.length) {
      bestMatch = key;
      bestDensity = density;
    }
  }
  
  return bestDensity;
}

// Find piece weight for count-based ingredients
function findPieceWeight(ingredientName: string): number | null {
  const normalized = normalizeIngredientName(ingredientName);
  
  // Direct match
  if (PIECE_WEIGHTS[normalized]) {
    return PIECE_WEIGHTS[normalized];
  }
  
  // Partial match
  for (const [key, weight] of Object.entries(PIECE_WEIGHTS)) {
    if (normalized.includes(key)) {
      return weight;
    }
  }
  
  return null;
}

// Main conversion function
export function convertToWeight(
  amount: number | string, 
  unit: string, 
  ingredientName: string = '',
  gramsPerPiece?: number | null
): WeightConversionResult {
  const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  
  if (isNaN(numAmount) || numAmount <= 0) {
    return { weight_grams: null, confidence: 'low', source: 'direct' };
  }
  
  const normalizedUnit = normalizeUnit(unit);
  
  // 1. Direct weight conversion (highest confidence)
  if (WEIGHT_CONVERSIONS[normalizedUnit]) {
    const baseWeight = numAmount * WEIGHT_CONVERSIONS[normalizedUnit];
    
    // If it's a volume unit, apply ingredient density
    const volumeUnits = ['ml', 'l', 'cup', 'tbsp', 'tsp', 'fl oz', 'pint', 'quart', 'gallon'];
    if (volumeUnits.some(u => normalizedUnit.includes(u))) {
      const density = findIngredientDensity(ingredientName);
      return {
        weight_grams: Math.round(baseWeight * density),
        confidence: density === 1.0 ? 'medium' : 'high',
        source: 'density'
      };
    }
    
    return {
      weight_grams: Math.round(baseWeight),
      confidence: 'high',
      source: 'direct'
    };
  }
  
  // 2. Count-based with known piece weight
  if (gramsPerPiece && gramsPerPiece > 0) {
    return {
      weight_grams: Math.round(numAmount * gramsPerPiece),
      confidence: 'high',
      source: 'piece_weight'
    };
  }
  
  // 3. Count-based with estimated piece weight
  const countUnits = ['piece', 'pieces', 'each', 'ea', 'whole', 'item', 'items'];
  if (countUnits.includes(normalizedUnit) || normalizedUnit === '') {
    const pieceWeight = findPieceWeight(ingredientName);
    if (pieceWeight) {
      return {
        weight_grams: Math.round(numAmount * pieceWeight),
        confidence: 'medium',
        source: 'estimated'
      };
    }
  }
  
  // 4. Special unit patterns (medium, large, small, etc.)
  if (normalizedUnit.includes('medium') || normalizedUnit.includes('large') || normalizedUnit.includes('small')) {
    const pieceWeight = findPieceWeight(ingredientName);
    if (pieceWeight) {
      let multiplier = 1.0;
      if (normalizedUnit.includes('large')) multiplier = 1.3;
      else if (normalizedUnit.includes('small')) multiplier = 0.7;
      
      return {
        weight_grams: Math.round(numAmount * pieceWeight * multiplier),
        confidence: 'medium',
        source: 'estimated'
      };
    }
  }
  
  // 5. Fallback - no conversion possible
  return { weight_grams: null, confidence: 'low', source: 'direct' };
}

// Format weight for display with grams first
export function formatIngredientWeight(
  amount: number, 
  unit: string, 
  weightGrams: number | null,
  showOriginal: boolean = true
): string {
  if (!weightGrams) {
    return `${formatAmount(amount)} ${unit}`;
  }
  
  const gramDisplay = weightGrams < 1000 
    ? `${weightGrams}g` 
    : `${(weightGrams / 1000).toFixed(1)}kg`;
  
  if (!showOriginal) {
    return gramDisplay;
  }
  
  // Show grams first, then original in parentheses
  return `${gramDisplay} (${formatAmount(amount)} ${unit})`;
}

// Format amount with proper fraction display
export function formatAmount(amount: number): string {
  // Handle common cooking fractions
  const fractions: Record<string, string> = {
    '0.125': '⅛',
    '0.25': '¼', 
    '0.333': '⅓',
    '0.375': '⅜',
    '0.5': '½',
    '0.625': '⅝',
    '0.667': '⅔',
    '0.75': '¾',
    '0.875': '⅞'
  };
  
  // Check for exact fraction matches
  const rounded = Math.round(amount * 1000) / 1000;
  const fractionKey = rounded.toString();
  if (fractions[fractionKey]) {
    return fractions[fractionKey];
  }
  
  // Handle mixed numbers (like 1.5 = 1½)
  const whole = Math.floor(amount);
  const decimal = amount - whole;
  const decimalKey = Math.round(decimal * 1000) / 1000;
  
  if (whole > 0 && fractions[decimalKey.toString()]) {
    return `${whole}${fractions[decimalKey.toString()]}`;
  }
  
  // For other numbers, show up to 2 decimal places, removing trailing zeros
  if (amount === Math.floor(amount)) {
    return amount.toString();
  }
  
  return parseFloat(amount.toFixed(2)).toString();
}

// Calculate unit cost from pack information
export function calculateUnitCost(
  costPerPack: number,
  packSize: number,
  packUnit: string,
  targetUnit: 'gram' | 'kg' | 'piece' = 'gram'
): number | null {
  if (!costPerPack || !packSize) return null;
  
  const normalizedPackUnit = normalizeUnit(packUnit);
  
  // Convert pack size to grams
  let packGrams: number;
  
  if (WEIGHT_CONVERSIONS[normalizedPackUnit]) {
    packGrams = packSize * WEIGHT_CONVERSIONS[normalizedPackUnit];
  } else {
    // If pack unit isn't weight, we can't calculate gram-based cost
    if (targetUnit === 'piece') {
      return costPerPack / packSize; // Cost per piece
    }
    return null;
  }
  
  // Calculate cost per target unit
  switch (targetUnit) {
    case 'gram':
      return costPerPack / packGrams;
    case 'kg':
      return costPerPack / (packGrams / 1000);
    case 'piece':
      return null; // Can't convert weight to pieces without piece weight
    default:
      return costPerPack / packGrams;
  }
}
