import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Suspense, lazy, Component, ReactNode } from 'react';

// CRITICAL: Navigation must be directly imported, not lazy-loaded
// Navigation uses useLocation() hook which requires Router context
// See REACT_ROUTER_ERROR_DOCUMENTATION.md for full details
import Navigation from './components/Navigation';

// Error boundary component
interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

interface ErrorBoundaryProps {
  children: ReactNode;
}

class AppErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error('🚨 APP ERROR BOUNDARY TRIGGERED 🚨');
    console.error('Error:', error.message);
    console.error('Error stack:', error.stack);
    console.error('Component stack:', errorInfo.componentStack);
    
    // Special handling for React Router errors
    if (error.message.includes('useNavigate') || error.message.includes('Router') || error.message.includes('useLocation') || error.message.includes('useParams')) {
      console.error('🔴 REACT ROUTER CONTEXT ERROR DETECTED 🔴');
      console.error('Error details:', {
        message: error.message,
        timestamp: new Date().toISOString(),
        errorType: 'Router Context Violation'
      });
      console.error('📚 See DEVELOPER_GUIDE_ROUTER_SAFETY.md for complete prevention guide');
      console.error('🔧 Most common causes:');
      console.error('  1. Component using router hooks is lazy-loaded');
      console.error('  2. Component using router hooks is outside Router context');
      console.error('  3. Component renders before Router is mounted');
      console.error('  4. Router component not properly wrapping the application');
      console.error('💡 Quick fix: Check App.tsx - ensure components with router hooks are directly imported and inside <Router>');
      
      // Log current component tree for debugging
      console.error('🔍 Component tree analysis needed - check if Navigation is inside Router wrapper');
    } else {
      console.error('💥 General application error:', {
        message: error.message,
        timestamp: new Date().toISOString(),
        stack: error.stack
      });
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ 
          padding: '20px', 
          color: '#dc2626', 
          backgroundColor: '#fef2f2',
          border: '2px solid #fecaca',
          borderRadius: '8px',
          margin: '20px',
          fontFamily: 'system-ui, sans-serif'
        }}>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '16px' }}>
            🚨 Application Error
          </h1>
          <div style={{ marginBottom: '16px', padding: '12px', backgroundColor: '#fff', border: '1px solid #fecaca', borderRadius: '4px' }}>
            <strong>Error:</strong> {this.state.error?.message || 'Unknown error'}
          </div>
          
          {this.state.error?.message?.includes('useNavigate') && (
            <div style={{ 
              marginBottom: '16px', 
              padding: '16px', 
              backgroundColor: '#dbeafe', 
              border: '2px solid #2563eb', 
              borderRadius: '8px',
              color: '#1e40af'
            }}>
              <div style={{ fontWeight: 'bold', marginBottom: '8px' }}>🔍 React Router Issue Detected:</div>
              <div style={{ marginBottom: '8px' }}>This error occurs when navigation hooks are used outside the Router context.</div>
              <div style={{ fontSize: '14px', color: '#374151' }}>
                <strong>Technical details:</strong><br/>
                • Navigation component may be rendering before Router is ready<br/>
                • Check that all router hooks are inside &lt;Router&gt; wrapper<br/>
                • Error: {this.state.error.message}
              </div>
            </div>
          )}
          
          <button 
            onClick={() => window.location.reload()} 
            style={{
              padding: '12px 24px',
              backgroundColor: '#2563eb',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              fontSize: '16px',
              fontWeight: '500',
              cursor: 'pointer'
            }}
          >
            🔄 Reload Page
          </button>
          
          <div style={{ marginTop: '16px', fontSize: '14px', color: '#6b7280' }}>
            If this error persists after reloading, please contact support.
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Loading component
function Loading() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-gray-600 dark:text-gray-400">Loading KitchenFlow...</p>
      </div>
    </div>
  );
}

// CRITICAL: Dashboard must be directly imported, not lazy-loaded
// Dashboard uses useNavigate() hook which requires Router context
// See REACT_ROUTER_ERROR_DOCUMENTATION.md for full details
import Dashboard from './pages/Dashboard';

// Lazy load other components
const Planner = lazy(() => import('./pages/Planner'));
const OrderList = lazy(() => import('./pages/OrderList'));
const Locations = lazy(() => import('./pages/Locations'));
const ERPImport = lazy(() => import('./pages/ERPImport'));
const EnhancedRecipes = lazy(() => import('./pages/EnhancedRecipes'));
const EnhancedRecipeDetail = lazy(() => import('./pages/EnhancedRecipeDetail'));
const ProductionPlanning = lazy(() => import('./pages/ProductionPlanning'));
const Items = lazy(() => import('./pages/Items'));
const ItemDetail = lazy(() => import('./pages/ItemDetail'));
const ItemDetailWhereUsed = lazy(() => import('./pages/ItemDetailWhereUsed'));
const RecipeDetailBom = lazy(() => import('./pages/RecipeDetailBom'));



export default function App() {
  return (
    <AppErrorBoundary>
      <Router>
        {/* CRITICAL: Navigation is inside Router context and directly imported */}
        <Navigation />
        <main className="min-h-screen bg-gray-50 dark:bg-gray-900">
          <Suspense fallback={<Loading />}>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/planner" element={<Planner />} />
              <Route path="/planner/:planId" element={<Planner />} />
              <Route path="/planner/:planId/order-list" element={<OrderList />} />
              <Route path="/locations" element={<Locations />} />
              <Route path="/erp-import" element={<ERPImport />} />
              <Route path="/enhanced-recipes" element={<EnhancedRecipes />} />
              <Route path="/enhanced-recipes/:id" element={<EnhancedRecipeDetail />} />
              <Route path="/production-planning" element={<ProductionPlanning />} />
              <Route path="/items" element={<Items />} />
              <Route path="/items/:itemId" element={<ItemDetail />} />
              <Route path="/items/:itemId/where-used" element={<ItemDetailWhereUsed />} />
              <Route path="/enhanced-recipes/:id/bom" element={<RecipeDetailBom />} />
              {/* Legacy redirects */}
              <Route path="/recipes" element={
                <div className="p-8 text-center">
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Redirected to Enhanced Recipes</h1>
                  <p className="mt-2 text-gray-600 dark:text-gray-400">The basic recipes have been replaced with the enhanced production system.</p>
                  <a href="/enhanced-recipes" className="text-blue-600 hover:underline">Go to Enhanced Recipes →</a>
                </div>
              } />
              <Route path="/ingredients" element={
                <div className="p-8 text-center">
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Redirected to Items</h1>
                  <p className="mt-2 text-gray-600 dark:text-gray-400">Ingredients are now managed in the Items catalog.</p>
                  <a href="/items" className="text-blue-600 hover:underline">Go to Items →</a>
                </div>
              } />
              <Route path="/make-sheet" element={
                <div className="p-8 text-center">
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Make Sheet - Coming Soon</h1>
                </div>
              } />
              <Route path="/shopping" element={
                <div className="p-8 text-center">
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Shopping List - Coming Soon</h1>
                </div>
              } />
            </Routes>
          </Suspense>
        </main>
      </Router>
    </AppErrorBoundary>
  );
}
