import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, CheckCircle, FolderOpen } from 'lucide-react';
import DocumentImporter from '@/react-app/components/DocumentImporter';

export default function DocumentImportPage() {
  const navigate = useNavigate();
  const [importComplete, setImportComplete] = useState(false);
  const [importResult, setImportResult] = useState<any>(null);

  const handleImportComplete = (result: any) => {
    setImportComplete(true);
    setImportResult(result);
  };

  const handleStartNew = () => {
    setImportComplete(false);
    setImportResult(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => navigate('/recipes/new')}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
            
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
                Document Recipe Import
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                Upload recipe documents and let AI extract all recipes automatically
              </p>
            </div>
          </div>
        </div>

        {/* How it Works */}
        {!importComplete && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                <FileText className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                1. Upload Document
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Upload PDF recipe books, Word documents, or Excel spreadsheets containing multiple recipes.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mb-4">
                <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                2. AI Analysis
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Advanced AI finds and extracts every recipe, parsing ingredients, instructions, and metadata.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mb-4">
                <FolderOpen className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                3. Select & Organize
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Choose which recipes to import, organize them into folders, and add to your shortlist when ready.
              </p>
            </div>
          </div>
        )}

        {/* Import Component or Success State */}
        {importComplete ? (
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8 text-center">
            <CheckCircle className="w-16 h-16 text-green-600 dark:text-green-400 mx-auto mb-6" />
            
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
              Recipes Imported Successfully!
            </h2>
            
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {importResult?.created_recipes?.length || 0} recipe{(importResult?.created_recipes?.length || 0) !== 1 ? 's have' : ' has'} been imported as drafts.
              You can review and activate them from your recipe management page.
            </p>

            {importResult?.created_recipes && importResult.created_recipes.length > 0 && (
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-6">
                <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-2">
                  Imported Recipes:
                </h3>
                <div className="space-y-1">
                  {importResult.created_recipes.slice(0, 5).map((recipe: any, index: number) => (
                    <div key={index} className="text-sm text-gray-600 dark:text-gray-400">
                      • {recipe.name}
                    </div>
                  ))}
                  {importResult.created_recipes.length > 5 && (
                    <div className="text-sm text-gray-500 dark:text-gray-500">
                      ... and {importResult.created_recipes.length - 5} more
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-center space-x-4">
              <button
                onClick={() => navigate('/recipes')}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
              >
                Manage Recipes
              </button>
              <button
                onClick={handleStartNew}
                className="px-6 py-2 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 font-medium rounded-lg transition-colors"
              >
                Import Another Document
              </button>
            </div>
          </div>
        ) : (
          <DocumentImporter onComplete={handleImportComplete} />
        )}

        {/* Tips */}
        {!importComplete && (
          <div className="mt-8 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-amber-900 dark:text-amber-100 mb-3">
              Tips for Best Results
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-amber-800 dark:text-amber-200 mb-2">Document Quality:</h4>
                <ul className="text-amber-700 dark:text-amber-300 space-y-1 text-sm">
                  <li>• Use clear, well-formatted documents</li>
                  <li>• Ensure text is readable and not blurry</li>
                  <li>• Separate recipes should have clear headings</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-amber-800 dark:text-amber-200 mb-2">Content Structure:</h4>
                <ul className="text-amber-700 dark:text-amber-300 space-y-1 text-sm">
                  <li>• Each recipe should have a clear title</li>
                  <li>• Ingredients and instructions should be listed</li>
                  <li>• Yield/serving information helps with scaling</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
