import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ChefHat, 
  Clock, 
  ArrowLeft, 
  Package,
  Calculator,
  Layers,
  AlertCircle,
  Users,
  MapPin,
  Plus,
  Minus,
  Calendar
} from 'lucide-react';

interface EnhancedRecipe {
  id: number;
  recipe_id: string;
  name: string;
  type: string;
  default_yield_qty: number;
  default_yield_uom: string;
  output_item_id: string | null;
  active_minutes: number;
  passive_minutes: number;
  lead_time_hours: number;
  station: string | null;
  notes: string | null;
  ingredients: any[];
  components: any[];
  used_in_recipes: any[];
  output_item_name: string | null;
}

const typeColors: Record<string, string> = {
  prep: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  component: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  final: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
};

export default function EnhancedRecipeDetail() {
  const { id: recipeId } = useParams();
  const navigate = useNavigate();
  const [recipe, setRecipe] = useState<EnhancedRecipe | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'ingredients' | 'components' | 'usage' | 'planning'>('ingredients');
  
  // Batch scaling state
  const [targetPortions, setTargetPortions] = useState(25);
  const [scaleFactor, setScaleFactor] = useState(1);

  useEffect(() => {
    const fetchRecipe = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/enhanced-recipes/${recipeId}`);
        if (!response.ok) {
          throw new Error('Failed to fetch recipe');
        }
        const data = await response.json();
        setRecipe(data);
        
        // Calculate default portions from yield
        const defaultPortions = calculatePortionsFromYield(data);
        setTargetPortions(defaultPortions);
      } catch (err) {
        console.error('Failed to fetch enhanced recipe:', err);
        setError('Failed to load recipe');
      } finally {
        setLoading(false);
      }
    };

    if (recipeId) {
      fetchRecipe();
    }
  }, [recipeId]);

  // Calculate portions from recipe yield
  const calculatePortionsFromYield = (recipe: EnhancedRecipe) => {
    if (recipe.default_yield_uom.toLowerCase().includes('portion') || 
        recipe.default_yield_uom.toLowerCase().includes('serving')) {
      return recipe.default_yield_qty;
    } else if (recipe.default_yield_uom.toLowerCase().includes('tray') || 
               recipe.default_yield_uom.toLowerCase().includes('gn')) {
      // Estimate portions from tray size
      let estimatedPortions = recipe.default_yield_qty * 36; // Default 1/1 GN = 36 portions
      if (recipe.default_yield_uom.toLowerCase().includes('1/2')) {
        estimatedPortions = recipe.default_yield_qty * 18;
      } else if (recipe.default_yield_uom.toLowerCase().includes('1/4')) {
        estimatedPortions = recipe.default_yield_qty * 9;
      }
      return estimatedPortions;
    } else if (recipe.default_yield_uom.toLowerCase().includes('kg') || 
               recipe.default_yield_uom.toLowerCase().includes('g')) {
      // Estimate portions from weight (assuming ~150g per portion)
      const grams = recipe.default_yield_uom.includes('kg') ? 
        recipe.default_yield_qty * 1000 : recipe.default_yield_qty;
      return Math.round(grams / 150);
    }
    return 25; // Default fallback
  };

  // Update scale factor when target portions change
  useEffect(() => {
    if (recipe) {
      const defaultPortions = calculatePortionsFromYield(recipe);
      setScaleFactor(targetPortions / defaultPortions);
    }
  }, [targetPortions, recipe]);

  // Scale ingredient quantities
  const scaleIngredientQuantity = (qty: number) => {
    return Math.round((qty * scaleFactor) * 100) / 100;
  };

  // Scale component quantities  
  const scaleComponentQuantity = (qty: number) => {
    return Math.round((qty * scaleFactor) * 100) / 100;
  };

  // Calculate scaled timing
  const getScaledTiming = () => {
    if (!recipe) return { active: 0, passive: 0 };
    
    // Timing scales sub-linearly - efficiency gains with larger batches
    const activeMultiplier = Math.pow(scaleFactor, 0.8);
    const passiveMultiplier = Math.pow(scaleFactor, 0.7);
    
    return {
      active: Math.round(recipe.active_minutes * activeMultiplier),
      passive: Math.round(recipe.passive_minutes * passiveMultiplier)
    };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading recipe...</p>
        </div>
      </div>
    );
  }

  if (error || !recipe) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">Recipe Not Found</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
          <button
            onClick={() => navigate('/enhanced-recipes')}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Recipes
          </button>
        </div>
      </div>
    );
  }

  const formatTime = (minutes: number): string => {
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}h${mins > 0 ? ` ${mins}m` : ''}`;
    }
    return `${minutes}m`;
  };

  const defaultPortions = calculatePortionsFromYield(recipe);
  const scaledTiming = getScaledTiming();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-start space-x-4 flex-1">
            <button 
              onClick={() => navigate('/enhanced-recipes')}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors mt-1"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
            
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {recipe.name}
                </h1>
                <span className={`inline-flex px-2.5 py-1 text-sm font-semibold rounded-full ${typeColors[recipe.type] || 'bg-gray-100 text-gray-800'}`}>
                  {recipe.type === 'final' ? 'batch recipe' : recipe.type}
                </span>
              </div>
              
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                Recipe ID: {recipe.recipe_id}
              </div>

              {/* Batch Information */}
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
                      Batch Configuration
                    </h3>
                    <div className="text-sm text-blue-800 dark:text-blue-200">
                      Standard batch: {defaultPortions} portions ({recipe.default_yield_qty} {recipe.default_yield_uom})
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="text-sm font-medium text-blue-900 dark:text-blue-100">Target portions:</span>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setTargetPortions(Math.max(1, targetPortions - 5))}
                        className="p-1 hover:bg-blue-200 dark:hover:bg-blue-800 rounded"
                      >
                        <Minus className="w-4 h-4 text-blue-700 dark:text-blue-300" />
                      </button>
                      <input
                        type="number"
                        min="1"
                        value={targetPortions}
                        onChange={(e) => setTargetPortions(parseInt(e.target.value) || 1)}
                        className="w-16 px-2 py-1 text-center border border-blue-300 dark:border-blue-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      />
                      <button
                        onClick={() => setTargetPortions(targetPortions + 5)}
                        className="p-1 hover:bg-blue-200 dark:hover:bg-blue-800 rounded"
                      >
                        <Plus className="w-4 h-4 text-blue-700 dark:text-blue-300" />
                      </button>
                    </div>
                    {scaleFactor !== 1 && (
                      <span className="text-sm font-medium text-orange-600 dark:text-orange-400">
                        {(scaleFactor * 100).toFixed(0)}% scale
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Recipe Stats */}
              <div className="flex items-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center space-x-1">
                  <Users className="w-4 h-4" />
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {targetPortions} portions
                  </span>
                </div>
                
                {scaledTiming.active > 0 && (
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{formatTime(scaledTiming.active)} active</span>
                  </div>
                )}
                
                {scaledTiming.passive > 0 && (
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{formatTime(scaledTiming.passive)} passive</span>
                  </div>
                )}
                
                {recipe.lead_time_hours > 0 && (
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{recipe.lead_time_hours}h lead time</span>
                  </div>
                )}
                
                {recipe.station && (
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>{recipe.station}</span>
                  </div>
                )}
              </div>

              {recipe.output_item_name && (
                <div className="mt-3 flex items-center space-x-2">
                  <Package className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span className="text-sm text-blue-600 dark:text-blue-400">
                    Produces: {recipe.output_item_name}
                  </span>
                </div>
              )}

              {recipe.notes && (
                <div className="mt-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                  <p className="text-sm text-amber-800 dark:text-amber-200">{recipe.notes}</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            <button className="flex items-center space-x-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm">
              <Calculator className="w-4 h-4" />
              <span>Calculate Cost</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-6">
          <button
            onClick={() => setActiveTab('ingredients')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'ingredients'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Ingredients ({recipe.ingredients?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('components')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'components'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Components ({recipe.components?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('usage')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'usage'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Used In ({recipe.used_in_recipes?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('planning')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'planning'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            <Calendar className="w-4 h-4 inline mr-1" />
            Production Planning
          </button>
        </div>

        {/* Content */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
          {activeTab === 'ingredients' && (
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Ingredients for {targetPortions} portions
                </h2>
                {scaleFactor !== 1 && (
                  <span className="text-sm text-orange-600 dark:text-orange-400">
                    Scaled from {defaultPortions} portions ({(scaleFactor * 100).toFixed(0)}%)
                  </span>
                )}
              </div>
              
              {recipe.ingredients && recipe.ingredients.length > 0 ? (
                <div className="space-y-3">
                  {recipe.ingredients.map((ingredient, index) => {
                    const scaledQty = scaleIngredientQuantity(ingredient.qty);
                    return (
                      <div key={index} className="flex items-center justify-between py-3 px-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="text-right min-w-[80px]">
                            <span className="font-medium text-gray-900 dark:text-gray-100">
                              {scaledQty}
                            </span>
                            <span className="text-gray-600 dark:text-gray-400 ml-1">
                              {ingredient.uom}
                            </span>
                            {scaleFactor !== 1 && (
                              <div className="text-xs text-orange-600 dark:text-orange-400">
                                (was {ingredient.qty})
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/items/${encodeURIComponent(ingredient.item_id)}`);
                              }}
                              className="font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:underline text-left"
                            >
                              {ingredient.item_name || ingredient.item_id}
                            </button>
                            {ingredient.notes && (
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                {ingredient.notes}
                              </p>
                            )}
                            <div className="flex items-center space-x-4 mt-1">
                              <span className="text-xs text-gray-500 dark:text-gray-400">
                                Line {ingredient.line_no}
                              </span>
                              {ingredient.scrap_pct > 0 && (
                                <span className="text-xs text-orange-600 dark:text-orange-400">
                                  {ingredient.scrap_pct}% waste
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                            ingredient.item_type === 'raw' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                            ingredient.item_type === 'prepped' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' :
                            'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                          }`}>
                            {ingredient.item_type || 'unknown'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No ingredients found</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'components' && (
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Recipe Components for {targetPortions} portions
                </h2>
                {scaleFactor !== 1 && (
                  <span className="text-sm text-orange-600 dark:text-orange-400">
                    Scaled from {defaultPortions} portions ({(scaleFactor * 100).toFixed(0)}%)
                  </span>
                )}
              </div>
              
              {recipe.components && recipe.components.length > 0 ? (
                <div className="space-y-3">
                  {recipe.components.map((component, index) => {
                    const scaledQty = scaleComponentQuantity(component.qty);
                    return (
                      <div key={index} className="flex items-center justify-between py-3 px-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="text-right min-w-[80px]">
                            <span className="font-medium text-gray-900 dark:text-gray-100">
                              {scaledQty}
                            </span>
                            <span className="text-gray-600 dark:text-gray-400 ml-1">
                              {component.uom}
                            </span>
                            {scaleFactor !== 1 && (
                              <div className="text-xs text-orange-600 dark:text-orange-400">
                                (was {component.qty})
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/enhanced-recipes/${encodeURIComponent(component.component_recipe_id)}`);
                              }}
                              className="font-medium text-purple-700 dark:text-purple-300 hover:text-purple-900 dark:hover:text-purple-100 hover:underline text-left"
                            >
                              {component.component_name || component.component_recipe_id}
                            </button>
                            {component.notes && (
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                {component.notes}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                            <Layers className="w-3 h-3 mr-1" />
                            {component.component_type || 'component'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Layers className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No components found</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                    This recipe doesn't use other recipes as components
                  </p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'usage' && (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Used In Recipes
              </h2>
              
              {recipe.used_in_recipes && recipe.used_in_recipes.length > 0 ? (
                <div className="space-y-3">
                  {recipe.used_in_recipes.map((usage, index) => (
                    <div key={index} className="flex items-center justify-between py-3 px-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="text-right min-w-[60px]">
                          <span className="font-medium text-gray-900 dark:text-gray-100">
                            {usage.qty}
                          </span>
                          <span className="text-gray-600 dark:text-gray-400 ml-1">
                            {usage.uom}
                          </span>
                        </div>
                        <div className="flex-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/enhanced-recipes/${encodeURIComponent(usage.parent_recipe_id)}`);
                            }}
                            className="font-medium text-green-700 dark:text-green-300 hover:text-green-900 dark:hover:text-green-100 hover:underline text-left"
                          >
                            {usage.parent_name || usage.parent_recipe_id}
                          </button>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${typeColors[usage.parent_type] || 'bg-gray-100 text-gray-800'}`}>
                          {usage.parent_type || 'recipe'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <ChefHat className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">Not used in other recipes</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                    This recipe is not a component of any other recipes
                  </p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'planning' && (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Production Timeline for {targetPortions} portions
              </h2>
              
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-4">
                  Production Schedule
                </h3>
                
                <div className="space-y-4">
                  {recipe.components && recipe.components.length > 0 && (
                    <div>
                      <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-2">
                        Component Preparation ({recipe.lead_time_hours || 2}h before service)
                      </h4>
                      <div className="space-y-2">
                        {recipe.components.map((component, index) => (
                          <div key={index} className="flex items-center justify-between py-2 px-3 bg-purple-100 dark:bg-purple-900/30 rounded">
                            <span className="text-sm text-purple-800 dark:text-purple-200">
                              {component.component_name}: {scaleComponentQuantity(component.qty)} {component.uom}
                            </span>
                            <span className="text-xs text-purple-600 dark:text-purple-400">
                              {component.component_type}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div>
                    <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-2">
                      Final Assembly & Cooking
                    </h4>
                    <div className="py-2 px-3 bg-green-100 dark:bg-green-900/30 rounded">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-green-800 dark:text-green-200">
                          {recipe.name} production
                        </span>
                        <div className="text-xs text-green-600 dark:text-green-400 space-x-2">
                          {scaledTiming.active > 0 && <span>{formatTime(scaledTiming.active)} active</span>}
                          {scaledTiming.passive > 0 && <span>{formatTime(scaledTiming.passive)} passive</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-sm text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-900/30 p-3 rounded">
                    <strong>Total Production Time:</strong> {formatTime(scaledTiming.active + scaledTiming.passive)}
                    {recipe.lead_time_hours > 0 && (
                      <span> + {recipe.lead_time_hours}h component prep time</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
