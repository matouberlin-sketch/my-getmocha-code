import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Package, DollarSign, Users, FileText, X, Save, Loader2, MoreHorizontal, Tag, Calendar } from 'lucide-react';
import BulkIngredientsModal from '../components/BulkIngredientsModal';
import IngredientFilters from '../components/IngredientFilters';
import TagInput from '../components/TagInput';

interface AddIngredientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

function AddIngredientModal({ isOpen, onClose, onSuccess }: AddIngredientModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    unit_type: 'weight' as 'weight' | 'volume' | 'count',
    grams_per_piece: '',
    waste_percentage: '',
    tags: [] as string[]
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const payload = {
        name: formData.name.trim(),
        unit_type: formData.unit_type,
        grams_per_piece: formData.grams_per_piece ? parseFloat(formData.grams_per_piece) : undefined,
        waste_percentage: formData.waste_percentage ? parseFloat(formData.waste_percentage) : undefined,
        tags: formData.tags.length > 0 ? formData.tags : undefined
      };

      const response = await fetch('/api/ingredients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create ingredient');
      }

      // Reset form
      setFormData({ name: '', unit_type: 'weight', grams_per_piece: '', waste_percentage: '', tags: [] });
      onSuccess();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create ingredient');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            Add New Ingredient
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Ingredient Name *
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="e.g., Olive oil, Chicken breast, Onion"
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Unit Type *
            </label>
            <select
              required
              value={formData.unit_type}
              onChange={(e) => setFormData(prev => ({ ...prev, unit_type: e.target.value as any }))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            >
              <option value="weight">Weight (kg, g, lb, oz)</option>
              <option value="volume">Volume (l, ml, cup, tbsp)</option>
              <option value="count">Count (piece, clove, each)</option>
            </select>
          </div>

          {formData.unit_type === 'count' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Weight per Piece (grams)
              </label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                value={formData.grams_per_piece}
                onChange={(e) => setFormData(prev => ({ ...prev, grams_per_piece: e.target.value }))}
                placeholder="e.g., 150 for medium onion, 3 for garlic clove"
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Optional: Average weight of one piece for better cost calculations
              </p>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Waste Percentage
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="number"
                step="0.1"
                min="0"
                max="100"
                value={formData.waste_percentage}
                onChange={(e) => setFormData(prev => ({ ...prev, waste_percentage: e.target.value }))}
                placeholder="e.g., 25 for onions (peeling loss)"
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
              <span className="text-sm text-gray-500 dark:text-gray-400">%</span>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Optional: Percentage lost during prep (trimming, peeling, etc.)
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Tags
            </label>
            <TagInput
              tags={formData.tags}
              onTagsChange={(tags) => setFormData(prev => ({ ...prev, tags }))}
              placeholder="Add tags (dairy, produce, spice, etc.)"
              suggestions={['dairy', 'produce', 'meat', 'seafood', 'spice', 'herb', 'grain', 'frozen', 'canned', 'fresh', 'dried', 'organic']}
            />
          </div>

          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <p className="text-red-700 dark:text-red-300 text-sm">{error}</p>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors flex items-center space-x-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Creating...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Add Ingredient</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Ingredients() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [ingredients, setIngredients] = useState<any[]>([]);
  const [availableTags, setAvailableTags] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedIngredients, setSelectedIngredients] = useState<number[]>([]);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [filters, setFilters] = useState<any>({
    unit_types: [],
    tags: [],
    has_suppliers: null,
    created_after: '',
    created_before: '',
    sort_by: 'name',
    sort_order: 'asc'
  });

  // Fetch ingredients and tags from API
  useEffect(() => {
    fetchIngredients();
    fetchAvailableTags();
  }, [filters]);

  const fetchIngredients = async () => {
    try {
      const params = new URLSearchParams();
      
      if (filters.unit_types.length > 0) {
        params.append('unit_types', filters.unit_types.join(','));
      }
      if (filters.tags.length > 0) {
        params.append('tags', filters.tags.join(','));
      }
      if (filters.sort_by) {
        params.append('sort', filters.sort_by);
        params.append('order', filters.sort_order);
      }
      
      const url = `/api/ingredients${params.toString() ? `?${params.toString()}` : ''}`;
      const response = await fetch(url);
      
      if (response.ok) {
        const data = await response.json();
        setIngredients(data);
      }
    } catch (error) {
      console.error('Failed to fetch ingredients:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableTags = async () => {
    try {
      const response = await fetch('/api/ingredient-tags');
      if (response.ok) {
        const data = await response.json();
        setAvailableTags(data.map((tag: any) => tag.tag));
      }
    } catch (error) {
      console.error('Failed to fetch tags:', error);
    }
  };

  const handleAddSuccess = () => {
    fetchIngredients(); // Refresh the list
    fetchAvailableTags(); // Refresh tags
  };

  const handleBulkAction = async (action: string, data: any) => {
    try {
      console.log('Performing bulk action:', action, data);
      
      const response = await fetch('/api/ingredients/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const responseText = await response.text();
      console.log('Bulk action response:', response.status, responseText);

      if (!response.ok) {
        let errorMessage = 'Bulk operation failed';
        try {
          const error = JSON.parse(responseText);
          errorMessage = error.error || errorMessage;
        } catch (e) {
          errorMessage = responseText || errorMessage;
        }
        throw new Error(errorMessage);
      }

      // Show success message
      const result = JSON.parse(responseText);
      console.log('Bulk action successful:', result);

      // Refresh data
      setSelectedIngredients([]);
      fetchIngredients();
      fetchAvailableTags();
    } catch (error) {
      console.error('Bulk operation failed:', error);
      alert(`Error: ${error instanceof Error ? error.message : 'Bulk operation failed'}`);
      throw error;
    }
  };

  const toggleIngredientSelection = (ingredientId: number) => {
    setSelectedIngredients(prev => 
      prev.includes(ingredientId) 
        ? prev.filter(id => id !== ingredientId)
        : [...prev, ingredientId]
    );
  };

  const toggleSelectAll = () => {
    setSelectedIngredients(prev => 
      prev.length === filteredIngredients.length 
        ? [] 
        : filteredIngredients.map(ing => ing.id)
    );
  };

  const filteredIngredients = ingredients.filter(ingredient => {
    // Apply text search
    const matchesSearch = ingredient.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Apply date filters
    let matchesDate = true;
    if (filters.created_after) {
      matchesDate = matchesDate && new Date(ingredient.created_at) >= new Date(filters.created_after);
    }
    if (filters.created_before) {
      const beforeDate = new Date(filters.created_before);
      beforeDate.setDate(beforeDate.getDate() + 1); // Include the full day
      matchesDate = matchesDate && new Date(ingredient.created_at) < beforeDate;
    }
    
    // Apply supplier filter
    let matchesSupplier = true;
    if (filters.has_suppliers === true) {
      matchesSupplier = (ingredient.supplier_count || 0) > 0;
    } else if (filters.has_suppliers === false) {
      matchesSupplier = (ingredient.supplier_count || 0) === 0;
    }
    
    return matchesSearch && matchesDate && matchesSupplier;
  });

  const formatCostRange = (minCost: number | null, maxCost: number | null) => {
    if (!minCost && !maxCost) return 'No pricing';
    if (!maxCost || minCost === maxCost) return `$${minCost?.toFixed(2)}/unit`;
    return `$${minCost?.toFixed(2)} - $${maxCost?.toFixed(2)}/unit`;
  };

  

  const formatTags = (tagsString: string | null) => {
    if (!tagsString) return [];
    return tagsString.split(',').filter(Boolean);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-1">
              Ingredients & Suppliers
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {filteredIngredients.length} ingredient{filteredIngredients.length !== 1 ? 's' : ''}
              {selectedIngredients.length > 0 && ` • ${selectedIngredients.length} selected`}
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            {selectedIngredients.length > 0 && (
              <button 
                onClick={() => setShowBulkModal(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-medium rounded-lg transition-colors"
              >
                <MoreHorizontal className="w-4 h-4" />
                <span>Bulk Actions ({selectedIngredients.length})</span>
              </button>
            )}
            
            <button 
              onClick={() => navigate('/ingredients/upload-invoice')}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors"
            >
              <FileText className="w-4 h-4" />
              <span>Upload Invoice</span>
            </button>
            <button 
              onClick={() => setShowAddModal(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Ingredient</span>
            </button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search ingredients..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <IngredientFilters 
            onFiltersChange={setFilters}
            availableTags={availableTags}
          />
        </div>

        {/* Enhanced Ingredients Table */}
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : filteredIngredients.length === 0 ? (
            <div className="p-12 text-center">
              <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                {searchTerm || Object.values(filters).some(v => v && (Array.isArray(v) ? v.length > 0 : true)) ? 'No ingredients found' : 'No ingredients yet'}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                {searchTerm || Object.values(filters).some(v => v && (Array.isArray(v) ? v.length > 0 : true))
                  ? 'Try adjusting your search or filters' 
                  : 'Start building your ingredient library'
                }
              </p>
              {(!searchTerm && !Object.values(filters).some(v => v && (Array.isArray(v) ? v.length > 0 : true))) && (
                <button 
                  onClick={() => setShowAddModal(true)}
                  className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Ingredient
                </button>
              )}
            </div>
          ) : (
            <>
              {/* Table Header */}
              <div className="grid grid-cols-12 gap-4 px-4 py-3 bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                <div className="col-span-1 flex items-center justify-center">
                  <input
                    type="checkbox"
                    checked={selectedIngredients.length === filteredIngredients.length && filteredIngredients.length > 0}
                    onChange={toggleSelectAll}
                    className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 cursor-pointer"
                  />
                </div>
                <div className="col-span-3">Ingredient</div>
                <div className="col-span-2">Type & Properties</div>
                <div className="col-span-2">Tags</div>
                <div className="col-span-2">Suppliers & Pricing</div>
                <div className="col-span-1">Waste %</div>
                <div className="col-span-1">Created</div>
              </div>
              
              {/* Table Body */}
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {filteredIngredients.map((ingredient) => (
                  <div 
                    key={ingredient.id}
                    className={`grid grid-cols-12 gap-4 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors group cursor-pointer ${
                      selectedIngredients.includes(ingredient.id) ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                    }`}
                    onClick={(e) => {
                      // Don't navigate if clicking on checkbox
                      const target = e.target as HTMLInputElement;
                      if (target.type !== 'checkbox') {
                        navigate(`/ingredients/${ingredient.id}`);
                      }
                    }}
                  >
                    {/* Checkbox */}
                    <div className="col-span-1 flex items-center justify-center">
                      <div 
                        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleIngredientSelection(ingredient.id);
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={selectedIngredients.includes(ingredient.id)}
                          onChange={() => {}} // Handled by parent div
                          className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 cursor-pointer pointer-events-none"
                        />
                      </div>
                    </div>

                    {/* Ingredient Name & Basic Info */}
                    <div className="col-span-3">
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0 w-8 h-8 bg-gray-100 dark:bg-gray-600 rounded-lg flex items-center justify-center">
                          <Package className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-gray-900 dark:text-gray-100 truncate group-hover:text-blue-600 dark:group-hover:text-blue-400">
                            {ingredient.name}
                          </h3>
                          {ingredient.grams_per_piece && (
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                              {ingredient.grams_per_piece}g per piece
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* Type & Properties */}
                    <div className="col-span-2 flex items-center">
                      <div>
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                          {ingredient.unit_type}
                        </span>
                        {ingredient.waste_percentage > 0 && (
                          <div className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                            {ingredient.waste_percentage}% waste
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Tags */}
                    <div className="col-span-2 flex items-center">
                      <div className="flex flex-wrap gap-1">
                        {formatTags(ingredient.tags).slice(0, 3).map((tag) => (
                          <span 
                            key={tag}
                            className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200"
                          >
                            <Tag className="w-2 h-2 mr-1" />
                            {tag}
                          </span>
                        ))}
                        {formatTags(ingredient.tags).length > 3 && (
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            +{formatTags(ingredient.tags).length - 3}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    {/* Suppliers & Pricing */}
                    <div className="col-span-2 flex items-center">
                      <div className="text-sm">
                        <div className="flex items-center space-x-1 text-gray-600 dark:text-gray-400">
                          <Users className="w-3 h-3" />
                          <span>{ingredient.supplier_count || 0} suppliers</span>
                        </div>
                        <div className="flex items-center space-x-1 text-gray-900 dark:text-gray-100 mt-0.5">
                          <DollarSign className="w-3 h-3" />
                          <span className="text-xs">
                            {formatCostRange(ingredient.min_unit_cost, ingredient.max_unit_cost)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Waste Percentage */}
                    <div className="col-span-1 flex items-center">
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {ingredient.waste_percentage ? `${ingredient.waste_percentage}%` : '-'}
                      </div>
                    </div>

                    {/* Created Date */}
                    <div className="col-span-1 flex items-center">
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>
                            {new Date(ingredient.created_at).toLocaleDateString('en-US', { 
                              month: 'short', 
                              day: 'numeric'
                            })}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500 mt-0.5">
                          {new Date(ingredient.created_at).toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit',
                            hour12: false 
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Add Ingredient Modal */}
        <AddIngredientModal
          isOpen={showAddModal}
          onClose={() => setShowAddModal(false)}
          onSuccess={handleAddSuccess}
        />

        {/* Bulk Actions Modal */}
        <BulkIngredientsModal
          isOpen={showBulkModal}
          onClose={() => setShowBulkModal(false)}
          selectedIngredients={selectedIngredients}
          ingredients={ingredients}
          onBulkAction={handleBulkAction}
        />
      </div>
    </div>
  );
}
