import { useState } from 'react';
import { Upload, Download, AlertCircle, CheckCircle, Loader2, Database, Package, Users, ChefHat, Layers } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ImportResults {
  suppliers: number;
  items: number;
  supplier_items: number;
  recipes: number;
  recipe_ingredients: number;
  recipe_components: number;
  errors: string[];
}

export default function ERPImport() {
  const navigate = useNavigate();
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<ImportResults | null>(null);
  const [error, setError] = useState('');

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setImportFile(file);
      setError('');
      setImportResults(null);
    }
  };

  const handleImport = async () => {
    if (!importFile) {
      setError('Please select a file to import');
      return;
    }

    setImporting(true);
    setError('');

    try {
      let csvData;
      
      // Check file type and process accordingly
      if (importFile.name.toLowerCase().endsWith('.xlsx') || importFile.name.toLowerCase().endsWith('.xls')) {
        // Handle Excel file
        const formData = new FormData();
        formData.append('file', importFile);
        
        const response = await fetch('/api/csv-import/upload-excel', {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Excel processing failed');
        }

        const result = await response.json();
        setImportResults(result.results);
        return;
      } else {
        // Handle JSON file
        const text = await importFile.text();
        csvData = JSON.parse(text);
        
        const response = await fetch('/api/csv-import/bulk-import', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ csvData }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Import failed');
        }

        const result = await response.json();
        setImportResults(result.results);
      }
      
    } catch (err) {
      console.error('Import error:', err);
      setError(err instanceof Error ? err.message : 'Failed to import data');
    } finally {
      setImporting(false);
    }
  };

  const handleExport = async () => {
    try {
      const response = await fetch('/api/csv-import/export');
      if (!response.ok) {
        throw new Error('Export failed');
      }

      const data = await response.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `kitchen-erp-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export error:', err);
      setError('Failed to export data');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            ERP Data Management
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Import comprehensive kitchen ERP data including suppliers, items, recipes, and costs
          </p>
        </div>

        {/* Import Section */}
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 mb-6">
          <div className="flex items-center space-x-2 mb-4">
            <Upload className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              Import ERP Data
            </h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Upload Excel or JSON File
              </label>
              <input
                type="file"
                accept=".json,.xlsx,.xls"
                onChange={handleFileUpload}
                className="block w-full text-sm text-gray-500 dark:text-gray-400
                         file:mr-4 file:py-2 file:px-4
                         file:rounded-lg file:border-0
                         file:text-sm file:font-medium
                         file:bg-blue-50 file:text-blue-700
                         hover:file:bg-blue-100
                         dark:file:bg-blue-900 dark:file:text-blue-300"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Supports Excel files (.xlsx, .xls) and JSON files
              </p>
            </div>

            {importFile && (
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Ready to import: {importFile.name} ({(importFile.size / 1024).toFixed(1)} KB)
                </p>
              </div>
            )}

            <button
              onClick={handleImport}
              disabled={!importFile || importing}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors"
            >
              {importing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Importing...</span>
                </>
              ) : (
                <>
                  <Database className="w-4 h-4" />
                  <span>Import Data</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Export Section */}
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 mb-6">
          <div className="flex items-center space-x-2 mb-4">
            <Download className="w-5 h-5 text-green-600 dark:text-green-400" />
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              Export Current Data
            </h2>
          </div>

          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Export your current database to JSON format for backup or sharing
          </p>

          <button
            onClick={handleExport}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export to JSON</span>
          </button>
        </div>

        {/* Results */}
        {importResults && (
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 mb-6">
            <div className="flex items-center space-x-2 mb-4">
              <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Import Results
              </h2>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
              <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <Users className="w-6 h-6 text-blue-600 dark:text-blue-400 mx-auto mb-1" />
                <div className="text-lg font-semibold text-blue-900 dark:text-blue-100">
                  {importResults.suppliers}
                </div>
                <div className="text-xs text-blue-600 dark:text-blue-400">Suppliers</div>
              </div>

              <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <Package className="w-6 h-6 text-green-600 dark:text-green-400 mx-auto mb-1" />
                <div className="text-lg font-semibold text-green-900 dark:text-green-100">
                  {importResults.items}
                </div>
                <div className="text-xs text-green-600 dark:text-green-400">Items</div>
              </div>

              <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <ChefHat className="w-6 h-6 text-purple-600 dark:text-purple-400 mx-auto mb-1" />
                <div className="text-lg font-semibold text-purple-900 dark:text-purple-100">
                  {importResults.recipes}
                </div>
                <div className="text-xs text-purple-600 dark:text-purple-400">Recipes</div>
              </div>

              <div className="text-center p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                <Database className="w-6 h-6 text-amber-600 dark:text-amber-400 mx-auto mb-1" />
                <div className="text-lg font-semibold text-amber-900 dark:text-amber-100">
                  {importResults.supplier_items}
                </div>
                <div className="text-xs text-amber-600 dark:text-amber-400">Supplier Items</div>
              </div>

              <div className="text-center p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
                <Package className="w-6 h-6 text-indigo-600 dark:text-indigo-400 mx-auto mb-1" />
                <div className="text-lg font-semibold text-indigo-900 dark:text-indigo-100">
                  {importResults.recipe_ingredients}
                </div>
                <div className="text-xs text-indigo-600 dark:text-indigo-400">Recipe Ingredients</div>
              </div>

              <div className="text-center p-3 bg-pink-50 dark:bg-pink-900/20 rounded-lg">
                <Layers className="w-6 h-6 text-pink-600 dark:text-pink-400 mx-auto mb-1" />
                <div className="text-lg font-semibold text-pink-900 dark:text-pink-100">
                  {importResults.recipe_components}
                </div>
                <div className="text-xs text-pink-600 dark:text-pink-400">Recipe Components</div>
              </div>
            </div>

            {importResults.errors.length > 0 && (
              <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <h3 className="text-sm font-medium text-red-800 dark:text-red-200 mb-2">
                  Import Errors ({importResults.errors.length})
                </h3>
                <div className="text-xs text-red-600 dark:text-red-300 max-h-32 overflow-y-auto">
                  {importResults.errors.map((error, index) => (
                    <div key={index} className="mb-1">• {error}</div>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-4 flex space-x-3">
              <button
                onClick={() => navigate('/enhanced-recipes')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
              >
                View Enhanced Recipes
              </button>
              <button
                onClick={() => navigate('/items')}
                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors"
              >
                View Items
              </button>
            </div>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
            <div className="flex items-start space-x-2">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm font-medium text-red-800 dark:text-red-200">
                  Import Error
                </h3>
                <p className="text-sm text-red-600 dark:text-red-300 mt-1">
                  {error}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* File Format Information */}
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Supported File Formats
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Excel Format */}
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-2">Excel Files (.xlsx, .xls)</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                Upload an Excel file with separate sheets for each data type:
              </p>
              <ul className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
                <li>• <strong>suppliers</strong> - Supplier information</li>
                <li>• <strong>items</strong> - Item catalog</li>
                <li>• <strong>supplier_items</strong> - Supplier pricing</li>
                <li>• <strong>recipes</strong> - Recipe definitions</li>
                <li>• <strong>recipe_ingredients</strong> - Recipe ingredient lists</li>
                <li>• <strong>recipe_components</strong> - Recipe hierarchy</li>
                <li>• <strong>item_uom_conversions</strong> - Unit conversions</li>
              </ul>
            </div>
            
            {/* JSON Format */}
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-2">JSON Files (.json)</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                JSON file with the following structure:
              </p>
              <pre className="text-xs bg-gray-100 dark:bg-gray-700 p-3 rounded-lg overflow-x-auto">
{`{
  "suppliers": [...],
  "items": [...],
  "supplier_items": [...],
  "item_uom_conversions": [...],
  "recipes": [...],
  "recipe_ingredients": [...],
  "recipe_components": [...]
}`}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
