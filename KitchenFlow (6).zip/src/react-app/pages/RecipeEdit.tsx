import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Loader2, Plus, X, Check } from 'lucide-react';
import { convertToWeight } from '@/shared/utils/weightConversion';
import CookingSection from '@/react-app/components/CookingSection';
import TagInput from '@/react-app/components/TagInput';
import IngredientAutocomplete from '@/react-app/components/IngredientAutocomplete';

export default function RecipeEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [recipe, setRecipe] = useState<any>(null);

  // Form data
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    yield_amount: 4,
    yield_unit: 'servings',
    prep_time_minutes: '',
    hands_on_minutes: '',
    notes: '',
    tags: [] as string[],
    ingredients: [{ 
      ingredient_name: '', 
      amount: '', 
      unit: '', 
      notes: '', 
      weight_grams: undefined as number | undefined,
      ingredient_id: undefined as number | undefined,
      subrecipe_id: undefined as number | undefined,
      is_subrecipe: false,
      grams_per_piece: undefined as number | undefined
    }],
    steps: [{ instruction: '' }],
    cookingSteps: [{ equipment: '', method: '', temperature: '', duration: '', notes: '' }]
  });

  // Load recipe data
  useEffect(() => {
    const fetchRecipe = async () => {
      try {
        const response = await fetch(`/api/recipes/${id}`);
        if (response.ok) {
          const data = await response.json();
          setRecipe(data);
          
          // Populate form with existing data
          setFormData({
            name: data.name || '',
            description: data.description || '',
            yield_amount: data.yield_amount || 4,
            yield_unit: data.yield_unit || 'servings',
            prep_time_minutes: data.prep_time_minutes || '',
            hands_on_minutes: data.hands_on_minutes || '',
            notes: data.notes || '',
            tags: data.tags || [],
            ingredients: data.ingredients?.length > 0 ? data.ingredients.map((ing: any) => ({
              ingredient_name: ing.ingredient_name || ing.subrecipe_name || '',
              amount: ing.amount?.toString() || '',
              unit: ing.unit || '',
              notes: ing.notes || '',
              weight_grams: ing.weight_grams,
              ingredient_id: ing.ingredient_id,
              subrecipe_id: ing.subrecipe_id,
              is_subrecipe: !!ing.subrecipe_id,
              grams_per_piece: ing.grams_per_piece
            })) : [{ 
              ingredient_name: '', 
              amount: '', 
              unit: '', 
              notes: '', 
              weight_grams: undefined,
              ingredient_id: undefined,
              subrecipe_id: undefined,
              is_subrecipe: false,
              grams_per_piece: undefined
            }],
            steps: data.steps?.length > 0 ? data.steps.map((step: any) => ({
              instruction: step.instruction || ''
            })) : [{ instruction: '' }],
            cookingSteps: data.cookingSteps?.length > 0 ? data.cookingSteps.map((step: any) => ({
              equipment: step.equipment || '',
              method: step.method || '',
              temperature: step.temperature || '',
              duration: step.duration || '',
              notes: step.notes || '',
              process: step.process || '',
              timing: step.timing || 'sequential'
            })) : [{ equipment: '', method: '', temperature: '', duration: '', notes: '' }]
          });
        } else {
          setError('Recipe not found');
        }
      } catch (err) {
        console.error('Failed to fetch recipe:', err);
        setError('Failed to load recipe');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchRecipe();
    }
  }, [id]);

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateIngredient = (index: number, field: string, value: string, ingredientData?: any) => {
    const updatedIngredients = formData.ingredients.map((ing: any, i: number) => {
      if (i === index) {
        let updatedIng = { ...ing, [field]: value };
        
        // Handle ingredient selection from autocomplete
        if (field === 'ingredient_name' && ingredientData) {
          if (ingredientData.isSubRecipe) {
            updatedIng = {
              ...updatedIng,
              ingredient_id: ingredientData.id,
              subrecipe_id: ingredientData.id,
              is_subrecipe: true,
              unit: updatedIng.unit || 'portion',
              grams_per_piece: undefined
            };
          } else if (ingredientData.isNewIngredient) {
            updatedIng = {
              ...updatedIng,
              ingredient_id: undefined,
              subrecipe_id: undefined,
              is_subrecipe: false,
              grams_per_piece: undefined
            };
          } else {
            updatedIng = {
              ...updatedIng,
              ingredient_id: ingredientData.id,
              subrecipe_id: undefined,
              is_subrecipe: false,
              grams_per_piece: ingredientData.grams_per_piece
            };
            
            // Auto-fill unit based on ingredient type if no unit is set
            if (!updatedIng.unit) {
              if (ingredientData.unit_type === 'weight') updatedIng.unit = 'g';
              else if (ingredientData.unit_type === 'volume') updatedIng.unit = 'ml';
              else if (ingredientData.unit_type === 'count') updatedIng.unit = 'piece';
            }
          }
        }
        
        // Recalculate weight when amount, unit, or ingredient changes
        if (field === 'amount' || field === 'unit' || field === 'ingredient_name') {
          const weightResult = convertToWeight(
            parseFloat(updatedIng.amount) || 0,
            updatedIng.unit,
            updatedIng.ingredient_name,
            updatedIng.grams_per_piece
          );
          updatedIng.weight_grams = weightResult.weight_grams === null ? undefined : weightResult.weight_grams;
        }
        
        return updatedIng;
      }
      return ing;
    });
    
    updateField('ingredients', updatedIngredients);
  };

  const addIngredient = () => {
    const newIngredients = [...formData.ingredients, {
      ingredient_name: '',
      amount: '',
      unit: '',
      notes: '',
      weight_grams: undefined,
      ingredient_id: undefined,
      subrecipe_id: undefined,
      is_subrecipe: false,
      grams_per_piece: undefined
    }];
    updateField('ingredients', newIngredients);
  };

  const removeIngredient = (index: number) => {
    if (formData.ingredients.length > 1) {
      const newIngredients = formData.ingredients.filter((_: any, i: number) => i !== index);
      updateField('ingredients', newIngredients);
    }
  };

  const updateStep = (index: number, instruction: string) => {
    const updatedSteps = formData.steps.map((step: any, i: number) => 
      i === index ? { ...step, instruction } : step
    );
    updateField('steps', updatedSteps);
  };

  const addStep = () => {
    const newSteps = [...formData.steps, { instruction: '' }];
    updateField('steps', newSteps);
  };

  const removeStep = (index: number) => {
    if (formData.steps.length > 1) {
      const newSteps = formData.steps.filter((_: any, i: number) => i !== index);
      updateField('steps', newSteps);
    }
  };

  const updateCookingSteps = (cookingSteps: any[]) => {
    updateField('cookingSteps', cookingSteps);
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');
    
    try {
      // Validation
      if (!formData.name?.trim()) {
        throw new Error('Recipe name is required');
      }
      
      if (!formData.yield_amount || formData.yield_amount <= 0) {
        throw new Error('Yield amount must be greater than 0');
      }
      
      if (!formData.yield_unit?.trim()) {
        throw new Error('Yield unit is required');
      }
      
      if (!formData.ingredients?.length) {
        throw new Error('At least one ingredient is required');
      }
      
      if (!formData.steps?.length) {
        throw new Error('At least one instruction step is required');
      }
      
      // Clean and validate ingredients
      const cleanIngredients = formData.ingredients
        .filter((ing: any) => ing.ingredient_name?.trim() && ing.amount && ing.unit?.trim())
        .map((ing: any) => ({
          ingredient_name: ing.ingredient_name.trim(),
          ingredient_id: ing.ingredient_id || null,
          subrecipe_id: ing.subrecipe_id || null,
          amount: Number(ing.amount),
          unit: ing.unit.trim(),
          notes: ing.notes?.trim() || null,
          weight_grams: ing.weight_grams || null,
          is_subrecipe: !!ing.subrecipe_id,
          grams_per_piece: ing.grams_per_piece || null
        }));

      // Clean and validate steps
      const cleanSteps = formData.steps
        .filter((step: any) => step.instruction?.trim())
        .map((step: any, index: number) => ({
          step_number: index + 1,
          instruction: step.instruction.trim()
        }));

      // Clean and validate cooking steps
      const cleanCookingSteps = formData.cookingSteps
        .filter((step: any) => step.equipment?.trim() && step.method?.trim())
        .map((step: any, index: number) => ({
          step_number: index + 1,
          equipment: step.equipment.trim(),
          method: step.method.trim(),
          temperature: step.temperature?.trim() || null,
          duration: step.duration?.trim() || null,
          notes: step.notes?.trim() || null,
          process: step.process?.trim() || null,
          timing: step.timing || 'sequential'
        }));

      // Prepare update payload
      const updatePayload = {
        name: formData.name.trim(),
        description: formData.description?.trim() || null,
        yield_amount: Number(formData.yield_amount),
        yield_unit: formData.yield_unit.trim(),
        prep_time_minutes: formData.prep_time_minutes ? Number(formData.prep_time_minutes) : null,
        hands_on_minutes: formData.hands_on_minutes ? Number(formData.hands_on_minutes) : null,
        notes: formData.notes?.trim() || null,
        tags: Array.isArray(formData.tags) ? formData.tags.filter(Boolean) : [],
        ingredients: cleanIngredients,
        steps: cleanSteps,
        cookingSteps: cleanCookingSteps
      };

      console.log('Sending update payload:', updatePayload);

      const response = await fetch(`/api/recipes/${id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(updatePayload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { error: `HTTP ${response.status}: ${errorText}` };
        }
        throw new Error(errorData.error || `Server error ${response.status}`);
      }

      const result = await response.json();
      console.log('Recipe updated successfully:', result);

      // Navigate back to recipe detail page
      navigate(`/recipes/${id}`);
      
    } catch (err: any) {
      console.error('Recipe update failed:', err);
      setError(err.message || 'Failed to update recipe');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error && !recipe) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">Error</h1>
          <p className="text-red-600 dark:text-red-400 mb-4">{error}</p>
          <button 
            onClick={() => navigate('/recipes')}
            className="text-blue-600 dark:text-blue-400 hover:underline"
          >
            Back to Recipes
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <button
              onClick={() => navigate(`/recipes/${id}`)}
              className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Recipe</span>
            </button>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Edit Recipe
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Make changes to your recipe and save when ready
          </p>
        </div>

        <div className="space-y-6">
          {/* Basic Information */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Basic Information
            </h2>
            
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Recipe Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => updateField('description', e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Yield Amount *
                  </label>
                  <input
                    type="number"
                    required
                    min="0.1"
                    step="0.1"
                    value={formData.yield_amount}
                    onChange={(e) => updateField('yield_amount', parseFloat(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Yield Unit *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.yield_unit}
                    onChange={(e) => updateField('yield_unit', e.target.value)}
                    placeholder="servings, kg, etc."
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Prep Time (min)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.prep_time_minutes}
                    onChange={(e) => updateField('prep_time_minutes', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Hands-On (min)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.hands_on_minutes}
                    onChange={(e) => updateField('hands_on_minutes', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
              </div>

              {/* Tags */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Tags
                </label>
                <TagInput 
                  tags={formData.tags || []}
                  onTagsChange={(tags) => updateField('tags', tags)}
                />
              </div>
            </div>
          </div>

          {/* Ingredients */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Ingredients
              </h2>
              <button
                type="button"
                onClick={addIngredient}
                className="flex items-center space-x-1 text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
              >
                <Plus className="w-4 h-4" />
                <span>Add</span>
              </button>
            </div>

            <div className="space-y-3">
              {formData.ingredients.map((ingredient: any, index: number) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-2 items-end">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Amount
                    </label>
                    <input
                      type="text"
                      value={ingredient.amount}
                      onChange={(e) => updateIngredient(index, 'amount', e.target.value)}
                      placeholder="1.5"
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Unit
                    </label>
                    <select
                      value={ingredient.unit}
                      onChange={(e) => updateIngredient(index, 'unit', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    >
                      <option value="">Select unit</option>
                      <optgroup label="Weight">
                        <option value="kg">kg</option>
                        <option value="g">g</option>
                        <option value="lb">lb</option>
                        <option value="oz">oz</option>
                      </optgroup>
                      <optgroup label="Volume">
                        <option value="l">l</option>
                        <option value="ml">ml</option>
                        <option value="cup">cup</option>
                        <option value="tbsp">tbsp</option>
                        <option value="tsp">tsp</option>
                        <option value="fl oz">fl oz</option>
                      </optgroup>
                      <optgroup label="Count">
                        <option value="piece">piece</option>
                        <option value="clove">clove</option>
                        <option value="large">large</option>
                        <option value="medium">medium</option>
                        <option value="small">small</option>
                        <option value="whole">whole</option>
                        <option value="bunch">bunch</option>
                        <option value="can">can</option>
                      </optgroup>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Ingredient
                    </label>
                    <IngredientAutocomplete
                      value={ingredient.ingredient_name}
                      onChange={(value, data) => updateIngredient(index, 'ingredient_name', value, data)}
                      placeholder="Search ingredients..."
                      className="text-sm"
                    />
                    <div className="mt-1 text-xs">
                      {ingredient.weight_grams && ingredient.weight_grams > 0 && (
                        <span className="text-gray-600 dark:text-gray-400">
                          {ingredient.weight_grams < 1000 
                            ? `${ingredient.weight_grams}g` 
                            : `${(ingredient.weight_grams / 1000).toFixed(1)}kg`
                          }
                        </span>
                      )}
                      {ingredient.is_subrecipe && (
                        <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                          Sub-Recipe
                        </span>
                      )}
                      {ingredient.ingredient_id && (
                        <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                          <Check className="w-3 h-3 mr-1" />
                          Found in DB
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={ingredient.notes}
                      onChange={(e) => updateIngredient(index, 'notes', e.target.value)}
                      placeholder="Notes (optional)"
                      className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    />
                    {formData.ingredients.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeIngredient(index)}
                        className="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cooking Method */}
          <CookingSection 
            cookingSteps={formData.cookingSteps || []}
            onUpdateCookingSteps={updateCookingSteps}
          />

          {/* Instructions */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Instructions
              </h2>
              <button
                type="button"
                onClick={addStep}
                className="flex items-center space-x-1 text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
              >
                <Plus className="w-4 h-4" />
                <span>Add Step</span>
              </button>
            </div>

            <div className="space-y-4">
              {formData.steps.map((step: any, index: number) => (
                <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <textarea
                        value={step.instruction}
                        onChange={(e) => updateStep(index, e.target.value)}
                        placeholder="Describe this step..."
                        rows={2}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                      />
                    </div>
                    {formData.steps.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeStep(index)}
                        className="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Notes
            </h2>
            <textarea
              value={formData.notes}
              onChange={(e) => updateField('notes', e.target.value)}
              placeholder="Additional notes, allergens, substitutions, scaling considerations, etc."
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>

          {/* Error Display */}
          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <div className="flex items-start space-x-2">
                <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-red-800 dark:text-red-200">
                    Update Failed
                  </h3>
                  <p className="text-sm text-red-600 dark:text-red-300 mt-1">
                    {error}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-between">
            <button
              onClick={() => navigate(`/recipes/${id}`)}
              className="flex items-center space-x-2 px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Cancel</span>
            </button>
            
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors flex items-center space-x-2"
            >
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Save Changes</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
