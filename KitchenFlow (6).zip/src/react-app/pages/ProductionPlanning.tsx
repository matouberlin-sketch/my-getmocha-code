import { useState, useEffect } from 'react';
import { ChefHat, Layers, Plus, Calculator, ArrowRight } from 'lucide-react';

interface EnhancedRecipe {
  id: number;
  recipe_id: string;
  name: string;
  type: string;
  default_yield_qty: number;
  default_yield_uom: string;
  active_minutes: number;
  passive_minutes: number;
  lead_time_hours: number;
  station: string | null;
  components: any[];
  ingredients: any[];
}

interface PlannedDish {
  recipe: EnhancedRecipe;
  targetPortions: number;
  scaleFactor: number;
  serviceTime: Date;
}

export default function ProductionPlanning() {
  const [recipes, setRecipes] = useState<EnhancedRecipe[]>([]);
  const [plannedDishes, setPlannedDishes] = useState<PlannedDish[]>([]);
  const [loading, setLoading] = useState(true);
  const [serviceDate, setServiceDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [serviceTime, setServiceTime] = useState('12:30');

  useEffect(() => {
    const fetchRecipes = async () => {
      try {
        const response = await fetch('/api/enhanced-recipes?type=final');
        if (response.ok) {
          const data = await response.json();
          
          // Fetch detailed recipe data for each final dish
          const recipesWithDetails = await Promise.all(
            data.map(async (recipe: any) => {
              const detailResponse = await fetch(`/api/enhanced-recipes/${recipe.recipe_id}`);
              if (detailResponse.ok) {
                return await detailResponse.json();
              }
              return recipe;
            })
          );
          
          setRecipes(recipesWithDetails);
        }
      } catch (error) {
        console.error('Failed to fetch recipes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRecipes();
  }, []);

  // Calculate portions from recipe yield
  const calculatePortionsFromYield = (recipe: EnhancedRecipe) => {
    if (recipe.default_yield_uom.toLowerCase().includes('portion') || 
        recipe.default_yield_uom.toLowerCase().includes('serving')) {
      return recipe.default_yield_qty;
    } else if (recipe.default_yield_uom.toLowerCase().includes('tray') || 
               recipe.default_yield_uom.toLowerCase().includes('gn')) {
      let estimatedPortions = recipe.default_yield_qty * 36;
      if (recipe.default_yield_uom.toLowerCase().includes('1/2')) {
        estimatedPortions = recipe.default_yield_qty * 18;
      } else if (recipe.default_yield_uom.toLowerCase().includes('1/4')) {
        estimatedPortions = recipe.default_yield_qty * 9;
      }
      return estimatedPortions;
    } else if (recipe.default_yield_uom.toLowerCase().includes('kg') || 
               recipe.default_yield_uom.toLowerCase().includes('g')) {
      const grams = recipe.default_yield_uom.includes('kg') ? 
        recipe.default_yield_qty * 1000 : recipe.default_yield_qty;
      return Math.round(grams / 150);
    }
    return 25;
  };

  const addDishToPlan = (recipe: EnhancedRecipe, targetPortions: number) => {
    const serviceDateTime = new Date(`${serviceDate}T${serviceTime}`);
    const defaultPortions = calculatePortionsFromYield(recipe);
    const scaleFactor = targetPortions / defaultPortions;
    
    const plannedDish: PlannedDish = {
      recipe,
      targetPortions,
      scaleFactor,
      serviceTime: serviceDateTime
    };

    setPlannedDishes([...plannedDishes, plannedDish]);
  };

  const removeDishFromPlan = (index: number) => {
    setPlannedDishes(plannedDishes.filter((_, i) => i !== index));
  };

  // Generate production timeline
  const generateTimeline = () => {
    const timeline: any[] = [];
    
    plannedDishes.forEach((dish, dishIndex) => {
      const serviceDateTime = dish.serviceTime;
      
      // Add component preparation tasks
      dish.recipe.components?.forEach((component) => {
        const componentLeadTime = dish.recipe.lead_time_hours || 2;
        const startTime = new Date(serviceDateTime.getTime() - (componentLeadTime * 60 * 60 * 1000));
        
        timeline.push({
          id: `component-${dishIndex}-${component.component_recipe_id}`,
          type: 'component',
          dishName: dish.recipe.name,
          taskName: `Prepare ${component.component_name}`,
          componentName: component.component_name,
          quantity: Math.round((component.qty * dish.scaleFactor) * 100) / 100,
          unit: component.uom,
          startTime,
          station: 'prep', // Default station for components
          leadTime: componentLeadTime,
          scaleFactor: dish.scaleFactor
        });
      });
      
      // Add final assembly task
      const assemblyLeadTime = 0.5; // 30 minutes before service
      const assemblyStartTime = new Date(serviceDateTime.getTime() - (assemblyLeadTime * 60 * 60 * 1000));
      
      timeline.push({
        id: `final-${dishIndex}`,
        type: 'final',
        dishName: dish.recipe.name,
        taskName: `Final assembly: ${dish.recipe.name}`,
        quantity: dish.targetPortions,
        unit: 'portions',
        startTime: assemblyStartTime,
        serviceTime: serviceDateTime,
        station: dish.recipe.station || 'main',
        activeMinutes: Math.round(dish.recipe.active_minutes * Math.pow(dish.scaleFactor, 0.8)),
        passiveMinutes: Math.round(dish.recipe.passive_minutes * Math.pow(dish.scaleFactor, 0.7)),
        scaleFactor: dish.scaleFactor
      });
    });
    
    // Sort by start time
    return timeline.sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
  };

  const timeline = generateTimeline();

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false 
    });
  };

  const formatDuration = (minutes: number) => {
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}h${mins > 0 ? ` ${mins}m` : ''}`;
    }
    return `${minutes}m`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading recipes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Production Planning
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Plan your production timeline by selecting dishes and portions. The system calculates when to prepare components.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column - Service Planning */}
          <div className="space-y-6">
            {/* Service Details */}
            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Service Details
              </h2>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Service Date
                  </label>
                  <input
                    type="date"
                    value={serviceDate}
                    onChange={(e) => setServiceDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Service Time
                  </label>
                  <input
                    type="time"
                    value={serviceTime}
                    onChange={(e) => setServiceTime(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
              </div>
            </div>

            {/* Available Dishes */}
            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Available Dishes
              </h2>
              
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {recipes.map((recipe) => {
                  const defaultPortions = calculatePortionsFromYield(recipe);
                  
                  return (
                    <div key={recipe.id} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-gray-900 dark:text-gray-100">
                          {recipe.name}
                        </h3>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-500 dark:text-gray-400">
                            ~{defaultPortions} portions
                          </span>
                          {recipe.components?.length > 0 && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                              <Layers className="w-3 h-3 mr-1" />
                              {recipe.components.length} components
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          {recipe.station && (
                            <span className="mr-3">{recipe.station}</span>
                          )}
                          <span>{formatDuration(recipe.active_minutes + recipe.passive_minutes)}</span>
                          {recipe.lead_time_hours > 0 && (
                            <span className="ml-2 text-orange-600 dark:text-orange-400">
                              +{recipe.lead_time_hours}h prep
                            </span>
                          )}
                        </div>
                        
                        <button
                          onClick={() => {
                            const portions = prompt(`Enter portions for ${recipe.name}:`, defaultPortions.toString());
                            if (portions && !isNaN(parseInt(portions))) {
                              addDishToPlan(recipe, parseInt(portions));
                            }
                          }}
                          className="flex items-center space-x-1 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                          <span>Add</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Planned Dishes */}
            {plannedDishes.length > 0 && (
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                  Planned Menu
                </h2>
                
                <div className="space-y-3">
                  {plannedDishes.map((dish, index) => (
                    <div key={index} className="border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium text-gray-900 dark:text-gray-100">
                            {dish.recipe.name}
                          </h3>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {dish.targetPortions} portions
                            {dish.scaleFactor !== 1 && (
                              <span className="ml-2 text-orange-600 dark:text-orange-400">
                                ({(dish.scaleFactor * 100).toFixed(0)}% scale)
                              </span>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => removeDishFromPlan(index)}
                          className="text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 text-sm"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Production Timeline */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Production Timeline
            </h2>
            
            {timeline.length === 0 ? (
              <div className="text-center py-8">
                <Calculator className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400">
                  Add dishes to your menu to see the production timeline
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {timeline.map((task) => (
                  <div key={task.id} className={`border rounded-lg p-4 ${
                    task.type === 'component' 
                      ? 'border-purple-200 dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20'
                      : 'border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20'
                  }`}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                            task.type === 'component'
                              ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
                              : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                          }`}>
                            {task.type === 'component' ? (
                              <Layers className="w-3 h-3 mr-1" />
                            ) : (
                              <ChefHat className="w-3 h-3 mr-1" />
                            )}
                            {task.type}
                          </span>
                          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {formatTime(task.startTime)}
                          </span>
                        </div>
                        
                        <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-1">
                          {task.taskName}
                        </h3>
                        
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          <div className="flex items-center space-x-4">
                            <span>{task.quantity} {task.unit}</span>
                            <span>{task.station}</span>
                            {task.activeMinutes && (
                              <span>{formatDuration(task.activeMinutes + (task.passiveMinutes || 0))}</span>
                            )}
                          </div>
                          {task.scaleFactor !== 1 && (
                            <div className="text-xs text-orange-600 dark:text-orange-400 mt-1">
                              Scaled {(task.scaleFactor * 100).toFixed(0)}%
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {task.serviceTime && (
                        <div className="text-right">
                          <div className="text-sm text-gray-500 dark:text-gray-400">Service</div>
                          <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {formatTime(task.serviceTime)}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    {task.type === 'final' && (
                      <div className="flex items-center text-xs text-blue-600 dark:text-blue-400 mt-2">
                        <ArrowRight className="w-3 h-3 mr-1" />
                        Ready for service in {formatDuration((task.activeMinutes || 0) + (task.passiveMinutes || 0))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
