import { useState, useEffect } from 'react';
import { ChefHat, Search, Plus, Clock, Users, Package, Layers, AlertCircle, Calculator } from 'lucide-react';

interface EnhancedRecipe {
  id: number;
  recipe_id: string;
  name: string;
  type: string;
  default_yield_qty: number;
  default_yield_uom: string;
  output_item_id: string | null;
  active_minutes: number;
  passive_minutes: number;
  lead_time_hours: number;
  station: string | null;
  notes: string | null;
  ingredient_count: number;
  component_count: number;
  output_item_name: string | null;
  created_at: string;
  updated_at: string;
}

const typeColors: Record<string, string> = {
  prep: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  component: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  final: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
};

export default function EnhancedRecipes() {
  const [recipes, setRecipes] = useState<EnhancedRecipe[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [stationFilter, setStationFilter] = useState('');
  const [activeTab, setActiveTab] = useState<'recipes' | 'planning'>('recipes');

  const fetchRecipes = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (searchQuery) params.set('search', searchQuery);
      if (typeFilter) params.set('type', typeFilter);
      if (stationFilter) params.set('station', stationFilter);

      const response = await fetch(`/api/enhanced-recipes?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch enhanced recipes');
      }
      const data = await response.json();
      setRecipes(data);
    } catch (err) {
      console.error('Failed to fetch enhanced recipes:', err);
      setError('Failed to load enhanced recipes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecipes();
  }, [searchQuery, typeFilter, stationFilter]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchRecipes();
  };

  // Calculate portions per person for display
  const getPortionsPerPerson = (recipe: EnhancedRecipe) => {
    // Convert yield to a per-person basis
    if (recipe.default_yield_uom.toLowerCase().includes('portion') || 
        recipe.default_yield_uom.toLowerCase().includes('serving')) {
      return `${recipe.default_yield_qty} portions`;
    } else if (recipe.default_yield_uom.toLowerCase().includes('tray') || 
               recipe.default_yield_uom.toLowerCase().includes('gn')) {
      // Estimate portions from tray size
      let estimatedPortions = recipe.default_yield_qty * 36; // Default 1/1 GN = 36 portions
      if (recipe.default_yield_uom.toLowerCase().includes('1/2')) {
        estimatedPortions = recipe.default_yield_qty * 18;
      } else if (recipe.default_yield_uom.toLowerCase().includes('1/4')) {
        estimatedPortions = recipe.default_yield_qty * 9;
      }
      return `~${estimatedPortions} portions`;
    } else if (recipe.default_yield_uom.toLowerCase().includes('kg') || 
               recipe.default_yield_uom.toLowerCase().includes('g')) {
      // Estimate portions from weight (assuming ~150g per portion)
      const grams = recipe.default_yield_uom.includes('kg') ? 
        recipe.default_yield_qty * 1000 : recipe.default_yield_qty;
      const estimatedPortions = Math.round(grams / 150);
      return `~${estimatedPortions} portions`;
    }
    return `${recipe.default_yield_qty} ${recipe.default_yield_uom}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading production recipes...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">Error Loading Recipes</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
          <button
            onClick={fetchRecipes}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  const stations = [...new Set(recipes.map(recipe => recipe.station).filter(Boolean))];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                Production Recipes
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Manage batch recipes with scalable portions, components, and production planning
              </p>
            </div>
            <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors">
              <Plus className="w-4 h-4" />
              <span>Add Recipe</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-6">
          <button
            onClick={() => setActiveTab('recipes')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'recipes'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            <ChefHat className="w-4 h-4 inline mr-2" />
            Batch Recipes
          </button>
          <button
            onClick={() => setActiveTab('planning')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'planning'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            <Calculator className="w-4 h-4 inline mr-2" />
            Production Planning
          </button>
        </div>

        {activeTab === 'recipes' && (
          <>
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
                <div className="flex items-center">
                  <ChefHat className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Recipes</h3>
                    <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{recipes.length}</p>
                  </div>
                </div>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
                <div className="flex items-center">
                  <Layers className="w-8 h-8 text-green-600 dark:text-green-400" />
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Final Dishes</h3>
                    <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                      {recipes.filter(r => r.type === 'final').length}
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
                <div className="flex items-center">
                  <Package className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Components</h3>
                    <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                      {recipes.filter(r => r.type === 'component').length}
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
                <div className="flex items-center">
                  <Users className="w-8 h-8 text-orange-600 dark:text-orange-400" />
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Stations</h3>
                    <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{stations.length}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 mb-6">
              <div className="flex flex-wrap gap-4">
                <div className="flex-1 min-w-64">
                  <form onSubmit={handleSearch} className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <input
                      type="text"
                      placeholder="Search recipes..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </form>
                </div>
                <select
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value)}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                >
                  <option value="">All Types</option>
                  <option value="prep">Prep Components</option>
                  <option value="component">Recipe Components</option>
                  <option value="final">Final Dishes</option>
                </select>
                <select
                  value={stationFilter}
                  onChange={(e) => setStationFilter(e.target.value)}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                >
                  <option value="">All Stations</option>
                  {stations.map(station => (
                    <option key={station} value={station || ''}>{station}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Recipes List */}
            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
              {recipes.length === 0 ? (
                <div className="p-8 text-center">
                  <ChefHat className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">No recipes found</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {searchQuery || typeFilter || stationFilter ? 'Try adjusting your filters' : 'Import some recipes to get started'}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Recipe
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Type
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Batch Yield
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Station
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Time
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Complexity
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                      {recipes.map((recipe) => (
                        <tr key={recipe.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors cursor-pointer" onClick={() => window.location.href = `/enhanced-recipes/${recipe.recipe_id}`}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                {recipe.name}
                              </div>
                              <div className="text-sm text-gray-500 dark:text-gray-400">
                                ID: {recipe.recipe_id}
                              </div>
                              {recipe.output_item_name && (
                                <div className="text-xs text-blue-600 dark:text-blue-400">
                                  → {recipe.output_item_name}
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${typeColors[recipe.type] || 'bg-gray-100 text-gray-800'}`}>
                              {recipe.type === 'final' ? 'dish' : recipe.type}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 dark:text-gray-100">
                              <div className="font-medium">{getPortionsPerPerson(recipe)}</div>
                              <div className="text-xs text-gray-500 dark:text-gray-400">
                                {recipe.default_yield_qty} {recipe.default_yield_uom}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                            {recipe.station || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-1 text-sm text-gray-900 dark:text-gray-100">
                              <Clock className="w-3 h-3 text-gray-400" />
                              <span>{recipe.active_minutes + recipe.passive_minutes}m</span>
                              {recipe.lead_time_hours > 0 && (
                                <span className="text-xs text-orange-600 dark:text-orange-400">
                                  (+{recipe.lead_time_hours}h)
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-2">
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                                {recipe.ingredient_count} ingredients
                              </span>
                              {recipe.component_count > 0 && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                                  {recipe.component_count} components
                                </span>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === 'planning' && (
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8">
            <div className="text-center">
              <Calculator className="w-16 h-16 text-blue-600 dark:text-blue-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
                Production Planning
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-2xl mx-auto">
                Plan your production timeline by selecting final dishes and portions. 
                The system will automatically calculate when to prepare components and ingredients based on lead times.
              </p>
              
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6 max-w-2xl mx-auto">
                <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-3">
                  Coming Soon: Advanced Production Planning
                </h3>
                <div className="text-sm text-blue-800 dark:text-blue-200 space-y-2">
                  <p>• Select final dishes and adjust portion counts</p>
                  <p>• Automatic component timeline calculation</p>
                  <p>• Station workload balancing</p>
                  <p>• Ingredient ordering schedules</p>
                  <p>• Cost estimation and scaling</p>
                </div>
                
                <button className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors">
                  Request Early Access
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
