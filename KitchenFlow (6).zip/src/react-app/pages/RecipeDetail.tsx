import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ChefHat, 
  Clock, 
  Users, 
  ArrowLeft, 
  Edit, 
  Copy,
  Calculator,
  Layers,
  Tag,
  History,
  Printer,
  List,
  Package,
  Download,
  AlertTriangle,
  Activity,
  DollarSign
} from 'lucide-react';
import AddToPlannerModal from '@/react-app/components/AddToPlannerModal';
import PrintModal from '@/react-app/components/PrintModal';
import ShortlistToggle from '@/react-app/components/ShortlistToggle';


interface ScaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScale: (factor: number) => void;
  currentYield: number;
  yieldUnit: string;
}

function ScaleModal({ isOpen, onClose, onScale, currentYield, yieldUnit }: ScaleModalProps) {
  const [newYield, setNewYield] = useState(currentYield);
  const [scaleFactor, setScaleFactor] = useState(1);

  useEffect(() => {
    setScaleFactor(newYield / currentYield);
  }, [newYield, currentYield]);

  const handleScale = () => {
    onScale(scaleFactor);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-md w-full mx-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          Scale Recipe
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              New Yield Amount
            </label>
            <input
              type="number"
              min="0.1"
              step="0.1"
              value={newYield}
              onChange={(e) => setNewYield(parseFloat(e.target.value) || 1)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Original: {currentYield} {yieldUnit}
            </p>
          </div>
          
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-blue-900 dark:text-blue-100">
                Scale Factor:
              </span>
              <span className="text-lg font-bold text-blue-600 dark:text-blue-400">
                {scaleFactor.toFixed(2)}x
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3 mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleScale}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
          >
            Scale Recipe
          </button>
        </div>
      </div>
    </div>
  );
}

interface CookingTimelineProps {
  cookingSteps: any[];
  totalTimeMinutes: number;
}

function CookingTimeline({ cookingSteps, totalTimeMinutes }: CookingTimelineProps) {
  if (!cookingSteps || cookingSteps.length === 0) return null;

  const parseTimeToMinutes = (timeStr: string): number => {
    if (!timeStr) return 0;
    // Parse formats like "3 minutes", "2 hours", "1 hour 30 minutes", "25'"
    if (timeStr.includes("'")) {
      const match = timeStr.match(/(\d+)'(\d+)'?|(\d+)'/);
      if (match) {
        if (match[1] && match[2]) {
          return parseInt(match[1]) * 60 + parseInt(match[2]);
        } else if (match[3]) {
          return parseInt(match[3]);
        }
      }
    }
    
    const hourMatch = timeStr.match(/(\d+)\s*hour/i);
    const minuteMatch = timeStr.match(/(\d+)\s*minute/i);
    
    const hours = hourMatch ? parseInt(hourMatch[1]) : 0;
    const minutes = minuteMatch ? parseInt(minuteMatch[1]) : 0;
    
    return hours * 60 + minutes;
  };

  // Calculate timeline segments
  let currentTime = 0;
  const segments = cookingSteps.map((step, _) => {
    const duration = parseTimeToMinutes(step.duration);
    const startTime = currentTime;
    currentTime += duration;
    
    return {
      ...step,
      startTime,
      endTime: currentTime,
      duration
    };
  });

  const maxTime = Math.max(totalTimeMinutes, currentTime);

  const formatTimeForDisplay = (minutes: number): string => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h${mins}m` : `${hours}h`;
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4 mb-6">
      <div className="flex items-center space-x-2 mb-3">
        <Clock className="w-4 h-4 text-gray-600 dark:text-gray-400" />
        <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">
          Cooking Timeline
        </h3>
        <span className="text-xs text-gray-500 dark:text-gray-400">
          {formatTimeForDisplay(maxTime)} total
        </span>
      </div>

      {/* Timeline Steps - Compact Format */}
      <div className="space-y-1">
        {segments.map((segment, index) => (
          <div key={index} className="flex items-center text-sm">
            <div className="font-mono text-gray-500 dark:text-gray-400 w-12 text-xs">
              {formatTimeForDisplay(segment.startTime)}
            </div>
            <div className="flex-1 text-gray-900 dark:text-gray-100">
              <span className="font-medium">{segment.method}</span>
              {segment.equipment && <span className="text-gray-600 dark:text-gray-400"> on {segment.equipment}</span>}
              {segment.temperature && <span className="text-orange-600 dark:text-orange-400"> at {segment.temperature}</span>}
              {segment.duration > 0 && <span className="text-gray-500 dark:text-gray-400"> for {formatTimeForDisplay(segment.duration)}</span>}
              {segment.notes && <span className="text-gray-500 dark:text-gray-400 italic"> ({segment.notes})</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function RecipeDetail() {
  const { id, versionNumber } = useParams();
  const navigate = useNavigate();
  const [recipe, setRecipe] = useState<any>(null);
  const [scaledIngredients, setScaledIngredients] = useState<any[]>([]);
  const [currentScale, setCurrentScale] = useState(1);
  const [showScaleModal, setShowScaleModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'ingredients' | 'instructions' | 'suppliers' | 'allergens' | 'nutrition'>('ingredients');
  const [supplierData, setSupplierData] = useState<any>(null);
  const [supplierLoading, setSupplierLoading] = useState(false);
  const [allergenData, setAllergenData] = useState<any>(null);
  const [nutritionData, setNutritionData] = useState<any>(null);
  const [allergenLoading, setAllergenLoading] = useState(false);
  const [nutritionLoading, setNutritionLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [ingredientView, setIngredientView] = useState<'total' | 'steps'>('total');
  const [ingredientsByStep, setIngredientsByStep] = useState<any[]>([]);
  const [showAddToPlanner, setShowAddToPlanner] = useState(false);
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [versions, setVersions] = useState<any[]>([]);

  // Fetch recipe data from API (current version or specific version)
  useEffect(() => {
    const fetchRecipe = async () => {
      try {
        console.log('Fetching recipe with ID:', id, 'version:', versionNumber);
        
        let url = `/api/recipes/${id}`;
        if (versionNumber) {
          url = `/api/recipes/${id}/versions/${versionNumber}`;
        }
        
        console.log('API URL:', url);
        const response = await fetch(url);
        console.log('Response status:', response.status);
        
        if (response.ok) {
          const data = await response.json();
          console.log('Recipe data received:', data);
          setRecipe(data);
          setScaledIngredients(data.ingredients || []);
        } else {
          const errorText = await response.text();
          console.error('Recipe API error:', response.status, errorText);
          setRecipe(null);
        }
      } catch (error) {
        console.error('Failed to fetch recipe:', error);
        setRecipe(null);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchRecipe();
    } else {
      console.error('No recipe ID provided');
      setLoading(false);
    }
  }, [id, versionNumber]);

  // Fetch version history
  useEffect(() => {
    const fetchVersions = async () => {
      try {
        const response = await fetch(`/api/recipes/${id}/versions`);
        if (response.ok) {
          const data = await response.json();
          setVersions(data);
        }
      } catch (error) {
        console.error('Failed to fetch versions:', error);
      }
    };

    if (id) {
      fetchVersions();
    }
  }, [id]);

  const handleScale = async (scaleFactor: number) => {
    if (!recipe) return;
    
    try {
      // Scale ingredients
      const newIngredients = recipe.ingredients.map((ing: any) => ({
        ...ing,
        amount: (ing.amount * scaleFactor),
        weight_grams: ing.weight_grams ? Math.round(ing.weight_grams * scaleFactor) : null
      }));
      
      setScaledIngredients(newIngredients);
      setCurrentScale(scaleFactor);
      
      // Update yield
      setRecipe((prev: any) => ({
        ...prev,
        yield_amount: Math.round((prev.yield_amount * scaleFactor) * 10) / 10
      }));
      
    } catch (error) {
      console.error('Scaling error:', error);
    }
  };

  const handleCsvExport = async () => {
    try {
      const response = await fetch(`/api/recipe-csv/export?ids=${recipe.id}`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${recipe.name.replace(/[^a-zA-Z0-9]/g, '_')}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Failed to export CSV:', error);
    }
  };

  

  

  const formatTimeCompact = (minutes: number | null): string => {
    if (!minutes) return '0m';
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}h${mins > 0 ? `${mins}m` : ''}`;
    }
    return `${minutes}m`;
  };

  const handleIngredientClick = (ingredient: any) => {
    if (ingredient.ingredient_id) {
      navigate(`/ingredients/${ingredient.ingredient_id}`);
    } else if (ingredient.subrecipe_id) {
      navigate(`/recipes/${ingredient.subrecipe_id}`);
    }
  };

  // Function to organize ingredients by steps based on when they're mentioned in instructions
  const organizeIngredientsBySteps = () => {
    if (!recipe || !recipe.steps || !scaledIngredients) return [];

    const stepGroups: any[] = [];
    const usedIngredients = new Set<number>();

    // Create ingredient lookup by name (normalized)
    const ingredientLookup = new Map();
    scaledIngredients.forEach((ing, index) => {
      const names = [
        ing.ingredient_name?.toLowerCase(),
        ing.subrecipe_name?.toLowerCase(),
        // Add common variations
        ing.ingredient_name?.toLowerCase().replace(/s$/, ''), // singular
        ing.ingredient_name?.toLowerCase() + 's', // plural
      ].filter(Boolean);
      
      names.forEach(name => {
        if (!ingredientLookup.has(name)) {
          ingredientLookup.set(name, []);
        }
        ingredientLookup.get(name).push({ ...ing, originalIndex: index });
      });
    });

    // Process each step
    recipe.steps.forEach((step: any) => {
      const stepIngredients: any[] = [];
      const instruction = step.instruction.toLowerCase();

      // Find ingredients mentioned in this step
      for (const [ingredientName, ingredients] of ingredientLookup.entries()) {
        if (instruction.includes(ingredientName)) {
          ingredients.forEach((ingredient: any) => {
            if (!usedIngredients.has(ingredient.originalIndex)) {
              stepIngredients.push(ingredient);
              usedIngredients.add(ingredient.originalIndex);
            }
          });
        }
      }

      // Only add step if it has ingredients
      if (stepIngredients.length > 0) {
        stepGroups.push({
          stepNumber: step.step_number,
          instruction: step.instruction,
          ingredients: stepIngredients.sort((a, b) => a.originalIndex - b.originalIndex)
        });
      }
    });

    // Add any remaining ingredients to a "Preparation" step
    const remainingIngredients = scaledIngredients.filter((_, index) => !usedIngredients.has(index));
    if (remainingIngredients.length > 0) {
      stepGroups.unshift({
        stepNumber: 0,
        instruction: "Preparation and mise en place",
        ingredients: remainingIngredients
      });
    }

    return stepGroups;
  };

  // Update ingredients by step when recipe or scaling changes
  useEffect(() => {
    if (recipe && scaledIngredients.length > 0) {
      setIngredientsByStep(organizeIngredientsBySteps());
    }
  }, [recipe, scaledIngredients]);

  const fetchSupplierData = async () => {
    if (!id) return;
    
    try {
      setSupplierLoading(true);
      const response = await fetch(`/api/recipes/${id}/suppliers`);
      if (!response.ok) {
        throw new Error('Failed to fetch supplier data');
      }
      const data = await response.json();
      setSupplierData(data);
    } catch (err) {
      console.error('Failed to fetch supplier data:', err);
      setSupplierData(null);
    } finally {
      setSupplierLoading(false);
    }
  };

  const fetchAllergenData = async () => {
    if (!id) return;
    
    try {
      setAllergenLoading(true);
      const response = await fetch(`/api/recipes/${id}/allergens`);
      if (!response.ok) {
        throw new Error('Failed to fetch allergen data');
      }
      const data = await response.json();
      setAllergenData(data);
    } catch (err) {
      console.error('Failed to fetch allergen data:', err);
      setAllergenData(null);
    } finally {
      setAllergenLoading(false);
    }
  };

  const fetchNutritionData = async () => {
    if (!id) return;
    
    try {
      setNutritionLoading(true);
      const response = await fetch(`/api/recipes/${id}/nutrition`);
      if (!response.ok) {
        throw new Error('Failed to fetch nutrition data');
      }
      const data = await response.json();
      setNutritionData(data);
    } catch (err) {
      console.error('Failed to fetch nutrition data:', err);
      setNutritionData(null);
    } finally {
      setNutritionLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'suppliers' && id) {
      fetchSupplierData();
    } else if (activeTab === 'allergens' && id) {
      fetchAllergenData();
    } else if (activeTab === 'nutrition' && id) {
      fetchNutritionData();
    }
  }, [activeTab, id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!recipe) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">Recipe not found</h1>
          <button 
            onClick={() => navigate('/recipes')}
            className="text-blue-600 dark:text-blue-400 hover:underline"
          >
            Back to Recipes
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-5xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-start space-x-4 flex-1">
            <button 
              onClick={() => navigate('/recipes')}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors mt-1"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
            
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {recipe.name}
                </h1>
                {versionNumber && (
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-sm font-medium bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200">
                    Version {versionNumber}
                  </span>
                )}
              </div>
              
              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-3">
                {recipe.tags?.map((tag: string) => (
                  <span 
                    key={tag}
                    className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200"
                  >
                    <Tag className="w-3 h-3 mr-1" />
                    {tag}
                  </span>
                ))}
                {recipe.is_subrecipe && (
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                    <Layers className="w-3 h-3 mr-1" />
                    Sub-Recipe
                  </span>
                )}
              </div>

              {/* Compact Stats */}
              <div className="flex items-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center space-x-1">
                  <Users className="w-4 h-4" />
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {recipe.yield_amount} {recipe.yield_unit}
                  </span>
                  {currentScale !== 1 && (
                    <span className="text-blue-600 dark:text-blue-400">
                      ({currentScale.toFixed(1)}x)
                    </span>
                  )}
                </div>
                
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{formatTimeCompact(recipe.prep_time_minutes)}</span>
                  <span className="text-gray-400">prep</span>
                </div>
                
                <div className="flex items-center space-x-1">
                  <ChefHat className="w-4 h-4" />
                  <span>{formatTimeCompact(recipe.hands_on_minutes)}</span>
                  <span className="text-gray-400">active</span>
                </div>
              </div>

              {recipe.description && (
                <p className="text-gray-600 dark:text-gray-400 mt-2 text-sm">
                  {recipe.description}
                </p>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            <ShortlistToggle recipeId={recipe.id} size="md" />
            
            <button 
              onClick={() => setShowVersionHistory(true)}
              className="flex items-center space-x-2 px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors text-sm"
            >
              <History className="w-4 h-4" />
              <span>Versions</span>
            </button>
            
            <button 
              onClick={() => setShowPrintModal(true)}
              className="flex items-center space-x-2 px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors text-sm"
            >
              <Printer className="w-4 h-4" />
              <span>Print</span>
            </button>
            
            <button 
              onClick={handleCsvExport}
              className="flex items-center space-x-2 px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
            
            <button 
              onClick={handleCsvExport}
              className="flex items-center space-x-2 px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
            
            <button 
              onClick={() => setShowScaleModal(true)}
              className="flex items-center space-x-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm"
            >
              <Calculator className="w-4 h-4" />
              <span>Scale</span>
            </button>
            
            {!versionNumber && (
              <button 
                onClick={() => navigate(`/recipes/${recipe.id}/edit`)}
                className="flex items-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors text-sm"
              >
                <Edit className="w-4 h-4" />
                <span>Edit</span>
              </button>
            )}
            
            {versionNumber && (
              <button 
                onClick={() => navigate(`/recipes/${recipe.id}`)}
                className="flex items-center space-x-2 px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Current Version</span>
              </button>
            )}
          </div>
        </div>

        {/* Cooking Timeline */}
        <CookingTimeline 
          cookingSteps={recipe.cookingSteps || []} 
          totalTimeMinutes={recipe.prep_time_minutes || 0}
        />

        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-4">
          <button
            onClick={() => setActiveTab('ingredients')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'ingredients'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Ingredients ({scaledIngredients.length})
          </button>
          <button
            onClick={() => setActiveTab('instructions')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'instructions'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Instructions ({recipe.steps?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('suppliers')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'suppliers'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Suppliers & Costs
          </button>
          <button
            onClick={() => setActiveTab('allergens')}
            className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'allergens'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Allergens</span>
          </button>
          <button
            onClick={() => setActiveTab('nutrition')}
            className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'nutrition'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Nutrition</span>
          </button>
        </div>

        {/* Content */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
          {activeTab === 'ingredients' ? (
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                    Ingredients
                  </h2>
                  
                  {/* View Toggle */}
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setIngredientView('total')}
                      className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                        ingredientView === 'total'
                          ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
                      }`}
                    >
                      <List className="w-4 h-4" />
                      <span>Total</span>
                    </button>
                    
                    <button
                      onClick={() => setIngredientView('steps')}
                      className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                        ingredientView === 'steps'
                          ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
                      }`}
                    >
                      <Package className="w-4 h-4" />
                      <span>By Steps</span>
                    </button>
                  </div>
                </div>
                
                <button className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 flex items-center space-x-1">
                  <Copy className="w-4 h-4" />
                  <span>Copy List</span>
                </button>
              </div>
              
              {/* Ingredients Display */}
              {ingredientView === 'total' ? (
                <div className="space-y-2">
                  {scaledIngredients.map((ingredient, index) => {
                    const displayName = ingredient.subrecipe_id ? 
                      ingredient.subrecipe_name || ingredient.ingredient_name : 
                      ingredient.ingredient_name;
                    
                    const capitalizedName = displayName.charAt(0).toUpperCase() + displayName.slice(1);
                    
                    return (
                      <div 
                        key={index} 
                        className={`flex items-center py-2 px-3 rounded-lg transition-colors ${
                          ingredient.ingredient_id || ingredient.subrecipe_id 
                            ? 'hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer' 
                            : ''
                        }`}
                        onClick={() => handleIngredientClick(ingredient)}
                      >
                  {/* Combined Weight and Unit with precise spacing */}
                  <div className="flex items-baseline justify-end w-20 text-gray-900 dark:text-gray-100 mr-6">
                    {ingredient.weight_grams && displayName.toLowerCase() !== 'water' && (
                      <>
                        <span className="font-medium">
                          {ingredient.weight_grams}
                        </span>
                        <span className="text-gray-600 dark:text-gray-400 ml-2">g</span> {/* Adjust ml-1 for desired small gap */}
                      </>
                    )}
                  </div>
                        
                        {/* Ingredient name with proper spacing */}
                        <div className="flex-1 flex items-center">
                          <span className={`font-medium ${
                            ingredient.ingredient_id || ingredient.subrecipe_id 
                              ? 'text-gray-900 dark:text-gray-100 hover:text-gray-700 dark:hover:text-gray-300' 
                              : 'text-gray-900 dark:text-gray-100'
                          }`}>
                            {capitalizedName}
                          </span>
                          
                          {ingredient.notes && (
                            <span className="ml-3 text-xs text-gray-500 dark:text-gray-400 italic">
                              {ingredient.notes}
                            </span>
                          )}
                          
                          {ingredient.subrecipe_id && (
                            <span className="ml-3 inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                              <Layers className="w-3 h-3 mr-1" />
                              Sub
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="space-y-6">
                  {ingredientsByStep.map((stepGroup, stepIndex) => (
                    <div key={stepIndex} className="border border-gray-200 dark:border-gray-600 rounded-lg overflow-hidden">
                      {/* Step Header */}
                      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
                        <div className="flex items-start space-x-3">
                          <div className="flex-shrink-0 w-7 h-7 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center text-sm font-medium">
                            {stepGroup.stepNumber || 'P'}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900 dark:text-gray-100">
                              {stepGroup.stepNumber === 0 ? 'Preparation' : `Step ${stepGroup.stepNumber}`}
                            </h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              {stepGroup.instruction}
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Step Ingredients */}
                      <div className="p-4">
                        <div className="space-y-2">
                          {stepGroup.ingredients.map((ingredient: any, ingIndex: number) => {
                            const displayName = ingredient.subrecipe_id ? 
                              ingredient.subrecipe_name || ingredient.ingredient_name : 
                              ingredient.ingredient_name;
                            
                            const capitalizedName = displayName.charAt(0).toUpperCase() + displayName.slice(1);
                            
                            return (
                              <div 
                                key={ingIndex} 
                                className={`flex items-center py-2 px-3 rounded-lg transition-colors ${
                                  ingredient.ingredient_id || ingredient.subrecipe_id 
                                    ? 'hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer' 
                                    : ''
                                }`}
                                onClick={() => handleIngredientClick(ingredient)}
                              >
                                <div className="w-20 text-right font-medium text-gray-900 dark:text-gray-100">
                                  {ingredient.weight_grams && displayName.toLowerCase() !== 'water' ? 
                                    `${ingredient.weight_grams}` : ''
                                  }
                                </div>
                                <div className="text-left text-gray-600 dark:text-gray-400 mr-6">
                                  {ingredient.weight_grams && displayName.toLowerCase() !== 'water' ? 'g' : ''}
                                </div>
                                
                                <div className="flex-1 flex items-center">
                                  <span className={`font-medium ${
                                    ingredient.ingredient_id || ingredient.subrecipe_id 
                                      ? 'text-gray-900 dark:text-gray-100 hover:text-gray-700 dark:hover:text-gray-300' 
                                      : 'text-gray-900 dark:text-gray-100'
                                  }`}>
                                    {capitalizedName}
                                  </span>
                                  
                                  {ingredient.notes && (
                                    <span className="ml-3 text-xs text-gray-500 dark:text-gray-400 italic">
                                      {ingredient.notes}
                                    </span>
                                  )}
                                  
                                  {ingredient.subrecipe_id && (
                                    <span className="ml-3 inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                                      <Layers className="w-3 h-3 mr-1" />
                                      Sub
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {recipe.subRecipes?.length > 0 && (
                <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
                  <h3 className="flex items-center space-x-2 text-sm font-medium text-purple-900 dark:text-purple-100 mb-2">
                    <Layers className="w-4 h-4" />
                    <span>Sub-recipes to prepare first:</span>
                  </h3>
                  {recipe.subRecipes.map((sub: any) => (
                    <div key={sub.id} className="text-sm text-purple-700 dark:text-purple-300">
                      <button
                        onClick={() => navigate(`/recipes/${sub.id}`)}
                        className="hover:underline"
                      >
                        • {sub.name} (yields {sub.yield_amount} {sub.yield_unit})
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Instructions
              </h2>
              
              <div className="space-y-3">
                {recipe.steps.map((step: any) => (
                  <div key={step.step_number} className="flex items-start space-x-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg">
                    <div className="flex-shrink-0 w-7 h-7 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center text-sm font-medium">
                      {step.step_number}
                    </div>
                    <p className="text-gray-700 dark:text-gray-300 leading-relaxed flex-1 pt-1">
                      {step.instruction}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'allergens' && (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Allergen Information
              </h2>
              
              {allergenLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : allergenData ? (
                <div>
                  {allergenData.allergens && allergenData.allergens.length > 0 ? (
                    <div className="space-y-4">
                      <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400" />
                          <h3 className="font-medium text-red-900 dark:text-red-100">
                            Contains Allergens
                          </h3>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {allergenData.allergens.map((allergen: any, index: number) => (
                            <span 
                              key={index}
                              className="inline-flex items-center px-3 py-1.5 rounded-full text-sm font-medium bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 border border-red-200 dark:border-red-700"
                            >
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              {allergen.label || allergen.code}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        <p className="mb-2">
                          <strong>Important:</strong> This allergen information is based on the ingredients used in this recipe.
                        </p>
                        <ul className="list-disc list-inside space-y-1 text-xs">
                          <li>Cross-contamination may occur during preparation</li>
                          <li>Always verify with suppliers for processed ingredients</li>
                          <li>Check labels on all packaged items</li>
                          <li>Review preparation environment for allergen safety</li>
                        </ul>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-5 h-5 bg-green-600 dark:bg-green-400 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                        <h3 className="font-medium text-green-900 dark:text-green-100">
                          No Known Allergens
                        </h3>
                      </div>
                      <p className="text-sm text-green-700 dark:text-green-300 mt-2">
                        This recipe does not contain any ingredients with registered allergen information. Always verify with ingredient suppliers.
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <AlertTriangle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">Failed to load allergen data</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'nutrition' && (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Nutritional Information
              </h2>
              
              {nutritionLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : nutritionData ? (
                <div className="space-y-6">
                  <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                    <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-3">
                      Per Portion ({recipe.yield_unit})
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                          {nutritionData.per_portion?.kcal_per_portion || 0}
                        </div>
                        <div className="text-sm text-blue-700 dark:text-blue-300">kcal</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                          {nutritionData.per_portion?.protein_g_per_portion || 0}g
                        </div>
                        <div className="text-sm text-green-700 dark:text-green-300">Protein</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                          {nutritionData.per_portion?.carbs_g_per_portion || 0}g
                        </div>
                        <div className="text-sm text-orange-700 dark:text-orange-300">Carbs</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                          {nutritionData.per_portion?.fat_g_per_portion || 0}g
                        </div>
                        <div className="text-sm text-purple-700 dark:text-purple-300">Fat</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    <p className="mb-2">
                      <strong>Note:</strong> Nutritional values are calculated based on ingredient data and may vary.
                    </p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>Values are estimates based on ingredient nutritional profiles</li>
                      <li>Cooking methods may affect final nutritional content</li>
                      <li>Some ingredients may not have complete nutritional data</li>
                      <li>Consult a nutritionist for precise dietary requirements</li>
                    </ul>
                  </div>
                  
                  {(nutritionData.per_portion?.kcal_per_portion === 0 && 
                    nutritionData.per_portion?.protein_g_per_portion === 0 &&
                    nutritionData.per_portion?.carbs_g_per_portion === 0 &&
                    nutritionData.per_portion?.fat_g_per_portion === 0) && (
                    <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
                      <div className="flex items-center space-x-2">
                        <Activity className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                        <h3 className="font-medium text-amber-900 dark:text-amber-100">
                          Limited Nutritional Data
                        </h3>
                      </div>
                      <p className="text-sm text-amber-700 dark:text-amber-300 mt-2">
                        Nutritional information is not available for all ingredients in this recipe. Consider adding nutritional data to individual ingredients for more accurate calculations.
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">Failed to load nutrition data</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'suppliers' && (
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Supplier Matrix & Costing
                </h2>
                {supplierData?.per_portion_cost && (
                  <div className="bg-green-100 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg px-4 py-2">
                    <div className="text-center">
                      <div className="text-sm text-green-600 dark:text-green-400 font-medium">
                        Per Portion Cost
                      </div>
                      <div className="text-lg font-bold text-green-700 dark:text-green-300">
                        €{supplierData.per_portion_cost.toFixed(3)}
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              {supplierLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : supplierData ? (
                <div className="space-y-6">
                  {supplierData.items && supplierData.items.length > 0 ? (
                    <div className="space-y-4">
                      {supplierData.items.map((item: any, index: number) => (
                        <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                          <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
                            <div className="flex items-center justify-between">
                              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                                {item.name}
                              </h3>
                              <div className="text-sm text-gray-600 dark:text-gray-400">
                                {item.per_portion_qty?.toFixed(3)} {item.base_uom} per portion
                              </div>
                            </div>
                          </div>
                          
                          <div className="p-4">
                            {item.suppliers && item.suppliers.length > 0 ? (
                              <div className="overflow-x-auto">
                                <table className="w-full">
                                  <thead className="bg-gray-50 dark:bg-gray-800">
                                    <tr>
                                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Supplier
                                      </th>
                                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Unit Cost
                                      </th>
                                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Per Portion
                                      </th>
                                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Status
                                      </th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                    {item.suppliers.map((supplier: any, supplierIndex: number) => (
                                      <tr key={supplierIndex} className={`${supplier.preferred ? 'bg-green-50 dark:bg-green-900/20' : 'hover:bg-gray-50 dark:hover:bg-gray-700'}`}>
                                        <td className="px-3 py-3 text-sm font-medium text-gray-900 dark:text-gray-100">
                                          {supplier.name}
                                        </td>
                                        <td className="px-3 py-3 text-sm text-gray-900 dark:text-gray-100">
                                          €{supplier.unit_cost?.toFixed(4) || '0.0000'} / {item.base_uom}
                                        </td>
                                        <td className="px-3 py-3 text-sm text-gray-900 dark:text-gray-100">
                                          €{(supplier.unit_cost * item.per_portion_qty)?.toFixed(4) || '0.0000'}
                                        </td>
                                        <td className="px-3 py-3 text-sm">
                                          {supplier.preferred ? (
                                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                                              Preferred
                                            </span>
                                          ) : (
                                            <span className="text-gray-500 dark:text-gray-400">Alternative</span>
                                          )}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            ) : (
                              <div className="text-center py-4">
                                <p className="text-gray-500 dark:text-gray-400 text-sm">No suppliers found</p>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 dark:text-gray-400">No ingredient supplier data found</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">Failed to load supplier data</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Notes */}
        {recipe.notes && (
          <div className="mt-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
            <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">Notes</h3>
            <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
              {recipe.notes}
            </p>
          </div>
        )}
      </div>

      <ScaleModal
        isOpen={showScaleModal}
        onClose={() => setShowScaleModal(false)}
        onScale={handleScale}
        currentYield={recipe.yield_amount / currentScale} // Original yield
        yieldUnit={recipe.yield_unit}
      />

      <AddToPlannerModal
        isOpen={showAddToPlanner}
        onClose={() => setShowAddToPlanner(false)}
        recipe={{
          id: recipe.id,
          name: recipe.name,
          yield_amount: recipe.yield_amount,
          yield_unit: recipe.yield_unit
        }}
        onSuccess={() => {
          // Could add a toast notification here
          console.log('Recipe added to planner successfully');
        }}
      />

      <PrintModal
        isOpen={showPrintModal}
        onClose={() => setShowPrintModal(false)}
        recipe={{
          id: recipe.id,
          name: recipe.name,
          yield_amount: recipe.yield_amount,
          yield_unit: recipe.yield_unit
        }}
      />

      {/* Version History Modal */}
      {showVersionHistory && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Version History
              </h3>
              <button
                onClick={() => setShowVersionHistory(false)}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <span className="sr-only">Close</span>
                ×
              </button>
            </div>
            
            <div className="space-y-3">
              {versions.length === 0 ? (
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                  No version history yet. Versions are created when you edit and save recipes.
                </p>
              ) : (
                versions.map((version: any) => (
                  <div 
                    key={version.id}
                    className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            Version {version.version_number}
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {new Date(version.created_at).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </span>
                          {version.usage_count > 0 && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
                              Used in {version.usage_count} production{version.usage_count !== 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          <p className="font-medium">{version.name}</p>
                          {version.description && (
                            <p className="mt-1">{version.description}</p>
                          )}
                          <p className="mt-1">
                            Yield: {version.yield_amount} {version.yield_unit}
                            {version.prep_time_minutes && (
                              <span className="ml-3">
                                Prep: {version.prep_time_minutes}min
                              </span>
                            )}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          navigate(`/recipes/${recipe.id}/versions/${version.version_number}`);
                          setShowVersionHistory(false);
                        }}
                        className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        View
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
            
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowVersionHistory(false)}
                className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
