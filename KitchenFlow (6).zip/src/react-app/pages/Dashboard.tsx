import { ChefHat, Calendar, Plus, CalendarDays, List, Package, Database, TrendingUp, Users } from 'lucide-react';
import DashboardCard from '@/react-app/components/DashboardCard';
import QuickAction from '@/react-app/components/QuickAction';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';

interface DashboardStats {
  enhancedRecipes: number;
  items: number;
  suppliers: number;
  upcomingMeals: number;
  totalPortions: number;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats>({
    enhancedRecipes: 0,
    items: 0,
    suppliers: 0,
    upcomingMeals: 0,
    totalPortions: 0
  });
  const [loading, setLoading] = useState(true);
  
  // Generate week dates starting from Monday
  const getWeekDates = () => {
    const today = new Date();
    const monday = new Date(today);
    const dayOfWeek = today.getDay();
    const daysFromMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
    monday.setDate(today.getDate() + daysFromMonday);
    
    return Array.from({ length: 7 }, (_, i) => {
      const date = new Date(monday);
      date.setDate(monday.getDate() + i);
      return date;
    });
  };

  const weekDates = getWeekDates();

  // Fetch dashboard stats
  useEffect(() => {
    const fetchStats = async () => {
      try {
        // Fetch enhanced recipes count
        const recipesResponse = await fetch('/api/enhanced-recipes');
        const recipes = recipesResponse.ok ? await recipesResponse.json() : [];

        // Fetch items count
        const itemsResponse = await fetch('/api/items');
        const items = itemsResponse.ok ? await itemsResponse.json() : [];

        // Fetch planned meals for the week
        const startDate = weekDates[0].toISOString().split('T')[0];
        const endDate = weekDates[6].toISOString().split('T')[0];
        const mealsResponse = await fetch(`/api/planned-meals?date_from=${startDate}&date_to=${endDate}`);
        const meals = mealsResponse.ok ? await mealsResponse.json() : [];

        // Calculate supplier count from items
        const supplierCount = new Set(
          items.filter((item: any) => item.supplier_count > 0)
            .map((item: any) => item.supplier_count)
        ).size;

        setStats({
          enhancedRecipes: recipes.length,
          items: items.length,
          suppliers: supplierCount,
          upcomingMeals: meals.length,
          totalPortions: meals.reduce((total: number, meal: any) => 
            total + (meal.total_portions || meal.portion_count || 0), 0)
        });
      } catch (error) {
        console.error('Failed to fetch dashboard stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  // Mock upcoming production data - this would come from enhanced recipes
  const upcomingProduction = [
    { type: 'prep', name: 'Curry Paste Base', station: 'Prep Kitchen', due: '9:00 AM', portions: 50 },
    { type: 'component', name: 'Thai Jasmine Rice', station: 'Hot Kitchen', due: '11:30 AM', portions: 80 },
    { type: 'final', name: 'Green Curry Chicken', station: 'Hot Kitchen', due: '12:00 PM', portions: 65 },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Production Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
        </div>

        {/* System Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 md:gap-6 mb-8">
          <DashboardCard
            title="Production Recipes"
            value={loading ? '...' : stats.enhancedRecipes}
            subtitle="with components & costs"
            icon={<ChefHat className="w-5 h-5" />}
          />
          
          <DashboardCard
            title="Items Catalog"
            value={loading ? '...' : stats.items}
            subtitle="raw materials & components"
            icon={<Package className="w-5 h-5" />}
          />
          
          <DashboardCard
            title="Active Suppliers"
            value={loading ? '...' : stats.suppliers}
            subtitle="with current pricing"
            icon={<Users className="w-5 h-5" />}
          />

          <DashboardCard
            title="Week's Meals"
            value={loading ? '...' : stats.upcomingMeals}
            subtitle="planned production runs"
            icon={<Calendar className="w-5 h-5" />}
          />

          <DashboardCard
            title="Total Portions"
            value={loading ? '...' : stats.totalPortions}
            subtitle="this week's volume"
            icon={<TrendingUp className="w-5 h-5" />}
          />
        </div>

        {/* Today's Production Queue */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
              Today's Production Queue
            </h2>
            <button 
              onClick={() => navigate('/make-sheet')}
              className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
            >
              View Full Make Sheet
            </button>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
            {upcomingProduction.length === 0 ? (
              <div className="p-8 text-center">
                <ChefHat className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                  No Production Scheduled
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Plan meals to generate production schedules from your enhanced recipes.
                </p>
                <button 
                  onClick={() => navigate('/planner')}
                  className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Plan Today's Meals
                </button>
              </div>
            ) : (
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {upcomingProduction.map((item, index) => (
                  <div key={index} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${
                          item.type === 'prep' ? 'bg-blue-500' :
                          item.type === 'component' ? 'bg-purple-500' : 'bg-green-500'
                        }`} />
                        <div>
                          <h3 className="font-medium text-gray-900 dark:text-gray-100">
                            {item.name}
                          </h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {item.station} • {item.portions} portions
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-gray-900 dark:text-gray-100">
                          {item.due}
                        </div>
                        <div className={`text-xs font-medium ${
                          item.type === 'prep' ? 'text-blue-600' :
                          item.type === 'component' ? 'text-purple-600' : 'text-green-600'
                        }`}>
                          {item.type.toUpperCase()}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Quick Actions
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <QuickAction
              icon={<Plus className="w-5 h-5" />}
              title="Create Recipe"
              description="Add new production recipe with components"
              onClick={() => navigate('/enhanced-recipes')}
              variant="primary"
            />
            
            <QuickAction
              icon={<CalendarDays className="w-5 h-5" />}
              title="Plan Production"
              description="Schedule meals using enhanced recipes"
              onClick={() => navigate('/planner')}
            />
            
            <QuickAction
              icon={<Database className="w-5 h-5" />}
              title="Import ERP Data"
              description="Upload recipes, items, and suppliers"
              onClick={() => navigate('/erp-import')}
            />
            
            <QuickAction
              icon={<List className="w-5 h-5" />}
              title="Today's Make Sheet" 
              description="Production schedule and prep lists"
              onClick={() => navigate('/make-sheet')}
            />
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">
            System Overview
          </h2>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <Database className="w-8 h-8 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
                <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-1">
                  Production Recipe System
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Professional recipes with components, yields, and cost tracking
                </p>
              </div>
              
              <div className="text-center">
                <Package className="w-8 h-8 text-green-600 dark:text-green-400 mx-auto mb-2" />
                <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-1">
                  Items & Supply Chain
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Complete item catalog with supplier pricing and conversions
                </p>
              </div>
              
              <div className="text-center">
                <TrendingUp className="w-8 h-8 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
                <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-1">
                  Production Planning
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Automated scheduling and cost calculations
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
