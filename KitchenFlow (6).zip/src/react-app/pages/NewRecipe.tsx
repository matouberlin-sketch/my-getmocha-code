import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link as LinkIcon, Type, Loader2, Plus, X, Layers, Check, Wand2, Edit3, ArrowRight, ArrowLeft, FileText } from 'lucide-react';
import { convertToWeight } from '@/shared/utils/weightConversion';
import CookingSection from '@/react-app/components/CookingSection';
import TagInput from '@/react-app/components/TagInput';
import IngredientAutocomplete from '@/react-app/components/IngredientAutocomplete';

interface RecipePreviewProps {
  previewData: any;
  onEdit: (data: any) => void;
  onConfirm: () => void;
  onBack: () => void;
  isLoading: boolean;
  error?: string;
}

function RecipePreview({ previewData, onEdit, onConfirm, onBack, isLoading, error }: RecipePreviewProps) {
  const [editingData, setEditingData] = useState(previewData);

  const updateField = (field: string, value: any) => {
    const updated = { ...editingData, [field]: value };
    setEditingData(updated);
    onEdit(updated);
  };

  const updateIngredient = (index: number, field: string, value: string, ingredientData?: any) => {
    const updatedIngredients = editingData.ingredients.map((ing: any, i: number) => {
      if (i === index) {
        let updatedIng = { ...ing, [field]: value };
        
        // Handle ingredient selection from autocomplete
        if (field === 'ingredient_name' && ingredientData) {
          if (ingredientData.isSubRecipe) {
            updatedIng = {
              ...updatedIng,
              ingredient_id: ingredientData.id,
              subrecipe_id: ingredientData.id,
              is_subrecipe: true,
              unit: updatedIng.unit || 'portion',
              grams_per_piece: undefined
            };
          } else if (ingredientData.isNewIngredient) {
            updatedIng = {
              ...updatedIng,
              ingredient_id: undefined,
              subrecipe_id: undefined,
              is_subrecipe: false,
              grams_per_piece: undefined
            };
          } else {
            updatedIng = {
              ...updatedIng,
              ingredient_id: ingredientData.id,
              subrecipe_id: undefined,
              is_subrecipe: false,
              grams_per_piece: ingredientData.grams_per_piece
            };
            
            // Auto-fill unit based on ingredient type if no unit is set
            if (!updatedIng.unit) {
              if (ingredientData.unit_type === 'weight') updatedIng.unit = 'g';
              else if (ingredientData.unit_type === 'volume') updatedIng.unit = 'ml';
              else if (ingredientData.unit_type === 'count') updatedIng.unit = 'piece';
            }
          }
        }
        
        // Recalculate weight when amount, unit, or ingredient changes
        if (field === 'amount' || field === 'unit' || field === 'ingredient_name') {
          const weightResult = convertToWeight(
            parseFloat(updatedIng.amount) || 0,
            updatedIng.unit,
            updatedIng.ingredient_name,
            updatedIng.grams_per_piece
          );
          updatedIng.weight_grams = weightResult.weight_grams === null ? undefined : weightResult.weight_grams;
        }
        
        return updatedIng;
      }
      return ing;
    });
    
    updateField('ingredients', updatedIngredients);
  };

  const addIngredient = () => {
    const newIngredients = [...editingData.ingredients, {
      ingredient_name: '',
      amount: '',
      unit: '',
      notes: '',
      weight_grams: undefined,
      ingredient_id: undefined,
      subrecipe_id: undefined,
      is_subrecipe: false,
      grams_per_piece: undefined
    }];
    updateField('ingredients', newIngredients);
  };

  const removeIngredient = (index: number) => {
    if (editingData.ingredients.length > 1) {
      const newIngredients = editingData.ingredients.filter((_: any, i: number) => i !== index);
      updateField('ingredients', newIngredients);
    }
  };

  const updateStep = (index: number, instruction: string) => {
    const updatedSteps = editingData.steps.map((step: any, i: number) => 
      i === index ? { ...step, instruction } : step
    );
    updateField('steps', updatedSteps);
  };

  const addStep = () => {
    const newSteps = [...editingData.steps, { instruction: '' }];
    updateField('steps', newSteps);
  };

  const removeStep = (index: number) => {
    if (editingData.steps.length > 1) {
      const newSteps = editingData.steps.filter((_: any, i: number) => i !== index);
      updateField('steps', newSteps);
    }
  };

  const updateCookingSteps = (cookingSteps: any[]) => {
    updateField('cookingSteps', cookingSteps);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <button
              onClick={onBack}
              className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Import</span>
            </button>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Preview & Edit Recipe
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Review the AI analysis and make any changes before creating the recipe
          </p>
        </div>

        <div className="space-y-6">
          {/* Basic Information */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Edit3 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Basic Information
              </h2>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Recipe Name *
                </label>
                <input
                  type="text"
                  required
                  value={editingData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Description
                </label>
                <textarea
                  value={editingData.description}
                  onChange={(e) => updateField('description', e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Yield Amount *
                  </label>
                  <input
                    type="number"
                    required
                    min="0.1"
                    step="0.1"
                    value={editingData.yield_amount}
                    onChange={(e) => updateField('yield_amount', parseFloat(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Yield Unit *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingData.yield_unit}
                    onChange={(e) => updateField('yield_unit', e.target.value)}
                    placeholder="servings, kg, etc."
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Prep Time (min)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={editingData.prep_time_minutes}
                    onChange={(e) => updateField('prep_time_minutes', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Hands-On (min)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={editingData.hands_on_minutes}
                    onChange={(e) => updateField('hands_on_minutes', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
              </div>

              {/* Tags */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Tags (AI Generated)
                </label>
                <TagInput 
                  tags={editingData.tags || []}
                  onTagsChange={(tags) => updateField('tags', tags)}
                />
              </div>
            </div>
          </div>

          {/* Ingredients */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Edit3 className="w-5 h-5 text-green-600 dark:text-green-400" />
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Ingredients (AI Parsed)
                </h2>
              </div>
              <button
                type="button"
                onClick={addIngredient}
                className="flex items-center space-x-1 text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
              >
                <Plus className="w-4 h-4" />
                <span>Add</span>
              </button>
            </div>

            <div className="space-y-3">
              {editingData.ingredients.map((ingredient: any, index: number) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-2 items-end">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Amount
                    </label>
                    <input
                      type="text"
                      value={ingredient.amount}
                      onChange={(e) => updateIngredient(index, 'amount', e.target.value)}
                      placeholder="1.5"
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Unit
                    </label>
                    <select
                      value={ingredient.unit}
                      onChange={(e) => updateIngredient(index, 'unit', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    >
                      <option value="">Select unit</option>
                      <optgroup label="Weight">
                        <option value="kg">kg</option>
                        <option value="g">g</option>
                        <option value="lb">lb</option>
                        <option value="oz">oz</option>
                      </optgroup>
                      <optgroup label="Volume">
                        <option value="l">l</option>
                        <option value="ml">ml</option>
                        <option value="cup">cup</option>
                        <option value="tbsp">tbsp</option>
                        <option value="tsp">tsp</option>
                        <option value="fl oz">fl oz</option>
                      </optgroup>
                      <optgroup label="Count">
                        <option value="piece">piece</option>
                        <option value="clove">clove</option>
                        <option value="large">large</option>
                        <option value="medium">medium</option>
                        <option value="small">small</option>
                        <option value="whole">whole</option>
                        <option value="bunch">bunch</option>
                        <option value="can">can</option>
                      </optgroup>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Ingredient
                    </label>
                    <IngredientAutocomplete
                      value={ingredient.ingredient_name}
                      onChange={(value, data) => updateIngredient(index, 'ingredient_name', value, data)}
                      placeholder="Search ingredients..."
                      className="text-sm"
                    />
                    <div className="mt-1 text-xs">
                      {ingredient.weight_grams && ingredient.weight_grams > 0 && (
                        <span className="text-gray-600 dark:text-gray-400">
                          {ingredient.weight_grams < 1000 
                            ? `${ingredient.weight_grams}g` 
                            : `${(ingredient.weight_grams / 1000).toFixed(1)}kg`
                          }
                        </span>
                      )}
                      {ingredient.is_subrecipe && (
                        <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                          <Layers className="w-3 h-3 mr-1" />
                          Sub-Recipe
                        </span>
                      )}
                      {ingredient.ingredient_id && (
                        <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                          <Check className="w-3 h-3 mr-1" />
                          Found in DB
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={ingredient.notes}
                      onChange={(e) => updateIngredient(index, 'notes', e.target.value)}
                      placeholder="Notes (optional)"
                      className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    />
                    {editingData.ingredients.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeIngredient(index)}
                        className="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cooking Method */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Edit3 className="w-5 h-5 text-orange-600 dark:text-orange-400" />
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Cooking Method (AI Detected)
              </h2>
            </div>
            
            <CookingSection 
              cookingSteps={editingData.cookingSteps || []}
              onUpdateCookingSteps={updateCookingSteps}
            />
          </div>

          {/* Instructions */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Edit3 className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Instructions
                </h2>
              </div>
              <button
                type="button"
                onClick={addStep}
                className="flex items-center space-x-1 text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
              >
                <Plus className="w-4 h-4" />
                <span>Add Step</span>
              </button>
            </div>

            <div className="space-y-4">
              {editingData.steps.map((step: any, index: number) => (
                <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <textarea
                        value={step.instruction}
                        onChange={(e) => updateStep(index, e.target.value)}
                        placeholder="Describe this step..."
                        rows={2}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                      />
                    </div>
                    {editingData.steps.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeStep(index)}
                        className="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Edit3 className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Notes
              </h2>
            </div>
            <textarea
              value={editingData.notes}
              onChange={(e) => updateField('notes', e.target.value)}
              placeholder="Additional notes, allergens, substitutions, scaling considerations, etc."
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>

          {/* Error Display */}
          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <div className="flex items-start space-x-2">
                <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-red-800 dark:text-red-200">
                    Recipe Creation Failed
                  </h3>
                  <p className="text-sm text-red-600 dark:text-red-300 mt-1">
                    {error}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-between">
            <button
              onClick={onBack}
              className="flex items-center space-x-2 px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Import</span>
            </button>
            
            <button
              onClick={onConfirm}
              disabled={isLoading}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors flex items-center space-x-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Creating Recipe...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Create Recipe</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function NewRecipe() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'import' | 'preview'>('import');
  const [mode, setMode] = useState<'url' | 'manual' | 'document'>('url');
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [previewData, setPreviewData] = useState<any>(null);
  const [finalData, setFinalData] = useState<any>(null);

  // Manual entry form for when no URL is provided
  const [manualData, setManualData] = useState({
    name: '',
    description: '',
    yield_amount: 4,
    yield_unit: 'servings',
    prep_time_minutes: '',
    hands_on_minutes: '',
    notes: '',
    tags: [] as string[],
    ingredients: [{ 
      ingredient_name: '', 
      amount: '', 
      unit: '', 
      notes: '', 
      weight_grams: undefined as number | undefined,
      ingredient_id: undefined as number | undefined,
      subrecipe_id: undefined as number | undefined,
      is_subrecipe: false,
      grams_per_piece: undefined as number | undefined
    }],
    steps: [{ instruction: '' }],
    cookingSteps: [{ equipment: '', method: '', temperature: '', duration: '', notes: '' }]
  });

  const handleScrapeUrl = async () => {
    if (!url.trim()) {
      setError('Please enter a valid URL');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('/api/recipes/scrape', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: url.trim() }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to scrape recipe');
      }

      // Enhanced data processing - match ingredients against database
      const enhancedData = await enhanceRecipeData(data);
      
      setPreviewData(enhancedData);
      setFinalData(enhancedData);
      setStep('preview');
      
    } catch (err) {
      console.error('Recipe scraping error:', err);
      
      // Handle different error types for scraping
      let errorMessage = 'Failed to scrape recipe';
      
      if (err instanceof Error) {
        errorMessage = err.message;
        
        // Add specific help for quota errors
        if (errorMessage.includes('quota exceeded')) {
          errorMessage += '\n\nThis feature uses OpenAI for recipe analysis. Please check your OpenAI usage and billing, or try again later.';
        }
      } else if (typeof err === 'string') {
        errorMessage = err;
      } else if (err && typeof err === 'object') {
        if ('error' in err && typeof err.error === 'string') {
          errorMessage = err.error;
        } else if ('message' in err && typeof err.message === 'string') {
          errorMessage = err.message;
        } else if ('details' in err && typeof err.details === 'string') {
          errorMessage = err.details;
        } else {
          // Extract any useful information from the error object
          const keys = Object.keys(err);
          if (keys.length > 0) {
            const firstKey = keys[0];
            const firstValue = (err as any)[firstKey];
            if (typeof firstValue === 'string') {
              errorMessage = firstValue;
            } else {
              errorMessage = `Scraping error: ${JSON.stringify(err, null, 2)}`;
            }
          } else {
            errorMessage = 'Unable to extract recipe data from the provided URL';
          }
        }
      }
      
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const enhanceRecipeData = async (data: any) => {
    try {
      // Fetch existing ingredients to match against
      const ingredientsResponse = await fetch('/api/ingredients');
      const existingIngredients = ingredientsResponse.ok ? await ingredientsResponse.json() : [];
      
      // Enhanced ingredient matching and validation
      const enhancedIngredients = await Promise.all(
        data.ingredients.map(async (ing: any) => {
          // Find matching ingredient in database
          const match = findBestIngredientMatch(ing.ingredient_name, existingIngredients);
          
          return {
            ...ing,
            ingredient_id: match ? match.id : undefined,
            grams_per_piece: match ? match.grams_per_piece : undefined,
            matched_name: match ? match.name : ing.ingredient_name,
            is_database_match: !!match,
            weight_grams: ing.weight_grams || null
          };
        })
      );

      // Enhanced tag generation with context
      const enhancedTags = await generateEnhancedTags(data, enhancedIngredients);

      return {
        ...data,
        ingredients: enhancedIngredients,
        tags: enhancedTags,
        notes: data.notes ? `${data.notes}\n\nSource: ${url}` : `Source: ${url}`,
        cookingSteps: data.cookingSteps || []
      };
    } catch (error) {
      console.error('Failed to enhance recipe data:', error);
      return data;
    }
  };

  const findBestIngredientMatch = (ingredientName: string, existingIngredients: any[]) => {
    const cleanName = ingredientName.toLowerCase().trim();
    
    // Exact match
    let match = existingIngredients.find(ing => 
      ing.name.toLowerCase() === cleanName
    );
    
    if (match) return match;
    
    // Partial match - ingredient name contains existing ingredient
    match = existingIngredients.find(ing => 
      cleanName.includes(ing.name.toLowerCase()) || 
      ing.name.toLowerCase().includes(cleanName)
    );
    
    if (match) return match;
    
    // Fuzzy matching for common variations
    const variations = {
      'onions': 'onion',
      'tomatoes': 'tomato', 
      'potatoes': 'potato',
      'carrots': 'carrot',
      'eggs': 'egg',
      'mushrooms': 'mushroom'
    };
    
    const variation = variations[cleanName as keyof typeof variations];
    if (variation) {
      match = existingIngredients.find(ing => 
        ing.name.toLowerCase() === variation
      );
    }
    
    return match;
  };

  const generateEnhancedTags = async (recipeData: any, ingredients: any[]) => {
    const baseTags = recipeData.tags || [];
    const name = recipeData.name.toLowerCase();
    const description = (recipeData.description || '').toLowerCase();
    const ingredientNames = ingredients.map(ing => ing.ingredient_name.toLowerCase()).join(' ');
    const allText = `${name} ${description} ${ingredientNames}`;

    const enhancedTags = [...baseTags];

    // Cuisine detection based on ingredients and name
    const cuisineMapping = {
      'italian': ['pasta', 'parmesan', 'basil', 'mozzarella', 'tomato', 'olive oil', 'risotto', 'pizza'],
      'asian': ['soy sauce', 'ginger', 'sesame', 'rice', 'noodles', 'miso', 'teriyaki'],
      'mexican': ['cumin', 'chili', 'lime', 'cilantro', 'avocado', 'jalapeño', 'taco', 'salsa'],
      'indian': ['curry', 'turmeric', 'garam masala', 'cardamom', 'coriander', 'cumin', 'naan'],
      'mediterranean': ['olive oil', 'feta', 'oregano', 'lemon', 'olives', 'hummus', 'tahini']
    };

    for (const [cuisine, keywords] of Object.entries(cuisineMapping)) {
      const matches = keywords.filter(keyword => allText.includes(keyword)).length;
      if (matches >= 2 && !enhancedTags.includes(cuisine)) {
        enhancedTags.push(cuisine);
      }
    }

    // Meal type detection
    if (name.includes('breakfast') || name.includes('pancake') || name.includes('eggs')) {
      if (!enhancedTags.includes('breakfast')) enhancedTags.push('breakfast');
    }
    if (name.includes('salad') || allText.includes('lunch')) {
      if (!enhancedTags.includes('lunch')) enhancedTags.push('lunch');  
    }
    if (!enhancedTags.some(tag => ['breakfast', 'lunch', 'appetizer', 'dessert'].includes(tag))) {
      enhancedTags.push('dinner');
    }

    // Dietary restrictions
    const meatIngredients = ['chicken', 'beef', 'pork', 'lamb', 'fish', 'salmon'];
    const hasMeat = ingredients.some(ing => 
      meatIngredients.some(meat => ing.ingredient_name.toLowerCase().includes(meat))
    );
    if (!hasMeat && !enhancedTags.includes('vegetarian')) {
      enhancedTags.push('vegetarian');
    }

    // Cooking method from instructions or name
    if (name.includes('baked') || name.includes('roast')) {
      enhancedTags.push('baked');
    }
    if (name.includes('grilled') || name.includes('bbq')) {
      enhancedTags.push('grilled');
    }

    // Difficulty based on ingredient count and complexity
    if (ingredients.length <= 5) {
      enhancedTags.push('easy');
    } else if (ingredients.length <= 10) {
      enhancedTags.push('medium');
    } else {
      enhancedTags.push('advanced');
    }

    return [...new Set(enhancedTags)];
  };

  const handleCreateManual = () => {
    setPreviewData({
      ...manualData,
      cookingSteps: manualData.cookingSteps.filter(step => step.equipment && step.method)
    });
    setFinalData({
      ...manualData,
      cookingSteps: manualData.cookingSteps.filter(step => step.equipment && step.method)
    });
    setStep('preview');
  };

  const handlePreviewEdit = (data: any) => {
    setFinalData(data);
  };

  const handleConfirmRecipe = async () => {
    setIsLoading(true);
    setError('');
    
    try {
      // Simple validation
      if (!finalData.name?.trim()) {
        throw new Error('Recipe name is required');
      }
      
      if (!finalData.yield_amount || finalData.yield_amount <= 0) {
        throw new Error('Yield amount must be greater than 0');
      }
      
      if (!finalData.yield_unit?.trim()) {
        throw new Error('Yield unit is required');
      }
      
      if (!finalData.ingredients?.length) {
        throw new Error('At least one ingredient is required');
      }
      
      if (!finalData.steps?.length) {
        throw new Error('At least one instruction step is required');
      }
      
      // Create simplified payload
      const recipePayload = {
        name: finalData.name.trim(),
        description: finalData.description?.trim() || '',
        yield_amount: Number(finalData.yield_amount),
        yield_unit: finalData.yield_unit.trim(),
        prep_time_minutes: finalData.prep_time_minutes ? Number(finalData.prep_time_minutes) : null,
        hands_on_minutes: finalData.hands_on_minutes ? Number(finalData.hands_on_minutes) : null,
        notes: finalData.notes?.trim() || '',
        is_subrecipe: false,
        ingredients: finalData.ingredients.filter((ing: any) => 
          ing.ingredient_name?.trim() && ing.amount && ing.unit?.trim()
        ).map((ing: any) => ({
          ingredient_name: ing.ingredient_name.trim(),
          amount: Number(ing.amount),
          unit: ing.unit.trim(),
          notes: ing.notes?.trim() || ''
        })),
        steps: finalData.steps.filter((step: any) => 
          step.instruction?.trim()
        ).map((step: any, index: number) => ({
          step_number: index + 1,
          instruction: step.instruction.trim()
        })),
        tags: Array.isArray(finalData.tags) ? finalData.tags.filter(Boolean) : []
      };

      console.log('Creating recipe:', recipePayload);

      const response = await fetch('/api/recipes', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(recipePayload),
      });

      const responseText = await response.text();
      console.log('Raw response:', responseText);

      let responseData;
      try {
        responseData = JSON.parse(responseText);
      } catch (parseError) {
        console.error('JSON parse error:', parseError);
        throw new Error(`Invalid server response: ${responseText}`);
      }

      if (!response.ok) {
        const errorMsg = responseData?.error || responseData?.message || `Server error ${response.status}`;
        throw new Error(errorMsg);
      }

      console.log('Recipe created successfully:', responseData);
      navigate('/recipes');
      
    } catch (err: any) {
      console.error('Recipe creation failed:', err);
      setError(err.message || 'Failed to create recipe');
    } finally {
      setIsLoading(false);
    }
  };

  if (step === 'preview' && previewData) {
    return (
      <RecipePreview
        previewData={previewData}
        onEdit={handlePreviewEdit}
        onConfirm={handleConfirmRecipe}
        onBack={() => setStep('import')}
        isLoading={isLoading}
        error={error}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Import Recipe
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Import from a website URL or create manually, then preview and edit before creating
          </p>
        </div>

        {/* Mode Selection */}
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 mb-6">
          <div className="flex space-x-4 mb-6">
            <button
              onClick={() => setMode('url')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                mode === 'url'
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              <LinkIcon className="w-4 h-4" />
              <span>Import from URL</span>
            </button>
            <button
              onClick={() => navigate('/recipes/import-document')}
              className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              <FileText className="w-4 h-4" />
              <span>Import from Document</span>
            </button>
            <button
              onClick={() => setMode('manual')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                mode === 'manual'
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              <Type className="w-4 h-4" />
              <span>Create Manually</span>
            </button>
          </div>

          {/* URL Import */}
          {mode === 'url' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Recipe URL
              </label>
              <div className="flex space-x-2">
                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://example.com/recipe"
                  className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
                <button
                  onClick={handleScrapeUrl}
                  disabled={isLoading}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg transition-colors flex items-center space-x-2"
                >
                  {isLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Wand2 className="w-4 h-4" />
                  )}
                  <span>{isLoading ? 'Analyzing...' : 'Analyze Recipe'}</span>
                  {!isLoading && <ArrowRight className="w-4 h-4" />}
                </button>
              </div>
              
              <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <div className="flex items-start space-x-2">
                  <Wand2 className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-blue-700 dark:text-blue-300">
                    <p className="font-medium">AI Analysis Process:</p>
                    <ul className="mt-1 space-y-1 text-xs">
                      <li>• Extracts and parses all ingredients with proper measurements</li>
                      <li>• Matches ingredients against your database</li>
                      <li>• Detects cooking methods, temperatures, and timing</li>
                      <li>• Generates relevant tags based on cuisine and content</li>
                      <li>• You'll get a chance to review and edit everything before creating</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              {error && (
                <p className="mt-2 text-sm text-red-600 dark:text-red-400">
                  {error}
                </p>
              )}
            </div>
          )}

          {/* Manual Mode */}
          {mode === 'manual' && (
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Start with basic information and continue to the preview step to add detailed ingredients and instructions.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Recipe Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={manualData.name}
                    onChange={(e) => setManualData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Yield (e.g., 4 servings)
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="number"
                      min="0.1"
                      step="0.1"
                      value={manualData.yield_amount}
                      onChange={(e) => setManualData(prev => ({ ...prev, yield_amount: parseFloat(e.target.value) }))}
                      className="w-20 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                    <input
                      type="text"
                      value={manualData.yield_unit}
                      onChange={(e) => setManualData(prev => ({ ...prev, yield_unit: e.target.value }))}
                      placeholder="servings, kg, etc."
                      className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                </div>
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Description
                </label>
                <textarea
                  value={manualData.description}
                  onChange={(e) => setManualData(prev => ({ ...prev, description: e.target.value }))}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleCreateManual}
                  disabled={!manualData.name.trim()}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg transition-colors flex items-center space-x-2"
                >
                  <span>Continue to Preview</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
