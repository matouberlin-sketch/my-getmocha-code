import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Package, 
  ArrowLeft, 
  Edit, 
  Scale,
  DollarSign,
  Users,
  TrendingUp,
  AlertCircle,
  Plus,
  Tag,
  ChefHat,
  Percent
} from 'lucide-react';

export default function IngredientDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [ingredient, setIngredient] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Fetch ingredient data from API
  useEffect(() => {
    const fetchIngredient = async () => {
      try {
        const response = await fetch(`/api/ingredients/${id}`);
        if (response.ok) {
          const data = await response.json();
          setIngredient(data);
        } else {
          console.error('Ingredient not found');
          setIngredient(null);
        }
      } catch (error) {
        console.error('Failed to fetch ingredient:', error);
        setIngredient(null);
      } finally {
        setLoading(false);
      }
    };

    fetchIngredient();
  }, [id]);

  const formatUnitType = (unitType: string) => {
    return unitType.charAt(0).toUpperCase() + unitType.slice(1);
  };

  const formatCurrency = (amount: number | null) => {
    if (!amount) return '-';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!ingredient) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">Ingredient not found</h1>
          <button 
            onClick={() => navigate('/ingredients')}
            className="text-blue-600 dark:text-blue-400 hover:underline"
          >
            Back to Ingredients
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-5xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-start space-x-4 flex-1">
            <button 
              onClick={() => navigate('/ingredients')}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors mt-1"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
            
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                {ingredient.name}
              </h1>
              
              {/* Basic Info */}
              <div className="flex items-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center space-x-1">
                  <Package className="w-4 h-4" />
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {formatUnitType(ingredient.unit_type)} unit
                  </span>
                </div>
                
                {ingredient.grams_per_piece && (
                  <div className="flex items-center space-x-1">
                    <Scale className="w-4 h-4" />
                    <span>{ingredient.grams_per_piece}g per piece</span>
                  </div>
                )}

                {ingredient.waste_percentage && ingredient.waste_percentage > 0 && (
                  <div className="flex items-center space-x-1">
                    <Percent className="w-4 h-4" />
                    <span>{ingredient.waste_percentage}% waste</span>
                  </div>
                )}
                
                <div className="flex items-center space-x-1">
                  <Users className="w-4 h-4" />
                  <span>{ingredient.supplier_prices?.length || 0} suppliers</span>
                </div>
              </div>

              {/* Tags */}
              {ingredient.tags && ingredient.tags.length > 0 && (
                <div className="mt-3">
                  <div className="flex flex-wrap gap-2">
                    {ingredient.tags.map((tag: string) => (
                      <span
                        key={tag}
                        className="inline-flex items-center px-2.5 py-1 rounded-full text-sm font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 border border-blue-200 dark:border-blue-800"
                      >
                        <Tag className="w-3 h-3 mr-1" />
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            <button 
              onClick={() => navigate(`/ingredients/${ingredient.id}/edit`)}
              className="flex items-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors text-sm"
            >
              <Edit className="w-4 h-4" />
              <span>Edit</span>
            </button>
          </div>
        </div>

        {/* Pricing Information */}
        {ingredient.supplier_prices && ingredient.supplier_prices.length > 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 mb-6">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Supplier Pricing
              </h2>
              
              {/* Price Summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <TrendingUp className="w-4 h-4 text-green-600 dark:text-green-400" />
                    <span className="text-sm font-medium text-green-900 dark:text-green-100">Best Price</span>
                  </div>
                  <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                    {formatCurrency(Math.min(...ingredient.supplier_prices.map((p: any) => p.cost_per_pack / p.pack_size)))}
                  </div>
                  <div className="text-xs text-green-700 dark:text-green-300">per {ingredient.unit_type} unit</div>
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <DollarSign className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span className="text-sm font-medium text-blue-900 dark:text-blue-100">Average Price</span>
                  </div>
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {formatCurrency(
                      ingredient.supplier_prices.reduce((sum: number, p: any) => sum + (p.cost_per_pack / p.pack_size), 0) / 
                      ingredient.supplier_prices.length
                    )}
                  </div>
                  <div className="text-xs text-blue-700 dark:text-blue-300">per {ingredient.unit_type} unit</div>
                </div>
                
                <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <span className="text-sm font-medium text-amber-900 dark:text-amber-100">Price Range</span>
                  </div>
                  <div className="text-lg font-bold text-amber-600 dark:text-amber-400">
                    {(((Math.max(...ingredient.supplier_prices.map((p: any) => p.cost_per_pack / p.pack_size)) - 
                        Math.min(...ingredient.supplier_prices.map((p: any) => p.cost_per_pack / p.pack_size))) / 
                        Math.min(...ingredient.supplier_prices.map((p: any) => p.cost_per_pack / p.pack_size))) * 100).toFixed(0)}%
                  </div>
                  <div className="text-xs text-amber-700 dark:text-amber-300">variation</div>
                </div>
              </div>
            </div>

            {/* Supplier Details */}
            <div className="p-6">
              <h3 className="text-md font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Supplier Details
              </h3>
              
              <div className="space-y-3">
                {ingredient.supplier_prices
                  .sort((a: any, b: any) => (a.cost_per_pack / a.pack_size) - (b.cost_per_pack / b.pack_size))
                  .map((price: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <h4 className="font-medium text-gray-900 dark:text-gray-100">
                          {price.supplier_name}
                        </h4>
                        {index === 0 && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                            Best Price
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {price.pack_size} {price.pack_unit} pack • {formatCurrency(price.cost_per_pack)}
                      </div>
                      {price.contact_person && (
                        <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          Contact: {price.contact_person}
                          {price.phone && ` • ${price.phone}`}
                        </div>
                      )}
                    </div>
                    
                    <div className="text-right">
                      <div className="text-lg font-bold text-gray-900 dark:text-gray-100">
                        {formatCurrency(price.cost_per_pack / price.pack_size)}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        per {ingredient.unit_type} unit
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-8 text-center mb-6">
            <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
              No Pricing Information
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              No supplier pricing has been added for this ingredient yet.
            </p>
            <button className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors">
              <Plus className="w-4 h-4 mr-2" />
              Add Pricing
            </button>
          </div>
        )}

        {/* Recipe Usage */}
        {ingredient.recipe_usage && ingredient.recipe_usage.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Recipe Usage ({ingredient.recipe_usage.length})
            </h2>
            
            <div className="space-y-3">
              {ingredient.recipe_usage.map((usage: any) => (
                <div 
                  key={usage.id}
                  onClick={() => navigate(`/recipes/${usage.id}`)}
                  className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                      <ChefHat className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-gray-100">
                        {usage.name}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Yields {usage.yield_amount} {usage.yield_unit}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-gray-900 dark:text-gray-100">
                      {usage.amount} {usage.unit}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      per batch
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Usage Information */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Properties & Specifications
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                Unit Specifications
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Unit Type:</span>
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {formatUnitType(ingredient.unit_type)}
                  </span>
                </div>
                {ingredient.grams_per_piece && (
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Weight per piece:</span>
                    <span className="font-medium text-gray-900 dark:text-gray-100">
                      {ingredient.grams_per_piece}g
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Waste percentage:</span>
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {ingredient.waste_percentage || 0}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Created:</span>
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {new Date(ingredient.created_at).toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'short', 
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Last updated:</span>
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {new Date(ingredient.updated_at).toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'short', 
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                Cost Analysis
              </h3>
              <div className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                <p>
                  This ingredient is used in {ingredient.recipe_usage?.length || 0} recipes 
                  and affects direct food cost calculations.
                </p>
                {ingredient.waste_percentage > 0 && (
                  <p className="text-amber-600 dark:text-amber-400">
                    <strong>Note:</strong> {ingredient.waste_percentage}% waste factor is applied 
                    to procurement calculations (trim loss, peeling, etc.).
                  </p>
                )}
                <p className="text-xs mt-3">
                  Edible Portion (EP) = As Purchased (AP) × (100 - waste%)
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
