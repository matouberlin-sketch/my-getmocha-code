import { useState, useEffect, useCallback } from 'react';
import { Plus, Search, X, ChevronLeft, ChevronRight, Loader2, Check, AlertCircle, ChevronUp, ChevronDown, Trash2, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

import type { PlannerPlan, PlannerSlot, PlannerSlotRecipe, Recipe } from '../../shared/types';
import PlannerBreakdown from '../components/PlannerBreakdown';
import LineCookView from '../components/LineCookView';

interface SaveStatus {
  type: 'saving' | 'saved' | 'error';
  message?: string;
}



export default function Planner() {
  
  // State management
  const [currentWeek, setCurrentWeek] = useState(0);
  const [showLockModal, setShowLockModal] = useState(false);
  const [plan, setPlan] = useState<PlannerPlan | null>(null);
  const [slots, setSlots] = useState<PlannerSlot[]>([]);
  const [slotRecipes, setSlotRecipes] = useState<PlannerSlotRecipe[]>([]);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>({ type: 'saved' });
  
  // UI state
  const [showRecipeDrawer, setShowRecipeDrawer] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<PlannerSlot | null>(null);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState('');
  const [tab, setTab] = useState<'grid'|'breakdown'|'linecook'>('grid');
  
  // Recipe picker state
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [recipeSearch, setRecipeSearch] = useState('');
  const [recipeCategory, setRecipeCategory] = useState<'all' | 'main' | 'side' | 'dessert'>('all');
  const [isLoadingRecipes, setIsLoadingRecipes] = useState(false);

  

  // Generate week dates starting from Monday
  const getWeekDates = (weekOffset: number = 0) => {
    const today = new Date();
    const monday = new Date(today);
    const dayOfWeek = today.getDay();
    const daysFromMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
    monday.setDate(today.getDate() + daysFromMonday + (weekOffset * 7));
    
    return Array.from({ length: 7 }, (_, i) => {
      const date = new Date(monday);
      date.setDate(monday.getDate() + i);
      return date;
    });
  };

  const weekDates = getWeekDates(currentWeek);
  const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  // Get Monday date for current week
  const getMondayDate = () => {
    return weekDates[0].toISOString().split('T')[0];
  };

  const handleLockPlan = async () => {
    if (!plan) return;
    
    try {
      setSaveStatus({ type: 'saving' });
      const response = await fetch(`/api/planner/plan/${plan.id}/lock`, {
        method: 'POST',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to lock plan');
      }
      
      const result = await response.json();
      setPlan({ ...plan, status: 'locked' });
      setShowLockModal(false);
      alert(`Plan locked successfully! Order snapshot created with ${result.totals.suppliers} suppliers.`);
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Error locking plan:', error);
      alert(error instanceof Error ? error.message : 'Failed to lock plan');
      setSaveStatus({ type: 'error', message: 'Failed to lock plan' });
    }
  };

  // Load or create plan for current week
  const loadPlan = async () => {
    try {
      setSaveStatus({ type: 'saving' });
      const mondayDate = getMondayDate();
      
      const response = await fetch('/api/planner/plan/from-week', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ week_start_date: mondayDate })
      });
      
      if (!response.ok) throw new Error('Failed to load plan');
      
      const data = await response.json();
      setPlan(data.plan);
      setSlots(data.slots);
      setSlotRecipes(data.slot_recipes);
      setTitleInput(data.plan.name || '');
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Failed to load plan:', error);
      setSaveStatus({ type: 'error', message: 'Failed to load plan' });
    }
  };

  // Load recipes with debounced search
  const loadRecipes = useCallback(async () => {
    setIsLoadingRecipes(true);
    try {
      const params = new URLSearchParams();
      if (recipeSearch.trim()) params.set('search', recipeSearch.trim());
      if (recipeCategory !== 'all') params.set('category', recipeCategory.toUpperCase());
      
      const response = await fetch(`/api/recipes?${params}`);
      if (!response.ok) throw new Error('Failed to load recipes');
      
      const data = await response.json();
      setRecipes(data);
    } catch (error) {
      console.error('Failed to load recipes:', error);
    } finally {
      setIsLoadingRecipes(false);
    }
  }, [recipeSearch, recipeCategory]);

  // Debounced recipe search
  useEffect(() => {
    const timer = setTimeout(loadRecipes, 200);
    return () => clearTimeout(timer);
  }, [loadRecipes]);

  // Load plan when week changes
  useEffect(() => {
    loadPlan();
  }, [currentWeek]);

  

  // Create slot
  const createSlot = async (dayIndex: number, slotLabel: string) => {
    if (!plan) return;
    
    try {
      setSaveStatus({ type: 'saving' });
      
      const response = await fetch('/api/planner/slots', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan_id: plan.id,
          day_index: dayIndex,
          slot_label: slotLabel
        })
      });
      
      if (!response.ok) throw new Error('Failed to create slot');
      
      const newSlot = await response.json();
      setSlots(prev => [...prev, newSlot]);
      setSaveStatus({ type: 'saved' });
      
      return newSlot;
    } catch (error) {
      console.error('Failed to create slot:', error);
      setSaveStatus({ type: 'error', message: 'Failed to create slot' });
      return null;
    }
  };

  // Add recipe to slot
  const addRecipeToSlot = async (slot: PlannerSlot, recipeId: number, portions: number = 1) => {
    try {
      setSaveStatus({ type: 'saving' });
      
      const response = await fetch('/api/planner/slot-recipes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slot_id: slot.id,
          recipe_id: recipeId,
          portions
        })
      });
      
      if (!response.ok) throw new Error('Failed to add recipe');
      
      const newSlotRecipe = await response.json();
      setSlotRecipes(prev => [...prev, newSlotRecipe]);
      setSaveStatus({ type: 'saved' });
      setShowRecipeDrawer(false);
    } catch (error) {
      console.error('Failed to add recipe:', error);
      setSaveStatus({ type: 'error', message: 'Failed to add recipe' });
    }
  };

  // Update recipe portions
  const updateRecipePortions = async (slotRecipeId: number, portions: number) => {
    try {
      setSaveStatus({ type: 'saving' });
      
      // Optimistic update
      setSlotRecipes(prev => 
        prev.map(sr => 
          sr.id === slotRecipeId ? { ...sr, portions } : sr
        )
      );
      
      const response = await fetch(`/api/planner/slot-recipes/${slotRecipeId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ portions })
      });
      
      if (!response.ok) throw new Error('Failed to update portions');
      
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Failed to update portions:', error);
      setSaveStatus({ type: 'error', message: 'Failed to update portions' });
      // Revert optimistic update
      loadPlan();
    }
  };

  // Delete slot recipe
  const deleteSlotRecipe = async (slotRecipeId: number) => {
    try {
      setSaveStatus({ type: 'saving' });
      
      // Optimistic update
      setSlotRecipes(prev => prev.filter(sr => sr.id !== slotRecipeId));
      
      const response = await fetch(`/api/planner/slot-recipes/${slotRecipeId}`, {
        method: 'DELETE'
      });
      
      if (!response.ok) throw new Error('Failed to delete recipe');
      
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Failed to delete recipe:', error);
      setSaveStatus({ type: 'error', message: 'Failed to delete recipe' });
      // Revert optimistic update
      loadPlan();
    }
  };

  // Delete slot for specific day only
  const deleteSlotForDay = async (dayIndex: number, slotLabel: string) => {
    const slot = getSlot(dayIndex, slotLabel);
    if (!slot) return;
    
    if (!confirm(`Delete "${slotLabel}" for ${dayNames[dayIndex]}?`)) {
      return;
    }
    
    try {
      setSaveStatus({ type: 'saving' });
      
      const response = await fetch(`/api/planner/slots/${slot.id}`, {
        method: 'DELETE'
      });
      
      if (!response.ok) throw new Error('Failed to delete slot');
      
      // Remove from local state
      setSlots(prev => prev.filter(s => s.id !== slot.id));
      setSlotRecipes(prev => prev.filter(sr => sr.slot_id !== slot.id));
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Failed to delete slot:', error);
      setSaveStatus({ type: 'error', message: 'Failed to delete slot' });
      loadPlan();
    }
  };

  // Delete entire slot row
  const deleteSlotRow = async (slotLabel: string) => {
    if (!plan) return;
    
    if (!confirm(`Delete the entire "${slotLabel}" row? This will remove all recipes from this slot across all days.`)) {
      return;
    }
    
    try {
      setSaveStatus({ type: 'saving' });
      
      // Delete all slots with this label
      const slotsToDelete = slots.filter(s => s.slot_label === slotLabel);
      
      for (const slot of slotsToDelete) {
        const response = await fetch(`/api/planner/slots/${slot.id}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Failed to delete slot');
      }
      
      // Reload plan to get fresh data
      await loadPlan();
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Failed to delete slot row:', error);
      setSaveStatus({ type: 'error', message: 'Failed to delete slot row' });
      loadPlan();
    }
  };

  // Move slot row up/down
  const moveSlotRow = async (slotLabel: string, direction: 'up' | 'down') => {
    if (!plan) return;
    
    try {
      setSaveStatus({ type: 'saving' });
      
      const slotLabels = getSlotLabels();
      const currentIndex = slotLabels.indexOf(slotLabel);
      const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
      
      if (targetIndex < 0 || targetIndex >= slotLabels.length) {
        setSaveStatus({ type: 'saved' });
        return;
      }
      
      // For each day, reorder the slots
      for (let dayIndex = 0; dayIndex < 7; dayIndex++) {
        const daySlotsForLabels = slotLabels
          .map(label => getSlot(dayIndex, label))
          .filter(slot => slot !== undefined) as PlannerSlot[];
        
        if (daySlotsForLabels.length === 0) continue;
        
        // Swap positions
        const newOrder = [...slotLabels];
        [newOrder[currentIndex], newOrder[targetIndex]] = [newOrder[targetIndex], newOrder[currentIndex]];
        
        const reorderedSlots = newOrder
          .map(label => getSlot(dayIndex, label))
          .filter(slot => slot !== undefined) as PlannerSlot[];
        
        if (reorderedSlots.length > 0) {
          await fetch('/api/planner/slots/reorder', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              plan_id: plan.id,
              day_index: dayIndex,
              slot_ids: reorderedSlots.map(s => s.id)
            })
          });
        }
      }
      
      // Reload plan to get fresh data
      await loadPlan();
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Failed to move slot row:', error);
      setSaveStatus({ type: 'error', message: 'Failed to move slot row' });
      loadPlan();
    }
  };

  // Move slot to different day
  const moveSlotToDay = async (slotId: number, targetDayIndex: number) => {
    try {
      setSaveStatus({ type: 'saving' });
      
      const response = await fetch(`/api/planner/slots/${slotId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ day_index: targetDayIndex })
      });
      
      if (!response.ok) throw new Error('Failed to move slot');
      
      // Reload plan to get fresh data
      await loadPlan();
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Failed to move slot:', error);
      setSaveStatus({ type: 'error', message: 'Failed to move slot' });
      loadPlan();
    }
  };

  // Update plan title
  const updatePlanTitle = async (title: string) => {
    if (!plan) return;
    
    try {
      setSaveStatus({ type: 'saving' });
      
      const response = await fetch(`/api/planner/plan/${plan.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: title || null })
      });
      
      if (!response.ok) throw new Error('Failed to update title');
      
      setPlan(prev => prev ? { ...prev, name: title || null } : null);
      setSaveStatus({ type: 'saved' });
    } catch (error) {
      console.error('Failed to update title:', error);
      setSaveStatus({ type: 'error', message: 'Failed to update title' });
    }
  };

  // Get unique slot labels ordered by position
  const getSlotLabels = () => {
    const slotsByPosition = new Map<string, number>();
    
    // Find the minimum position for each slot label across all days
    slots.forEach(slot => {
      const existing = slotsByPosition.get(slot.slot_label);
      if (existing === undefined || (slot as any).position < existing) {
        slotsByPosition.set(slot.slot_label, (slot as any).position || 0);
      }
    });
    
    // Sort by position, then by name
    return Array.from(slotsByPosition.entries())
      .sort(([a, posA], [b, posB]) => posA - posB || a.localeCompare(b))
      .map(([label]) => label);
  };

  // Get slot for day and label
  const getSlot = (dayIndex: number, slotLabel: string) => {
    return slots.find(s => s.day_index === dayIndex && s.slot_label === slotLabel);
  };

  // Get slot recipes for slot
  const getSlotRecipes = (slotId: number) => {
    return slotRecipes.filter(sr => sr.slot_id === slotId);
  };

  // Format week header
  const formatWeekHeader = () => {
    const start = weekDates[0];
    const end = weekDates[6];
    return `${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${end.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;
  };

  // Handle slot cell click
  const handleSlotClick = async (dayIndex: number, slotLabel: string) => {
    let slot = getSlot(dayIndex, slotLabel);
    
    if (!slot) {
      // Create slot if it doesn't exist
      slot = await createSlot(dayIndex, slotLabel);
      if (!slot) return;
    }
    
    setSelectedSlot(slot);
    setRecipeSearch('');
    setRecipeCategory('all');
    setShowRecipeDrawer(true);
  };

  // Status indicator component
  const StatusIndicator = () => {
    const icons = {
      saving: <Loader2 className="w-4 h-4 animate-spin text-blue-500" />,
      saved: <Check className="w-4 h-4 text-green-500" />,
      error: <AlertCircle className="w-4 h-4 text-red-500" />
    };

    const labels = {
      saving: 'Saving...',
      saved: 'Saved',
      error: saveStatus.message || 'Error'
    };

    return (
      <div className="flex items-center space-x-2 text-sm">
        {icons[saveStatus.type]}
        <span className={`${
          saveStatus.type === 'error' ? 'text-red-500' : 
          saveStatus.type === 'saving' ? 'text-blue-500' : 
          'text-green-500'
        }`}>
          {labels[saveStatus.type]}
        </span>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">
              Weekly Planner
            </h1>
            
            {/* Editable title */}
            {isEditingTitle ? (
              <input
                type="text"
                value={titleInput}
                onChange={(e) => setTitleInput(e.target.value)}
                onBlur={() => {
                  setIsEditingTitle(false);
                  updatePlanTitle(titleInput);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    setIsEditingTitle(false);
                    updatePlanTitle(titleInput);
                  } else if (e.key === 'Escape') {
                    setIsEditingTitle(false);
                    setTitleInput(plan?.name || '');
                  }
                }}
                className="text-lg font-medium text-gray-700 dark:text-gray-300 bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-blue-500 max-w-md"
                placeholder="Enter plan title..."
                autoFocus
              />
            ) : (
              <button
                onClick={() => setIsEditingTitle(true)}
                className="text-lg font-medium text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100 px-2 py-1 -mx-2 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                {plan?.name || 'Click to add title...'}
              </button>
            )}
          </div>
          
          {/* Week navigation */}
          <div className="flex items-center space-x-4">
            {/* Tab switcher */}
            <div className="flex items-center gap-2">
              <button 
                onClick={()=>setTab('grid')} 
                className={`px-3 py-1 rounded text-sm ${tab==='grid'?'bg-blue-600 text-white':'bg-gray-200 hover:bg-gray-300'}`}
              >
                Grid
              </button>
              <button 
                onClick={()=>setTab('breakdown')} 
                className={`px-3 py-1 rounded text-sm ${tab==='breakdown'?'bg-blue-600 text-white':'bg-gray-200 hover:bg-gray-300'}`}
              >
                Breakdown
              </button>
              <button 
                onClick={()=>setTab('linecook')} 
                className={`px-3 py-1 rounded text-sm ${tab==='linecook'?'bg-blue-600 text-white':'bg-gray-200 hover:bg-gray-300'}`}
              >
                Line Cook
              </button>
            </div>

            {/* Lock/Order List buttons */}
            {plan?.status === 'locked' ? (
              <Link
                to={`/planner/${plan.id}/order-list`}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
              >
                View Order List
              </Link>
            ) : (
              <button
                onClick={() => setShowLockModal(true)}
                disabled={saveStatus.type === 'saving'}
                className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium disabled:opacity-50"
              >
                Lock Plan
              </button>
            )}

            <StatusIndicator />
            
            <button
              onClick={() => setCurrentWeek(currentWeek - 1)}
              className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            
            <div className="text-center">
              <div className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                {formatWeekHeader()}
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400">
                {currentWeek === 0 ? 'This Week' : `${Math.abs(currentWeek)} week${Math.abs(currentWeek) !== 1 ? 's' : ''} ${currentWeek > 0 ? 'ahead' : 'ago'}`}
              </div>
            </div>
            
            <button
              onClick={() => setCurrentWeek(currentWeek + 1)}
              className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Lock Confirmation Modal */}
        {showLockModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md mx-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Lock Plan
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Locking will freeze edits and generate an order list. This cannot be undone.
              </p>
              <div className="flex gap-3 justify-end">
                <button
                  onClick={() => setShowLockModal(false)}
                  className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleLockPlan}
                  disabled={saveStatus.type === 'saving'}
                  className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50"
                >
                  {saveStatus.type === 'saving' ? 'Locking...' : 'Lock Plan'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Planning Grid */}
        {tab === 'grid' && (
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
          {/* Day headers */}
          <div className="grid grid-cols-8 border-b border-gray-200 dark:border-gray-700">
            <div className="p-4 bg-gray-50 dark:bg-gray-700 border-r border-gray-200 dark:border-gray-700">
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Slot</span>
            </div>
            {weekDates.map((date, index) => (
              <div key={index} className="p-4 bg-gray-50 dark:bg-gray-700 border-r border-gray-200 dark:border-gray-700 last:border-r-0 text-center">
                <div className="font-semibold text-gray-900 dark:text-gray-100 text-sm">
                  {dayNames[index]}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  {date.getDate()}/{date.getMonth() + 1}
                </div>
              </div>
            ))}
          </div>

          {/* Slot rows */}
          {getSlotLabels().map((slotLabel, slotIndex) => (
            <div key={slotLabel} className="grid grid-cols-8 border-b border-gray-100 dark:border-gray-800 last:border-b-0">
              {/* Slot label with controls */}
              <div className="p-2 bg-gray-25 dark:bg-gray-850 border-r border-gray-200 dark:border-gray-700 flex items-center justify-between group">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 flex-1">
                  {slotLabel}
                </span>
                
                {/* Row controls */}
                <div className="opacity-0 group-hover:opacity-100 flex items-center space-x-1 ml-2">
                  {/* Move up */}
                  <button
                    onClick={() => moveSlotRow(slotLabel, 'up')}
                    disabled={slotIndex === 0}
                    className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-gray-100 dark:hover:bg-gray-800 rounded"
                    title="Move up"
                  >
                    <ChevronUp className="w-3 h-3" />
                  </button>
                  
                  {/* Move down */}
                  <button
                    onClick={() => moveSlotRow(slotLabel, 'down')}
                    disabled={slotIndex === getSlotLabels().length - 1}
                    className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-gray-100 dark:hover:bg-gray-800 rounded"
                    title="Move down"
                  >
                    <ChevronDown className="w-3 h-3" />
                  </button>
                  
                  {/* Delete row */}
                  <button
                    onClick={() => deleteSlotRow(slotLabel)}
                    className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded"
                    title="Delete entire row"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
              
              {/* Day cells */}
              {weekDates.map((_, dayIndex) => {
                const slot = getSlot(dayIndex, slotLabel);
                const recipes = slot ? getSlotRecipes(slot.id) : [];
                
                return (
                  <div 
                    key={dayIndex}
                    className="relative group border-r border-gray-100 dark:border-gray-800 last:border-r-0 min-h-[80px] hover:bg-gray-50 dark:hover:bg-gray-700"
                  >
                    {/* Cell toolbar */}
                    {slot && (
                      <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 flex items-center gap-1">
                        {/* Move to day dropdown */}
                        <select
                          onChange={(e) => {
                            const targetDay = parseInt(e.target.value);
                            if (targetDay !== dayIndex) {
                              moveSlotToDay(slot.id, targetDay);
                            }
                            e.target.value = dayIndex.toString(); // Reset selection
                          }}
                          value={dayIndex}
                          className="text-xs p-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded shadow-sm focus:outline-none focus:border-blue-500"
                          title="Move to day"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <option value={dayIndex}>Move to...</option>
                          {dayNames.map((dayName, targetIndex) => (
                            <option key={targetIndex} value={targetIndex} disabled={targetIndex === dayIndex}>
                              {dayName}
                            </option>
                          ))}
                        </select>
                        
                        {/* Delete row for this day */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteSlotForDay(dayIndex, slotLabel);
                          }}
                          className="text-xs text-red-600 hover:text-red-800 hover:bg-red-50 px-1 py-0.5 rounded"
                          title="Delete row (this day)"
                        >
                          Delete row (this day)
                        </button>
                      </div>
                    )}
                    
                    <div 
                      className={`p-2 h-full ${plan?.status === 'locked' ? 'cursor-default' : 'cursor-pointer'}`}
                      onClick={() => {
                        if (plan?.status !== 'locked') {
                          handleSlotClick(dayIndex, slotLabel);
                        }
                      }}
                    >
                      <div className="space-y-1">
                        {recipes.map((slotRecipe) => (
                          <div 
                            key={slotRecipe.id}
                            className="group bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 px-2 py-1 rounded text-xs font-medium flex items-center justify-between hover:bg-blue-200 dark:hover:bg-blue-900/50"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <div className="flex-1 min-w-0">
                              <div className="truncate">
                                {slotRecipe.recipe_name}
                              </div>
                              <div className="flex items-center space-x-1 mt-0.5">
                                <span>×</span>
                                <input
                                  type="number"
                                  min="1"
                                  value={slotRecipe.portions}
                                  onChange={(e) => updateRecipePortions(slotRecipe.id, parseFloat(e.target.value) || 1)}
                                  disabled={plan?.status === 'locked'}
                                  className="w-12 px-1 py-0 text-xs bg-white dark:bg-gray-800 border border-blue-300 dark:border-blue-600 rounded focus:outline-none focus:border-blue-500 disabled:opacity-50"
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>
                            </div>
                            {plan?.status !== 'locked' && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  deleteSlotRecipe(slotRecipe.id);
                                }}
                                className="opacity-0 group-hover:opacity-100 ml-1 p-0.5 text-blue-600 hover:text-red-600 dark:text-blue-300 dark:hover:text-red-400"
                              >
                              <X className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        ))}
                        
                        {recipes.length === 0 && (
                          <div className="text-xs text-gray-400 dark:text-gray-500 p-2 text-center border border-dashed border-gray-200 dark:border-gray-700 rounded">
                            <Plus className="w-4 h-4 mx-auto mb-1" />
                            Add recipe
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}

          {/* Add new slot row or locked notice */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
            {plan?.status === 'locked' ? (
              <div className="flex items-center justify-center text-sm text-gray-500 dark:text-gray-400">
                <Lock className="w-4 h-4 mr-2" />
                Plan is locked and cannot be edited. 
                <Link to={`/planner/${plan.id}/order-list`} className="ml-2 text-blue-600 dark:text-blue-400 hover:underline">
                  View Order List →
                </Link>
              </div>
            ) : (
              <button
                onClick={() => {
                  const label = prompt('Enter slot label (e.g., Lunch, Dinner, Breakfast):');
                  if (label && label.trim()) {
                    // Create the slot for Monday (day 0) as a starting point
                    createSlot(0, label.trim());
                  }
                }}
                className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 flex items-center space-x-1 px-2 py-1 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
              >
                <Plus className="w-4 h-4" />
                <span>Add slot</span>
              </button>
            )}
          </div>
        </div>
        )}

        {/* Breakdown and Line Cook tabs */}
        {tab==='breakdown' && plan && <PlannerBreakdown planId={plan.id} />}
        {tab==='linecook' && plan && <LineCookView planId={plan.id} />}

        {/* Recipe Selection Drawer */}
        {showRecipeDrawer && selectedSlot && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-end z-50">
            <div className="bg-white dark:bg-gray-800 w-96 h-full overflow-hidden flex flex-col">
              {/* Header */}
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                    Add Recipe
                  </h2>
                  <button
                    onClick={() => setShowRecipeDrawer(false)}
                    className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
                  >
                    <X className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
                
                <div className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  {selectedSlot.slot_label} • {dayNames[selectedSlot.day_index]} {weekDates[selectedSlot.day_index].getDate()}/{weekDates[selectedSlot.day_index].getMonth() + 1}
                </div>

                {/* Search */}
                <div className="relative mb-4">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search recipes..."
                    value={recipeSearch}
                    onChange={(e) => setRecipeSearch(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:border-blue-500"
                  />
                </div>

                {/* Category filter */}
                <div className="flex space-x-1">
                  {(['all', 'main', 'side', 'dessert'] as const).map((category) => (
                    <button
                      key={category}
                      onClick={() => setRecipeCategory(category)}
                      className={`px-3 py-1 text-xs rounded ${
                        recipeCategory === category
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                          : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      {category === 'all' ? 'All' : category.charAt(0).toUpperCase() + category.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Recipe list */}
              <div className="flex-1 overflow-y-auto p-4">
                {isLoadingRecipes ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
                  </div>
                ) : (
                  <div className="space-y-2">
                    {recipes.map((recipe) => (
                      <button
                        key={recipe.id}
                        onClick={() => addRecipeToSlot(selectedSlot, recipe.id, 1)}
                        className="w-full p-3 text-left hover:bg-gray-50 dark:hover:bg-gray-700 rounded border border-transparent hover:border-gray-200 dark:hover:border-gray-600"
                      >
                        <div className="font-medium text-gray-900 dark:text-gray-100 mb-1">
                          {recipe.name}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {recipe.yield_amount} {recipe.yield_unit}
                          {recipe.station && ` • ${recipe.station}`}
                          {(recipe.prep_time_minutes || recipe.hands_on_minutes) && (
                            ` • ${(recipe.prep_time_minutes || 0) + (recipe.hands_on_minutes || 0)}m`
                          )}
                        </div>
                      </button>
                    ))}
                    
                    {recipes.length === 0 && !isLoadingRecipes && (
                      <div className="text-center py-8">
                        <p className="text-gray-500 dark:text-gray-400">
                          No recipes found
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
