import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Package, 
  ArrowLeft, 
  DollarSign,
  TrendingUp,
  Layers,
  AlertCircle,
  Scale,
  Tag,
  Search
} from 'lucide-react';

interface Item {
  id: number;
  item_id: string;
  name: string;
  item_type: string;
  base_uom: string;
  category: string | null;
  default_state: string | null;
  edible_yield_pct: number;
  density_g_per_ml: number | null;
  allergen_tags: string | null;
  notes: string | null;
  supplier_items: any[];
  uom_conversions: any[];
  used_in_recipes: any[];
  output_recipes: any[];
}

const typeColors: Record<string, string> = {
  raw: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  prepped: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  component: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  finished: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'
};

export default function ItemDetail() {
  const { itemId } = useParams();
  const navigate = useNavigate();
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'suppliers' | 'recipes' | 'conversions' | 'where-used'>('suppliers');
  const [whereUsedData, setWhereUsedData] = useState<any>(null);
  const [whereUsedLoading, setWhereUsedLoading] = useState(false);

  useEffect(() => {
    const fetchItem = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/items/${itemId}`);
        if (!response.ok) {
          throw new Error('Failed to fetch item');
        }
        const data = await response.json();
        setItem(data);
      } catch (err) {
        console.error('Failed to fetch item:', err);
        setError('Failed to load item');
      } finally {
        setLoading(false);
      }
    };

    if (itemId) {
      fetchItem();
    }
  }, [itemId]);

  const fetchWhereUsed = async () => {
    if (!itemId) return;
    
    try {
      setWhereUsedLoading(true);
      const response = await fetch(`/api/items/${itemId}/where-used`);
      if (!response.ok) {
        throw new Error('Failed to fetch where-used data');
      }
      const data = await response.json();
      setWhereUsedData(data);
    } catch (err) {
      console.error('Failed to fetch where-used data:', err);
      setWhereUsedData(null);
    } finally {
      setWhereUsedLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'where-used' && itemId) {
      fetchWhereUsed();
    }
  }, [activeTab, itemId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading item...</p>
        </div>
      </div>
    );
  }

  if (error || !item) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">Item Not Found</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
          <button
            onClick={() => navigate('/items')}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Items
          </button>
        </div>
      </div>
    );
  }

  const allergens = item.allergen_tags ? item.allergen_tags.split(',').map(tag => tag.trim()) : [];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-start space-x-4 flex-1">
            <button 
              onClick={() => navigate('/items')}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors mt-1"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
            
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {item.name}
                </h1>
                <span className={`inline-flex px-2.5 py-1 text-sm font-semibold rounded-full ${typeColors[item.item_type] || 'bg-gray-100 text-gray-800'}`}>
                  {item.item_type}
                </span>
              </div>
              
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                Item ID: {item.item_id}
              </div>

              {/* Item Stats */}
              <div className="flex items-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center space-x-1">
                  <Scale className="w-4 h-4" />
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {item.base_uom}
                  </span>
                  <span>base unit</span>
                </div>
                
                {item.category && (
                  <div className="flex items-center space-x-1">
                    <Tag className="w-4 h-4" />
                    <span>{item.category}</span>
                  </div>
                )}
                
                {item.edible_yield_pct < 100 && (
                  <div className="flex items-center space-x-1">
                    <TrendingUp className="w-4 h-4" />
                    <span>{item.edible_yield_pct}% yield</span>
                  </div>
                )}
                
                {item.density_g_per_ml && (
                  <div className="flex items-center space-x-1">
                    <Scale className="w-4 h-4" />
                    <span>{item.density_g_per_ml}g/ml density</span>
                  </div>
                )}
              </div>

              {allergens.length > 0 && (
                <div className="mt-3 flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                  <span className="text-sm text-red-600 dark:text-red-400">
                    Allergens: {allergens.join(', ')}
                  </span>
                </div>
              )}

              {item.notes && (
                <div className="mt-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                  <p className="text-sm text-amber-800 dark:text-amber-200">{item.notes}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center">
              <DollarSign className="w-8 h-8 text-green-600 dark:text-green-400" />
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Suppliers</h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{item.supplier_items?.length || 0}</p>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center">
              <Layers className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Used In Recipes</h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{item.used_in_recipes?.length || 0}</p>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center">
              <Package className="w-8 h-8 text-purple-600 dark:text-purple-400" />
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Output Recipes</h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{item.output_recipes?.length || 0}</p>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center">
              <Scale className="w-8 h-8 text-orange-600 dark:text-orange-400" />
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">UOM Conversions</h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{item.uom_conversions?.length || 0}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-6">
          <button
            onClick={() => setActiveTab('suppliers')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'suppliers'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Suppliers ({item.supplier_items?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('recipes')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'recipes'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Recipes ({item.used_in_recipes?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('conversions')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'conversions'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            Conversions ({item.uom_conversions?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('where-used')}
            className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === 'where-used'
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>Where Used</span>
          </button>
        </div>

        {/* Content */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
          {activeTab === 'suppliers' && (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Supplier Pricing
              </h2>
              
              {item.supplier_items && item.supplier_items.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Supplier
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Pack Size
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Price
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Unit Cost
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Order Code
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                      {item.supplier_items.map((supplier: any, index: number) => (
                        <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-4 py-4 text-sm font-medium text-gray-900 dark:text-gray-100">
                            {supplier.supplier_name}
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900 dark:text-gray-100">
                            {supplier.pack_qty} {supplier.pack_uom}
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900 dark:text-gray-100">
                            €{supplier.price?.toFixed(2) || '0.00'}
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900 dark:text-gray-100">
                            €{(supplier.price / supplier.pack_qty)?.toFixed(3) || '0.000'}
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-500 dark:text-gray-400">
                            {supplier.order_code || '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No supplier pricing found</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'recipes' && (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Used In Recipes
              </h2>
              
              {item.used_in_recipes && item.used_in_recipes.length > 0 ? (
                <div className="space-y-3">
                  {item.used_in_recipes.map((usage: any, index: number) => (
                    <div key={index} className="flex items-center justify-between py-3 px-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="text-right min-w-[60px]">
                          <span className="font-medium text-gray-900 dark:text-gray-100">
                            {usage.qty}
                          </span>
                          <span className="text-gray-600 dark:text-gray-400 ml-1">
                            {usage.uom}
                          </span>
                        </div>
                        <div className="flex-1">
                          <button
                            onClick={() => navigate(`/enhanced-recipes/${encodeURIComponent(usage.recipe_id)}`)}
                            className="font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:underline text-left"
                          >
                            {usage.recipe?.name || usage.recipe_id}
                          </button>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${typeColors[usage.type] || 'bg-gray-100 text-gray-800'}`}>
                          {usage.type || 'recipe'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Layers className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">Not used in any recipes</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'conversions' && (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Unit Conversions
              </h2>
              
              {item.uom_conversions && item.uom_conversions.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          From Unit
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          To Unit
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Factor
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Method
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          Notes
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                      {item.uom_conversions.map((conversion: any, index: number) => (
                        <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-4 py-4 text-sm font-medium text-gray-900 dark:text-gray-100">
                            {conversion.from_uom}
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900 dark:text-gray-100">
                            {conversion.to_uom}
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900 dark:text-gray-100">
                            {conversion.factor}
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900 dark:text-gray-100">
                            {conversion.method}
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-500 dark:text-gray-400">
                            {conversion.notes || '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Scale className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No unit conversions defined</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'where-used' && (
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Where Used Analysis
              </h2>
              
              {whereUsedLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : whereUsedData ? (
                <div className="space-y-6">
                  {/* Main Recipes */}
                  {whereUsedData.recipes && whereUsedData.recipes.length > 0 && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                        Main Recipes ({whereUsedData.recipes.length})
                      </h3>
                      <div className="space-y-2">
                        {whereUsedData.recipes.map((recipe: any, index: number) => (
                          <div key={index} className="flex items-center justify-between py-3 px-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                            <div className="flex items-center space-x-3">
                              <button
                                onClick={() => navigate(`/enhanced-recipes/${encodeURIComponent(recipe.id)}`)}
                                className="font-medium text-green-700 dark:text-green-300 hover:text-green-900 dark:hover:text-green-100 hover:underline text-left"
                              >
                                {recipe.name}
                              </button>
                              {recipe.via_subrecipe && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                                  <Layers className="w-3 h-3 mr-1" />
                                  Via Sub-recipe
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Sub-recipes */}
                  {whereUsedData.subrecipes && whereUsedData.subrecipes.length > 0 && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                        Sub-recipes ({whereUsedData.subrecipes.length})
                      </h3>
                      <div className="space-y-2">
                        {whereUsedData.subrecipes.map((subrecipe: any, index: number) => (
                          <div key={index} className="flex items-center justify-between py-3 px-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
                            <div className="flex items-center space-x-3">
                              <button
                                onClick={() => navigate(`/enhanced-recipes/${encodeURIComponent(subrecipe.id)}`)}
                                className="font-medium text-purple-700 dark:text-purple-300 hover:text-purple-900 dark:hover:text-purple-100 hover:underline text-left"
                              >
                                {subrecipe.name}
                              </button>
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                                <Layers className="w-3 h-3 mr-1" />
                                Sub-recipe
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* No usage found */}
                  {(!whereUsedData.recipes || whereUsedData.recipes.length === 0) && 
                   (!whereUsedData.subrecipes || whereUsedData.subrecipes.length === 0) && (
                    <div className="text-center py-8">
                      <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 dark:text-gray-400">This item is not used in any recipes</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">Failed to load where-used data</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
