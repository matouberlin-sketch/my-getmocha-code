import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Download, Copy, Check } from 'lucide-react';

interface SupplierLine {
  item_id: number;
  name: string;
  qty: number;
  uom: string;
  unit_cost: number | null;
  line_cost: number | null;
  requires_price?: boolean;
}

interface SupplierBucket {
  supplier_id: number | null;
  supplier_name: string;
  lines: SupplierLine[];
  subtotal: number | null;
}

interface OrderSnapshot {
  plan_id: number;
  week_start_date: string;
  currency: string;
  costing_strategy: 'preferred' | 'lowest';
  suppliers: SupplierBucket[];
  grand_total: number | null;
}

export default function OrderList() {
  const { planId } = useParams<{ planId: string }>();
  const [orderData, setOrderData] = useState<OrderSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  const [copiedSupplier, setCopiedSupplier] = useState<string | null>(null);

  useEffect(() => {
    fetchOrderData();
  }, [planId]);

  const fetchOrderData = async () => {
    if (!planId) return;
    
    setLoading(true);
    try {
      const response = await fetch(`/api/planner/plan/${planId}/order-list`);
      if (!response.ok) {
        throw new Error('Failed to fetch order list');
      }
      const data = await response.json();
      setOrderData(data);
    } catch (error) {
      console.error('Error fetching order data:', error);
      alert('Failed to load order list');
    } finally {
      setLoading(false);
    }
  };

  const copySupplierToClipboard = async (supplier: SupplierBucket) => {
    const rows = supplier.lines.map(line => 
      `${line.name}\t${line.qty}\t${line.uom}\t${line.unit_cost || 'N/A'}\t${line.line_cost || 'N/A'}`
    ).join('\n');
    
    const header = 'Item\tQty\tUoM\tUnit Cost\tLine Cost\n';
    const text = header + rows;
    
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSupplier(supplier.supplier_name);
      setTimeout(() => setCopiedSupplier(null), 2000);
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
    }
  };

  const formatCurrency = (amount: number | null) => {
    if (amount === null) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: orderData?.currency || 'USD'
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-lg">Loading order list...</div>
      </div>
    );
  }

  if (!orderData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-lg">Order list not found</div>
      </div>
    );
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-sm border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <Link
                to={`/planner/${planId}`}
                className="inline-flex items-center text-white/80 hover:text-white transition-colors mb-2"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Planner
              </Link>
              <h1 className="text-3xl font-bold text-white">
                Order List
              </h1>
              <p className="text-white/80 mt-1">
                Week of {formatDate(orderData.week_start_date)} • {orderData.costing_strategy} pricing
              </p>
            </div>
            <div className="flex gap-3">
              <a
                href={`/api/planner/plan/${planId}/order-list.csv`}
                className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Supplier Tabs */}
        <div className="mb-6">
          <div className="border-b border-white/20">
            <nav className="flex space-x-8">
              {orderData.suppliers.map((supplier, index) => (
                <button
                  key={supplier.supplier_name}
                  onClick={() => setActiveTab(index)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === index
                      ? 'border-white text-white'
                      : 'border-transparent text-white/60 hover:text-white/80'
                  }`}
                >
                  {supplier.supplier_name}
                  <span className="ml-2 text-xs bg-white/20 px-2 py-1 rounded-full">
                    {supplier.lines.length}
                  </span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Supplier Content */}
        {orderData.suppliers.map((supplier, index) => (
          <div
            key={supplier.supplier_name}
            className={activeTab === index ? 'block' : 'hidden'}
          >
            <div className="bg-white/10 backdrop-blur-sm rounded-lg border border-white/20 overflow-hidden">
              {/* Supplier Header */}
              <div className="bg-white/5 px-6 py-4 border-b border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-semibold text-white">
                      {supplier.supplier_name}
                    </h2>
                    <p className="text-white/60 text-sm">
                      {supplier.lines.length} items
                    </p>
                  </div>
                  <button
                    onClick={() => copySupplierToClipboard(supplier)}
                    className="inline-flex items-center px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                  >
                    {copiedSupplier === supplier.supplier_name ? (
                      <Check className="w-4 h-4 mr-1" />
                    ) : (
                      <Copy className="w-4 h-4 mr-1" />
                    )}
                    {copiedSupplier === supplier.supplier_name ? 'Copied!' : 'Copy Rows'}
                  </button>
                </div>
              </div>

              {/* Items Table */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-white/5">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-white/80 uppercase tracking-wider">
                        Item
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-white/80 uppercase tracking-wider">
                        Qty
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-white/80 uppercase tracking-wider">
                        UoM
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-white/80 uppercase tracking-wider">
                        Unit Cost
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-white/80 uppercase tracking-wider">
                        Line Cost
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {supplier.lines.map((line, lineIndex) => (
                      <tr key={lineIndex} className="hover:bg-white/5 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="text-sm font-medium text-white">
                              {line.name}
                            </div>
                            {line.requires_price && (
                              <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-800">
                                No Price
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right">
                          <div className="text-sm text-white">
                            {line.qty.toFixed(2)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-white/80">
                            {line.uom}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right">
                          <div className="text-sm text-white">
                            {formatCurrency(line.unit_cost)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right">
                          <div className="text-sm font-medium text-white">
                            {formatCurrency(line.line_cost)}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Supplier Footer */}
              <div className="bg-white/5 px-6 py-4 border-t border-white/20">
                <div className="flex justify-between items-center">
                  <div className="text-sm text-white/60">
                    Subtotal for {supplier.supplier_name}
                  </div>
                  <div className="text-lg font-semibold text-white">
                    {formatCurrency(supplier.subtotal)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Grand Total */}
        <div className="mt-6 bg-gradient-to-r from-green-600/20 to-blue-600/20 backdrop-blur-sm rounded-lg border border-white/20 p-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold text-white">
                Grand Total
              </h3>
              <p className="text-white/60 text-sm">
                {orderData.suppliers.length} suppliers • {orderData.suppliers.reduce((sum, s) => sum + s.lines.length, 0)} items
              </p>
            </div>
            <div className="text-2xl font-bold text-white">
              {formatCurrency(orderData.grand_total)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
