import { useState, useEffect } from 'react';
import { Plus, Search, Filter, ChefHat, Clock, Edit, Trash2, Archive, MoreHorizontal, Users, X, Download, Upload } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import ShortlistToggle from '@/react-app/components/ShortlistToggle';
import CsvImportModal from '@/react-app/components/CsvImportModal';

interface FilterState {
  tags: string[];
  stations: string[];
  is_subrecipe: boolean | null;
  min_prep_time: number | null;
  max_prep_time: number | null;
  min_yield: number | null;
  max_yield: number | null;
}

interface ColumnDefinition {
  key: string;
  label: string;
  color: string;
  width: string;
  required?: boolean;
}

interface ColumnHeaderProps {
  column: ColumnDefinition;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  onSort: (key: string) => void;
  onRemove: (key: string) => void;
}

function ColumnHeader({ column, sortBy, sortOrder, onSort, onRemove }: ColumnHeaderProps) {
  const isActive = sortBy === column.key;
  
  return (
    <div className={`${column.width} flex items-center justify-between group`}>
      <button
        onClick={() => onSort(column.key)}
        className={`flex items-center space-x-1 px-3 py-1.5 rounded text-xs font-medium transition-colors ${column.color} ${
          isActive ? 'opacity-100' : 'opacity-70 hover:opacity-100'
        } hover:shadow-sm`}
      >
        <span>{column.label}</span>
        {isActive && (
          <span className="ml-1 text-xs">
            {sortOrder === 'asc' ? '↑' : '↓'}
          </span>
        )}
      </button>
      
      {column.key !== 'name' && (
        <button
          onClick={() => onRemove(column.key)}
          className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition-opacity"
        >
          <X className="w-3 h-3 text-gray-500" />
        </button>
      )}
    </div>
  );
}

interface AddColumnDropdownProps {
  availableColumns: ColumnDefinition[];
  visibleColumns: string[];
  onToggle: (key: string) => void;
}

function AddColumnDropdown({ availableColumns, visibleColumns, onToggle }: AddColumnDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  // Add visible columns to show checkboxes for currently visible ones
  const currentVisible = availableColumns.filter(col => visibleColumns.includes(col.key));
  const allManageableColumns = [
    ...currentVisible,
    ...availableColumns.filter(col => !visibleColumns.includes(col.key))
  ].filter(col => col.key !== 'name'); // Never show name column as it's required
  
  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        title="Manage Columns"
        className="flex items-center justify-center w-8 h-8 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
      >
        <Plus className="w-5 h-5" />
      </button>
      
      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute bottom-full right-0 mb-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50 w-96 p-3">
            <div className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">
              Manage Columns
            </div>
            <div className="grid grid-cols-2 gap-2">
              {allManageableColumns.map(column => {
                const isVisible = visibleColumns.includes(column.key);
                return (
                  <label
                    key={column.key}
                    className="flex items-center p-2 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors rounded"
                  >
                    <input
                      type="checkbox"
                      checked={isVisible}
                      onChange={() => onToggle(column.key)}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 mr-2 flex-shrink-0"
                    />
                    <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${column.color} text-center flex-1`}>
                      {column.label}
                    </span>
                  </label>
                );
              })}
            </div>
            {allManageableColumns.length === 0 && (
              <div className="text-xs text-gray-500 dark:text-gray-400 text-center py-2">
                All columns are visible
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

interface BulkActionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedRecipes: number[];
  recipes: any[];
  onBulkAction: (action: 'delete' | 'archive' | 'edit', recipeIds: number[]) => void;
}

function BulkActionsModal({ isOpen, onClose, selectedRecipes, recipes, onBulkAction }: BulkActionsModalProps) {
  const [action, setAction] = useState<'delete' | 'archive' | 'edit'>('archive');
  const [confirmText, setConfirmText] = useState('');
  
  const selectedRecipeNames = recipes
    .filter(r => selectedRecipes.includes(r.id))
    .map(r => r.name);

  const handleSubmit = () => {
    if (action === 'delete' && confirmText !== 'DELETE') {
      return;
    }
    onBulkAction(action, selectedRecipes);
    onClose();
    setConfirmText('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-md w-full p-6">
        <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">
          Bulk Actions ({selectedRecipes.length} recipes)
        </h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Action
            </label>
            <select
              value={action}
              onChange={(e) => setAction(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            >
              <option value="archive">Archive Recipes</option>
              <option value="edit">Bulk Edit Properties</option>
              <option value="delete">Delete Recipes</option>
            </select>
          </div>

          <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">
              Selected Recipes:
            </h3>
            <div className="text-sm text-gray-600 dark:text-gray-400 max-h-24 overflow-y-auto">
              {selectedRecipeNames.map((name, index) => (
                <div key={index}>• {name}</div>
              ))}
            </div>
          </div>

          {action === 'delete' && (
            <div>
              <label className="block text-sm font-medium text-red-700 dark:text-red-300 mb-2">
                Type "DELETE" to confirm deletion (this cannot be undone)
              </label>
              <input
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="DELETE"
                className="w-full px-3 py-2 border border-red-300 dark:border-red-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>
          )}

          {action === 'archive' && (
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                Archived recipes will be hidden from the main library but can be restored later.
              </p>
            </div>
          )}

          {action === 'edit' && (
            <div className="p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <p className="text-sm text-amber-700 dark:text-amber-300">
                This will open a bulk edit interface to modify common properties like tags, station, etc.
              </p>
            </div>
          )}
        </div>

        <div className="flex justify-end space-x-3 mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={action === 'delete' && confirmText !== 'DELETE'}
            className={`px-4 py-2 font-medium rounded-lg transition-colors ${
              action === 'delete'
                ? 'bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white'
                : action === 'archive'
                ? 'bg-amber-600 hover:bg-amber-700 text-white'
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {action === 'delete' ? 'Delete' : action === 'archive' ? 'Archive' : 'Edit'} Recipes
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Recipes() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [selectedRecipes, setSelectedRecipes] = useState<number[]>([]);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [showCsvImport, setShowCsvImport] = useState(false);

  const [filters] = useState<FilterState>({
    tags: [],
    stations: [],
    is_subrecipe: null,
    min_prep_time: null,
    max_prep_time: null,
    min_yield: null,
    max_yield: null,
  });

  // Column configuration
  const allColumnDefinitions: ColumnDefinition[] = [
    { key: 'name', label: 'Recipe Name', color: 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-gray-100', width: 'flex-1', required: true },
    { key: 'time', label: 'Prep Time', color: 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200', width: 'w-20' },
    { key: 'yield', label: 'Yield', color: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200', width: 'w-24' },
    { key: 'station', label: 'Station', color: 'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200', width: 'w-24' },
    { key: 'category', label: 'Category', color: 'bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200', width: 'w-24' },
    { key: 'tags', label: 'Tags', color: 'bg-pink-100 dark:bg-pink-900 text-pink-800 dark:text-pink-200', width: 'w-32' },
    { key: 'updated', label: 'Updated', color: 'bg-cyan-100 dark:bg-cyan-900 text-cyan-800 dark:text-cyan-200', width: 'w-24' },
  ];

  const [visibleColumnKeys, setVisibleColumnKeys] = useState(['name', 'time', 'yield']);

  const visibleColumns = allColumnDefinitions.filter(col => visibleColumnKeys.includes(col.key));
  const availableColumns = allColumnDefinitions.filter(col => !visibleColumnKeys.includes(col.key));

  const categories = ['all', 'appetizers', 'mains', 'sides', 'desserts', 'sauces', 'stocks', 'prep'];

  const [recipes, setRecipes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch recipes from API with tags
  useEffect(() => {
    const fetchRecipes = async () => {
      try {
        const response = await fetch('/api/recipes');
        if (response.ok) {
          const data = await response.json();
          // Fetch tags for each recipe
          const recipesWithTags = await Promise.all(
            data.map(async (recipe: any) => {
              try {
                const tagsResponse = await fetch(`/api/recipes/${recipe.id}`);
                if (tagsResponse.ok) {
                  const detailData = await tagsResponse.json();
                  return { ...recipe, tags: detailData.tags || [] };
                }
                return { ...recipe, tags: [] };
              } catch {
                return { ...recipe, tags: [] };
              }
            })
          );
          setRecipes(recipesWithTags);
        }
      } catch (error) {
        console.error('Failed to fetch recipes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRecipes();
  }, []);

  // Mock categories for now - will be added to database later
  const getCategoriesForRecipe = (recipe: any) => {
    if (recipe.is_subrecipe) return ['prep'];
    if (recipe.name.toLowerCase().includes('sauce') || recipe.name.toLowerCase().includes('paste')) return ['sauces'];
    if (recipe.name.toLowerCase().includes('stock') || recipe.name.toLowerCase().includes('broth')) return ['stocks'];
    return ['mains']; // Default category
  };

  const filteredRecipes = recipes.filter(recipe => {
    // Basic search
    const matchesSearch = recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         recipe.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Category filter
    const recipeCategories = getCategoriesForRecipe(recipe);
    const matchesCategory = selectedCategory === 'all' || recipeCategories.includes(selectedCategory);
    
    // Advanced filters
    const matchesSubrecipe = filters.is_subrecipe === null || recipe.is_subrecipe === filters.is_subrecipe;
    
    const matchesTags = filters.tags.length === 0 || 
      filters.tags.some(tag => recipe.tags?.includes(tag));
    
    const matchesStations = filters.stations.length === 0 || 
      filters.stations.includes(recipe.station);
    
    const matchesPrepTime = (filters.min_prep_time === null || (recipe.prep_time_minutes || 0) >= filters.min_prep_time) &&
                           (filters.max_prep_time === null || (recipe.prep_time_minutes || 0) <= filters.max_prep_time);
    
    const matchesYield = (filters.min_yield === null || recipe.yield_amount >= filters.min_yield) &&
                        (filters.max_yield === null || recipe.yield_amount <= filters.max_yield);
    
    return matchesSearch && matchesCategory && matchesSubrecipe && matchesTags && matchesStations && matchesPrepTime && matchesYield;
  }).sort((a, b) => {
    let result = 0;
    
    switch (sortBy) {
      case 'name':
        result = a.name.localeCompare(b.name);
        break;
      case 'time':
        result = (a.prep_time_minutes || 0) - (b.prep_time_minutes || 0);
        break;
      case 'yield':
        result = a.yield_amount - b.yield_amount;
        break;
      case 'updated':
        result = new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
        break;
      case 'station':
        result = (a.station || '').localeCompare(b.station || '');
        break;
      case 'category':
        const aCat = getCategoriesForRecipe(a)[0] || '';
        const bCat = getCategoriesForRecipe(b)[0] || '';
        result = aCat.localeCompare(bCat);
        break;
      case 'tags':
        const aTags = (a.tags || []).join(', ');
        const bTags = (b.tags || []).join(', ');
        result = aTags.localeCompare(bTags);
        break;
      default:
        result = 0;
    }
    
    return sortOrder === 'desc' ? -result : result;
  });

  const formatTime = (minutes: number) => {
    if (!minutes) return '0m';
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}h${mins > 0 ? ` ${mins}m` : ''}`;
    }
    return `${minutes}m`;
  };

  const handleSort = (columnKey: string) => {
    if (sortBy === columnKey) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(columnKey);
      setSortOrder('asc');
    }
  };

  const handleToggleColumn = (columnKey: string) => {
    if (columnKey === 'name') return; // Don't allow toggling the name column
    
    setVisibleColumnKeys(prev => 
      prev.includes(columnKey)
        ? prev.filter(key => key !== columnKey)
        : [...prev, columnKey]
    );
  };

  const activeFilterCount = 
    filters.tags.length +
    filters.stations.length +
    (filters.is_subrecipe !== null ? 1 : 0) +
    (filters.min_prep_time !== null ? 1 : 0) +
    (filters.max_prep_time !== null ? 1 : 0) +
    (filters.min_yield !== null ? 1 : 0) +
    (filters.max_yield !== null ? 1 : 0);

  const toggleRecipeSelection = (recipeId: number) => {
    setSelectedRecipes(prev => 
      prev.includes(recipeId) 
        ? prev.filter(id => id !== recipeId)
        : [...prev, recipeId]
    );
  };

  const toggleSelectAll = () => {
    setSelectedRecipes(prev => 
      prev.length === filteredRecipes.length 
        ? [] 
        : filteredRecipes.map(r => r.id)
    );
  };

  const handleBulkAction = async (action: 'delete' | 'archive' | 'edit', recipeIds: number[]) => {
    try {
      if (action === 'delete') {
        // Call delete API for each recipe
        for (const id of recipeIds) {
          await fetch(`/api/recipes/${id}`, { method: 'DELETE' });
        }
        // Remove from local state
        setRecipes(prev => prev.filter(r => !recipeIds.includes(r.id)));
      } else if (action === 'archive') {
        // Call archive API
        for (const id of recipeIds) {
          await fetch(`/api/recipes/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ archived: true })
          });
        }
        // Remove from view (they're archived)
        setRecipes(prev => prev.filter(r => !recipeIds.includes(r.id)));
      } else if (action === 'edit') {
        // Navigate to bulk edit page
        navigate(`/recipes/bulk-edit?ids=${recipeIds.join(',')}`);
      }
      
      setSelectedRecipes([]);
    } catch (error) {
      console.error(`Failed to ${action} recipes:`, error);
    }
  };

  const handleSingleAction = async (action: 'edit' | 'archive' | 'delete', recipeId: number) => {
    if (action === 'edit') {
      navigate(`/recipes/${recipeId}/edit`);
    } else if (action === 'delete') {
      if (confirm('Are you sure you want to delete this recipe? This cannot be undone.')) {
        await handleBulkAction('delete', [recipeId]);
      }
    } else if (action === 'archive') {
      await handleBulkAction('archive', [recipeId]);
    }
  };

  const handleCsvExport = async (recipeIds?: number[]) => {
    try {
      const exportIds = recipeIds || selectedRecipes;
      const params = exportIds.length > 0 ? `?ids=${exportIds.join(',')}` : '';
      
      const response = await fetch(`/api/recipe-csv/export${params}`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = response.headers.get('content-disposition')?.split('filename=')[1]?.replace(/"/g, '') || 'recipes.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Failed to export CSV:', error);
    }
  };

  const handleCsvImportSuccess = () => {
    setShowCsvImport(false);
    // Refresh recipes list
    const fetchRecipes = async () => {
      try {
        const response = await fetch('/api/recipes');
        if (response.ok) {
          const data = await response.json();
          const recipesWithTags = await Promise.all(
            data.map(async (recipe: any) => {
              try {
                const tagsResponse = await fetch(`/api/recipes/${recipe.id}`);
                if (tagsResponse.ok) {
                  const detailData = await tagsResponse.json();
                  return { ...recipe, tags: detailData.tags || [] };
                }
                return { ...recipe, tags: [] };
              } catch {
                return { ...recipe, tags: [] };
              }
            })
          );
          setRecipes(recipesWithTags);
        }
      } catch (error) {
        console.error('Failed to fetch recipes:', error);
      }
    };

    fetchRecipes();
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              Recipe Library
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {filteredRecipes.length} recipe{filteredRecipes.length !== 1 ? 's' : ''}
              {selectedRecipes.length > 0 && ` • ${selectedRecipes.length} selected`}
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            {selectedRecipes.length > 0 && (
              <>
                <button
                  onClick={() => handleCsvExport(selectedRecipes)}
                  className="flex items-center space-x-2 px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>Export CSV ({selectedRecipes.length})</span>
                </button>
                <button
                  onClick={() => setShowBulkModal(true)}
                  className="flex items-center space-x-2 px-3 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium rounded-lg transition-colors"
                >
                  <MoreHorizontal className="w-4 h-4" />
                  <span>Actions ({selectedRecipes.length})</span>
                </button>
              </>
            )}
            
            <div className="flex items-center space-x-2">
              <button
                onClick={() => handleCsvExport()}
                className="flex items-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Export All</span>
              </button>
              
              <button
                onClick={() => setShowCsvImport(true)}
                className="flex items-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>Import Document</span>
              </button>
            </div>
            
            <button 
              onClick={() => navigate('/recipes/new')}
              className="flex items-center space-x-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Recipe</span>
            </button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search recipes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg text-sm"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            
            {activeFilterCount > 0 && (
              <div className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-medium px-2 py-1 rounded-full">
                {activeFilterCount} filters
              </div>
            )}
          </div>
        </div>

        {/* Recipe List */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : filteredRecipes.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-8 text-center">
            <ChefHat className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
              {searchTerm || selectedCategory !== 'all' ? 'No recipes found' : 'No recipes yet'}
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              {searchTerm || selectedCategory !== 'all' 
                ? 'Try adjusting your search or filters' 
                : 'Start building your recipe library'
              }
            </p>
            {(!searchTerm && selectedCategory === 'all') && (
              <button 
                onClick={() => navigate('/recipes/new')}
                className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Recipe
              </button>
            )}
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
            {/* Dynamic Header */}
            <div className="flex items-center px-4 py-3 bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
              <input
                type="checkbox"
                checked={selectedRecipes.length === filteredRecipes.length && filteredRecipes.length > 0}
                onChange={toggleSelectAll}
                className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 mr-3 flex-shrink-0"
              />
              
              <div className="flex-1 flex items-center space-x-3">
                {visibleColumns.map(column => (
                  <ColumnHeader
                    key={column.key}
                    column={column}
                    sortBy={sortBy}
                    sortOrder={sortOrder}
                    onSort={handleSort}
                    onRemove={handleToggleColumn}
                  />
                ))}
              </div>
              
              <div className="w-24 flex justify-center">
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                  Quick List
                </span>
              </div>
              
              <div className="w-20 flex items-center justify-end">
                <AddColumnDropdown
                  availableColumns={availableColumns}
                  visibleColumns={visibleColumnKeys}
                  onToggle={handleToggleColumn}
                />
              </div>
            </div>
            
            {/* Recipe List */}
            <div className="divide-y divide-gray-100 dark:divide-gray-700">
              {filteredRecipes.map((recipe) => (
                <div 
                  key={recipe.id}
                  className={`flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors group ${
                    selectedRecipes.includes(recipe.id) ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                  }`}
                >
                  {/* Checkbox */}
                  <input
                    type="checkbox"
                    checked={selectedRecipes.includes(recipe.id)}
                    onChange={() => toggleRecipeSelection(recipe.id)}
                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 mr-3 flex-shrink-0"
                  />

                  {/* Recipe Data */}
                  <div className="flex-1 flex items-center space-x-3 min-w-0">
                    {visibleColumns.map(column => {
                      if (column.key === 'name') {
                        return (
                          <div 
                            key={column.key}
                            className={`${column.width} cursor-pointer min-w-0`}
                            onClick={() => navigate(`/recipes/${recipe.id}`)}
                          >
                            <div className="flex items-center space-x-2">
                              <h3 className="font-medium text-gray-900 dark:text-gray-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 truncate">
                                {recipe.name}
                              </h3>
                              {recipe.is_subrecipe && (
                                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 flex-shrink-0">
                                  SUB
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      }
                      
                      if (column.key === 'time') {
                        return (
                          <div key={column.key} className={`${column.width} flex items-center space-x-1 text-sm text-gray-500 dark:text-gray-400`}>
                            <Clock className="w-3 h-3" />
                            <span>{formatTime(recipe.prep_time_minutes || 0)}</span>
                          </div>
                        );
                      }
                      
                      if (column.key === 'yield') {
                        return (
                          <div key={column.key} className={`${column.width} flex items-center space-x-1 text-sm text-gray-500 dark:text-gray-400`}>
                            <Users className="w-3 h-3" />
                            <span>{recipe.yield_amount} {recipe.yield_unit}</span>
                          </div>
                        );
                      }
                      
                      if (column.key === 'station') {
                        return (
                          <div key={column.key} className={`${column.width} text-sm text-gray-500 dark:text-gray-400 truncate`}>
                            {recipe.station || '-'}
                          </div>
                        );
                      }
                      
                      if (column.key === 'category') {
                        return (
                          <div key={column.key} className={`${column.width} text-sm text-gray-500 dark:text-gray-400`}>
                            {getCategoriesForRecipe(recipe)[0]}
                          </div>
                        );
                      }
                      
                      if (column.key === 'tags') {
                        return (
                          <div key={column.key} className={`${column.width} text-sm text-gray-500 dark:text-gray-400 truncate`}>
                            {recipe.tags?.length > 0 ? recipe.tags.slice(0, 2).join(', ') + (recipe.tags.length > 2 ? '...' : '') : '-'}
                          </div>
                        );
                      }
                      
                      if (column.key === 'updated') {
                        return (
                          <div key={column.key} className={`${column.width} text-sm text-gray-500 dark:text-gray-400`}>
                            {new Date(recipe.updated_at).toLocaleDateString()}
                          </div>
                        );
                      }
                      
                      return null;
                    })}
                  </div>

                  {/* Shortlist Toggle - Right Side */}
                  <div className="w-24 flex justify-center">
                    <ShortlistToggle recipeId={recipe.id} size="sm" />
                  </div>

                  {/* Actions */}
                  <div className="w-20 flex items-center justify-end space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSingleAction('edit', recipe.id);
                      }}
                      className="p-1 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors rounded"
                      title="Edit"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSingleAction('archive', recipe.id);
                      }}
                      className="p-1 text-gray-400 hover:text-amber-600 dark:hover:text-amber-400 transition-colors rounded"
                      title="Archive"
                    >
                      <Archive className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSingleAction('delete', recipe.id);
                      }}
                      className="p-1 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors rounded"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <BulkActionsModal
        isOpen={showBulkModal}
        onClose={() => setShowBulkModal(false)}
        selectedRecipes={selectedRecipes}
        recipes={recipes}
        onBulkAction={handleBulkAction}
      />

      <CsvImportModal
        isOpen={showCsvImport}
        onClose={() => setShowCsvImport(false)}
        onSuccess={handleCsvImportSuccess}
      />

      
    </div>
  );
}
