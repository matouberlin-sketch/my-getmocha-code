import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Package, Edit3, DollarSign, Calculator, Eye, EyeOff } from 'lucide-react';
import BomTree from '@/react-app/components/BomTree';
import BomEditor from '@/react-app/components/BomEditor';

export default function RecipeDetailBom() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [recipe, setRecipe] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [showCosts, setShowCosts] = useState(true);
  const [costData, setCostData] = useState<any>(null);

  useEffect(() => {
    fetchRecipe();
    if (showCosts) {
      fetchCostData();
    }
  }, [id, showCosts]);

  const fetchRecipe = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/recipes/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch recipe');
      }
      const data = await response.json();
      setRecipe(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load recipe');
      setRecipe(null);
    } finally {
      setLoading(false);
    }
  };

  const fetchCostData = async () => {
    try {
      const response = await fetch(`/api/bom/cost/recipes/${id}`);
      if (response.ok) {
        const data = await response.json();
        setCostData(data);
      }
    } catch (err) {
      console.warn('Could not fetch cost data:', err);
    }
  };

  const handleSave = () => {
    setShowEditor(false);
    // Refresh the BOM data
    window.location.reload();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !recipe) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 mb-2">⚠️ Error</div>
          <p className="text-gray-600 text-sm mb-4">{error}</p>
          <button
            onClick={() => navigate('/recipes')}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
          >
            Back to Recipes
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-start space-x-4 flex-1">
            <button 
              onClick={() => navigate(`/recipes/${recipe.id}`)}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors mt-1"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
            
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <Package className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  BOM - {recipe.name}
                </h1>
              </div>
              
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Bill of Materials • Yield: {recipe.yield_amount} {recipe.yield_unit}
                {costData && (
                  <span className="ml-4">
                    Cost per portion: <span className="font-medium text-green-600 dark:text-green-400">
                      ${(costData.cost_per_portion_cents / 100).toFixed(2)}
                    </span>
                  </span>
                )}
              </div>

              {recipe.description && (
                <p className="text-gray-600 dark:text-gray-400 mt-2 text-sm">
                  {recipe.description}
                </p>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            <button
              onClick={() => setShowCosts(!showCosts)}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors text-sm ${
                showCosts 
                  ? 'bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900 dark:text-green-300' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'
              }`}
            >
              {showCosts ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              <span>{showCosts ? 'Hide Costs' : 'Show Costs'}</span>
            </button>

            {costData && (
              <div className="flex items-center space-x-2 px-3 py-2 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <Calculator className="w-4 h-4 text-green-600 dark:text-green-400" />
                <span className="text-sm font-medium text-green-700 dark:text-green-300">
                  Total: ${(costData.cost_per_portion_cents * recipe.yield_amount / 100).toFixed(2)}
                </span>
              </div>
            )}
            
            <button 
              onClick={() => setShowEditor(true)}
              className="flex items-center space-x-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm"
            >
              <Edit3 className="w-4 h-4" />
              <span>Edit BOM</span>
            </button>
          </div>
        </div>

        {/* Content */}
        {showEditor ? (
          <BomEditor
            recipeId={parseInt(id!)}
            onSave={handleSave}
            onCancel={() => setShowEditor(false)}
          />
        ) : (
          <BomTree 
            recipeId={parseInt(id!)} 
            showCosts={showCosts}
          />
        )}

        {/* Cost Breakdown */}
        {showCosts && costData && costData.breakdown && costData.breakdown.length > 0 && (
          <div className="mt-6 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
            <div className="border-b border-gray-200 dark:border-gray-700 p-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 flex items-center">
                <DollarSign className="w-5 h-5 mr-2 text-green-600 dark:text-green-400" />
                Cost Breakdown
              </h3>
            </div>
            
            <div className="p-4">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Item
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Quantity
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Unit Cost
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Line Cost
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {costData.breakdown.map((item: any, index: number) => (
                      <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td className="px-4 py-3 text-sm font-medium text-gray-900 dark:text-gray-100">
                          {item.item_name}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-900 dark:text-gray-100 text-right">
                          {item.qty_base.toFixed(3)} {item.uom}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-900 dark:text-gray-100 text-right">
                          ${(item.unit_cost_cents / 100).toFixed(3)}
                        </td>
                        <td className="px-4 py-3 text-sm font-medium text-gray-900 dark:text-gray-100 text-right">
                          ${(item.line_cost_cents / 100).toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <td colSpan={3} className="px-4 py-3 text-sm font-medium text-gray-900 dark:text-gray-100 text-right">
                        Total per portion:
                      </td>
                      <td className="px-4 py-3 text-sm font-bold text-green-600 dark:text-green-400 text-right">
                        ${(costData.cost_per_portion_cents / 100).toFixed(2)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
