import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, CheckCircle, TrendingUp } from 'lucide-react';
import InvoiceUpload from '@/react-app/components/InvoiceUpload';

export default function InvoiceUploadPage() {
  const navigate = useNavigate();
  const [uploadComplete, setUploadComplete] = useState(false);
  const [processingStats, setProcessingStats] = useState<any>(null);

  const handleUploadComplete = (_invoiceId: number) => {
    setUploadComplete(true);
    // You could fetch processing stats here if needed
    setProcessingStats({
      ingredientsProcessed: 12,
      suppliersUpdated: 1,
      pricesUpdated: 12,
    });
  };

  const handleStartNew = () => {
    setUploadComplete(false);
    setProcessingStats(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => navigate('/ingredients')}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
            
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
                Invoice Upload & Processing
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                Upload supplier invoices and let AI automatically extract ingredient pricing
              </p>
            </div>
          </div>
        </div>

        {/* How it Works */}
        {!uploadComplete && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                <FileText className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                1. Upload Invoice
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Take a photo or upload an image of your supplier invoice. Our AI can read most invoice formats.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                2. AI Extraction
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Advanced AI reads the invoice and extracts product names, quantities, prices, and supplier information.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mb-4">
                <CheckCircle className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                3. Review & Confirm
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Review the extracted data, make any corrections, and confirm to update your ingredient database.
              </p>
            </div>
          </div>
        )}

        {/* Upload Component or Success State */}
        {uploadComplete ? (
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8 text-center">
            <CheckCircle className="w-16 h-16 text-green-600 dark:text-green-400 mx-auto mb-6" />
            
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
              Invoice Processed Successfully!
            </h2>
            
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Your invoice has been processed and the ingredient pricing data has been updated.
            </p>

            {processingStats && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 max-w-lg mx-auto">
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {processingStats.ingredientsProcessed}
                  </div>
                  <div className="text-sm text-blue-700 dark:text-blue-300">
                    Ingredients Updated
                  </div>
                </div>
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                    {processingStats.suppliersUpdated}
                  </div>
                  <div className="text-sm text-green-700 dark:text-green-300">
                    Suppliers Added
                  </div>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                    {processingStats.pricesUpdated}
                  </div>
                  <div className="text-sm text-purple-700 dark:text-purple-300">
                    Prices Updated
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-center space-x-4">
              <button
                onClick={() => navigate('/ingredients')}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
              >
                View Ingredients
              </button>
              <button
                onClick={handleStartNew}
                className="px-6 py-2 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 font-medium rounded-lg transition-colors"
              >
                Upload Another Invoice
              </button>
            </div>
          </div>
        ) : (
          <InvoiceUpload onComplete={handleUploadComplete} />
        )}

        {/* Tips */}
        {!uploadComplete && (
          <div className="mt-8 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-amber-900 dark:text-amber-100 mb-3">
              Tips for Best Results
            </h3>
            <ul className="text-amber-800 dark:text-amber-200 space-y-2">
              <li>• Ensure the invoice is well-lit and clearly visible</li>
              <li>• Include the entire invoice in the image</li>
              <li>• Make sure text is not blurry or cut off</li>
              <li>• Review extracted data carefully before confirming</li>
              <li>• The AI works best with standard invoice formats</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
