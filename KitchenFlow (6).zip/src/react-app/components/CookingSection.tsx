import { Plus, X, Flame, Thermometer, Clock, ChefHat } from 'lucide-react';

interface CookingStep {
  equipment: string;
  method: string;
  temperature: string;
  duration: string;
  notes: string;
  process?: string; // Optional process name (e.g., "bolognese", "bechamel", "assembly")
  timing?: 'parallel' | 'sequential' | 'prep'; // Whether this can be done in parallel
}

interface CookingSectionProps {
  cookingSteps: CookingStep[];
  onUpdateCookingSteps: (steps: CookingStep[]) => void;
  readOnly?: boolean;
}

const COOKING_METHODS = [
  'bake', 'roast', 'grill', 'fry', 'sauté', 'simmer', 'boil', 'steam', 
  'braise', 'stew', 'poach', 'blanch', 'sear', 'broil', 'smoke', 'confit'
];

const EQUIPMENT_OPTIONS = [
  'oven', 'stove', 'grill', 'combi oven', 'steamer', 'fryer', 'pan', 'pot', 
  'saucepan', 'skillet', 'wok', 'griddle', 'cast iron', 'non-stick pan', 'stockpot',
  'pot (large)', 'pot (medium)', 'pot (small)', 'saucepan (large)', 'saucepan (medium)',
  'frying pan', 'sauté pan', 'baking dish', 'roasting pan', 'sheet pan', 'mixing bowl'
];

const PROCESS_OPTIONS = [
  'sauce preparation', 'protein cooking', 'vegetable preparation', 'assembly', 
  'baking', 'finishing', 'garnish', 'marinating', 'reduction', 'braising',
  'bolognese', 'bechamel', 'ragu', 'stock', 'base preparation'
];

export default function CookingSection({ cookingSteps, onUpdateCookingSteps, readOnly = false }: CookingSectionProps) {
  const addCookingStep = () => {
    onUpdateCookingSteps([
      ...cookingSteps,
      { equipment: '', method: '', temperature: '', duration: '', notes: '', process: '', timing: 'sequential' }
    ]);
  };

  const removeCookingStep = (index: number) => {
    if (cookingSteps.length > 1) {
      onUpdateCookingSteps(cookingSteps.filter((_, i) => i !== index));
    }
  };

  const updateCookingStep = (index: number, field: keyof CookingStep, value: string | undefined) => {
    onUpdateCookingSteps(
      cookingSteps.map((step, i) => 
        i === index ? { ...step, [field]: value } : step
      )
    );
  };

  const getEquipmentEmoji = (equipment: string): string => {
    const lower = equipment.toLowerCase();
    if (lower.includes('oven') || lower.includes('combi')) return '🔥';
    if (lower.includes('grill')) return '🔥';
    if (lower.includes('pan') || lower.includes('skillet')) return '🍳';
    if (lower.includes('pot') || lower.includes('sauce')) return '🫕';
    if (lower.includes('wok')) return '🥢';
    if (lower.includes('steamer')) return '🔥';
    if (lower.includes('fryer')) return '🔥';
    return '🔥';
  };

  const formatTimeDisplay = (duration: string): string => {
    if (!duration) return '';
    // Convert duration to the preferred format (5' for minutes, 1'30' for hour+minutes)
    const match = duration.match(/(\d+)(?:\s*(?:hour|hr|h))?\s*(\d+)?(?:\s*(?:minute|min|m))?/i);
    if (match) {
      const hours = parseInt(match[1]) || 0;
      const minutes = parseInt(match[2]) || 0;
      
      if (hours > 0 && minutes > 0) {
        return `${hours}'${minutes.toString().padStart(2, '0')}'`;
      } else if (hours > 0) {
        return `${hours * 60}'`;
      } else {
        return `${hours || minutes}'`;
      }
    }
    return duration;
  };

  // Get equipment requirements summary
  const getEquipmentSummary = () => {
    const equipmentCounts = new Map<string, number>();
    
    cookingSteps.forEach(step => {
      if (step.equipment) {
        const baseEquipment = step.equipment.toLowerCase().replace(/\s*\([^)]*\)/g, ''); // Remove size specifications
        equipmentCounts.set(baseEquipment, (equipmentCounts.get(baseEquipment) || 0) + 1);
      }
    });
    
    return Array.from(equipmentCounts.entries())
      .map(([equipment, count]) => count > 1 ? `${count}x ${equipment}` : equipment)
      .join(', ');
  };

  // Group steps by process for better organization
  const getProcessGroups = () => {
    const groups = new Map<string, CookingStep[]>();
    const ungrouped: CookingStep[] = [];
    
    cookingSteps.forEach(step => {
      if (step.process && step.process.trim()) {
        const processName = step.process.trim();
        if (!groups.has(processName)) {
          groups.set(processName, []);
        }
        groups.get(processName)!.push(step);
      } else {
        ungrouped.push(step);
      }
    });
    
    return { groups: Array.from(groups.entries()), ungrouped };
  };

  if (readOnly && cookingSteps.length === 0) {
    return null;
  }

  return (
    <div className="bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 rounded-xl border border-orange-200 dark:border-orange-800 p-6 mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Flame className="w-5 h-5 text-orange-600 dark:text-orange-400" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
            Cooking Method
          </h3>
        </div>
        {!readOnly && (
          <button
            type="button"
            onClick={addCookingStep}
            className="flex items-center space-x-1 text-sm text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300"
          >
            <Plus className="w-4 h-4" />
            <span>Add Step</span>
          </button>
        )}
      </div>

      {readOnly ? (
        // Display mode for recipe view
        <div className="space-y-4">
          {/* Equipment Requirements Summary */}
          {cookingSteps.length > 0 && (
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
              <div className="flex items-center space-x-2 mb-1">
                <Flame className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span className="text-sm font-medium text-blue-900 dark:text-blue-100">
                  Equipment Required:
                </span>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                {getEquipmentSummary()}
              </p>
            </div>
          )}

          {(() => {
            const { groups, ungrouped } = getProcessGroups();
            
            return (
              <div className="space-y-4">
                {/* Process Groups */}
                {groups.map(([processName, processSteps]) => (
                  <div key={processName} className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                    <div className="bg-gray-50 dark:bg-gray-700 px-4 py-2 border-b border-gray-200 dark:border-gray-600">
                      <h4 className="font-medium text-gray-900 dark:text-gray-100 capitalize">
                        {processName}
                        {processSteps.some(s => s.timing === 'parallel') && (
                          <span className="ml-2 text-xs bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 px-2 py-1 rounded">
                            Can run in parallel
                          </span>
                        )}
                      </h4>
                    </div>
                    <div className="p-3 space-y-2">
                      {processSteps.map((step, stepIndex) => (
                        <div key={stepIndex} className="flex items-start space-x-4 p-2 bg-white dark:bg-gray-800 rounded border border-gray-100 dark:border-gray-600">
                          <div className="flex-shrink-0 text-lg">
                            {getEquipmentEmoji(step.equipment)}
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-1">
                              <span className="font-medium text-gray-900 dark:text-gray-100 capitalize text-sm">
                                {step.equipment}
                              </span>
                              
                              <div className="flex items-center space-x-1 text-xs">
                                <ChefHat className="w-3 h-3 text-purple-500" />
                                <span className="text-purple-700 dark:text-purple-300 capitalize">
                                  {step.method}
                                </span>
                              </div>
                              
                              {step.temperature && (
                                <div className="flex items-center space-x-1 text-xs">
                                  <Thermometer className="w-3 h-3 text-orange-500" />
                                  <span className="text-orange-700 dark:text-orange-300">
                                    {step.temperature}
                                  </span>
                                </div>
                              )}
                              
                              {step.duration && (
                                <div className="flex items-center space-x-1 text-xs">
                                  <Clock className="w-3 h-3 text-blue-500" />
                                  <span className="text-blue-700 dark:text-blue-300 font-mono">
                                    {formatTimeDisplay(step.duration)}
                                  </span>
                                </div>
                              )}
                            </div>
                            
                            {step.notes && (
                              <p className="text-xs text-gray-600 dark:text-gray-400">
                                {step.notes}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                {/* Ungrouped Steps */}
                {ungrouped.length > 0 && (
                  <div className="space-y-2">
                    {groups.length > 0 && (
                      <h4 className="font-medium text-gray-700 dark:text-gray-300 text-sm">
                        Additional Steps:
                      </h4>
                    )}
                    {ungrouped.map((step, index) => (
                      <div key={index} className="flex items-start space-x-4 p-3 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
                        <div className="flex-shrink-0 text-2xl">
                          {getEquipmentEmoji(step.equipment)}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-1">
                            <span className="font-medium text-gray-900 dark:text-gray-100 capitalize">
                              {step.equipment}
                            </span>
                            
                            <div className="flex items-center space-x-1 text-sm">
                              <ChefHat className="w-3 h-3 text-purple-500" />
                              <span className="text-purple-700 dark:text-purple-300 capitalize">
                                {step.method}
                              </span>
                            </div>
                            
                            {step.temperature && (
                              <div className="flex items-center space-x-1 text-sm">
                                <Thermometer className="w-3 h-3 text-orange-500" />
                                <span className="text-orange-700 dark:text-orange-300">
                                  {step.temperature}
                                </span>
                              </div>
                            )}
                            
                            {step.duration && (
                              <div className="flex items-center space-x-1 text-sm">
                                <Clock className="w-3 h-3 text-blue-500" />
                                <span className="text-blue-700 dark:text-blue-300 font-mono">
                                  {formatTimeDisplay(step.duration)}
                                </span>
                              </div>
                            )}
                          </div>
                          
                          {step.notes && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {step.notes}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      ) : (
        // Edit mode for recipe creation/editing
        <div className="space-y-4">
          {cookingSteps.map((step, index) => (
            <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 bg-white dark:bg-gray-800">
              <div className="flex items-start space-x-3 mb-3">
                <div className="flex-shrink-0 w-8 h-8 bg-orange-100 dark:bg-orange-900 text-orange-700 dark:text-orange-300 rounded-full flex items-center justify-center text-sm font-medium">
                  {index + 1}
                </div>
                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Equipment *
                    </label>
                    <select
                      value={step.equipment}
                      onChange={(e) => updateCookingStep(index, 'equipment', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    >
                      <option value="">Select equipment</option>
                      {EQUIPMENT_OPTIONS.map(equipment => (
                        <option key={equipment} value={equipment}>{equipment}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Method *
                    </label>
                    <select
                      value={step.method}
                      onChange={(e) => updateCookingStep(index, 'method', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    >
                      <option value="">Select method</option>
                      {COOKING_METHODS.map(method => (
                        <option key={method} value={method}>{method}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Temperature
                    </label>
                    <input
                      type="text"
                      value={step.temperature}
                      onChange={(e) => updateCookingStep(index, 'temperature', e.target.value)}
                      placeholder="350°F, medium heat, etc."
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Duration
                    </label>
                    <input
                      type="text"
                      value={step.duration}
                      onChange={(e) => updateCookingStep(index, 'duration', e.target.value)}
                      placeholder="25 minutes, 1 hour 30 min"
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Process
                    </label>
                    <select
                      value={step.process || ''}
                      onChange={(e) => updateCookingStep(index, 'process', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    >
                      <option value="">Select process (optional)</option>
                      {PROCESS_OPTIONS.map(process => (
                        <option key={process} value={process}>{process}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Timing
                    </label>
                    <select
                      value={step.timing || 'sequential'}
                      onChange={(e) => updateCookingStep(index, 'timing', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                    >
                      <option value="sequential">Sequential</option>
                      <option value="parallel">Can do in parallel</option>
                      <option value="prep">Prep work</option>
                    </select>
                  </div>
                </div>
                {cookingSteps.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeCookingStep(index)}
                    className="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              
              <div className="ml-11">
                <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Notes (optional)
                </label>
                <input
                  type="text"
                  value={step.notes}
                  onChange={(e) => updateCookingStep(index, 'notes', e.target.value)}
                  placeholder="covered, stirring occasionally, until golden..."
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                />
              </div>
            </div>
          ))}
        </div>
      )}
      
      {readOnly && (
        <div className="mt-4 text-xs text-gray-500 dark:text-gray-400 flex items-center space-x-1">
          <Clock className="w-3 h-3" />
          <span>Follow cooking steps in sequence for best results</span>
        </div>
      )}
    </div>
  );
}
