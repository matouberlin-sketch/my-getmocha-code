import { useEffect, useState } from 'react';
import { Tag, X } from 'lucide-react';

export default function LineCookView({ planId }:{ planId:number }){
  const [day, setDay] = useState(0);
  const [data, setData] = useState<{prep:any[]; cook:any[]; order:any[]}>({ prep:[], cook:[], order:[] });
  const [loading, setLoading] = useState(false);
  const [lots, setLots] = useState<Record<number, any[]>>({});
  const [consumptionEntries, setConsumptionEntries] = useState<any[]>([]);
  const [showLotSelector, setShowLotSelector] = useState(false);
  const [selectedItemForLot, setSelectedItemForLot] = useState<any>(null);

  async function load(){
    setLoading(true);
    try {
      const res = await fetch(`/api/planner/plan/${planId}/tasks?day_index=${day}`);
      const json = await res.json();
      setData(json);
    } catch (error) {
      console.error('Failed to load line cook tasks:', error);
    } finally {
      setLoading(false);
    }
  }
  
  useEffect(()=>{ load(); }, [planId, day]);

  // Fetch lots for items when needed
  const fetchLotsForItem = async (itemId: number) => {
    if (lots[itemId]) return; // Already fetched
    
    try {
      const response = await fetch(`/api/lots/${itemId}`);
      if (response.ok) {
        const data = await response.json();
        setLots(prev => ({
          ...prev,
          [itemId]: data.lots || []
        }));
      }
    } catch (error) {
      console.error('Failed to fetch lots:', error);
    }
  };

  const handleLotSelection = (item: any) => {
    setSelectedItemForLot(item);
    setShowLotSelector(true);
    fetchLotsForItem(item.item_id);
  };

  const handleConsumptionSubmit = async () => {
    if (consumptionEntries.length === 0) return;
    
    try {
      const response = await fetch(`/api/planner/plan/${planId}/consume`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          entries: consumptionEntries.map(entry => ({
            day_index: day,
            recipe_id: entry.recipe_id,
            item_id: entry.item_id,
            lot_id: entry.lot_id,
            qty: entry.qty,
            uom: entry.uom
          }))
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log('Consumption recorded:', data);
        setConsumptionEntries([]);
        // Could show success toast here
      }
    } catch (error) {
      console.error('Failed to record consumption:', error);
    }
  };

  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const Col = ({ title, rows, color }:{title:string; rows:any[]; color:string}) => (
    <div className="flex-1 border rounded-lg p-4 bg-white shadow-sm">
      <div className={`font-semibold mb-3 text-lg ${color}`}>{title}</div>
      {rows.length === 0 ? (
        <div className="text-gray-500 italic">No {title.toLowerCase()} tasks</div>
      ) : (
        <ul className="space-y-3">
          {rows.map((r, i)=> (
            <li key={i} className="border-b border-gray-100 pb-2 last:border-b-0">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-800">{r.name}</div>
                  <div className="text-xs text-gray-500 mt-1">
                    {r.qty?.toFixed ? r.qty.toFixed(2) : r.qty} {r.uom}
                    {r.source_recipe && ` · from ${r.source_recipe}`}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {title === 'Order' && r.item_id && (
                    <button
                      onClick={() => handleLotSelection({
                        item_id: r.item_id,
                        name: r.name,
                        qty: r.qty,
                        uom: r.uom,
                        recipe_id: r.recipe_id
                      })}
                      className="flex items-center space-x-1 text-xs text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 rounded px-2 py-1 transition-colors"
                    >
                      <Tag className="w-3 h-3" />
                      <span>Lot</span>
                    </button>
                  )}
                  <div className="text-xs text-gray-600 bg-gray-100 rounded px-2 py-1">
                    {r.mins||0}m
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
      
      {rows.length > 0 && (
        <div className="mt-3 pt-2 border-t border-gray-200">
          <div className="text-sm font-medium text-gray-700">
            Total: {rows.reduce((sum, r) => sum + (r.mins || 0), 0)} minutes
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="mt-6">
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Day:</span>
          <select 
            value={day} 
            onChange={e=>setDay(Number(e.target.value))} 
            className="border rounded px-3 py-1 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            {dayNames.map((name, index) => (
              <option key={index} value={index}>{name}</option>
            ))}
          </select>
        </div>
        <button 
          onClick={()=>window.print()} 
          className="ml-auto text-sm text-blue-600 hover:underline"
        >
          Print
        </button>
      </div>
      
      {loading ? (
        <div className="text-center py-8 text-gray-500">Loading tasks...</div>
      ) : (
        <div className="flex gap-4">
          <Col title="Prep" rows={data.prep} color="text-orange-600" />
          <Col title="Cook" rows={data.cook} color="text-red-600" />
          <Col title="Order" rows={data.order} color="text-green-600" />
        </div>
      )}
      
      {/* Consumption Recording */}
      {consumptionEntries.length > 0 && (
        <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-green-900">
              Batch Consumption ({consumptionEntries.length} entries)
            </h3>
            <button
              onClick={handleConsumptionSubmit}
              className="px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg transition-colors"
            >
              Record Consumption
            </button>
          </div>
          <div className="space-y-2">
            {consumptionEntries.map((entry, index) => (
              <div key={index} className="flex items-center justify-between py-2 px-3 bg-green-100 rounded-lg text-sm">
                <span className="font-medium text-green-900">
                  {entry.item_name}
                </span>
                <span className="text-green-700">
                  {entry.qty} {entry.uom} from lot {entry.lot_code}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Lot Selector Modal */}
      {showLotSelector && selectedItemForLot && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                Select Lot for {selectedItemForLot.name}
              </h3>
              <button
                onClick={() => setShowLotSelector(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-3 mb-4">
              {lots[selectedItemForLot.item_id]?.map((lot: any, index: number) => (
                <button
                  key={index}
                  onClick={() => {
                    // Add to consumption entries
                    setConsumptionEntries(prev => [...prev, {
                      item_id: selectedItemForLot.item_id,
                      item_name: selectedItemForLot.name,
                      lot_id: lot.id,
                      lot_code: lot.lot_code,
                      qty: selectedItemForLot.qty,
                      uom: selectedItemForLot.uom,
                      recipe_id: selectedItemForLot.recipe_id
                    }]);
                    setShowLotSelector(false);
                  }}
                  className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-gray-900">
                        Lot: {lot.lot_code}
                      </div>
                      <div className="text-sm text-gray-600">
                        {lot.qty} {lot.uom} available
                      </div>
                      <div className="text-xs text-gray-500">
                        Received: {new Date(lot.received_at).toLocaleDateString()}
                      </div>
                    </div>
                    {lot.supplier_name && (
                      <div className="text-xs text-blue-600">
                        {lot.supplier_name}
                      </div>
                    )}
                  </div>
                </button>
              )) || (
                <div className="text-center py-4">
                  <p className="text-gray-500">No lots available</p>
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowLotSelector(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
