import { useState, useEffect } from 'react';
import { Filter, X, ChevronDown, Tag, Package } from 'lucide-react';

interface IngredientFiltersProps {
  onFiltersChange: (filters: any) => void;
  availableTags: string[];
  className?: string;
}

interface FilterState {
  unit_types: string[];
  tags: string[];
  has_suppliers: boolean | null;
  created_after: string;
  created_before: string;
  sort_by: string;
  sort_order: 'asc' | 'desc';
}

const UNIT_TYPE_OPTIONS = [
  { value: 'weight', label: 'Weight (kg, g, lb, oz)', icon: Package },
  { value: 'volume', label: 'Volume (l, ml, cup, tbsp)', icon: Package },
  { value: 'count', label: 'Count (piece, clove, each)', icon: Package }
];

const SORT_OPTIONS = [
  { value: 'name', label: 'Name' },
  { value: 'created_at', label: 'Created Date' },
  { value: 'updated_at', label: 'Updated Date' },
  { value: 'supplier_count', label: 'Supplier Count' },
  { value: 'min_unit_cost', label: 'Lowest Price' },
];

export default function IngredientFilters({ 
  onFiltersChange, 
  availableTags, 
  className = "" 
}: IngredientFiltersProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    unit_types: [],
    tags: [],
    has_suppliers: null,
    created_after: '',
    created_before: '',
    sort_by: 'name',
    sort_order: 'asc'
  });

  const activeFilterCount = 
    filters.unit_types.length + 
    filters.tags.length + 
    (filters.has_suppliers !== null ? 1 : 0) +
    (filters.created_after ? 1 : 0) +
    (filters.created_before ? 1 : 0);

  useEffect(() => {
    onFiltersChange(filters);
  }, [filters, onFiltersChange]);

  const handleUnitTypeToggle = (unitType: string) => {
    setFilters(prev => ({
      ...prev,
      unit_types: prev.unit_types.includes(unitType)
        ? prev.unit_types.filter(t => t !== unitType)
        : [...prev.unit_types, unitType]
    }));
  };

  const handleTagToggle = (tag: string) => {
    setFilters(prev => ({
      ...prev,
      tags: prev.tags.includes(tag)
        ? prev.tags.filter(t => t !== tag)
        : [...prev.tags, tag]
    }));
  };

  const clearFilters = () => {
    setFilters({
      unit_types: [],
      tags: [],
      has_suppliers: null,
      created_after: '',
      created_before: '',
      sort_by: 'name',
      sort_order: 'asc'
    });
  };

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
      >
        <Filter className="w-4 h-4 text-gray-500" />
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
          Filters
        </span>
        {activeFilterCount > 0 && (
          <span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-medium px-2 py-1 rounded-full">
            {activeFilterCount}
          </span>
        )}
        <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-80 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-10">
          <div className="p-4 space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                Filter Ingredients
              </h3>
              <div className="flex items-center space-x-2">
                {activeFilterCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
                  >
                    Clear All
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Unit Types */}
            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">
                Unit Types
              </label>
              <div className="space-y-2">
                {UNIT_TYPE_OPTIONS.map(option => (
                  <label key={option.value} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={filters.unit_types.includes(option.value)}
                      onChange={() => handleUnitTypeToggle(option.value)}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                    <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                      {option.label}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Tags */}
            {availableTags.length > 0 && (
              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Tags
                </label>
                <div className="max-h-32 overflow-y-auto space-y-1">
                  {availableTags.slice(0, 20).map(tag => (
                    <label key={tag} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={filters.tags.includes(tag)}
                        onChange={() => handleTagToggle(tag)}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                      />
                      <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 flex items-center">
                        <Tag className="w-3 h-3 mr-1" />
                        {tag}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Supplier Status */}
            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">
                Supplier Status
              </label>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="supplier_status"
                    checked={filters.has_suppliers === null}
                    onChange={() => setFilters(prev => ({ ...prev, has_suppliers: null }))}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">All</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="supplier_status"
                    checked={filters.has_suppliers === true}
                    onChange={() => setFilters(prev => ({ ...prev, has_suppliers: true }))}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Has Suppliers</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="supplier_status"
                    checked={filters.has_suppliers === false}
                    onChange={() => setFilters(prev => ({ ...prev, has_suppliers: false }))}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">No Suppliers</span>
                </label>
              </div>
            </div>

            {/* Date Range */}
            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">
                Created Date Range
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="date"
                  value={filters.created_after}
                  onChange={(e) => setFilters(prev => ({ ...prev, created_after: e.target.value }))}
                  className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  placeholder="After"
                />
                <input
                  type="date"
                  value={filters.created_before}
                  onChange={(e) => setFilters(prev => ({ ...prev, created_before: e.target.value }))}
                  className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  placeholder="Before"
                />
              </div>
            </div>

            {/* Sort Options */}
            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">
                Sort By
              </label>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={filters.sort_by}
                  onChange={(e) => setFilters(prev => ({ ...prev, sort_by: e.target.value }))}
                  className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                >
                  {SORT_OPTIONS.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <select
                  value={filters.sort_order}
                  onChange={(e) => setFilters(prev => ({ ...prev, sort_order: e.target.value as 'asc' | 'desc' }))}
                  className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                >
                  <option value="asc">Ascending</option>
                  <option value="desc">Descending</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
