import { useState, useCallback, useEffect } from 'react';
import { Upload, FileText, File, Grid3X3, Loader2, CheckCircle, AlertCircle, X, Search, FolderPlus, ArrowRight } from 'lucide-react';

interface ParsedRecipe {
  name: string;
  description: string;
  yield_amount: number;
  yield_unit: string;
  prep_time_minutes?: number;
  hands_on_minutes?: number;
  ingredients: Array<{
    ingredient_name: string;
    amount: number;
    unit: string;
    notes?: string;
  }>;
  steps: Array<{
    step_number: number;
    instruction: string;
  }>;
  tags: string[];
  notes?: string;
}

interface DocumentImportResult {
  import_id: number;
  recipes_found: number;
  recipes: ParsedRecipe[];
}

interface Folder {
  id: number;
  name: string;
  description?: string;
  parent_folder_id?: number;
  recipe_count: number;
  active_recipes: number;
  draft_recipes: number;
}

interface DocumentImporterProps {
  onComplete?: (importResult: any) => void;
}

export default function DocumentImporter({ onComplete }: DocumentImporterProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [importResult, setImportResult] = useState<DocumentImportResult | null>(null);
  const [selectedRecipes, setSelectedRecipes] = useState<Set<number>>(new Set());
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<number | null>(null);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [showCreateFolder, setShowCreateFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [creating, setCreating] = useState(false);

  // Load folders on component mount
  const loadFolders = useCallback(async () => {
    try {
      const response = await fetch('/api/recipe-folders');
      if (response.ok) {
        const foldersData = await response.json();
        setFolders(foldersData);
      }
    } catch (error) {
      console.warn('Failed to load folders:', error);
    }
  }, []);

  useEffect(() => {
    loadFolders();
  }, [loadFolders]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleFile = async (file: File) => {
    const allowedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
      'application/msword', // .doc
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
      'text/plain' // For testing
    ];

    if (!allowedTypes.some(type => file.type === type || file.name.toLowerCase().endsWith('.pdf') || file.name.toLowerCase().endsWith('.docx') || file.name.toLowerCase().endsWith('.doc') || file.name.toLowerCase().endsWith('.xlsx'))) {
      setError('Please upload a PDF, Word document, or Excel file');
      return;
    }

    if (file.size > 50 * 1024 * 1024) { // 50MB limit
      setError('File size must be less than 50MB');
      return;
    }

    setProcessing(true);
    setError('');

    try {
      // Convert file to base64
      const base64 = await fileToBase64(file);
      
      // Determine file type
      let fileType = 'pdf';
      if (file.name.toLowerCase().endsWith('.docx')) fileType = 'docx';
      else if (file.name.toLowerCase().endsWith('.doc')) fileType = 'doc';
      else if (file.name.toLowerCase().endsWith('.xlsx')) fileType = 'xlsx';
      
      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          file_data: base64.split(',')[1], // Remove data prefix
          filename: file.name,
          file_type: fileType,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to process document');
      }

      const result = await response.json();
      setImportResult(result);
      
      // Pre-select all recipes by default
      const allIndexes = new Set<number>(result.recipes.map((_: any, index: number) => index));
      setSelectedRecipes(allIndexes);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process document');
    } finally {
      setProcessing(false);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleRecipeToggle = (index: number) => {
    const newSelected = new Set(selectedRecipes);
    if (newSelected.has(index)) {
      newSelected.delete(index);
    } else {
      newSelected.add(index);
    }
    setSelectedRecipes(newSelected);
  };

  const handleSelectAll = () => {
    if (!importResult) return;
    
    const filteredIndexes = importResult.recipes
      .map((_, index) => index)
      .filter(index => {
        const recipe = importResult.recipes[index];
        return recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
               recipe.description.toLowerCase().includes(searchTerm.toLowerCase());
      });
    
    const newSelected = new Set(selectedRecipes);
    filteredIndexes.forEach(index => newSelected.add(index));
    setSelectedRecipes(newSelected);
  };

  const handleDeselectAll = () => {
    if (!importResult) return;
    
    const filteredIndexes = importResult.recipes
      .map((_, index) => index)
      .filter(index => {
        const recipe = importResult.recipes[index];
        return recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
               recipe.description.toLowerCase().includes(searchTerm.toLowerCase());
      });
    
    const newSelected = new Set(selectedRecipes);
    filteredIndexes.forEach(index => newSelected.delete(index));
    setSelectedRecipes(newSelected);
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    
    setCreating(true);
    try {
      const response = await fetch('/api/recipe-folders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newFolderName.trim(),
          description: `Folder created during document import`
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create folder');
      }

      const result = await response.json();
      setSelectedFolder(result.id);
      setNewFolderName('');
      setShowCreateFolder(false);
      await loadFolders(); // Reload folders
    } catch (error) {
      setError('Failed to create folder');
    } finally {
      setCreating(false);
    }
  };

  const handleCreateRecipes = async () => {
    if (!importResult || selectedRecipes.size === 0) return;

    setCreating(true);
    try {
      const response = await fetch('/api/documents/create-recipes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          import_id: importResult.import_id,
          selected_recipes: Array.from(selectedRecipes),
          folder_id: selectedFolder,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create recipes');
      }

      const result = await response.json();
      onComplete?.(result);
    } catch (error) {
      setError('Failed to create recipes');
    } finally {
      setCreating(false);
    }
  };

  const resetImporter = () => {
    setImportResult(null);
    setSelectedRecipes(new Set());
    setError('');
    setSearchTerm('');
    setSelectedFolder(null);
    setProcessing(false);
  };

  // Filter recipes based on search term
  const filteredRecipes = importResult?.recipes.filter(recipe =>
    recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    recipe.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    recipe.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  ) || [];

  return (
    <div className="max-w-6xl mx-auto">
      {!importResult ? (
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8">
          <div className="text-center mb-6">
            <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">
              Import Recipes from Documents
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Upload PDF recipe books, Word documents, or Excel spreadsheets and AI will extract all recipes automatically
            </p>
          </div>

          {processing ? (
            <div className="text-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                Processing Document...
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                AI is analyzing your document and extracting all recipes. This may take a few minutes for large documents.
              </p>
            </div>
          ) : (
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                isDragging
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <div className="flex justify-center space-x-4 mb-4">
                <FileText className="w-12 h-12 text-red-400" />
                <File className="w-12 h-12 text-blue-400" />
                <Grid3X3 className="w-12 h-12 text-green-400" />
              </div>
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
                Drag and drop your document here, or click to browse
              </p>
              <input
                type="file"
                accept=".pdf,.doc,.docx,.xlsx"
                onChange={handleFileSelect}
                className="hidden"
                id="document-upload"
              />
              <label
                htmlFor="document-upload"
                className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg cursor-pointer transition-colors"
              >
                <Upload className="w-4 h-4 mr-2" />
                Choose Document
              </label>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                Supports PDF, Word (.doc/.docx), Excel (.xlsx) up to 50MB
              </p>
            </div>
          )}

          {/* Supported File Types */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4 text-center">
              <FileText className="w-8 h-8 text-red-600 dark:text-red-400 mx-auto mb-2" />
              <h3 className="font-medium text-red-900 dark:text-red-100 mb-1">PDF Files</h3>
              <p className="text-sm text-red-700 dark:text-red-300">Recipe books, scanned documents, menu collections</p>
            </div>
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 text-center">
              <File className="w-8 h-8 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
              <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-1">Word Documents</h3>
              <p className="text-sm text-blue-700 dark:text-blue-300">Recipe collections, catering menus, prep lists</p>
            </div>
            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 text-center">
              <Grid3X3 className="w-8 h-8 text-green-600 dark:text-green-400 mx-auto mb-2" />
              <h3 className="font-medium text-green-900 dark:text-green-100 mb-1">Excel Files</h3>
              <p className="text-sm text-green-700 dark:text-green-300">Recipe databases, ingredient lists, menu planning</p>
            </div>
          </div>

          {error && (
            <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <div className="flex items-start space-x-2">
                <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-red-800 dark:text-red-200 mb-1">
                    Document Processing Failed
                  </h3>
                  <p className="text-red-700 dark:text-red-300 text-sm">{error}</p>
                  {error.includes('quota exceeded') && (
                    <div className="mt-2 p-2 bg-red-100 dark:bg-red-800 rounded text-xs text-red-600 dark:text-red-300">
                      <strong>Tip:</strong> This feature uses OpenAI's API for document analysis. You can:
                      <ul className="mt-1 ml-4 list-disc">
                        <li>Check your <a href="https://platform.openai.com/usage" target="_blank" rel="noopener noreferrer" className="underline">OpenAI usage dashboard</a></li>
                        <li>Upgrade your OpenAI plan if needed</li>
                        <li>Try again after your quota resets</li>
                        <li>Use smaller documents or break large files into sections</li>
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Success Header */}
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 mr-2" />
                <div>
                  <h3 className="text-green-800 dark:text-green-200 font-medium">
                    Document Processed Successfully
                  </h3>
                  <p className="text-green-700 dark:text-green-300 text-sm">
                    Found {importResult.recipes_found} recipe{importResult.recipes_found !== 1 ? 's' : ''} • Select which ones to import
                  </p>
                </div>
              </div>
              <button
                onClick={resetImporter}
                className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search and Selection Controls */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Search recipes..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={handleSelectAll}
                  className="px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Select All
                </button>
                <button
                  onClick={handleDeselectAll}
                  className="px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Deselect All
                </button>
              </div>
            </div>

            <div className="mt-4 flex items-center text-sm text-gray-600 dark:text-gray-400">
              <span>{selectedRecipes.size} of {importResult.recipes_found} recipe{selectedRecipes.size !== 1 ? 's' : ''} selected for import</span>
            </div>
          </div>

          {/* Folder Selection */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Organization
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Import to Folder (Optional)
                </label>
                <div className="flex space-x-2">
                  <select
                    value={selectedFolder || ''}
                    onChange={(e) => setSelectedFolder(e.target.value ? parseInt(e.target.value) : null)}
                    className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  >
                    <option value="">No Folder (Root)</option>
                    {folders.map(folder => (
                      <option key={folder.id} value={folder.id}>
                        {folder.name} ({folder.recipe_count} recipes)
                      </option>
                    ))}
                  </select>
                  
                  <button
                    onClick={() => setShowCreateFolder(true)}
                    className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    <FolderPlus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {showCreateFolder && (
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      placeholder="Folder name"
                      value={newFolderName}
                      onChange={(e) => setNewFolderName(e.target.value)}
                      className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                    />
                    <button
                      onClick={handleCreateFolder}
                      disabled={creating || !newFolderName.trim()}
                      className="px-3 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg transition-colors"
                    >
                      Create
                    </button>
                    <button
                      onClick={() => {
                        setShowCreateFolder(false);
                        setNewFolderName('');
                      }}
                      className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Recipe List */}
          <div className="space-y-4">
            {filteredRecipes.map((recipe) => {
              const globalIndex = importResult.recipes.indexOf(recipe);
              const isSelected = selectedRecipes.has(globalIndex);
              
              return (
                <div
                  key={globalIndex}
                  className={`bg-white dark:bg-gray-800 rounded-xl border-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                  onClick={() => handleRecipeToggle(globalIndex)}
                >
                  <div className="p-6">
                    <div className="flex items-start space-x-4">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleRecipeToggle(globalIndex)}
                        className="mt-1 w-5 h-5 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                        onClick={(e) => e.stopPropagation()}
                      />
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                            {recipe.name}
                          </h3>
                          <div className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400">
                            {recipe.prep_time_minutes && (
                              <span>{recipe.prep_time_minutes}m prep</span>
                            )}
                            {recipe.hands_on_minutes && (
                              <span>• {recipe.hands_on_minutes}m hands-on</span>
                            )}
                            <span>• {recipe.yield_amount} {recipe.yield_unit}</span>
                          </div>
                        </div>
                        
                        {recipe.description && (
                          <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                            {recipe.description}
                          </p>
                        )}
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-gray-700 dark:text-gray-300">
                              Ingredients ({recipe.ingredients.length}):
                            </span>
                            <p className="text-gray-600 dark:text-gray-400 mt-1">
                              {recipe.ingredients.slice(0, 3).map(ing => ing.ingredient_name).join(', ')}
                              {recipe.ingredients.length > 3 && '...'}
                            </p>
                          </div>
                          
                          <div>
                            <span className="font-medium text-gray-700 dark:text-gray-300">
                              Steps ({recipe.steps.length}):
                            </span>
                            <p className="text-gray-600 dark:text-gray-400 mt-1">
                              {recipe.steps[0]?.instruction.slice(0, 50)}
                              {recipe.steps[0]?.instruction.length > 50 && '...'}
                            </p>
                          </div>
                          
                          <div>
                            <span className="font-medium text-gray-700 dark:text-gray-300">
                              Tags:
                            </span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {recipe.tags.slice(0, 4).map(tag => (
                                <span
                                  key={tag}
                                  className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full text-xs"
                                >
                                  {tag}
                                </span>
                              ))}
                              {recipe.tags.length > 4 && (
                                <span className="text-xs text-gray-500 dark:text-gray-400">
                                  +{recipe.tags.length - 4} more
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Actions */}
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Recipes will be imported as <span className="font-medium text-blue-600 dark:text-blue-400">drafts</span> for you to review before adding to your active shortlist
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={resetImporter}
                  className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
                >
                  Upload Different Document
                </button>
                <button
                  onClick={handleCreateRecipes}
                  disabled={creating || selectedRecipes.size === 0}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors flex items-center space-x-2"
                >
                  {creating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Creating...</span>
                    </>
                  ) : (
                    <>
                      <span>Import {selectedRecipes.size} Recipe{selectedRecipes.size !== 1 ? 's' : ''}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {error && (
            <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <div className="flex items-center">
                <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />
                <p className="text-red-700 dark:text-red-300">{error}</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
