import { useState } from 'react';
import { X, Save, Loader2, Trash2 } from 'lucide-react';
import TagInput from './TagInput';

interface BulkIngredientsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedIngredients: number[];
  ingredients: any[];
  onBulkAction: (action: string, data: any) => Promise<void>;
}

const COMMON_INGREDIENT_TAGS = [
  'dairy', 'produce', 'meat', 'seafood', 'poultry', 'spice', 'herb', 'grain',
  'frozen', 'canned', 'fresh', 'dried', 'organic', 'local', 'imported',
  'allergen-dairy', 'allergen-gluten', 'allergen-nuts', 'allergen-soy',
  'beverage', 'condiment', 'oil', 'vinegar', 'baking', 'pantry'
];

export default function BulkIngredientsModal({ 
  isOpen, 
  onClose, 
  selectedIngredients, 
  ingredients, 
  onBulkAction 
}: BulkIngredientsModalProps) {
  const [operation, setOperation] = useState<'delete' | 'tag_add' | 'tag_remove' | 'update_waste'>('tag_add');
  const [tags, setTags] = useState<string[]>([]);
  const [wastePercentage, setWastePercentage] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [confirmText, setConfirmText] = useState('');

  const selectedIngredientNames = ingredients
    .filter(ing => selectedIngredients.includes(ing.id))
    .map(ing => ing.name);

  const handleSubmit = async () => {
    if (operation === 'delete' && confirmText !== 'DELETE') {
      return;
    }

    setLoading(true);
    try {
      const data: any = { ingredient_ids: selectedIngredients, operation };
      
      if (operation === 'tag_add' || operation === 'tag_remove') {
        data.tags = tags;
      } else if (operation === 'update_waste') {
        data.waste_percentage = wastePercentage;
      }
      
      await onBulkAction(operation, data);
      onClose();
      
      // Reset form
      setTags([]);
      setWastePercentage(0);
      setConfirmText('');
    } catch (error) {
      console.error('Bulk operation failed:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            Bulk Actions ({selectedIngredients.length} ingredients)
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Operation Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Operation
            </label>
            <select
              value={operation}
              onChange={(e) => setOperation(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            >
              <option value="tag_add">Add Tags</option>
              <option value="tag_remove">Remove Tags</option>
              <option value="update_waste">Update Waste Percentage</option>
              <option value="delete">Delete Ingredients</option>
            </select>
          </div>

          {/* Selected Ingredients Preview */}
          <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">
              Selected Ingredients:
            </h3>
            <div className="text-sm text-gray-600 dark:text-gray-400 max-h-32 overflow-y-auto">
              {selectedIngredientNames.map((name, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <span>•</span>
                  <span>{name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Operation-specific inputs */}
          {(operation === 'tag_add' || operation === 'tag_remove') && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {operation === 'tag_add' ? 'Tags to Add' : 'Tags to Remove'}
              </label>
              <TagInput
                tags={tags}
                onTagsChange={setTags}
                suggestions={COMMON_INGREDIENT_TAGS}
                placeholder={`Add ${operation === 'tag_add' ? 'new' : 'existing'} tags...`}
              />
            </div>
          )}

          {operation === 'update_waste' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Waste Percentage
              </label>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={wastePercentage}
                  onChange={(e) => setWastePercentage(parseFloat(e.target.value) || 0)}
                  className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
                <span className="text-sm text-gray-500 dark:text-gray-400">%</span>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Percentage of ingredient lost during preparation (trimming, peeling, etc.)
              </p>
            </div>
          )}

          {operation === 'delete' && (
            <>
              <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <p className="text-sm text-red-700 dark:text-red-300">
                  <strong>Warning:</strong> This will permanently delete the selected ingredients and all their associated data (tags, supplier pricing). This action cannot be undone.
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-red-700 dark:text-red-300 mb-2">
                  Type "DELETE" to confirm deletion
                </label>
                <input
                  type="text"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)}
                  placeholder="DELETE"
                  className="w-full px-3 py-2 border border-red-300 dark:border-red-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
              </div>
            </>
          )}

          {/* Action descriptions */}
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
            <p className="text-sm text-blue-700 dark:text-blue-300">
              {operation === 'tag_add' && "Add the specified tags to all selected ingredients."}
              {operation === 'tag_remove' && "Remove the specified tags from all selected ingredients."}
              {operation === 'update_waste' && "Set the waste percentage for all selected ingredients to the specified value."}
              {operation === 'delete' && "Permanently delete all selected ingredients (if not used in recipes)."}
            </p>
          </div>
        </div>

        <div className="flex justify-end space-x-3 mt-8">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading || (operation === 'delete' && confirmText !== 'DELETE') || 
                     ((operation === 'tag_add' || operation === 'tag_remove') && tags.length === 0)}
            className={`px-6 py-2 font-medium rounded-lg transition-colors flex items-center space-x-2 ${
              operation === 'delete'
                ? 'bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white'
                : 'bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white'
            }`}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <>
                {operation === 'delete' ? <Trash2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
                <span>
                  {operation === 'delete' ? 'Delete' : 
                   operation === 'tag_add' ? 'Add Tags' :
                   operation === 'tag_remove' ? 'Remove Tags' : 'Update Waste %'}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
