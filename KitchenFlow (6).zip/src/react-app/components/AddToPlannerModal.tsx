import { useState } from 'react';
import { Calendar, Users, X } from 'lucide-react';

interface AddToPlannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipe: {
    id: number;
    name: string;
    yield_amount: number;
    yield_unit: string;
  };
  onSuccess: () => void;
}

export default function AddToPlannerModal({ isOpen, onClose, recipe, onSuccess }: AddToPlannerModalProps) {
  const [date, setDate] = useState('');
  const [mealType, setMealType] = useState<'lunch' | 'dinner'>('lunch');
  const [portionCount, setPortionCount] = useState(recipe.yield_amount);
  const [portionProfile, setPortionProfile] = useState('standard');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!date) return;

    setLoading(true);
    try {
      const response = await fetch('/api/planned-meals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          date,
          meal_type: mealType,
          recipe_id: recipe.id,
          portion_count: portionCount,
          portion_profile: portionProfile,
          notes: notes || null,
        }),
      });

      if (response.ok) {
        onSuccess();
        onClose();
        // Reset form
        setDate('');
        setPortionCount(recipe.yield_amount);
        setNotes('');
      } else {
        const error = await response.json();
        console.error('Failed to add to planner:', error);
        alert('Failed to add recipe to planner. Please try again.');
      }
    } catch (error) {
      console.error('Error adding to planner:', error);
      alert('Failed to add recipe to planner. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            Add to Weekly Quick List
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
          <h3 className="font-medium text-blue-900 dark:text-blue-100">
            {recipe.name}
          </h3>
          <p className="text-sm text-blue-700 dark:text-blue-300">
            Base yield: {recipe.yield_amount} {recipe.yield_unit}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              <Calendar className="w-4 h-4 inline mr-2" />
              Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Meal Type
            </label>
            <select
              value={mealType}
              onChange={(e) => setMealType(e.target.value as 'lunch' | 'dinner')}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            >
              <option value="lunch">Lunch</option>
              <option value="dinner">Dinner</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              <Users className="w-4 h-4 inline mr-2" />
              Portion Count
            </label>
            <input
              type="number"
              min="1"
              step="0.1"
              value={portionCount}
              onChange={(e) => setPortionCount(parseFloat(e.target.value) || 1)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Portion Profile
            </label>
            <select
              value={portionProfile}
              onChange={(e) => setPortionProfile(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            >
              <option value="standard">Standard Portions</option>
              <option value="staff">Staff Portions</option>
              <option value="xl">XL Portions</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Notes (Optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              placeholder="Any special notes for this planned meal..."
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !date}
              className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white font-medium rounded-lg transition-colors"
            >
              {loading ? 'Adding...' : 'Add to Quick List'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
