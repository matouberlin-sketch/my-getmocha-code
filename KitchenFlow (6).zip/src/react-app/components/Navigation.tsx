// CRITICAL: This component uses React Router hooks (useLocation)
// It MUST be imported directly in App.tsx, never lazy-loaded
// See REACT_ROUTER_ERROR_DOCUMENTATION.md for details
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  Calendar, 
  ChefHat, 
  Package, 
  ClipboardList, 
  ShoppingCart, 
  Database,
  MapPin,
  Search
} from 'lucide-react';

const navItems = [
  { path: '/', icon: Home, label: 'Dashboard' },
  { path: '/enhanced-recipes', icon: ChefHat, label: 'Recipes' },
  { path: '/planner', icon: Calendar, label: 'Menu Planning' },
  { path: '/items', icon: Package, label: 'Items' },
  { path: '/locations', icon: MapPin, label: 'Locations' },
  { path: '/erp-import', icon: Database, label: 'ERP Import' },
  { path: '/make-sheet', icon: ClipboardList, label: 'Make Sheet' },
  { path: '/shopping', icon: ShoppingCart, label: 'Shopping' },
];

export default function Navigation() {
  const location = useLocation();

  return (
    <nav className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-4 py-3 sticky top-0 z-40">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center space-x-1 overflow-x-auto">
          {navItems.map(({ path, icon: Icon, label }) => (
            <Link
              key={path}
              to={path}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                location.pathname === path || 
                (path === '/enhanced-recipes' && location.pathname.startsWith('/enhanced-recipes'))
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span className="hidden sm:inline">{label}</span>
            </Link>
          ))}
        </div>
        
        <button 
          className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors ml-4 flex-shrink-0"
          onClick={() => {
            // TODO: Implement global search (⌘/Ctrl-K)
          }}
        >
          <Search className="w-4 h-4" />
          <span className="hidden md:inline">Search</span>
          <kbd className="hidden md:inline-block px-2 py-1 text-xs font-mono bg-gray-200 dark:bg-gray-700 rounded">⌘K</kbd>
        </button>
      </div>
    </nav>
  );
}
