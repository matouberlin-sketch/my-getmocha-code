import { useEffect, useState } from 'react';

export default function PlannerBreakdown({ planId }:{ planId:number }){
  const [view, setView] = useState<'items'|'components'>('components');
  const [data, setData] = useState<any>({ days: [] });
  const [loading, setLoading] = useState(false);

  async function load(){
    setLoading(true);
    try {
      const res = await fetch(`/api/planner/plan/${planId}/components?view=${view}`);
      const json = await res.json();
      setData(json); 
    } catch (error) {
      console.error('Failed to load breakdown:', error);
    } finally {
      setLoading(false);
    }
  }
  
  useEffect(()=>{ load(); }, [planId, view]);

  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  return (
    <div className="mt-6">
      <div className="flex items-center gap-2 mb-3">
        <span className="text-sm font-medium">Breakdown:</span>
        <button 
          onClick={()=>setView('components')} 
          className={`px-3 py-1 rounded text-sm ${view==='components'?'bg-blue-600 text-white':'bg-gray-200 hover:bg-gray-300'}`}
        >
          Components
        </button>
        <button 
          onClick={()=>setView('items')} 
          className={`px-3 py-1 rounded text-sm ${view==='items'?'bg-blue-600 text-white':'bg-gray-200 hover:bg-gray-300'}`}
        >
          Items
        </button>
        <button 
          onClick={()=>window.print()} 
          className="ml-auto text-sm text-blue-600 hover:underline"
        >
          Print
        </button>
      </div>
      
      {loading ? (
        <div className="text-center py-8 text-gray-500">Loading breakdown...</div>
      ) : (
        <div className="space-y-6">
          {data.days.map((d:any)=> (
            <div key={d.day_index} className="border rounded-lg p-4 bg-white shadow-sm">
              <div className="font-semibold mb-3 text-lg text-gray-800">
                {dayNames[d.day_index]}
              </div>
              
              {d.lines.length === 0 ? (
                <div className="text-gray-500 italic">No items planned for this day</div>
              ) : view==='items' ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-gray-50">
                        <th className="text-left py-2 px-3 font-medium">Item</th>
                        <th className="text-right py-2 px-3 font-medium">Net Qty</th>
                        <th className="text-left py-2 px-3 font-medium">UoM</th>
                        <th className="text-right py-2 px-3 font-medium">Minutes</th>
                      </tr>
                    </thead>
                    <tbody>
                      {d.lines.map((ln:any, i:number)=> (
                        <tr key={i} className="border-b hover:bg-gray-50">
                          <td className="py-2 px-3">{ln.name}</td>
                          <td className="text-right py-2 px-3">{ln.net_qty.toFixed(2)}</td>
                          <td className="py-2 px-3">{ln.uom}</td>
                          <td className="text-right py-2 px-3">{ln.mins}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="space-y-3">
                  {d.lines.map((r:any) => (
                    <div key={r.recipe_id} className="border-l-4 border-blue-500 pl-4">
                      <div className="font-medium text-gray-800 mb-2">
                        {r.name} · <span className="text-sm text-gray-600">{r.portions} portions</span>
                      </div>
                      <ul className="space-y-1">
                        {r.children.map((c:any, i:number)=> (
                          <li key={i} className="text-sm text-gray-700 flex justify-between">
                            <span>
                              {c.type==='item' ? (
                                <span className="flex items-center">
                                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                                  {c.name}
                                </span>
                              ) : (
                                <span className="flex items-center">
                                  <span className="w-2 h-2 bg-orange-500 rounded-full mr-2"></span>
                                  {c.name}
                                </span>
                              )}
                            </span>
                            <span className="text-gray-500">
                              {c.net_qty.toFixed(2)} {c.uom} · {c.mins}m
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
