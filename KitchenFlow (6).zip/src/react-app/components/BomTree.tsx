import { useState, useEffect } from 'react';
import { ChevronDown, ChevronRight, Package, Utensils } from 'lucide-react';

interface BomNode {
  id: number;
  component_type: 'item' | 'subrecipe';
  component_id: number;
  component_name: string;
  gross_qty: number;
  net_qty: number;
  uom: string;
  trim_loss_pct: number;
  cook_yield_pct: number;
  stage?: string;
  note?: string;
  unit_cost_cents?: number;
  line_cost_cents?: number;
}

interface BomTreeData {
  recipe_id: number;
  recipe_name: string;
  portion_yield: number;
  bom: BomNode[];
  total_cost_cents?: number;
  cost_per_portion_cents?: number;
}

interface BomTreeProps {
  recipeId: number;
  showCosts?: boolean;
  className?: string;
}

export default function BomTree({ recipeId, showCosts = false, className = '' }: BomTreeProps) {
  const [bomData, setBomData] = useState<BomTreeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedItems, setExpandedItems] = useState<Set<number>>(new Set());

  useEffect(() => {
    fetchBomData();
  }, [recipeId, showCosts]);

  const fetchBomData = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (showCosts) params.set('show_costs', 'true');
      
      const response = await fetch(`/api/bom/recipes/${recipeId}/bom?${params}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch BOM: ${response.statusText}`);
      }
      
      const data = await response.json();
      setBomData(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load BOM');
      setBomData(null);
    } finally {
      setLoading(false);
    }
  };

  const toggleExpanded = (itemId: number) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(itemId)) {
      newExpanded.delete(itemId);
    } else {
      newExpanded.add(itemId);
    }
    setExpandedItems(newExpanded);
  };

  const formatCurrency = (cents: number) => {
    return `$${(cents / 100).toFixed(2)}`;
  };

  if (loading) {
    return (
      <div className={`bg-white rounded-lg border p-6 ${className}`}>
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded mb-4 w-1/3"></div>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-4 bg-gray-200 rounded w-full"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`bg-white rounded-lg border p-6 ${className}`}>
        <div className="text-center py-8">
          <div className="text-red-500 mb-2">⚠️ Error Loading BOM</div>
          <p className="text-gray-600 text-sm mb-4">{error}</p>
          <button
            onClick={fetchBomData}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!bomData || !bomData.bom.length) {
    return (
      <div className={`bg-white rounded-lg border p-6 ${className}`}>
        <div className="text-center py-8 text-gray-500">
          <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No BOM components found</p>
          <p className="text-sm">Add items or subrecipes to build the bill of materials</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-lg border ${className}`}>
      {/* Header */}
      <div className="border-b p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Bill of Materials</h3>
            <p className="text-sm text-gray-600">
              {bomData.recipe_name} • Yield: {bomData.portion_yield} portions
            </p>
          </div>
          {showCosts && bomData.cost_per_portion_cents !== undefined && (
            <div className="text-right">
              <div className="text-2xl font-bold text-green-600">
                {formatCurrency(bomData.cost_per_portion_cents)}
              </div>
              <div className="text-sm text-gray-600">per portion</div>
            </div>
          )}
        </div>
      </div>

      {/* Column Headers */}
      <div className="border-b bg-gray-50 px-4 py-2">
        <div className="grid grid-cols-12 gap-4 text-xs font-medium text-gray-700 uppercase tracking-wide">
          <div className="col-span-4">Component</div>
          <div className="col-span-2 text-center">Gross Qty</div>
          <div className="col-span-2 text-center">Net Qty</div>
          <div className="col-span-1 text-center">UoM</div>
          <div className="col-span-1 text-center">Loss %</div>
          <div className="col-span-1 text-center">Yield %</div>
          {showCosts && <div className="col-span-1 text-right">Cost</div>}
        </div>
      </div>

      {/* BOM Items */}
      <div className="divide-y">
        {bomData.bom.map((item) => (
          <BomItem
            key={item.id}
            item={item}
            showCosts={showCosts}
            isExpanded={expandedItems.has(item.id)}
            onToggleExpanded={() => toggleExpanded(item.id)}
            depth={0}
          />
        ))}
      </div>

      {/* Footer Summary */}
      {showCosts && bomData.total_cost_cents !== undefined && (
        <div className="border-t bg-gray-50 p-4">
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-600">
              Total recipe cost for {bomData.portion_yield} portions
            </div>
            <div className="text-lg font-semibold text-gray-900">
              {formatCurrency(bomData.total_cost_cents)}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

interface BomItemProps {
  item: BomNode;
  showCosts: boolean;
  isExpanded: boolean;
  onToggleExpanded: () => void;
  depth: number;
}

function BomItem({ item, showCosts, isExpanded, onToggleExpanded, depth }: BomItemProps) {
  const formatCurrency = (cents: number) => `$${(cents / 100).toFixed(2)}`;
  const formatQuantity = (qty: number) => qty % 1 === 0 ? qty.toString() : qty.toFixed(3);
  const formatPercentage = (value: number) => `${value.toFixed(1)}%`;

  const paddingLeft = depth * 24;
  const isSubrecipe = item.component_type === 'subrecipe';

  return (
    <div className="hover:bg-gray-50 transition-colors">
      <div className="px-4 py-3">
        <div className="grid grid-cols-12 gap-4 items-center">
          {/* Component Name */}
          <div className="col-span-4 flex items-center" style={{ paddingLeft: `${paddingLeft}px` }}>
            {isSubrecipe && (
              <button
                onClick={onToggleExpanded}
                className="p-1 hover:bg-gray-200 rounded mr-2 transition-colors"
              >
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </button>
            )}
            <div className="flex items-center">
              {isSubrecipe ? (
                <Utensils className="w-4 h-4 text-blue-500 mr-2" />
              ) : (
                <Package className="w-4 h-4 text-gray-500 mr-2" />
              )}
              <div>
                <div className="font-medium text-gray-900">{item.component_name}</div>
                {item.stage && (
                  <div className="text-xs text-blue-600 font-medium">Stage: {item.stage}</div>
                )}
                {item.note && (
                  <div className="text-xs text-gray-500">{item.note}</div>
                )}
              </div>
            </div>
          </div>

          {/* Gross Quantity */}
          <div className="col-span-2 text-center">
            <span className="font-mono text-sm">{formatQuantity(item.gross_qty)}</span>
          </div>

          {/* Net Quantity */}
          <div className="col-span-2 text-center">
            <span className="font-mono text-sm font-medium">{formatQuantity(item.net_qty)}</span>
            {item.gross_qty !== item.net_qty && (
              <div className="text-xs text-gray-500">
                ({((item.net_qty / item.gross_qty) * 100).toFixed(0)}%)
              </div>
            )}
          </div>

          {/* Unit of Measure */}
          <div className="col-span-1 text-center">
            <span className="text-xs bg-gray-100 px-2 py-1 rounded">{item.uom}</span>
          </div>

          {/* Trim Loss % */}
          <div className="col-span-1 text-center">
            {item.trim_loss_pct > 0 ? (
              <span className="text-xs text-orange-600">{formatPercentage(item.trim_loss_pct)}</span>
            ) : (
              <span className="text-xs text-gray-400">—</span>
            )}
          </div>

          {/* Cook Yield % */}
          <div className="col-span-1 text-center">
            {item.cook_yield_pct !== 100 ? (
              <span className={`text-xs ${item.cook_yield_pct < 100 ? 'text-red-600' : 'text-green-600'}`}>
                {formatPercentage(item.cook_yield_pct)}
              </span>
            ) : (
              <span className="text-xs text-gray-400">—</span>
            )}
          </div>

          {/* Cost */}
          {showCosts && (
            <div className="col-span-1 text-right">
              {item.line_cost_cents !== undefined ? (
                <div>
                  <div className="font-medium text-sm">{formatCurrency(item.line_cost_cents)}</div>
                  {item.unit_cost_cents !== undefined && item.unit_cost_cents > 0 && (
                    <div className="text-xs text-gray-500">
                      {formatCurrency(item.unit_cost_cents)}/{item.uom}
                    </div>
                  )}
                </div>
              ) : (
                <span className="text-xs text-gray-400">—</span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Subrecipe expansion would go here */}
      {isSubrecipe && isExpanded && (
        <div className="border-l-2 border-blue-200 ml-8">
          {/* This would recursively load subrecipe BOM */}
          <div className="px-4 py-2 text-sm text-gray-600 italic">
            Subrecipe expansion would be loaded here
          </div>
        </div>
      )}
    </div>
  );
}
