import { useState } from 'react';
import { Plus, X, Tag } from 'lucide-react';

interface TagInputProps {
  tags: string[];
  onTagsChange: (tags: string[]) => void;
  placeholder?: string;
  suggestions?: string[];
}

const DEFAULT_SUGGESTIONS = [
  'main', 'appetizer', 'dessert', 'side', 'sauce', 'component',
  'breakfast', 'lunch', 'dinner', 'snack',
  'vegetarian', 'vegan', 'gluten-free', 'dairy-free',
  'quick', 'easy', 'advanced', 'make-ahead',
  'italian', 'asian', 'mexican', 'indian', 'mediterranean', 'french',
  'chicken', 'beef', 'pork', 'seafood', 'vegetable',
  'baked', 'grilled', 'fried', 'slow-cooked', 'raw',
  'hot', 'cold', 'spicy', 'sweet', 'savory'
];

export default function TagInput({ 
  tags, 
  onTagsChange, 
  placeholder = "Add tags...",
  suggestions = DEFAULT_SUGGESTIONS 
}: TagInputProps) {
  const [inputValue, setInputValue] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  const filteredSuggestions = suggestions
    .filter(suggestion => 
      !tags.includes(suggestion) && 
      suggestion.toLowerCase().includes(inputValue.toLowerCase())
    )
    .slice(0, 8);

  const addTag = (tag: string) => {
    const trimmedTag = tag.trim().toLowerCase();
    if (trimmedTag && !tags.includes(trimmedTag)) {
      onTagsChange([...tags, trimmedTag]);
    }
    setInputValue('');
    setShowSuggestions(false);
  };

  const removeTag = (tagToRemove: string) => {
    onTagsChange(tags.filter(tag => tag !== tagToRemove));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (inputValue.trim()) {
        addTag(inputValue.trim());
      }
    } else if (e.key === 'Backspace' && inputValue === '' && tags.length > 0) {
      removeTag(tags[tags.length - 1]);
    } else if (e.key === 'Escape') {
      setShowSuggestions(false);
    }
  };

  return (
    <div className="relative">
      {/* Tags Display */}
      <div className="flex flex-wrap gap-2 mb-2">
        {tags.map((tag) => (
          <span
            key={tag}
            className="inline-flex items-center px-2.5 py-1 rounded-full text-sm font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 border border-blue-200 dark:border-blue-800"
          >
            <Tag className="w-3 h-3 mr-1" />
            {tag}
            <button
              type="button"
              onClick={() => removeTag(tag)}
              className="ml-1.5 hover:text-blue-600 dark:hover:text-blue-400"
            >
              <X className="w-3 h-3" />
            </button>
          </span>
        ))}
      </div>

      {/* Input */}
      <div className="relative">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => {
            setInputValue(e.target.value);
            setShowSuggestions(true);
          }}
          onKeyDown={handleKeyDown}
          onFocus={() => setShowSuggestions(true)}
          placeholder={placeholder}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 pr-10"
        />
        <button
          type="button"
          onClick={() => {
            if (inputValue.trim()) {
              addTag(inputValue.trim());
            }
          }}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
        >
          <Plus className="w-4 h-4" />
        </button>

        {/* Suggestions Dropdown */}
        {showSuggestions && (inputValue || filteredSuggestions.length > 0) && (
          <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-lg max-h-48 overflow-y-auto">
            {inputValue && !suggestions.includes(inputValue.toLowerCase()) && (
              <button
                type="button"
                onClick={() => addTag(inputValue)}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 border-b border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center">
                  <Plus className="w-4 h-4 mr-2 text-green-500" />
                  <span className="text-gray-900 dark:text-gray-100">
                    Add "{inputValue}"
                  </span>
                </div>
              </button>
            )}
            
            {filteredSuggestions.map((suggestion) => (
              <button
                key={suggestion}
                type="button"
                onClick={() => addTag(suggestion)}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-900 dark:text-gray-100"
              >
                <div className="flex items-center">
                  <Tag className="w-4 h-4 mr-2 text-gray-400" />
                  {suggestion}
                </div>
              </button>
            ))}
            
            {filteredSuggestions.length === 0 && !inputValue && (
              <div className="px-3 py-2 text-gray-500 dark:text-gray-400 text-sm">
                Start typing to see suggestions
              </div>
            )}
          </div>
        )}
      </div>

      {/* Help Text */}
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
        Press Enter to add a tag, or click suggestions below
      </p>
    </div>
  );
}
