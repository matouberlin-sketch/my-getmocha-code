import { ReactNode } from 'react';

interface QuickActionProps {
  icon: ReactNode;
  title: string;
  description: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary';
}

export default function QuickAction({ 
  icon, 
  title, 
  description, 
  onClick,
  variant = 'secondary'
}: QuickActionProps) {
  const baseClasses = "flex items-center space-x-4 p-4 rounded-xl border transition-all cursor-pointer group";
  const variantClasses = variant === 'primary' 
    ? "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/30"
    : "bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700";

  return (
    <button 
      onClick={onClick}
      className={`${baseClasses} ${variantClasses} w-full text-left`}
    >
      <div className={`flex-shrink-0 p-2 rounded-lg ${variant === 'primary' ? 'bg-blue-100 dark:bg-blue-800' : 'bg-white dark:bg-gray-700'} group-hover:scale-105 transition-transform`}>
        <div className={variant === 'primary' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'}>
          {icon}
        </div>
      </div>
      
      <div className="flex-1 min-w-0">
        <h3 className="font-medium text-gray-900 dark:text-gray-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
          {title}
        </h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          {description}
        </p>
      </div>
    </button>
  );
}
