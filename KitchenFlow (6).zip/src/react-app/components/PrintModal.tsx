import { useState } from 'react';
import { Printer, FileText, List, Package, ClipboardList, X, CheckSquare } from 'lucide-react';

interface PrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipe: {
    id: number;
    name: string;
    yield_amount: number;
    yield_unit: string;
  };
}

type PrintFormat = 'recipe' | 'ingredients' | 'steps' | 'pull-list' | 'prep-list' | 'multiple' | 'all';

export default function PrintModal({ isOpen, onClose, recipe }: PrintModalProps) {
  const [selectedFormat, setSelectedFormat] = useState<PrintFormat>('recipe');
  const [selectedMultiple, setSelectedMultiple] = useState<PrintFormat[]>(['recipe']);
  const [scaleFactor, setScaleFactor] = useState(1);
  const [includeNotes, setIncludeNotes] = useState(true);
  const [includeWeights, setIncludeWeights] = useState(true);

  const printFormats = [
    {
      id: 'recipe' as PrintFormat,
      name: 'Complete Recipe',
      description: 'Full recipe with ingredients and instructions',
      icon: FileText,
    },
    {
      id: 'ingredients' as PrintFormat,
      name: 'Ingredients Only',
      description: 'Shopping/ingredient list format',
      icon: List,
    },
    {
      id: 'steps' as PrintFormat,
      name: 'Instructions Only',
      description: 'Step-by-step cooking instructions',
      icon: ClipboardList,
    },
    {
      id: 'pull-list' as PrintFormat,
      name: 'Pull List',
      description: 'Whole units grouped by storage location',
      icon: Package,
    },
    {
      id: 'prep-list' as PrintFormat,
      name: 'Prep List',
      description: 'Consolidated prep tasks and timings',
      icon: ClipboardList,
    },
    {
      id: 'multiple' as PrintFormat,
      name: 'Multiple Formats',
      description: 'Select multiple formats to print together',
      icon: CheckSquare,
    },
    {
      id: 'all' as PrintFormat,
      name: 'All Formats',
      description: 'Print all available formats in one document',
      icon: FileText,
    },
  ];

  const handlePrint = () => {
    // Determine which formats to print
    let formatsToPrint: string[] = [];
    
    if (selectedFormat === 'all') {
      formatsToPrint = ['recipe', 'ingredients', 'steps', 'pull-list', 'prep-list'];
    } else if (selectedFormat === 'multiple') {
      formatsToPrint = selectedMultiple.filter(f => f !== 'multiple' && f !== 'all');
    } else {
      formatsToPrint = [selectedFormat];
    }
    
    // Generate print-friendly content and open in new window
    const printContent = generatePrintContent(formatsToPrint);
    const printWindow = window.open('', '_blank', 'width=800,height=600');
    
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.focus();
      
      // Print after a short delay to ensure content is loaded
      setTimeout(() => {
        printWindow.print();
      }, 250);
    }
    
    onClose();
  };

  const generatePrintContent = (formats: string[]): string => {
    const recipeName = recipe.name;
    const yieldInfo = `${recipe.yield_amount} ${recipe.yield_unit}`;
    const scaleInfo = scaleFactor !== 1 ? ` (scaled ${scaleFactor}x)` : '';
    
    let content = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Print Recipe - ${recipeName}</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; }
          .recipe-header { border-bottom: 2px solid #333; margin-bottom: 20px; padding-bottom: 10px; }
          .recipe-title { font-size: 24px; font-weight: bold; margin: 0; }
          .recipe-yield { font-size: 14px; color: #666; margin-top: 5px; }
          .section { margin-bottom: 30px; page-break-inside: avoid; }
          .section-title { font-size: 18px; font-weight: bold; margin-bottom: 10px; border-bottom: 1px solid #ccc; }
          .ingredient-list { list-style: none; padding: 0; }
          .ingredient-item { margin-bottom: 5px; }
          .ingredient-weight { font-weight: bold; margin-right: 10px; }
          .step-list { padding-left: 20px; }
          .step-item { margin-bottom: 10px; }
          @media print {
            .page-break { page-break-before: always; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="recipe-header">
          <h1 class="recipe-title">${recipeName}</h1>
          <p class="recipe-yield">Yield: ${yieldInfo}${scaleInfo}</p>
        </div>
    `;
    
    // Add each requested format
    formats.forEach((format, index) => {
      if (index > 0) content += '<div class="page-break"></div>';
      
      content += `<div class="section">`;
      
      switch (format) {
        case 'recipe':
          content += `
            <h2 class="section-title">Complete Recipe</h2>
            <div style="display: flex; gap: 40px;">
              <div style="flex: 1;">
                <h3>Ingredients</h3>
                <ul class="ingredient-list">
                  ${generateIngredientsList()}
                </ul>
              </div>
              <div style="flex: 1;">
                <h3>Instructions</h3>
                <ol class="step-list">
                  ${generateInstructionsList()}
                </ol>
              </div>
            </div>
          `;
          break;
          
        case 'ingredients':
          content += `
            <h2 class="section-title">Ingredients List</h2>
            <ul class="ingredient-list">
              ${generateIngredientsList()}
            </ul>
          `;
          break;
          
        case 'steps':
          content += `
            <h2 class="section-title">Cooking Instructions</h2>
            <ol class="step-list">
              ${generateInstructionsList()}
            </ol>
          `;
          break;
          
        case 'pull-list':
          content += `
            <h2 class="section-title">Pull List (Ingredient Prep)</h2>
            <ul class="ingredient-list">
              ${generatePullList()}
            </ul>
          `;
          break;
          
        case 'prep-list':
          content += `
            <h2 class="section-title">Prep List (Tasks & Timing)</h2>
            <ul class="ingredient-list">
              ${generatePrepList()}
            </ul>
          `;
          break;
      }
      
      content += `</div>`;
    });
    
    content += `
        <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ccc; text-align: center; font-size: 12px; color: #666;">
          Generated by KitchenFlow on ${new Date().toLocaleDateString()}
        </div>
      </body>
      </html>
    `;
    
    return content;
  };

  const generateIngredientsList = (): string => {
    // This would normally come from the recipe data
    // For now, return placeholder content
    return `
      <li class="ingredient-item">
        <span class="ingredient-weight">500g</span>
        Flour, all-purpose
      </li>
      <li class="ingredient-item">
        <span class="ingredient-weight">250ml</span>
        Water
      </li>
      <li class="ingredient-item">
        <span class="ingredient-weight">15g</span>
        Salt
      </li>
    `;
  };

  const generateInstructionsList = (): string => {
    return `
      <li class="step-item">Combine flour and salt in a large mixing bowl.</li>
      <li class="step-item">Gradually add water while mixing to form a dough.</li>
      <li class="step-item">Knead dough for 8-10 minutes until smooth.</li>
      <li class="step-item">Let rest for 30 minutes before use.</li>
    `;
  };

  const generatePullList = (): string => {
    return `
      <li class="ingredient-item">
        <strong>Dry Storage:</strong> Flour (500g), Salt (15g)
      </li>
      <li class="ingredient-item">
        <strong>Cold Storage:</strong> None required
      </li>
      <li class="ingredient-item">
        <strong>Fresh:</strong> Water (250ml)
      </li>
    `;
  };

  const generatePrepList = (): string => {
    return `
      <li class="ingredient-item">
        <strong>Prep (15 min before):</strong> Measure dry ingredients
      </li>
      <li class="ingredient-item">
        <strong>Start (10 min):</strong> Mix and knead dough
      </li>
      <li class="ingredient-item">
        <strong>Rest (30 min):</strong> Let dough rest covered
      </li>
    `;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            Print Recipe
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="mb-4 p-3 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
          <h3 className="font-medium text-purple-900 dark:text-purple-100">
            {recipe.name}
          </h3>
          <p className="text-sm text-purple-700 dark:text-purple-300">
            Base yield: {recipe.yield_amount} {recipe.yield_unit}
          </p>
        </div>

        <div className="space-y-6">
          {/* Print Format Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Print Format
            </label>
            <div className="space-y-2">
              {printFormats.map((format) => {
                const Icon = format.icon;
                return (
                  <label
                    key={format.id}
                    className={`flex items-start p-3 border rounded-lg cursor-pointer transition-colors ${
                      selectedFormat === format.id
                        ? 'border-purple-300 bg-purple-50 dark:border-purple-600 dark:bg-purple-900/20'
                        : 'border-gray-200 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="format"
                      value={format.id}
                      checked={selectedFormat === format.id}
                      onChange={(e) => setSelectedFormat(e.target.value as PrintFormat)}
                      className="mt-1 mr-3"
                    />
                    <Icon className="w-5 h-5 text-gray-600 dark:text-gray-400 mr-3 mt-0.5" />
                    <div>
                      <div className="font-medium text-gray-900 dark:text-gray-100">
                        {format.name}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {format.description}
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>

            {/* Multiple Format Selection */}
            {selectedFormat === 'multiple' && (
              <div className="mt-4 p-3 border border-purple-200 dark:border-purple-600 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                <label className="block text-sm font-medium text-purple-900 dark:text-purple-100 mb-2">
                  Select formats to include:
                </label>
                <div className="space-y-2">
                  {printFormats.filter(f => f.id !== 'multiple' && f.id !== 'all').map((format) => (
                    <label key={format.id} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={selectedMultiple.includes(format.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedMultiple([...selectedMultiple, format.id]);
                          } else {
                            setSelectedMultiple(selectedMultiple.filter(f => f !== format.id));
                          }
                        }}
                        className="mr-2"
                      />
                      <span className="text-sm text-purple-800 dark:text-purple-200">
                        {format.name}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Scale Factor */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Scale Recipe (multiplier)
            </label>
            <input
              type="number"
              min="0.1"
              max="10"
              step="0.1"
              value={scaleFactor}
              onChange={(e) => setScaleFactor(parseFloat(e.target.value) || 1)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              New yield: {(recipe.yield_amount * scaleFactor).toFixed(1)} {recipe.yield_unit}
            </p>
          </div>

          {/* Options */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Print Options
            </label>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={includeWeights}
                  onChange={(e) => setIncludeWeights(e.target.checked)}
                  className="mr-2"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  Include ingredient weights (grams)
                </span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={includeNotes}
                  onChange={(e) => setIncludeNotes(e.target.checked)}
                  className="mr-2"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  Include recipe notes and prep instructions
                </span>
              </label>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-3 pt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print</span>
          </button>
        </div>
      </div>
    </div>
  );
}
