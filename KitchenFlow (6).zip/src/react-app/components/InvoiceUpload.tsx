import { useState } from 'react';
import { Upload, FileText, Loader2, CheckCircle, AlertCircle, X } from 'lucide-react';

interface ExtractedInvoiceData {
  supplier_name: string;
  invoice_date: string;
  total_amount_due: number;
  currency: string;
  line_items: Array<{
    product_name: string;
    quantity: number;
    unit: string;
    unit_price: number;
    line_item_total: number;
  }>;
}

interface InvoiceUploadProps {
  onComplete?: (invoiceId: number) => void;
}

export default function InvoiceUpload({ onComplete }: InvoiceUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState<ExtractedInvoiceData | null>(null);
  const [invoiceId, setInvoiceId] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [editableData, setEditableData] = useState<ExtractedInvoiceData | null>(null);
  const [confirming, setConfirming] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file (JPG, PNG, etc.)');
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      setError('File size must be less than 10MB');
      return;
    }

    setProcessing(true);
    setError('');

    try {
      // Convert file to base64
      const base64 = await fileToBase64(file);
      
      const response = await fetch('/api/invoices/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image_data: base64.split(',')[1], // Remove data:image/jpeg;base64, prefix
          filename: file.name,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to process invoice');
      }

      const result = await response.json();
      setExtractedData(result.extracted_data);
      setEditableData({ ...result.extracted_data });
      setInvoiceId(result.invoice_id);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process invoice');
    } finally {
      setProcessing(false);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleConfirm = async () => {
    if (!editableData || !invoiceId) return;

    setConfirming(true);
    try {
      const response = await fetch('/api/invoices/review', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          invoice_id: invoiceId,
          confirmed_data: editableData,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to confirm invoice');
      }

      onComplete?.(invoiceId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to confirm invoice');
    } finally {
      setConfirming(false);
    }
  };

  const updateLineItem = (index: number, field: string, value: any) => {
    if (!editableData) return;
    
    const newData = { ...editableData };
    (newData.line_items[index] as any)[field] = value;
    
    // Recalculate line item total when quantity or unit price changes
    if (field === 'quantity' || field === 'unit_price') {
      const item = newData.line_items[index];
      item.line_item_total = item.quantity * item.unit_price;
    }
    
    setEditableData(newData);
  };

  const addLineItem = () => {
    if (!editableData) return;
    
    const newData = { ...editableData };
    newData.line_items.push({
      product_name: '',
      quantity: 1,
      unit: 'each',
      unit_price: 0,
      line_item_total: 0,
    });
    setEditableData(newData);
  };

  const removeLineItem = (index: number) => {
    if (!editableData) return;
    
    const newData = { ...editableData };
    newData.line_items.splice(index, 1);
    setEditableData(newData);
  };

  const resetUpload = () => {
    setExtractedData(null);
    setEditableData(null);
    setInvoiceId(null);
    setError('');
    setProcessing(false);
    setConfirming(false);
  };

  return (
    <div className="max-w-4xl mx-auto">
      {!extractedData ? (
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8">
          <div className="text-center mb-6">
            <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">
              Upload Supplier Invoice
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Upload an image of your invoice and AI will extract the product information automatically
            </p>
          </div>

          {processing ? (
            <div className="text-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                Processing Invoice...
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                AI is reading your invoice and extracting product details. This may take a minute.
              </p>
            </div>
          ) : (
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                isDragging
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
                Drag and drop your invoice image here, or click to browse
              </p>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
                id="invoice-upload"
              />
              <label
                htmlFor="invoice-upload"
                className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg cursor-pointer transition-colors"
              >
                <Upload className="w-4 h-4 mr-2" />
                Choose Image
              </label>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                Supports JPG, PNG, WEBP up to 10MB
              </p>
            </div>
          )}

          {error && (
            <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <div className="flex items-start space-x-2">
                <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-red-800 dark:text-red-200 mb-1">
                    Invoice Processing Failed
                  </h3>
                  <p className="text-red-700 dark:text-red-300 text-sm">{error}</p>
                  {error.includes('quota exceeded') && (
                    <div className="mt-2 p-2 bg-red-100 dark:bg-red-800 rounded text-xs text-red-600 dark:text-red-300">
                      <strong>Tip:</strong> This feature uses OpenAI's API for invoice analysis. You can:
                      <ul className="mt-1 ml-4 list-disc">
                        <li>Check your <a href="https://platform.openai.com/usage" target="_blank" rel="noopener noreferrer" className="underline">OpenAI usage dashboard</a></li>
                        <li>Upgrade your OpenAI plan if needed</li>
                        <li>Try again after your quota resets</li>
                        <li>Use smaller or clearer images</li>
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Success Header */}
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
            <div className="flex items-center">
              <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 mr-2" />
              <div>
                <h3 className="text-green-800 dark:text-green-200 font-medium">Invoice Processed Successfully</h3>
                <p className="text-green-700 dark:text-green-300 text-sm">
                  Review the extracted data below and make any necessary corrections before confirming.
                </p>
              </div>
            </div>
          </div>

          {/* Invoice Details */}
          {editableData && (
            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Invoice Details</h3>
                <button
                  onClick={resetUpload}
                  className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Supplier Name
                  </label>
                  <input
                    type="text"
                    value={editableData.supplier_name}
                    onChange={(e) => setEditableData({ ...editableData, supplier_name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Invoice Date
                  </label>
                  <input
                    type="date"
                    value={editableData.invoice_date}
                    onChange={(e) => setEditableData({ ...editableData, invoice_date: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Total Amount
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={editableData.total_amount_due}
                    onChange={(e) => setEditableData({ ...editableData, total_amount_due: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Currency
                  </label>
                  <select
                    value={editableData.currency}
                    onChange={(e) => setEditableData({ ...editableData, currency: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  >
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                    <option value="GBP">GBP</option>
                    <option value="CAD">CAD</option>
                    <option value="AUD">AUD</option>
                  </select>
                </div>
              </div>

              {/* Line Items */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-md font-semibold text-gray-900 dark:text-gray-100">Line Items</h4>
                  <button
                    onClick={addLineItem}
                    className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 text-sm font-medium"
                  >
                    + Add Item
                  </button>
                </div>

                <div className="space-y-4">
                  {editableData.line_items.map((item, index) => (
                    <div key={index} className="grid grid-cols-1 md:grid-cols-6 gap-2 items-end p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div className="md:col-span-2">
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Product Name
                        </label>
                        <input
                          type="text"
                          value={item.product_name}
                          onChange={(e) => updateLineItem(index, 'product_name', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Quantity
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          value={item.quantity}
                          onChange={(e) => updateLineItem(index, 'quantity', parseFloat(e.target.value))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Unit
                        </label>
                        <input
                          type="text"
                          value={item.unit}
                          onChange={(e) => updateLineItem(index, 'unit', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Unit Price
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          value={item.unit_price}
                          onChange={(e) => updateLineItem(index, 'unit_price', parseFloat(e.target.value))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                        />
                      </div>
                      <div className="flex items-end space-x-2">
                        <div className="flex-1">
                          <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Total
                          </label>
                          <div className="px-3 py-2 bg-gray-100 dark:bg-gray-600 rounded-lg text-sm text-gray-900 dark:text-gray-100">
                            ${item.line_item_total.toFixed(2)}
                          </div>
                        </div>
                        <button
                          onClick={() => removeLineItem(index)}
                          className="p-2 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  onClick={resetUpload}
                  className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirm}
                  disabled={confirming}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors flex items-center space-x-2"
                >
                  {confirming ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      <span>Confirm & Process</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {error && (
            <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <div className="flex items-center">
                <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />
                <p className="text-red-700 dark:text-red-300">{error}</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
