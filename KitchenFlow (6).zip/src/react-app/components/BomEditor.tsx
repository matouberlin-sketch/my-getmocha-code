import { useState, useEffect } from 'react';
import { Plus, Trash2, Save } from 'lucide-react';

interface BomComponent {
  id?: number;
  component_type: 'item' | 'subrecipe';
  component_id: number;
  component_name?: string;
  gross_qty: number;
  uom: string;
  trim_loss_pct: number;
  cook_yield_pct: number;
  stage?: string;
  note?: string;
  sort_order: number;
}

interface BomEditorProps {
  recipeId: number;
  onSave: () => void;
  onCancel: () => void;
  className?: string;
}

interface ItemOption {
  id: number;
  name: string;
  item_type: string;
  base_uom: string;
}

interface RecipeOption {
  id: number;
  name: string;
  is_subrecipe: boolean;
}

const COMMON_UOMS = [
  'g', 'kg', 'ml', 'l', 'cup', 'tbsp', 'tsp', 'oz', 'lb',
  'ea', 'piece', 'clove', 'large', 'medium', 'small', 'whole',
  'can', 'bunch', 'head'
];

export default function BomEditor({ recipeId, onSave, onCancel, className = '' }: BomEditorProps) {
  const [components, setComponents] = useState<BomComponent[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Options states
  const [itemOptions, setItemOptions] = useState<ItemOption[]>([]);
  const [recipeOptions, setRecipeOptions] = useState<RecipeOption[]>([]);

  useEffect(() => {
    loadExistingBom();
    loadItemOptions();
    loadRecipeOptions();
  }, [recipeId]);

  const loadExistingBom = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/bom/recipes/${recipeId}/bom`);
      if (response.ok) {
        const data = await response.json();
        if (data.bom) {
          setComponents(data.bom.map((item: any, index: number) => ({
            id: item.id,
            component_type: item.component_type,
            component_id: item.component_id,
            component_name: item.component_name,
            gross_qty: item.gross_qty,
            uom: item.uom,
            trim_loss_pct: item.trim_loss_pct || 0,
            cook_yield_pct: item.cook_yield_pct || 100,
            stage: item.stage || '',
            note: item.note || '',
            sort_order: index + 1
          })));
        }
      }
    } catch (err) {
      console.warn('Could not load existing BOM:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadItemOptions = async () => {
    try {
      const response = await fetch('/api/items');
      if (response.ok) {
        const items = await response.json();
        setItemOptions(items);
      }
    } catch (err) {
      console.warn('Could not load items:', err);
    }
  };

  const loadRecipeOptions = async () => {
    try {
      const response = await fetch('/api/recipes');
      if (response.ok) {
        const recipes = await response.json();
        setRecipeOptions(recipes.filter((r: any) => r.is_subrecipe));
      }
    } catch (err) {
      console.warn('Could not load recipes:', err);
    }
  };

  const addComponent = () => {
    const newComponent: BomComponent = {
      component_type: 'item',
      component_id: 0,
      gross_qty: 1,
      uom: 'g',
      trim_loss_pct: 0,
      cook_yield_pct: 100,
      stage: '',
      note: '',
      sort_order: components.length + 1
    };
    setComponents([...components, newComponent]);
  };

  const updateComponent = (index: number, field: keyof BomComponent, value: any) => {
    const updatedComponents = [...components];
    updatedComponents[index] = { ...updatedComponents[index], [field]: value };
    
    // Auto-populate component name when ID changes
    if (field === 'component_id') {
      const component = updatedComponents[index];
      if (component.component_type === 'item') {
        const item = itemOptions.find(i => i.id === value);
        if (item) {
          updatedComponents[index].component_name = item.name;
          // Auto-set UoM to item's base UoM if available
          if (item.base_uom) {
            updatedComponents[index].uom = item.base_uom;
          }
        }
      } else if (component.component_type === 'subrecipe') {
        const recipe = recipeOptions.find(r => r.id === value);
        if (recipe) {
          updatedComponents[index].component_name = recipe.name;
          updatedComponents[index].uom = 'portion'; // Default for subrecipes
        }
      }
    }
    
    setComponents(updatedComponents);
  };

  const removeComponent = (index: number) => {
    const updatedComponents = components.filter((_, i) => i !== index);
    // Update sort orders
    updatedComponents.forEach((comp, i) => {
      comp.sort_order = i + 1;
    });
    setComponents(updatedComponents);
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);

      // Validate components
      const validComponents = components.filter(comp => 
        comp.component_id > 0 && comp.gross_qty > 0 && comp.uom.trim()
      );

      if (validComponents.length === 0) {
        throw new Error('Please add at least one valid component');
      }

      // Save each component
      for (const component of validComponents) {
        const response = await fetch(`/api/bom/recipes/${recipeId}/bom`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            component_type: component.component_type,
            component_id: component.component_id,
            gross_qty: component.gross_qty,
            uom: component.uom,
            trim_loss_pct: component.trim_loss_pct,
            cook_yield_pct: component.cook_yield_pct,
            stage: component.stage || undefined,
            note: component.note || undefined,
            sort_order: component.sort_order
          })
        });

        if (!response.ok) {
          throw new Error(`Failed to save component: ${response.statusText}`);
        }
      }

      onSave();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save BOM');
    } finally {
      setSaving(false);
    }
  };

  const filteredItems = itemOptions;
  const filteredRecipes = recipeOptions;

  if (loading) {
    return (
      <div className={`bg-white rounded-lg border p-6 ${className}`}>
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded mb-4 w-1/3"></div>
          <div className="space-y-4">
            {[1, 2].map(i => (
              <div key={i} className="h-20 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-lg border ${className}`}>
      {/* Header */}
      <div className="border-b p-4">
        <h3 className="text-lg font-semibold text-gray-900">Edit Bill of Materials</h3>
        <p className="text-sm text-gray-600">Add items and subrecipes with quantities and yields</p>
      </div>

      {/* Error */}
      {error && (
        <div className="border-b bg-red-50 p-4">
          <div className="text-red-700 text-sm">{error}</div>
        </div>
      )}

      {/* Components */}
      <div className="p-4 space-y-4">
        {components.map((component, index) => (
          <BomComponentEditor
            key={index}
            component={component}
            index={index}
            itemOptions={filteredItems}
            recipeOptions={filteredRecipes}
            onUpdate={updateComponent}
            onRemove={removeComponent}
          />
        ))}

        {/* Add Component Button */}
        <button
          onClick={addComponent}
          className="w-full p-4 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700 transition-colors flex items-center justify-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Component
        </button>
      </div>

      {/* Footer */}
      <div className="border-t p-4 flex justify-end space-x-3">
        <button
          onClick={onCancel}
          className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
          disabled={saving}
        >
          Cancel
        </button>
        <button
          onClick={handleSave}
          disabled={saving || components.length === 0}
          className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center"
        >
          {saving ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save BOM
            </>
          )}
        </button>
      </div>
    </div>
  );
}

interface BomComponentEditorProps {
  component: BomComponent;
  index: number;
  itemOptions: ItemOption[];
  recipeOptions: RecipeOption[];
  onUpdate: (index: number, field: keyof BomComponent, value: any) => void;
  onRemove: (index: number) => void;
}

function BomComponentEditor({
  component,
  index,
  itemOptions,
  recipeOptions,
  onUpdate,
  onRemove
}: BomComponentEditorProps) {
  const netQty = component.gross_qty * 
    (1 - component.trim_loss_pct / 100) * 
    (component.cook_yield_pct / 100);

  return (
    <div className="p-4 border rounded-lg bg-gray-50">
      <div className="grid grid-cols-12 gap-4 items-start">
        {/* Component Type */}
        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-700 mb-1">Type</label>
          <select
            value={component.component_type}
            onChange={(e) => onUpdate(index, 'component_type', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="item">Item</option>
            <option value="subrecipe">Subrecipe</option>
          </select>
        </div>

        {/* Component Selection */}
        <div className="col-span-4">
          <label className="block text-xs font-medium text-gray-700 mb-1">
            {component.component_type === 'item' ? 'Item' : 'Subrecipe'}
          </label>
          <select
            value={component.component_id}
            onChange={(e) => onUpdate(index, 'component_id', parseInt(e.target.value))}
            className="w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value={0}>Select {component.component_type}...</option>
            {component.component_type === 'item' 
              ? itemOptions.map(item => (
                  <option key={item.id} value={item.id}>
                    {item.name} ({item.item_type})
                  </option>
                ))
              : recipeOptions.map(recipe => (
                  <option key={recipe.id} value={recipe.id}>
                    {recipe.name}
                  </option>
                ))
            }
          </select>
        </div>

        {/* Quantity & UoM */}
        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-700 mb-1">Gross Qty</label>
          <input
            type="number"
            step="0.001"
            min="0"
            value={component.gross_qty}
            onChange={(e) => onUpdate(index, 'gross_qty', parseFloat(e.target.value) || 0)}
            className="w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="0"
          />
        </div>

        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-700 mb-1">UoM</label>
          <select
            value={component.uom}
            onChange={(e) => onUpdate(index, 'uom', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            {COMMON_UOMS.map(uom => (
              <option key={uom} value={uom}>{uom}</option>
            ))}
          </select>
        </div>

        {/* Loss % */}
        <div className="col-span-1">
          <label className="block text-xs font-medium text-gray-700 mb-1">Loss %</label>
          <input
            type="number"
            step="0.1"
            min="0"
            max="100"
            value={component.trim_loss_pct}
            onChange={(e) => onUpdate(index, 'trim_loss_pct', parseFloat(e.target.value) || 0)}
            className="w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="0"
          />
        </div>

        {/* Remove Button */}
        <div className="col-span-1 flex items-end">
          <button
            onClick={() => onRemove(index)}
            className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded transition-colors"
            title="Remove component"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Second Row */}
      <div className="grid grid-cols-12 gap-4 mt-3">
        {/* Yield % */}
        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-700 mb-1">Yield %</label>
          <input
            type="number"
            step="0.1"
            min="0"
            max="200"
            value={component.cook_yield_pct}
            onChange={(e) => onUpdate(index, 'cook_yield_pct', parseFloat(e.target.value) || 100)}
            className="w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="100"
          />
        </div>

        {/* Net Quantity Display */}
        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-700 mb-1">Net Qty</label>
          <div className="px-3 py-2 bg-gray-100 rounded-lg text-sm font-mono">
            {netQty.toFixed(3)}
          </div>
        </div>

        {/* Stage */}
        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-700 mb-1">Stage</label>
          <input
            type="text"
            value={component.stage || ''}
            onChange={(e) => onUpdate(index, 'stage', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Optional"
          />
        </div>

        {/* Note */}
        <div className="col-span-6">
          <label className="block text-xs font-medium text-gray-700 mb-1">Note</label>
          <input
            type="text"
            value={component.note || ''}
            onChange={(e) => onUpdate(index, 'note', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Optional notes"
          />
        </div>
      </div>
    </div>
  );
}
