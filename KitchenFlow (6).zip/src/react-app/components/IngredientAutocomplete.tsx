import { useState, useEffect, useRef } from 'react';
import { Search, Package, Layers, Plus, ChefHat } from 'lucide-react';

interface IngredientAutocompleteProps {
  value: string;
  onChange: (value: string, ingredientData?: any) => void;
  placeholder?: string;
  className?: string;
}

export default function IngredientAutocomplete({ 
  value, 
  onChange, 
  placeholder = "Search ingredients...",
  className = ""
}: IngredientAutocompleteProps) {
  const [query, setQuery] = useState(value);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [loading, setLoading] = useState(false);
  const [subRecipes, setSubRecipes] = useState<any[]>([]);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [isHoveringInput, setIsHoveringInput] = useState(false);
  const [isHoveringDropdown, setIsHoveringDropdown] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Fetch ingredients and sub-recipes when query changes
  useEffect(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    if (query.length < 2) {
      setSuggestions([]);
      setSubRecipes([]);
      setShowSuggestions(false);
      return;
    }

    timeoutRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        // Fetch ingredients
        const ingredientsResponse = await fetch(`/api/ingredients/search/${encodeURIComponent(query)}`);
        const ingredients = ingredientsResponse.ok ? await ingredientsResponse.json() : [];

        // Fetch sub-recipes
        const recipesResponse = await fetch('/api/recipes');
        const allRecipes = recipesResponse.ok ? await recipesResponse.json() : [];
        const subRecipeResults = allRecipes.filter((recipe: any) => 
          recipe.is_subrecipe && 
          recipe.name.toLowerCase().includes(query.toLowerCase())
        );

        setSuggestions(ingredients);
        setSubRecipes(subRecipeResults);
        // Only show suggestions if input is focused or being hovered
        if (isInputFocused || isHoveringInput) {
          setShowSuggestions(true);
        }
      } catch (error) {
        console.error('Failed to fetch suggestions:', error);
        setSuggestions([]);
        setSubRecipes([]);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [query, isInputFocused, isHoveringInput]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setQuery(newValue);
    onChange(newValue);
  };

  const handleSelect = (item: any, isSubRecipe = false) => {
    const name = item.name;
    setQuery(name);
    setShowSuggestions(false);
    
    // Pass additional data about the selected item
    onChange(name, {
      ...item,
      isSubRecipe,
      id: isSubRecipe ? item.id : item.id,
      unit_type: isSubRecipe ? 'piece' : item.unit_type,
      grams_per_piece: isSubRecipe ? null : item.grams_per_piece
    });
  };

  const handleFocus = () => {
    setIsInputFocused(true);
    if (query.length >= 2) {
      setShowSuggestions(true);
    }
  };

  const handleBlur = () => {
    setIsInputFocused(false);
    // Hide suggestions when not focused and not hovering
    setTimeout(() => {
      if (!isHoveringInput && !isHoveringDropdown) {
        setShowSuggestions(false);
      }
    }, 150);
  };

  const handleInputMouseEnter = () => {
    setIsHoveringInput(true);
    if (query.length >= 2) {
      setShowSuggestions(true);
    }
  };

  const handleInputMouseLeave = () => {
    setIsHoveringInput(false);
    // Hide suggestions when not focused and not hovering dropdown
    setTimeout(() => {
      if (!isInputFocused && !isHoveringDropdown) {
        setShowSuggestions(false);
      }
    }, 100);
  };

  const handleDropdownMouseEnter = () => {
    setIsHoveringDropdown(true);
  };

  const handleDropdownMouseLeave = () => {
    setIsHoveringDropdown(false);
    // Hide suggestions when not focused and not hovering input
    setTimeout(() => {
      if (!isInputFocused && !isHoveringInput) {
        setShowSuggestions(false);
      }
    }, 100);
  };

  const formatUnitType = (unitType: string) => {
    return unitType.charAt(0).toUpperCase() + unitType.slice(1);
  };

  return (
    <div className="relative" ref={containerRef}>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={handleInputChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onMouseEnter={handleInputMouseEnter}
          onMouseLeave={handleInputMouseLeave}
          placeholder={placeholder}
          className={`w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm ${className}`}
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        {loading && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
          </div>
        )}
      </div>

      {/* Suggestions Dropdown */}
      {showSuggestions && (suggestions.length > 0 || subRecipes.length > 0 || query.length >= 2) && (
        <div 
          className="absolute z-30 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-xl shadow-xl max-h-72 overflow-y-auto"
          onMouseEnter={handleDropdownMouseEnter}
          onMouseLeave={handleDropdownMouseLeave}
        >
          {/* Sub-recipes section */}
          {subRecipes.length > 0 && (
            <>
              <div className="px-3 py-2 text-xs font-medium text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-900/20 border-b border-purple-200 dark:border-purple-800">
                <div className="flex items-center space-x-2">
                  <Layers className="w-3 h-3" />
                  <span>Sub-Recipes</span>
                </div>
              </div>
              {subRecipes.map((subRecipe) => (
                <button
                  key={`sub-${subRecipe.id}`}
                  type="button"
                  onClick={() => handleSelect(subRecipe, true)}
                  className="w-full px-3 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700"
                >
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                      <Layers className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-gray-900 dark:text-gray-100 truncate">
                        {subRecipe.name}
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400 truncate">
                        Yields {subRecipe.yield_amount} {subRecipe.yield_unit}
                        {subRecipe.description && ` • ${subRecipe.description}`}
                      </div>
                    </div>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                      Sub-Recipe
                    </span>
                  </div>
                </button>
              ))}
            </>
          )}

          {/* Ingredients section */}
          {suggestions.length > 0 && (
            <>
              {subRecipes.length > 0 && (
                <div className="px-3 py-2 text-xs font-medium text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-900/20 border-b border-blue-200 dark:border-blue-800">
                  <div className="flex items-center space-x-2">
                    <Package className="w-3 h-3" />
                    <span>Ingredients</span>
                  </div>
                </div>
              )}
              {suggestions.map((ingredient) => (
                <button
                  key={`ing-${ingredient.id}`}
                  type="button"
                  onClick={() => handleSelect(ingredient, false)}
                  className="w-full px-3 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700"
                >
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                      <Package className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-gray-900 dark:text-gray-100 truncate">
                        {ingredient.name}
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        {formatUnitType(ingredient.unit_type)} unit
                        {ingredient.grams_per_piece && ` • ${ingredient.grams_per_piece}g per piece`}
                        {ingredient.supplier_count > 0 && ` • ${ingredient.supplier_count} suppliers`}
                      </div>
                    </div>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
                      {formatUnitType(ingredient.unit_type)}
                    </span>
                  </div>
                </button>
              ))}
            </>
          )}

          {/* Create new options */}
          {query.length >= 2 && !suggestions.find(s => s.name.toLowerCase() === query.toLowerCase()) && !subRecipes.find(s => s.name.toLowerCase() === query.toLowerCase()) && (
            <>
              <button
                type="button"
                onClick={() => {
                  setQuery(query);
                  setShowSuggestions(false);
                  onChange(query, { isNewIngredient: true });
                }}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 border-t border-gray-200 dark:border-gray-600"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                    <Plus className="w-4 h-4 text-green-600 dark:text-green-400" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-gray-900 dark:text-gray-100">
                      Create "{query}"
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Add as new ingredient
                    </div>
                  </div>
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                    Ingredient
                  </span>
                </div>
              </button>
              
              <button
                type="button"
                onClick={() => {
                  setQuery(query);
                  setShowSuggestions(false);
                  onChange(query, { isNewSubRecipe: true });
                }}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
                    <ChefHat className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-gray-900 dark:text-gray-100">
                      Create "{query}" as Sub-Recipe
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Create nested recipe component
                    </div>
                  </div>
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-200">
                    Sub-Recipe
                  </span>
                </div>
              </button>
            </>
          )}

          {/* No results */}
          {!loading && suggestions.length === 0 && subRecipes.length === 0 && query.length >= 2 && (
            <div className="px-3 py-4 text-center text-gray-500 dark:text-gray-400 text-sm">
              <Package className="w-8 h-8 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
              <p>No ingredients or sub-recipes found</p>
              <p className="text-xs mt-1">Try a different search term</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
