import { useState, useEffect } from 'react';
import { Users, X, Search, Plus, Trash2 } from 'lucide-react';

interface Recipe {
  id: number;
  name: string;
  description?: string;
  yield_amount: number;
  yield_unit: string;
  prep_time_minutes?: number;
  hands_on_minutes?: number;
  station?: string;
  is_subrecipe: boolean;
}

interface MealComponent {
  component_type: 'main' | 'side' | 'dessert';
  component_order: number;
  recipe_id: number;
  recipe_name?: string;
  portion_count: number;
  notes?: string;
}

interface EnhancedMealPlanningModalProps {
  isOpen: boolean;
  onClose: () => void;
  date: string;
  mealType: 'lunch' | 'dinner';
  onSuccess: () => void;
}

export default function EnhancedMealPlanningModal({ isOpen, onClose, date, mealType, onSuccess }: EnhancedMealPlanningModalProps) {
  const [shortlistedRecipes, setShortlistedRecipes] = useState<Recipe[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Meal components state
  const [components, setComponents] = useState<MealComponent[]>([
    { component_type: 'main', component_order: 1, recipe_id: 0, portion_count: 0 }
  ]);

  // Portion planning state
  const [sameMenuBothServices, setSameMenuBothServices] = useState(true);
  const [totalPortions, setTotalPortions] = useState(50);
  const [vegetarianPortions, setVegetarianPortions] = useState(3);
  
  // Separate service portions
  const [lunchPortions, setLunchPortions] = useState(25);
  const [lunchVegetarian, setLunchVegetarian] = useState(2);
  const [dinnerPortions, setDinnerPortions] = useState(25);
  const [dinnerVegetarian, setDinnerVegetarian] = useState(1);

  // Recipe selection modal state
  const [showRecipeSelector, setShowRecipeSelector] = useState(false);
  const [selectedComponentIndex, setSelectedComponentIndex] = useState<number | null>(null);

  // Fetch shortlisted recipes
  useEffect(() => {
    if (isOpen) {
      fetchShortlistedRecipes();
    }
  }, [isOpen]);

  const fetchShortlistedRecipes = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/recipe-shortlist');
      if (response.ok) {
        const data = await response.json();
        const recipes = data.map((item: any) => ({
          id: item.recipe_id || item.id,
          name: item.name,
          description: item.description,
          yield_amount: item.yield_amount,
          yield_unit: item.yield_unit,
          prep_time_minutes: item.prep_time_minutes,
          hands_on_minutes: item.hands_on_minutes,
          station: item.station,
          is_subrecipe: item.is_subrecipe
        }));
        setShortlistedRecipes(recipes);
      }
    } catch (error) {
      console.error('Failed to fetch shortlisted recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredRecipes = shortlistedRecipes.filter(recipe =>
    recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    recipe.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatTime = (minutes: number | undefined) => {
    if (!minutes) return '0m';
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}h${mins > 0 ? ` ${mins}m` : ''}`;
    }
    return `${minutes}m`;
  };

  const addComponent = (type: 'main' | 'side' | 'dessert') => {
    const newOrder = Math.max(...components.filter(c => c.component_type === type).map(c => c.component_order), 0) + 1;
    const newComponent: MealComponent = {
      component_type: type,
      component_order: newOrder,
      recipe_id: 0,
      portion_count: sameMenuBothServices ? totalPortions : (mealType === 'lunch' ? lunchPortions : dinnerPortions)
    };
    setComponents([...components, newComponent]);
  };

  const removeComponent = (index: number) => {
    if (components.length > 1) {
      setComponents(components.filter((_, i) => i !== index));
    }
  };

  const updateComponent = (index: number, updates: Partial<MealComponent>) => {
    const updated = [...components];
    updated[index] = { ...updated[index], ...updates };
    setComponents(updated);
  };

  const selectRecipeForComponent = (index: number) => {
    setSelectedComponentIndex(index);
    setShowRecipeSelector(true);
  };

  const assignRecipeToComponent = (recipe: Recipe) => {
    if (selectedComponentIndex !== null) {
      updateComponent(selectedComponentIndex, {
        recipe_id: recipe.id,
        recipe_name: recipe.name,
        portion_count: sameMenuBothServices ? totalPortions : (mealType === 'lunch' ? lunchPortions : dinnerPortions)
      });
      setShowRecipeSelector(false);
      setSelectedComponentIndex(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate that all components have recipes selected
    const invalidComponents = components.filter(c => !c.recipe_id || c.recipe_id === 0);
    if (invalidComponents.length > 0) {
      alert('Please select recipes for all meal components before planning.');
      return;
    }

    setSaving(true);
    try {
      const mealData = {
        date,
        meal_type: mealType,
        total_portions: sameMenuBothServices ? totalPortions : lunchPortions + dinnerPortions,
        vegetarian_portions: sameMenuBothServices ? vegetarianPortions : (mealType === 'lunch' ? lunchVegetarian : dinnerVegetarian),
        same_menu_both_services: sameMenuBothServices,
        lunch_portions: lunchPortions,
        lunch_vegetarian: lunchVegetarian,
        dinner_portions: dinnerPortions,
        dinner_vegetarian: dinnerVegetarian,
        service_time: mealType === 'lunch' ? '12:30' : '16:00',
        components: components.map(component => ({
          component_type: component.component_type,
          component_order: component.component_order,
          recipe_id: component.recipe_id,
          portion_count: component.portion_count,
          notes: component.notes || null
        }))
      };

      // Check for existing meals
      const existingMealResponse = await fetch(`/api/planned-meals/date/${date}`);
      let existingMeal = null;
      
      if (existingMealResponse.ok) {
        const existingMeals = await existingMealResponse.json();
        existingMeal = existingMeals.find((meal: any) => meal.meal_type === mealType);
      }

      if (existingMeal) {
        const userConfirmed = confirm(
          `A ${mealType} is already planned for ${new Date(date).toLocaleDateString()}. Would you like to replace it?`
        );
        
        if (!userConfirmed) {
          setSaving(false);
          return;
        }

        // Delete existing meal first
        await fetch(`/api/planned-meals/${existingMeal.id}`, { method: 'DELETE' });
      }

      // Create new meal
      const response = await fetch('/api/planned-meals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mealData),
      });

      if (response.ok) {
        onSuccess();
        onClose();
        resetForm();
      } else {
        const error = await response.json();
        console.error('Failed to plan meal:', error);
        alert(`Failed to plan meal: ${error.error || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error planning meal:', error);
      alert('Failed to plan meal. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setComponents([{ component_type: 'main', component_order: 1, recipe_id: 0, portion_count: 0 }]);
    setSearchTerm('');
    setSameMenuBothServices(true);
    setTotalPortions(50);
    setVegetarianPortions(3);
    setLunchPortions(25);
    setLunchVegetarian(2);
    setDinnerPortions(25);
    setDinnerVegetarian(1);
  };

  const getComponentTypeColor = (type: 'main' | 'side' | 'dessert') => {
    switch (type) {
      case 'main': return 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200';
      case 'side': return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
      case 'dessert': return 'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            Plan {mealType.charAt(0).toUpperCase() + mealType.slice(1)} - {new Date(date).toLocaleDateString()}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="flex h-[calc(90vh-120px)]">
          {/* Recipe Selector Modal */}
          {showRecipeSelector && (
            <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center z-10">
              <div className="bg-white dark:bg-gray-800 rounded-xl max-w-md w-full max-h-[80vh] overflow-hidden m-4">
                <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                    Select Recipe
                  </h3>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <input
                      type="text"
                      placeholder="Search recipes..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                </div>
                <div className="p-4 max-h-96 overflow-y-auto">
                  {loading ? (
                    <div className="flex items-center justify-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {filteredRecipes.map((recipe) => (
                        <button
                          key={recipe.id}
                          onClick={() => assignRecipeToComponent(recipe)}
                          className="w-full p-3 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                        >
                          <div className="font-medium text-gray-900 dark:text-gray-100">{recipe.name}</div>
                          {recipe.description && (
                            <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">{recipe.description}</div>
                          )}
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            {recipe.yield_amount} {recipe.yield_unit} • {formatTime(recipe.prep_time_minutes)}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                  <button
                    onClick={() => setShowRecipeSelector(false)}
                    className="w-full px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Meal Components Planning */}
          <div className="flex-1 p-6 overflow-y-auto">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Meal Components
            </h3>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Menu Configuration */}
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={sameMenuBothServices}
                    onChange={(e) => setSameMenuBothServices(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                  />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Same menu for both lunch (12:30) and dinner (16:00)
                  </span>
                </label>
              </div>

              {/* Components List */}
              <div className="space-y-4">
                {components.map((component, index) => (
                  <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getComponentTypeColor(component.component_type)}`}>
                          {component.component_type.charAt(0).toUpperCase() + component.component_type.slice(1)}
                          {component.component_type !== 'main' && ` ${component.component_order}`}
                        </span>
                        <select
                          value={component.component_type}
                          onChange={(e) => updateComponent(index, { component_type: e.target.value as 'main' | 'side' | 'dessert' })}
                          className="px-2 py-1 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                        >
                          <option value="main">Main</option>
                          <option value="side">Side</option>
                          <option value="dessert">Dessert</option>
                        </select>
                      </div>
                      {components.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeComponent(index)}
                          className="p-1 text-red-600 hover:text-red-800 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Recipe
                        </label>
                        <button
                          type="button"
                          onClick={() => selectRecipeForComponent(index)}
                          className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg text-left hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                        >
                          {component.recipe_name ? (
                            <div>
                              <div className="font-medium text-gray-900 dark:text-gray-100">{component.recipe_name}</div>
                              <div className="text-sm text-gray-500 dark:text-gray-400">Click to change recipe</div>
                            </div>
                          ) : (
                            <div className="text-gray-500 dark:text-gray-400">Click to select recipe</div>
                          )}
                        </button>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Portions
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={component.portion_count || ''}
                          onChange={(e) => updateComponent(index, { portion_count: parseInt(e.target.value) || 0 })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                        />
                      </div>
                    </div>

                    <div className="mt-3">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Notes (Optional)
                      </label>
                      <input
                        type="text"
                        value={component.notes || ''}
                        onChange={(e) => updateComponent(index, { notes: e.target.value })}
                        placeholder="Special preparation notes..."
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      />
                    </div>
                  </div>
                ))}

                {/* Add Component Buttons */}
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() => addComponent('side')}
                    className="flex items-center space-x-2 px-3 py-2 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-lg hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Side</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => addComponent('dessert')}
                    className="flex items-center space-x-2 px-3 py-2 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200 rounded-lg hover:bg-purple-200 dark:hover:bg-purple-800 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Dessert</span>
                  </button>
                </div>
              </div>

              {/* Portion Planning */}
              {sameMenuBothServices ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      <Users className="w-4 h-4 inline mr-2" />
                      Total People
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={totalPortions}
                      onChange={(e) => {
                        const newTotal = parseInt(e.target.value) || 0;
                        setTotalPortions(newTotal);
                        // Update all component portions
                        setComponents(components.map(c => ({ ...c, portion_count: newTotal })));
                      }}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Vegetarians
                    </label>
                    <input
                      type="number"
                      min="0"
                      max={totalPortions}
                      value={vegetarianPortions}
                      onChange={(e) => setVegetarianPortions(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                    <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">Lunch Service (12:30)</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">People</label>
                        <input
                          type="number"
                          min="0"
                          value={lunchPortions}
                          onChange={(e) => setLunchPortions(parseInt(e.target.value) || 0)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Vegetarians</label>
                        <input
                          type="number"
                          min="0"
                          max={lunchPortions}
                          value={lunchVegetarian}
                          onChange={(e) => setLunchVegetarian(parseInt(e.target.value) || 0)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                    <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">Dinner Service (16:00)</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">People</label>
                        <input
                          type="number"
                          min="0"
                          value={dinnerPortions}
                          onChange={(e) => setDinnerPortions(parseInt(e.target.value) || 0)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Vegetarians</label>
                        <input
                          type="number"
                          min="0"
                          max={dinnerPortions}
                          value={dinnerVegetarian}
                          onChange={(e) => setDinnerVegetarian(parseInt(e.target.value) || 0)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      <strong>Total: {lunchPortions + dinnerPortions} people</strong>
                      <br />
                      Vegetarians: {lunchVegetarian + dinnerVegetarian}
                    </div>
                  </div>
                </div>
              )}

              {/* Submit Buttons */}
              <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving || components.some(c => !c.recipe_id)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors"
                >
                  {saving ? 'Planning...' : 'Plan Meal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
