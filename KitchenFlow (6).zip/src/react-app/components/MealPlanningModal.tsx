import { useState, useEffect } from 'react';
import { Calendar, Users, X, Clock, ChefHat, Search, Check } from 'lucide-react';

interface Recipe {
  id: number;
  name: string;
  description?: string;
  yield_amount: number;
  yield_unit: string;
  prep_time_minutes?: number;
  hands_on_minutes?: number;
  station?: string;
  is_subrecipe: boolean;
}

interface MealPlanningModalProps {
  isOpen: boolean;
  onClose: () => void;
  date: string;
  mealType: 'lunch' | 'dinner';
  onSuccess: () => void;
}

export default function MealPlanningModal({ isOpen, onClose, date, mealType, onSuccess }: MealPlanningModalProps) {
  const [shortlistedRecipes, setShortlistedRecipes] = useState<Recipe[]>([]);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Portion planning state
  const [sameMenuBothServices, setSameMenuBothServices] = useState(false);
  const [totalPortions, setTotalPortions] = useState(50);
  const [vegetarianPortions, setVegetarianPortions] = useState(3);
  
  // Separate service portions
  const [lunchPortions, setLunchPortions] = useState(25);
  const [lunchVegetarian, setLunchVegetarian] = useState(2);
  const [dinnerPortions, setDinnerPortions] = useState(25);
  const [dinnerVegetarian, setDinnerVegetarian] = useState(1);

  // Fetch shortlisted recipes
  useEffect(() => {
    if (isOpen) {
      fetchShortlistedRecipes();
    }
  }, [isOpen]);

  const fetchShortlistedRecipes = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/recipe-shortlist');
      if (response.ok) {
        const data = await response.json();
        console.log('Shortlisted recipes received:', data);
        // Map the data to ensure we're using the correct recipe IDs
        const recipes = data.map((item: any) => ({
          id: item.recipe_id || item.id, // Use recipe_id if available, fallback to id
          name: item.name,
          description: item.description,
          yield_amount: item.yield_amount,
          yield_unit: item.yield_unit,
          prep_time_minutes: item.prep_time_minutes,
          hands_on_minutes: item.hands_on_minutes,
          station: item.station,
          is_subrecipe: item.is_subrecipe
        }));
        console.log('Mapped recipes:', recipes);
        setShortlistedRecipes(recipes);
      }
    } catch (error) {
      console.error('Failed to fetch shortlisted recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredRecipes = shortlistedRecipes.filter(recipe =>
    recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    recipe.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatTime = (minutes: number | undefined) => {
    if (!minutes) return '0m';
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}h${mins > 0 ? ` ${mins}m` : ''}`;
    }
    return `${minutes}m`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecipe) return;

    setSaving(true);
    try {
      const mealData = {
        date,
        meal_type: mealType,
        recipe_id: selectedRecipe.id,
        portion_count: sameMenuBothServices ? totalPortions : (mealType === 'lunch' ? lunchPortions : dinnerPortions),
        total_portions: sameMenuBothServices ? totalPortions : lunchPortions + dinnerPortions,
        vegetarian_portions: sameMenuBothServices ? vegetarianPortions : (mealType === 'lunch' ? lunchVegetarian : dinnerVegetarian),
        same_menu_both_services: sameMenuBothServices,
        lunch_portions: lunchPortions,
        lunch_vegetarian: lunchVegetarian,
        dinner_portions: dinnerPortions,
        dinner_vegetarian: dinnerVegetarian,
        service_time: mealType === 'lunch' ? '12:30' : '16:00'
      };

      // First check if there's already a meal planned for this date and meal type
      const existingMealResponse = await fetch(`/api/planned-meals/date/${date}`);
      let existingMeal = null;
      
      if (existingMealResponse.ok) {
        const existingMeals = await existingMealResponse.json();
        existingMeal = existingMeals.find((meal: any) => meal.meal_type === mealType);
      }

      let response;
      if (existingMeal) {
        // Update existing meal
        const userConfirmed = confirm(
          `A ${mealType} is already planned for ${new Date(date).toLocaleDateString()} (${existingMeal.recipe_name}). Would you like to replace it with ${selectedRecipe.name}?`
        );
        
        if (!userConfirmed) {
          setSaving(false);
          return;
        }

        response = await fetch(`/api/planned-meals/${existingMeal.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(mealData),
        });
      } else {
        // Create new meal
        response = await fetch('/api/planned-meals', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(mealData),
        });
      }

      if (response.ok) {
        onSuccess();
        onClose();
        resetForm();
      } else {
        const error = await response.json();
        console.error('Failed to plan meal:', error);
        console.error('Response status:', response.status);
        console.error('Meal data sent:', mealData);
        console.error('Selected recipe:', selectedRecipe);
        
        // More specific error messages
        let errorMessage = 'Unknown error occurred';
        if (error.error) {
          errorMessage = error.error;
        } else if (error.details) {
          errorMessage = error.details;
        }
        
        // Better error message for duplicate meals
        if (errorMessage.includes('already planned')) {
          errorMessage = `A ${mealType} is already planned for ${new Date(date).toLocaleDateString()}. Please choose a different date or meal type, or edit the existing meal.`;
        }
        
        // Add debugging info for recipe not found errors
        if (errorMessage.includes('Recipe') && errorMessage.includes('not found')) {
          errorMessage += `\n\nDebug info:\n- Recipe ID: ${selectedRecipe?.id}\n- Recipe Name: ${selectedRecipe?.name}`;
        }
        
        alert(`Failed to plan meal: ${errorMessage}`);
      }
    } catch (error) {
      console.error('Error planning meal:', error);
      console.error('Selected recipe:', selectedRecipe);
      console.error('Form data:', {
        date,
        mealType,
        sameMenuBothServices,
        totalPortions,
        vegetarianPortions,
        lunchPortions,
        lunchVegetarian,
        dinnerPortions,
        dinnerVegetarian
      });
      
      const errorMessage = error instanceof Error ? error.message : 'Network error occurred';
      alert(`Failed to plan meal: ${errorMessage}`);
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setSelectedRecipe(null);
    setSearchTerm('');
    setSameMenuBothServices(false);
    setTotalPortions(50);
    setVegetarianPortions(3);
    setLunchPortions(25);
    setLunchVegetarian(2);
    setDinnerPortions(25);
    setDinnerVegetarian(1);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            Plan {mealType.charAt(0).toUpperCase() + mealType.slice(1)} - {new Date(date).toLocaleDateString()}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="flex h-[calc(90vh-120px)]">
          {/* Recipe Selection */}
          <div className="flex-1 p-6 border-r border-gray-200 dark:border-gray-700 overflow-y-auto">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Select Recipe from Quick List
            </h3>

            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search recipes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>

            {/* Recipe List */}
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : filteredRecipes.length === 0 ? (
              <div className="text-center py-8">
                <ChefHat className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 dark:text-gray-400">
                  {searchTerm ? 'No recipes match your search' : 'No recipes in Quick List'}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                  Add recipes to your Quick List from the Recipe Library
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredRecipes.map((recipe) => (
                  <div
                    key={recipe.id}
                    onClick={() => setSelectedRecipe(recipe)}
                    className={`p-4 border rounded-lg cursor-pointer transition-all ${
                      selectedRecipe?.id === recipe.id
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium text-gray-900 dark:text-gray-100">
                            {recipe.name}
                          </h4>
                          {selectedRecipe?.id === recipe.id && (
                            <Check className="w-4 h-4 text-blue-600" />
                          )}
                          {recipe.is_subrecipe && (
                            <span className="px-1.5 py-0.5 text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200 rounded">
                              SUB
                            </span>
                          )}
                        </div>
                        {recipe.description && (
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {recipe.description}
                          </p>
                        )}
                        <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500 dark:text-gray-400">
                          <div className="flex items-center space-x-1">
                            <Users className="w-3 h-3" />
                            <span>{recipe.yield_amount} {recipe.yield_unit}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>{formatTime(recipe.prep_time_minutes)}</span>
                          </div>
                          {recipe.station && (
                            <div className="flex items-center space-x-1">
                              <ChefHat className="w-3 h-3" />
                              <span>{recipe.station}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Portion Planning */}
          <div className="w-1/2 p-6 overflow-y-auto">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
              Portion Planning
            </h3>

            {selectedRecipe ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Selected Recipe Info */}
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                  <h4 className="font-medium text-blue-900 dark:text-blue-100">
                    {selectedRecipe.name}
                  </h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    Base yield: {selectedRecipe.yield_amount} {selectedRecipe.yield_unit}
                  </p>
                </div>

                {/* Menu Configuration */}
                <div>
                  <label className="flex items-center space-x-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sameMenuBothServices}
                      onChange={(e) => setSameMenuBothServices(e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Same menu for both lunch (12:30) and dinner (16:00)
                    </span>
                  </label>
                </div>

                {sameMenuBothServices ? (
                  /* Single Menu Configuration */
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        <Users className="w-4 h-4 inline mr-2" />
                        Total People
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={totalPortions}
                        onChange={(e) => setTotalPortions(parseInt(e.target.value) || 0)}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Vegetarians
                      </label>
                      <input
                        type="number"
                        min="0"
                        max={totalPortions}
                        value={vegetarianPortions}
                        onChange={(e) => setVegetarianPortions(parseInt(e.target.value) || 0)}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      />
                    </div>
                  </div>
                ) : (
                  /* Separate Service Configuration */
                  <div className="space-y-6">
                    {/* Lunch Service */}
                    <div className="p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                      <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">
                        Lunch Service (12:30)
                      </h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            People
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={lunchPortions}
                            onChange={(e) => setLunchPortions(parseInt(e.target.value) || 0)}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Vegetarians
                          </label>
                          <input
                            type="number"
                            min="0"
                            max={lunchPortions}
                            value={lunchVegetarian}
                            onChange={(e) => setLunchVegetarian(parseInt(e.target.value) || 0)}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Dinner Service */}
                    <div className="p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                      <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">
                        Dinner Service (16:00)
                      </h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            People
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={dinnerPortions}
                            onChange={(e) => setDinnerPortions(parseInt(e.target.value) || 0)}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Vegetarians
                          </label>
                          <input
                            type="number"
                            min="0"
                            max={dinnerPortions}
                            value={dinnerVegetarian}
                            onChange={(e) => setDinnerVegetarian(parseInt(e.target.value) || 0)}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Total Summary */}
                    <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        <strong>Total: {lunchPortions + dinnerPortions} people</strong>
                        <br />
                        Vegetarians: {lunchVegetarian + dinnerVegetarian}
                      </div>
                    </div>
                  </div>
                )}

                {/* Submit Buttons */}
                <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors"
                  >
                    {saving ? 'Planning...' : 'Plan Meal'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 dark:text-gray-400">
                  Select a recipe to configure portions
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
