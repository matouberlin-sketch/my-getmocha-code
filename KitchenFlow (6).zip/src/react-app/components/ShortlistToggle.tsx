import { useState, useEffect } from 'react';

interface ShortlistToggleProps {
  recipeId: number;
  size?: 'sm' | 'md';
}

export default function ShortlistToggle({ recipeId, size = 'md' }: ShortlistToggleProps) {
  const [isInShortlist, setIsInShortlist] = useState(false);
  const [loading, setLoading] = useState(false);

  // Check if recipe is in shortlist
  useEffect(() => {
    const checkShortlist = async () => {
      try {
        const response = await fetch(`/api/recipe-shortlist/${recipeId}`);
        if (response.ok) {
          const data = await response.json();
          setIsInShortlist(data.isInShortlist);
        }
      } catch (error) {
        console.error('Failed to check shortlist status:', error);
      }
    };

    checkShortlist();
  }, [recipeId]);

  const toggleShortlist = async () => {
    setLoading(true);
    try {
      if (isInShortlist) {
        const response = await fetch(`/api/recipe-shortlist/${recipeId}`, {
          method: 'DELETE'
        });
        if (response.ok) {
          setIsInShortlist(false);
        }
      } else {
        const response = await fetch(`/api/recipe-shortlist`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ recipe_id: recipeId })
        });
        if (response.ok) {
          setIsInShortlist(true);
        }
      }
    } catch (error) {
      console.error('Failed to toggle shortlist:', error);
    } finally {
      setLoading(false);
    }
  };

  const buttonSize = size === 'sm' ? 'w-6 h-6 text-sm' : 'w-8 h-8 text-base';

  return (
    <button
      onClick={toggleShortlist}
      disabled={loading}
      className={`${buttonSize} flex items-center justify-center rounded-full transition-colors ${
        isInShortlist
          ? 'text-yellow-500 hover:text-yellow-600'
          : 'text-gray-400 hover:text-yellow-500'
      } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
      title={isInShortlist ? 'Remove from shortlist' : 'Add to shortlist'}
    >
      {isInShortlist ? '⭐' : '☆'}
    </button>
  );
}
